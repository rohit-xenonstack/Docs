package config

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"runtime"

	"github.com/sirupsen/logrus"
)

// Log is the global logger instance
var Log *logrus.Logger

// InitLogger initializes the global logger with appropriate settings
func InitLogger() {
	// Create a new logger instance
	Log = logrus.New()

	// Enable reporting the calling method and line number
	Log.SetReportCaller(true)

	// Set default formatter with caller info
	Log.SetFormatter(&logrus.JSONFormatter{
		CallerPrettyfier: func(f *runtime.Frame) (string, string) {
			// Customize function name and file line
			return "", fmt.Sprintf("%s:%d", filepath.Base(f.File), f.Line)
		},
	})

	// Set default output
	Log.SetOutput(os.Stdout)

	// Set default level from environment variable
	logLevel := os.Getenv("LOG_LEVEL")
	if logLevel == "" {
		logLevel = "info"
	}

	log.Println("Log level set to:", logLevel)

	level, err := logrus.ParseLevel(logLevel)
	if err != nil {
		level = logrus.InfoLevel
	}
	Log.SetLevel(level)
}

// SetLoggerOutput sets the output destination for the logger
func SetLoggerOutput(output io.Writer) {
	Log.SetOutput(output)
}

// SetLoggerLevel sets the logging level
func SetLoggerLevel(level logrus.Level) {
	Log.SetLevel(level)
}

// SetLoggerFormatter sets the formatter for the logger
func SetLoggerFormatter(formatter logrus.Formatter) {
	Log.SetFormatter(formatter)
}
