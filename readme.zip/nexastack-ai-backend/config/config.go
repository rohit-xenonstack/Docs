package config

import (
	"fmt"
	"os"
	"time"

	"github.com/go-redis/redis"

	"github.com/BurntSushi/toml"
	"github.com/jinzhu/gorm"
)

// Config is a structure for configuration
type Config struct {
	Database  Database
	Redis     Redis
	Service   Service
	Address   Address
	Admin     Admin
	Mail      Mail
	Vault     Vault
	JWT       JWT
	Kube      KUBE
	ChartHelm ChartHelm
	Minio     Minio
	// Bitbucket        Bitbucket
	MinioJupyterHelm MinioJupyterHelm
	MinioModelHelm   MinioModelHelm
	ModelDownload    ModelDownload
	// Values          Values
	// SingleUser      SingleUser
}

// Address is a structure that contains different-2 service addresses
type Address struct {
	Deployment      string
	FrontEndAddress string
	HostAddress     string
	Integration     string
}

// ChartHelm is stucture for Chartz address and Helm Driver
type ChartHelm struct {
	Address    string
	HelmDriver string
	Token      string
}

// Vault is structure for saving vault configuration
type Vault struct {
	Address string
	Token   string
}

type NodeConfigFiles struct {
	Address string
	Token   string
}

// JWT is structure for jwt token specific configuration
type JWT struct {
	PrivateKey    string
	JWTExpireTime time.Duration
}

// Database is a structure for postgres database configuration
type Database struct {
	Name  string
	Host  string
	Port  string
	User  string
	Pass  string
	Ssl   string
	Ideal string
}

// Redis is a structure for redis database configuration
type Redis struct {
	Database string
	Host     string
	Port     string
	Pass     string
	Client   *redis.Client
}

// Service is a structure for service specific related configuration
type Service struct {
	Port              string
	Environment       string
	Build             string
	Branch            string
	Mails             string
	IsLogoutOthers    string
	MailService       bool
	FixOTP            bool
	VerifyLinkTimeout int64
	Infrastucture     string
	InviteLinkTimeout int64
	Workspaces        string
	WSServices        string
	GitlabSecret      string
	IsNSCreate        bool
	IsNSDelete        bool
	Projects          string
}

// Admin is a structure for admin account credentials
type Admin struct {
	Email string
	Pass  string
}

// KUBE structure for Kube-config
type KUBE struct {
	KubeServer        *string
	CertAuthData      *string
	ClientCertificate *string
	ClientKey         *string
	Namespace         *string
	Token             *string
}

// Mail is a structure for mail service configuration
type Mail struct {
	Host string
	Port string
	From string
	User string
	Pass string
}

// Minio is a structure for minio configurations
type Minio struct {
	Endpoint  string
	AccessKey string
	SecretKey string
}

type MinioJupyterHelm struct {
	BucketName string
	FileName   string
}

type MinioModelHelm struct {
	BucketName string
	FileName   string
}

type ModelDownload struct {
	MinioBucket    string
	MinioEndpoint  string
	MinioAccessKey string
	MinioSecretKey string
}

// HfBaseURL    string  = "https://huggingface.co"
// 		MinioBucket  string   = "playground"
// 		MinioEndpoint  string  = "10.0.0.55:32177"
// 		MinioAccessKey string = "admin"
// 		MinioSecretKey string = "3MAulYluIJ"
// 		HfAccessToken string = "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"

// Bitbucket creds
// type Bitbucket struct {
// 	Username string
// 	Password string
// }

// // // Resources defines the structure for CPU and memory resources (requests and limits)
// type Resources struct {
// 	Requests struct {
// 		CPU    string `json:"cpu"`
// 		Memory string `json:"memory"`
// 	} `json:"requests"`
// 	Limits struct {
// 		CPU    string `json:"cpu"`
// 		Memory string `json:"memory"`
// 	} `json:"limits"`
// }

// falseStr is a constant to remove duplicacy code
const falseStr string = "false"

var (
	// Conf is a global variable for configuration
	Conf Config
	// TomlFile is a global variable for toml file path
	TomlFile string
	// DB Database client
	DB        *gorm.DB
	DefaultDb *gorm.DB
	// OTP mail disabled
	// OTP string = "true"

	// MailService enabled
	// MailService string = "false"
	//PersistStoragePath is used for foldername
	PersistStoragePath string = "data/nexa-uploads"
)

// ConfigurationWithEnv is a method to initialize configuration with environment variables
func ConfigurationWithEnv() {
	// postgres database configuration
	Conf.Database.Host = os.Getenv("AUTH_DB_HOST")
	Conf.Database.Port = os.Getenv("AUTH_DB_PORT")
	Conf.Database.User = os.Getenv("AUTH_DB_USER")
	Conf.Database.Pass = os.Getenv("AUTH_DB_PASS")
	Conf.Database.Name = os.Getenv("AUTH_DB_NAME")
	Conf.Database.Ideal = os.Getenv("AUTH_DB_IDEAL_CONNECTIONS")
	Conf.Database.Ssl = "disable"

	// redis database configuration
	Conf.Redis.Database = os.Getenv("AUTH_REDIS_DB")
	Conf.Redis.Host = os.Getenv("AUTH_REDIS_HOST")
	Conf.Redis.Port = os.Getenv("AUTH_REDIS_PORT")
	Conf.Redis.Pass = os.Getenv("AUTH_REDIS_PASS")

	// admin account credentials configuration
	Conf.Admin.Email = os.Getenv("AUTH_ADMIN_EMAIL")
	Conf.Admin.Pass = os.Getenv("AUTH_ADMIN_PASS")

	// set Deployment api addar
	Conf.Address.Deployment = os.Getenv("DEPLOYMENT_API_ADDR")
	Conf.Address.FrontEndAddress = os.Getenv("AUTH_FRONT_ADDR")

	// mail service configuration
	Conf.Mail.Host = os.Getenv("AUTH_MAIL_SMTP_HOST")
	Conf.Mail.Port = os.Getenv("AUTH_MAIL_SMTP_PORT")
	Conf.Mail.From = os.Getenv("AUTH_MAIL_FROM")
	Conf.Mail.User = os.Getenv("AUTH_MAIL_USERID")
	Conf.Mail.Pass = os.Getenv("AUTH_MAIL_PASS")

	//addresses
	Conf.Address.FrontEndAddress = os.Getenv("AUTH_FRONT_ADDR")
	Conf.Address.Integration = os.Getenv("INTEGRATION_ADDR")

	//Kube-configuration
	if certAuth := os.Getenv("CERTIFICATE_AUTHORITY_DATA"); certAuth != "" {
		Conf.Kube.CertAuthData = &certAuth
	}
	if kubeHost := os.Getenv("KUBERNETES_SERVICE_HOST"); kubeHost != "" {
		kubeServer := kubeHost + ":" + os.Getenv("KUBERNETES_SERVICE_PORT")
		Conf.Kube.KubeServer = &kubeServer
	}
	if clientCert := os.Getenv("WORKSPACE_KUBE_CLIENT_CERT_DATA"); clientCert != "" {
		Conf.Kube.ClientCertificate = &clientCert
	}
	if clientKey := os.Getenv("WORKSPACE_KUBE_CLIENT_KEY"); clientKey != "" {
		Conf.Kube.ClientKey = &clientKey
	}
	if token := os.Getenv("WORKSPACE_KUBE_TOKEN"); token != "" {
		Conf.Kube.Token = &token
	}
	if namespace := os.Getenv("NAMESPACE"); namespace != "" {
		Conf.Kube.Namespace = &namespace
	}

	//chartHelm
	// Conf.ChartHelm.Address = os.Getenv("CHART_URL_ZIP")
	// Conf.ChartHelm.Token = os.Getenv("CHART_TOKEN")
	Conf.ChartHelm.HelmDriver = os.Getenv("HELM_DRIVER")

	// Conf.Bitbucket.Username = os.Getenv("BITBUCKET_USERNAME")
	// Conf.Bitbucket.Password = os.Getenv("BITBUCKET_PASSWORD")

	//minio-configuration
	Conf.Minio.Endpoint = os.Getenv("MINIO_ENDPOINT")
	Conf.Minio.AccessKey = os.Getenv("MINIO_ACCESS_KEY")
	Conf.Minio.SecretKey = os.Getenv("MINIO_SECRET_KEY")

	// minio model helm bucket and filename
	Conf.MinioModelHelm.BucketName = os.Getenv("MINIO_MODEL_HELM_BUCKET")
	Conf.MinioModelHelm.FileName = os.Getenv("MINIO_MODEL_HELM_FILENAME")

	// minio jupyter helm bucket and filename
	Conf.MinioJupyterHelm.BucketName = os.Getenv("MINIO_JUPYTER_HELM_BUCKET")
	Conf.MinioJupyterHelm.FileName = os.Getenv("MINIO_JUPYTER_HELM_FILENAME")

	Conf.Vault.Address = os.Getenv("VAULT_ADDR")
	Conf.Vault.Token = os.Getenv("VAULT_TOKEN")

	Conf.ModelDownload.MinioBucket = os.Getenv("DOWNLOAD_MINIO_BUCKET")
	Conf.ModelDownload.MinioAccessKey = os.Getenv("DOWNLOAD_MINIO_ACCESS_KEY")
	Conf.ModelDownload.MinioSecretKey = os.Getenv("DOWNLOAD_MINIO_SECRET_KEY")
	Conf.ModelDownload.MinioEndpoint = os.Getenv("DOWNLOAD_MINIO_ENDPOINT")

	// if service port is not defined set default port
	if os.Getenv("NEXA_AUTH_PORT") != "" {
		Conf.Service.Port = os.Getenv("NEXA_AUTH_PORT")
	} else {
		Conf.Service.Port = "8000"
	}
	Conf.Service.Environment = os.Getenv("ENVIRONMENT")
	Conf.Service.Branch = os.Getenv("BRANCH")
	Conf.Service.Build = os.Getenv("BUILD_IMAGE")
	Conf.Service.Mails = os.Getenv("NOTIFICATION_EMAILS")

	// set constants
	//JWT Token Timeout in minutes
	Conf.JWT.JWTExpireTime = time.Minute * 60

	//service specific configuration
	//default value of is logout other is true
	Conf.Service.IsLogoutOthers = "true"
	if os.Getenv("IS_LOGOUT_OTHER") == falseStr {
		Conf.Service.IsLogoutOthers = falseStr
	}
	// constants
	//Link Expiration time in seconds
	if Conf.Service.VerifyLinkTimeout == 0 {
		Conf.Service.VerifyLinkTimeout = 1800
	}
	if Conf.Service.InviteLinkTimeout == 0 {
		Conf.Service.InviteLinkTimeout = 86400
	}

}

// ConfigurationWithToml is a method to initialize configuration with toml file
func ConfigurationWithToml(filePath string) error {
	// set varible as file path if configuration is done using toml
	TomlFile = filePath
	Log.Info(filePath)
	// parse toml file and save data config structure
	_, err := toml.DecodeFile(filePath, &Conf)
	if err != nil {
		Log.Error(err)
		return err
	}

	if Conf.Service.Port == "" {
		Conf.Service.Port = "8000"
	}
	Conf.Database.Ssl = "disable"
	Conf.Service.Build = os.Getenv("BUILD_IMAGE")

	// set constants
	//JWT Token Timeout in minutes
	Conf.JWT.JWTExpireTime = time.Minute * 60

	//service specific configuration
	//default value of is logout other is true
	Conf.Service.IsLogoutOthers = "true"
	if os.Getenv("IS_LOGOUT_OTHER") == falseStr {
		Conf.Service.IsLogoutOthers = falseStr
	}
	// constants
	//Link Expiration time in seconds

	if Conf.Service.VerifyLinkTimeout == 0 {
		Conf.Service.VerifyLinkTimeout = 600
	}
	if Conf.Service.InviteLinkTimeout == 0 {
		Conf.Service.InviteLinkTimeout = 604800
	}
	return nil
}

// SetConfig is a method to re-intialise configuration at runtime
func SetConfig() {
	if TomlFile == "" {
		ConfigurationWithEnv()
	} else {
		ConfigurationWithToml(TomlFile)
	}
}

// DBConfig is a method that return postgres database connection string
func DBConfig() string {
	//again reset the config if any changes in toml file or environment variables
	SetConfig()
	// creating postgres connection string
	str := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=%s application_name=%s",
		Conf.Database.Host,
		Conf.Database.Port,
		Conf.Database.User,
		Conf.Database.Pass,
		Conf.Database.Name,
		Conf.Database.Ssl,
		Conf.Database.Name)
	return str
}
