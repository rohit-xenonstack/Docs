# Changelog

All notable changes to this project will be documented in this file.

## 1.0.0 - 13th August 2020

### Added

* Create admin account at db initialization
* Signup User
* Verify user email-id and send code again feature
* Login User with and without workspace
* Update and view profile
* JWT token based authentication
* Change, forgot and reset password
* Workspace creation, check status and availability feature for user
* Admin can delete workspace, list workspace and delete account of user
* Workspace login, forgot workspace feature
* Invite member in a Workspace
* Member singup and set password for new members in a Workspace
* Mail service is enabled to send mails using smtp server
* Configuration with TOML file and environment variables
* Set configuration with command-line flags
* Session Management using Redis Cache
* Logout API to delete Session
* Refresh Token API to generate new session and delete old Session
* Proper code commenting according to go-vet
* Mail data(template to use, subject, images to be passed) with toml file
* Inner Service Communication use Nats Server
* Health check logic(checking all services and databases health)
* README contains all environment variables to be set
* CHANGELOG.md file contains all changes in this project with the release
