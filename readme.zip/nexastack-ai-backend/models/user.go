package models

import "time"

type User struct {
	ID        uint `gorm:"primaryKey"`
	CreatedAt time.Time
	UpdatedAt time.Time
	Username  string `gorm:"unique"`
	Password  string
	Email     string `gorm:"unique"`
	FirstName string
	LastName  string
}

type AccountRoleMapping struct {
	ID        uint `gorm:"primaryKey"`
	CreatedAt time.Time
	UpdatedAt time.Time
	AccountID uint
	RoleID    uint
	ProjectId int
}

func (AccountRoleMapping) TableName() string {
	return "roles.account_role_mapping"
}

type SignupData struct {
	Name     string `json:"name"`
	Contact  string `json:"contact"`
	Email    string `json:"email" binding:"required"`
	Password string `json:"password" binding:"required"`
	Role     string `json:"role"`
}
