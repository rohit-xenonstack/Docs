package models

import (
	"time"

	"github.com/twinj/uuid"
)

type Member struct {
	ID          int       `json:"-" gorm:"primary_key"`
	Email       string    `json:"user_email" gorm:"unique_index:idx_memberproject" binding:"required"`
	ProjectSlug string    `json:"-" gorm:"unique_index:idx_memberproject"`
	UserName    string    `json:"user_Name" gorm:"default:''" binding:"required"`
	UserRole    string    `json:"user_role" gorm:"default:''" binding:"required"`
	AddedAt     int64     `json:"added_at"`
	CreatedAt   time.Time `json:"-"`
	UpdatedAt   time.Time `json:"-"`
	Environment string    `json:"environment"`
	ProjectId   string    `json:"project_id"`
}

// MemberList structure for used the storethe response of member list
type MemberList struct {
	Name        string `json:"name"`
	Email       string `json:"email"`
	Role        string `json:"role"`
	Join        int64  `json:"joined"`
	ProjectId   int    `json:"project_id"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
}

// Content structure for used the storethe response of member list
type Content struct {
	Member      []MemberList `json:"members"`
	ProjectId   int          `json:"project_id"`
	Environment string       `json:"environment"`
}

type Environment struct {
	ID          int       `gorm:"primary_key;auto_increment;type:int" json:"id"`              // Auto-incrementing primary key
	Name        string    `gorm:"type:varchar(255);not null" json:"name"`                     // Name of the environment (e.g., DEV, UAT, PROD)
	ProjectID   uuid.UUID `gorm:"type:uuid;not null" json:"project_id"`                       // Foreign key to the project the environment belongs to
	CreatedAt   time.Time `gorm:"type:timestamp;default:current_timestamp" json:"created_at"` // When the environment was created
	UpdatedAt   time.Time `gorm:"type:timestamp;default:current_timestamp" json:"updated_at"` // When the environment was last updated
	ProjectId   int       `json:"project_id"`
	Environment string    `json:"environment"`
}

type Membership struct {
	ID          int       `gorm:"primary_key;auto_increment;type:int" json:"id"` // Auto-incrementing primary key
	MemberID    uuid.UUID `gorm:"type:uuid;not null" json:"member_id"`
	EntityID    uuid.UUID `gorm:"type:uuid;not null" json:"entity_id"`                       // ID of the workspace, project, or environment
	EntityType  string    `gorm:"type:varchar(50);not null" json:"entity_type"`              // 'workspace', 'project', 'environment'
	Role        string    `gorm:"type:varchar(50);not null" json:"role"`                     // Role within the entity (e.g., Admin, Developer, Viewer)
	JoinedAt    time.Time `gorm:"type:timestamp;default:current_timestamp" json:"joined_at"` // When the member joined
	ProjectId   int       `json:"project_id"`
	Environment string    `json:"environment"`
	Workspace   string    `json:"workspace"`
}

// Resource struct represents the resources linked to an environment
type Resource struct {
	ID            int       `gorm:"primary_key;auto_increment;type:int" json:"id"`              // Auto-incrementing primary key
	Name          string    `gorm:"type:varchar(255);not null" json:"name"`                     // Name of the resource (e.g., Database, Compute)
	Type          string    `gorm:"type:varchar(100);not null" json:"type"`                     // Type of resource (e.g., Database, Compute, Storage)
	EnvironmentID uuid.UUID `gorm:"type:uuid;not null" json:"environment_id"`                   // Foreign key to the environment the resource belongs to
	CreatedAt     time.Time `gorm:"type:timestamp;default:current_timestamp" json:"created_at"` // When the resource was created
	UpdatedAt     time.Time `gorm:"type:timestamp;default:current_timestamp" json:"updated_at"` // When the resource was last updated
	ProjectId     int       `json:"project_id"`
	Environment   string    `json:"environment"`
	Workspace     string    `json:"workspace"`
}
