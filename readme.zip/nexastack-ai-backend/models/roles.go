package models

import "time"

type Role struct {
	Id          int `gorm:"primaryKey;autoIncrement" json:"id"` // Primary Key
	CreatedAt   time.Time
	UpdatedAt   time.Time
	Name        string `json:"name"`
	Domain      string `json:"domain"`
	Environment string `json:"environment"`
	ProjectId   int    `json:"project_id"`
}

func (Role) TableName() string {
	return "roles.role"
}
