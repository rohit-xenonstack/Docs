package models

import (
	"time"

	"github.com/lib/pq"
)

// FineTuneFieldMetadata defines the metadata for each fine-tune field
type FineTuneFieldMetadata struct {
	Id          int       `gorm:"primaryKey" json:"id"`                        // Primary Key
	Name        string    `gorm:"type:varchar(255);not null" json:"name"`      // Name of the field
	Section     string    `gorm:"type:varchar(255)" json:"section"`            // Section in which value falls
	InputType   string    `gorm:"type:varchar(255)" json:"input_type"`         // Input type of the fields
	FieldType   string    `gorm:"type:varchar(255)" json:"field_type"`         // Field type (e.g., string, int)
	Description string    `gorm:"type:text" json:"description,omitempty"`      // Description of the field
	CreatedAt   time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"` // Creation timestamp
	UpdatedAt   time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"` // Last update timestamp
	CreatedBy   int       `gorm:"type:int" json:"created_by"`                  // Creator of the field
	ProjectId   int       `json:"project_id"`
	Environment string    `json:"environment"`
}

// FineTuneModelConfigurations defines the configuration for the model
type FineTuneModelConfigurations struct {
	Id                  int           `gorm:"primaryKey;autoIncrement" json:"id"`              // Primary Key
	ModelName           string        `gorm:"type:varchar(255)" json:"model_name"`             // Model name
	Dataset             string        `gorm:"type:varchar(255)" json:"dataset"`                // Dataset
	ModelPath           string        `gorm:"type:varchar(255)" json:"model_path"`             // Path to the model
	FieldConfigurations pq.Int32Array `gorm:"type:int[];not null" json:"field_configurations"` // Array of field IDs (can be JSON or string)
	CreatedAt           time.Time     `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`     // Creation timestamp
	UpdatedAt           time.Time     `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`     // Last update timestamp
	CreatedBy           int           `gorm:"type:int" json:"created_by"`
	ProjectId           int           `json:"project_id"`
	Environment         string        `json:"environment"`
}

// FineTuneModelConfigurations defines the configuration for the model
type TempFineTuneModelConfigurations struct {
	Id                  int                   `gorm:"primaryKey;autoIncrement" json:"id"`              // Primary Key
	ModelName           string                `gorm:"type:varchar(255);not null" json:"model_name"`    // Model name
	ModelPath           string                `gorm:"type:varchar(255)" json:"model_path"`             // Path to the model
	FieldConfigurations []FineTuneFieldValues `gorm:"type:int[];not null" json:"field_configurations"` // Array of field IDs (can be JSON or string)
	CreatedAt           time.Time             `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`     // Creation timestamp
	UpdatedAt           time.Time             `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`     // Last update timestamp
	CreatedBy           int                   `gorm:"type:int" json:"created_by"`
	Dataset             string                `gorm:"type:varchar(255)" json:"dataset"` // Dataset
	ProjectId           int                   `json:"project_id"`
	Environment         string                `json:"environment"`
	Workspace           string                `json:"workspace"`
}

type FineTuneFieldValues struct {
	Id            int       `gorm:"primaryKey;autoIncrement" json:"id"`
	FieldId       int       `gorm:"type:int;not null;uniqueIndex:idx_field_model_config" json:"field_id"`        // Apply uniqueIndex on this field
	ModelConfigId int       `gorm:"type:int;not null;uniqueIndex:idx_field_model_config" json:"model_config_id"` // Apply uniqueIndex on this field
	Value         string    `gorm:"type:jsonb;not null" json:"value"`
	CreatedAt     time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`
	UpdatedAt     time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`
	CreatedBy     int       `gorm:"type:int" json:"created_by"`
	ProjectId     int       `json:"project_id"`
	Environment   string    `json:"environment"`
	Workspace     string    `json:"workspace"`
}
