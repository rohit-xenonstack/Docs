package models

import "time"

type AzureAccountRoles struct {
	ID              int       `json:"-" gorm:"primary_key"`
	UserId          int       `json:"user_id"`
	AccountName     string    `json:"account_name"`
	SelectedCluster string    `json:"selected_cluster"`
	CreatedAt       time.Time `json:"-"`
	UpdatedAt       time.Time `json:"-"`
	Environment     string    `json:"environment"`
	ProjectId       string    `json:"project_id"`
	Workspace       string    `json:"workspace"`
}

type BestClusters struct {
	ClusterName           string `json:"cluster_name"`
	IsSuffiecientResource bool   `json:"is_best_cluster"`
}
