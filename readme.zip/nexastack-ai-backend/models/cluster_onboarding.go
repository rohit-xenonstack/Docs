package models

import (
	"time"

	"gorm.io/gorm"
)

type AWSAccountRoles struct {
	ID              uint           `gorm:"primaryKey" json:"id"`
	UserId          int            `gorm:"primaryKey" json:"user_id"`
	AccountName     string         `json:"account_name"`
	AccountId       string         `json:"account_id"`
	ManageAccess    bool           `json:"manage_access"`
	IsActive        bool           `json:"is_active"`
	UserResourceARN string         `gorm:"type:varchar(255)" json:"user_resource_arn"`
	RoleARN         string         `gorm:"type:varchar(255)" json:"role_arn"`
	PolicyARN       string         `gorm:"type:varchar(255)" json:"policy_arn"`
	Region          string         `gorm:"type:varchar(255)" json:"region"`
	CreatedAt       time.Time      `gorm:"autoCreateTime" json:"created_at"`
	UpdatedAt       time.Time      `gorm:"autoUpdateTime" json:"updated_at"`
	DeletedAt       gorm.DeletedAt `gorm:"index" json:"deleted_at,omitempty"`
	SelectedCluster string         `gorm:"type:varchar(255)" json:"selected_cluster"`
	Environment     string         `json:"environment"`
	ProjectId       int            `json:"project_id"`
	Workspace       string         `json:"workspace"`
}

type ClusterRegister struct {
	ClusterName string `json:"cluster_name"`
	UserId      string `json:"user_id"`
	AccountId   string `json:"account_id"`
	ProjectId   int    `json:"project_id"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
}
