package models

import (
	"time"

	"gorm.io/gorm"
)

// DockerHubRepository represents a repository in Docker Hub
type DockerHubRepository struct {
	Name        string    `json:"name"`
	Description string    `json:"description"`
	Namespace   string    `json:"namespace"`
	HubUser     string    `json:"hub_user"`
	LastUpdated time.Time `json:"last_updated"`
}

// DockerHubResponse represents the response from Docker Hub API
type DockerHubResponse struct {
	Count    int                   `json:"count"`
	Next     string                `json:"next"`
	Previous string                `json:"previous"`
	Results  []DockerHubRepository `json:"results"`
}

// MCPRepository is our database model
type MCPRepository struct {
	gorm.Model
	Name            string    `json:"name"`
	Description     string    `json:"description"`
	Namespace       string    `json:"namespace"`
	HubUser         string    `json:"hub_user"`
	By              string    `json:"by"` // <-- Add this line
	LastUpdated     time.Time `json:"last_updated"`
	Characteristics string    `json:"characteristics"`
	Tools           string    `json:"tools"` // We'll store tools as JSON string
	McpConfig       string    `json:"mcp_config"`
}

// RepositoryDetails represents additional info about a repository
type RepositoryDetails struct {
	Tags  []string          `json:"tags"`
	Tools []ToolDescription `json:"tools,omitempty"`
}

type Characteristics struct {
	ImageSource            string `json:"image_source"`
	DockerImage            string `json:"docker_image"`
	Author                 string `json:"author"`
	Repository             string `json:"repository"`
	Dockerfile             string `json:"dockerfile"`
	DockerImageBuiltBy     string `json:"docker_image_built_by"`
	DockerScoutHealthScore string `json:"docker_scout_health_score"`
	License                string `json:"license"`
}

type Characteristic struct {
	Key   string
	Value string
}

type DockerHubTags struct {
	Count    int            `json:"count"`
	Next     string         `json:"next"`
	Previous string         `json:"previous"`
	Results  []DockerHubTag `json:"results"`
}

type DockerHubTag struct {
	Name        string    `json:"name"`
	LastUpdated time.Time `json:"last_updated"`
}

// ToolDescription represents a tool extracted from OpenAPI spec
type ToolDescription struct {
	Tool        string              `json:"tool"`
	Description string              `json:"description"`
	Parameters  []ToolParameterInfo `json:"parameters"`
}

type ToolParameterInfo struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Description string `json:"description"`
	Optional    bool   `json:"optional"`
}

type FullRepo struct {
	FullDescription string `json:"full_description"`
}

type MCPRepositoryResponse struct {
	ID              uint                   `json:"id"`
	Name            string                 `json:"name"`
	Description     string                 `json:"description"`
	Namespace       string                 `json:"namespace"`
	LastUpdated     time.Time              `json:"last_updated"`
	By              string                 `json:"by"`
	Characteristics Characteristics        `json:"characteristics"`
	Tools           []ToolDescription      `json:"tools"`
	McpConfig       map[string]interface{} `json:"mcp_config"`
}

type MCPResponse struct {
	RepositoryDetails RepositoryDetails
	FullRepo          FullRepo
	MCPConfig         map[string]interface{}
}
