package models

import (
	"time"

	"github.com/lib/pq"
	"gorm.io/gorm"
)

type Project struct {
	ID             int              `json:"id" gorm:"primaryKey"`
	WorkspaceID    string           `json:"workspace_id"`
	Name           string           `json:"name"`
	Description    string           `json:"description"`
	CreatedBy      uint             `json:"created_by"`
	UpdatedBy      uint             `json:"updated_by"`
	CreatedAt      time.Time        `json:"created_at"`
	UpdatedAt      time.Time        `json:"updated_at"`
	DeletedAt      gorm.DeletedAt   `gorm:"index" json:"deleted_at"`
	OrganizationId int              `json:"organization_id"`
	ProjectId      int              `json:"project_id"`
	Environment    string           `json:"environment"`
	Members        []ProjectMembers `json:"members" gorm:"foreignKey:ProjectId;references:ID"`
}

type ProjectToAccountMapping struct {
	ID          int            `json:"id" gorm:"primaryKey"`
	ProjectID   int            `json:"project_id"`
	AccountID   int            `json:"account_id"`
	CreatedAt   time.Time      `json:"created_at"`
	UpdatedAt   time.Time      `json:"updated_at"`
	DeletedAt   gorm.DeletedAt `gorm:"index" json:"deleted_at"`
	Environment string         `json:"environment"`
	Workspace   string         `json:"workspace"`
}

// ProjectMember represents a member of a project
type ProjectMembers struct {
	ID                int                      `json:"id" gorm:"primaryKey;autoIncrement"`
	Role              string                   `json:"role"`
	RoleId            int                      `json:"role_id"`
	Email             string                   `json:"email"`
	Name              string                   `json:"name"`
	Status            string                   `json:"status" gorm:"default:'pending'"`
	EnvironmentAccess []EnvironmentPermissions `json:"environment_access" gorm:"foreignKey:MemberID;references:ID"`
	UserId            int                      `json:"user_id"`
	ProjectId         string                   `json:"project_id" gorm:"index"`
	Workspace         string                   `json:"workspace"`
	ProjectName       string                   `json:"project_name"`
}

// EnvironmentPermission represents permissions for a specific environment
type EnvironmentPermissions struct {
	ID          int            `json:"id" gorm:"primaryKey;autoIncrement"`
	MemberID    int            `json:"member_id" gorm:"index"`
	Environment string         `json:"environment"`
	Permissions pq.StringArray `json:"permissions" gorm:"type:text[]"`
}

// ProjectRequest represents the request body for creating a project
type ProjectRequest struct {
	Name      string          `json:"name" binding:"required"`
	Workspace string          `json:"workspace" binding:"required"`
	Members   []MemberRequest `json:"members"`
}

// MemberRequest represents the request body for adding a member to a project
type MemberRequest struct {
	Role              string                         `json:"role" binding:"required"`
	RoleId            int                            `json:"role_id" binding:"required"`
	Email             string                         `json:"email" binding:"required,email"`
	Name              string                         `json:"name" binding:"required"`
	EnvironmentAccess []EnvironmentPermissionRequest `json:"environment_access"`
}

// EnvironmentPermissionRequest represents the request body for setting environment permissions
type EnvironmentPermissionRequest struct {
	Environment string   `json:"environment" binding:"required"`
	Permissions []string `json:"permissions" binding:"required"`
}

func (ProjectMembers) TableName() string {
	return "project_management.project_members"
}

// Set the table name with schema
func (Project) TableName() string {
	return "project_management.project"
}

func (ProjectToAccountMapping) TableName() string {
	return "project_management.project_to_account_mapping"
}

func (EnvironmentPermissions) TableName() string {
	return "project_management.environment_permissions"
}

// Create a temporary struct that can handle array permissions
type TempEnvironmentPermissions struct {
	ID          int         `json:"id"`
	MemberID    int         `json:"member_id"`
	Environment string      `json:"environment"`
	Permissions interface{} `json:"permissions"`
}

type TempProjectMembers struct {
	ID                int                          `json:"id"`
	Role              string                       `json:"role"`
	RoleId            int                          `json:"role_id"`
	Email             string                       `json:"email"`
	Name              string                       `json:"name"`
	UserId            int                          `json:"user_id"`
	Status            string                       `json:"status"`
	EnvironmentAccess []TempEnvironmentPermissions `json:"environment_access"`
	ProjectId         string                       `json:"project_id"`
	Workspace         string                       `json:"workspace"`
	ProjectName       string                       `json:"project_name"`
}

type ProjectMemberRegistration struct {
	Password    string `json:"password" binding:"required"`
	Email       string `json:"email" binding:"required"`
	Workspace   string `json:"workspace" binding:"required"`
	ProjectId   int    `json:"project_id"`
	Environment string `json:"environment"`
	Token       string `json:"token"`
}
