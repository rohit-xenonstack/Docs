package models

import "time"

type Permission struct {
	ID          uint `gorm:"primaryKey"`
	CreatedAt   time.Time
	UpdatedAt   time.Time
	Feature     string `json:"feature"`
	Action      string `json:"action"`
	ProjectId   int    `json:"project_id"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
}

func (Permission) TableName() string {
	return "roles.permission"
}
