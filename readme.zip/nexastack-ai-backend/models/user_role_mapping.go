package models

import "time"

type RolePermissionMapping struct {
	ID           uint `gorm:"primaryKey"`
	CreatedAt    time.Time
	UpdatedAt    time.Time
	PermissionId uint
	RoleID       uint
}

func (RolePermissionMapping) TableName() string {
	return "roles.role_permission_mapping"
}
