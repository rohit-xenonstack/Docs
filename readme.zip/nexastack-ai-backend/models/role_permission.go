package models

// ... existing code ...

// RolePermissionResponse represents the role and its associated permissions
// type RolePermissionResponse struct {
// 	Id          int                      `json:"id"`
// 	RoleName    string                   `json:"role_name"`
// 	Permissions []FeaturePermissionGroup `json:"permissions"`
// }

type RolePermissionResponse struct {
	Id          int      `json:"id"`
	RoleName    string   `json:"role_name"`
	Permissions []string `json:"permission"`
	Domain      string   `json:"domain"`
	ProjectId   int      `json:"project_id"`
}

// FeaturePermissionGroup represents a feature and its allowed actions
type FeaturePermissionGroup struct {
	Feature    string   `json:"feature"`
	Permission []string `json:"permission"`
}

func (RolePermissionResponse) TableName() string {
	return "roles.role_permission_response"
}

func (FeaturePermissionGroup) TableName() string {
	return "roles.feature_permission_group"
}

// ... existing code ...
