package models

import "time"

type Status string

const (
	StatusRunning  Status = "Running"
	StatusInactive Status = "Inactive"
)

type Jobs struct {
	ID          int       `json:"id" db:"id"`
	Model       string    `json:"model" db:"model"`
	Dataset     string    `json:"dataset" db:"dataset"`
	Status      Status    `json:"status" db:"status" gorm:"type:status"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
	UpdatedAt   time.Time `json:"updated_at" db:"updated_at"`
	AccountId   int       `json:"account_id" db:"account_id"`
	ProjectId   int       `json:"project_id"`
	Environment string    `json:"environment"`
	Workspace   string    `json:"workspace"`
}

type KubeConfigData struct {
	Id   int    `gorm:"primaryKey;autoIncrement" json:"id"` // Primary Key
	Type string `json:"type"`
	File string ` json:"file"`
}
