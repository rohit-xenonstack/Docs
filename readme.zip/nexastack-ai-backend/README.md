# accounts



## Requirements ##
1. go (1.11 or above)
2. Postgres Database
3. JWT token
4. Redis Database
5. Deployment Service


## Documentation ##
1. [Sample Configuration using toml](example.toml)


## Environment Variables => ##
```
//service based
export NEXA_AUTH_PORT="8000"
export ENVIRONMENT="development"
export BUILD_IMAGE="d11111"
export IS_LOGOUT_OTHERS="true"
//comma separated emails to notify workspace is create
export NOTIFICATION_EMAILS="admin@xenonstack.com,support@xenonstack.com"

// Postgres database
export AUTH_DB_HOST="localhost"
export AUTH_DB_PORT="5432"
export AUTH_DB_USER="Postgres"
export AUTH_DB_PASS="Postgres"
export AUTH_DB_NAME="nexa_auth"

//redis Database
export AUTH_REDIS_DB="1"
export AUTH_REDIS_HOST="localhost"
export AUTH_REDIS_PORT="6379"
export AUTH_REDIS_PASS=""

//smtp mail
export AUTH_MAIL_SMTP_HOST="smtp.mailgun.org"
export AUTH_MAIL_SMTP_PORT="465"
export AUTH_MAIL_FROM="mailer@nexa.com"
export AUTH_MAIL_USERID=""
export AUTH_MAIL_PASS=""

//admin credentials
export AUTH_ADMIN_EMAIL="admin@nexa.com"
export AUTH_ADMIN_PASS=""

//addresses
export DEPLOYMENT_API_ADDR=""
export AUTH_FRONT_ADDR=""

//jwt Configuration
export PRIVATE_KEY=""
```



## How to run the app ##

### 1. Configuration using environment variables ###

```
i.    Export above all environment variables
ii.   Build the app or binary -> command -> `$ go install`
iii.  Run the app or binary -> command -> `$GOPATH/bin/accounts -conf=environment`
```

### 2. Configuration using TOML file ###

```
i.    Create a configuration toml file
ii.   Build the app or binary -> command -> `$ go install`
iii.  Run the app or binary -> command -> `$GOPATH/bin/accounts --conf=toml --file=<path of toml file>`
```
### 3. Run the Test Case ###

```
i.    Run the Test case ->  go test ./... -p 1 -v -coverprofile=coverage.out
ii.   To see the Test Coverage Output in html page -> go tool cover -html=coverage.out 
```

### 4. To generate the sonarqube analysis
```
 go env -w GOARCH=amd64

i. go test -coverprofile=coverage.out -coverpkg=./src/api/... ./tests -v
i. sonar-scanner
```

`Note :- for any help regarding flags, run this command '$GOPATH/bin/accounts --help'`
