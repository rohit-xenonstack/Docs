package database

import (
	"fmt"
	"os"

	"git.xenonstack.com/nexa-platform/accounts/config"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"

	// postgres dialects
	_ "github.com/jinzhu/gorm/dialects/postgres"
	"gopkg.in/yaml.v2"
)

// Database structure used for store the database infomation
type Database struct {
	Host string `json:"host"`
	Port string `json:"port"`
	Name string `json:"name"`
	User string `json:"user"`
	Pass string `json:"pass"`
	Ssl  string
}

// Config structure used for store database Config
type Config struct {
	Database Database `json:"database"`
}

// CreateDatabaseTables funtion for create Table
func CreateDatabaseTables() {
	// connecting db using connection string
	db := config.DB

	// creating all tables one by one but firstly checking whether table exists or not
	if !(db.HasTable(Accounts{})) {
		db.CreateTable(Accounts{})
		//creating admin account
		adminAcc := InitAdminAccount()
		db.Create(&adminAcc)
	}

	if !(db.HasTable(Activities{})) {
		db.CreateTable(Activities{})
	}
	if !(db.HasTable(Tokens{})) {
		db.CreateTable(Tokens{})
	}
	if !(db.HasTable(ActiveSessions{})) {
		db.CreateTable(ActiveSessions{})
	}

	if !(db.HasTable(Workspaces{})) {
		db.CreateTable(Workspaces{})
	}
	if !(db.HasTable(WorkspaceMembers{})) {
		db.CreateTable(WorkspaceMembers{})
	}
	if !(db.HasTable(ComputeConfig{})) {
		db.CreateTable(ComputeConfig{})
	}

	if !(db.HasTable(Instance{})) {
		db.CreateTable(Instance{})
	}

	if !(db.HasTable(ModelMarketplace{})) {
		db.CreateTable(ModelMarketplace{})
	}
	if !(db.HasTable(Deployment{})) {
		db.CreateTable(Deployment{})
	}

	if !(db.HasTable(models.FineTuneFieldMetadata{})) {
		db.CreateTable(models.FineTuneFieldMetadata{})
	}

	if !(db.HasTable(models.FineTuneFieldValues{})) {
		db.CreateTable(models.FineTuneFieldValues{})
	}

	if !(db.HasTable(models.FineTuneModelConfigurations{})) {
		db.CreateTable(models.FineTuneModelConfigurations{})
	}

	if !(db.HasTable(models.Jobs{})) {
		db.CreateTable(models.Jobs{})
	}
	if !(db.HasTable(InfraIntegration{})) {
		db.CreateTable(InfraIntegration{})
	}

	if !(db.HasTable(models.AWSAccountRoles{})) {
		db.CreateTable(models.AWSAccountRoles{})
	}

	if !(db.HasTable(VmDetailes{})) {
		db.CreateTable(VmDetailes{})
	}

	// Specify the schema name (e.g., "project_management")
	schemaName := "project_management"

	// Create schema if it doesn't exist (optional)
	db.Exec("CREATE SCHEMA IF NOT EXISTS " + schemaName)
	db.Exec("CREATE SCHEMA IF NOT EXISTS roles")

	if !db.HasTable(&models.Membership{}) {
		db.Table(schemaName + ".membership").CreateTable(&models.Membership{})
	}
	if !db.HasTable(&models.Project{}) {
		db.Table(schemaName + ".project").CreateTable(&models.Project{})
	}
	if !db.HasTable(&models.Environment{}) {
		db.Table(schemaName + ".environment").CreateTable(&models.Environment{})
	}
	if !db.HasTable(&models.Resource{}) {
		db.Table(schemaName + ".resource").CreateTable(&models.Resource{})
	}
	if !db.HasTable(&models.ProjectToAccountMapping{}) {
		db.Table(schemaName + ".project_to_account_mapping").CreateTable(&models.ProjectToAccountMapping{})
	}

	if !(db.HasTable(&models.Role{})) {
		db.CreateTable(&models.Role{})
	}

	if !(db.HasTable(&models.RolePermissionMapping{})) {
		db.CreateTable(&models.RolePermissionMapping{})
	}

	if !(db.HasTable(&models.Permission{})) {
		db.CreateTable(&models.Permission{})
		// Add unique constraint for feature and action combination
		db.Exec("ALTER TABLE roles.permission ADD CONSTRAINT unique_feature_action UNIQUE (feature, action)")
	}

	if !(db.HasTable(&models.AccountRoleMapping{})) {
		db.CreateTable(&models.AccountRoleMapping{})
	}

	if !(db.HasTable(&models.ProjectToAccountMapping{})) {
		db.CreateTable(&models.ProjectToAccountMapping{})
	}

	if !(db.HasTable(Model{})) {
		db.CreateTable(Model{})
	}

	if !(db.HasTable(&models.ProjectMembers{})) {
		db.CreateTable(&models.ProjectMembers{})
	}

	if !(db.HasTable(&models.EnvironmentPermissions{})) {
		db.CreateTable(&models.EnvironmentPermissions{})
	}

	if !(db.HasTable(&models.Vulnerabilities{})) {
		db.CreateTable(&models.Vulnerabilities{})
	}

	if !(db.HasTable(&models.KubeConfigData{})) {
		db.CreateTable(&models.KubeConfigData{})
	}

	if !(db.HasTable(&models.MCPRepository{})) {
		db.CreateTable(&models.MCPRepository{})
	}

	err := createJobStatusEnum(db)
	if err != nil {
		config.Log.Error(err)
	}

	// Database migration
	db.AutoMigrate(&Accounts{},
		&Activities{},
		&Tokens{},
		&ActiveSessions{},
		&Workspaces{},
		&WorkspaceMembers{},
		&ComputeConfig{},
		&Instance{},
		&ModelMarketplace{},
		&Deployment{},
		&models.FineTuneFieldMetadata{},
		&models.FineTuneFieldValues{},
		&models.FineTuneModelConfigurations{},
		&models.Jobs{},
		&InfraIntegration{},
		&models.AWSAccountRoles{},
		&VmDetailes{},
		&models.Membership{},
		&models.Project{},
		&models.Environment{},
		&models.Resource{},
		&models.Role{},
		&models.RolePermissionMapping{},
		&models.Permission{},
		&models.AccountRoleMapping{},
		&models.ProjectToAccountMapping{},
		&Model{},
		models.ProjectMembers{},
		models.EnvironmentPermissions{},
		models.Vulnerabilities{},
		models.KubeConfigData{},
		models.MCPRepository{},
	)

	// Add foreignKeys
	db.Model(&ActiveSessions{}).AddForeignKey("userid", "accounts(id)", "CASCADE", "CASCADE")
	db.Model(&Tokens{}).AddForeignKey("userid", "accounts(id)", "CASCADE", "CASCADE")
	db.Model(&WorkspaceMembers{}).AddForeignKey("member_email", "accounts(email)", "CASCADE", "CASCADE")
	db.Model(&WorkspaceMembers{}).AddForeignKey("workspace_id", "workspaces(workspace_id)", "CASCADE", "CASCADE")
	db.Model(&ComputeConfig{}).AddForeignKey("workspace_id", "workspaces(workspace_id)", "CASCADE", "CASCADE")
	db.Model(&ComputeConfig{}).AddForeignKey("user_email", "accounts(email)", "CASCADE", "CASCADE")
	db.Model(&Instance{}).AddForeignKey("workspace_id", "workspaces(workspace_id)", "CASCADE", "CASCADE")
	db.Model(&Instance{}).AddForeignKey("user_email", "accounts(email)", "CASCADE", "CASCADE")
	db.Model(&Deployment{}).AddForeignKey("user_email", "accounts(email)", "CASCADE", "CASCADE")
	db.Model(&Deployment{}).AddForeignKey("workspace_id", "workspaces(workspace_id)", "CASCADE", "CASCADE")
	db.Model(&InfraIntegration{}).AddForeignKey("user_email", "accounts(email)", "CASCADE", "CASCADE")
	db.Model(&models.AccountRoleMapping{}).AddForeignKey("account_id", "accounts(id)", "CASCADE", "CASCADE")
	db.Model(&models.AccountRoleMapping{}).AddForeignKey("role_id", "roles.role(id)", "CASCADE", "CASCADE")
	db.Model(&models.RolePermissionMapping{}).AddForeignKey("role_id", "roles.role(id)", "CASCADE", "CASCADE")
	db.Model(&models.RolePermissionMapping{}).AddForeignKey("permission_id", "roles.permission(id)", "CASCADE", "CASCADE")

	// db.Model(&models.Project{}).AddForeignKey("workspace_id", "workspaces(id)", "CASCADE", "CASCADE")
	// db.Model(&models.Environment{}).AddForeignKey("project_id", "projects(id)", "CASCADE", "CASCADE")
	// db.Model(&models.Resource{}).AddForeignKey("environment_id", "environments(id)", "CASCADE", "CASCADE")
	// db.Model(&models.ProjectToAccountMapping{}).AddForeignKey("project_id", "projects(id)", "CASCADE", "CASCADE")
	// db.Model(&models.ProjectToAccountMapping{}).AddForeignKey("account_id", "accounts(id)", "CASCADE", "CASCADE")
}

// CreateDatabase Initializing Database
func CreateDatabase() error {

	// connecting with postgres database root db
	db, err := gorm.Open("postgres", fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		config.Conf.Database.Host,
		config.Conf.Database.Port,
		config.Conf.Database.User,
		config.Conf.Database.Pass,
		config.Conf.Database.Name, config.Conf.Database.Ssl))

	if err != nil {
		config.Log.Error(err)
		return err
	}

	var subDomainName string
	if os.Getenv("ONPREM_CLUSTER") == "azure" {
		subDomainName = ".lab.neuralcompany.team"
	} else if os.Getenv("ONPREM_CLUSTER") == "nexastack" {
		subDomainName = ".nexastack.neuralcompany.team"
	}

	err = db.Debug().Exec(`update model_marketplaces set deployment_sub_name =?`, subDomainName).Error
	if err != nil {
		config.Log.Error(err)
	}

	defer db.Close()

	// Check if database exists
	var exists bool
	dbName := config.Conf.Database.Name
	query := `SELECT EXISTS(SELECT datname FROM pg_catalog.pg_database WHERE datname = ?)`

	err = db.Raw(query, dbName).Row().Scan(&exists)
	if err != nil {
		config.Log.Error("Failed to check database existence:", err)
		return err
	}

	if exists {
		config.Log.Info(fmt.Sprintf("Database %s already exists. Skipping creation.", dbName))
	} else {
		err = db.Exec(fmt.Sprintf("CREATE DATABASE %s;", dbName)).Error
		if err != nil {
			config.Log.Error("Failed to create database:", err)
			return err
		}
	}
	return nil
}

// Delete function used for delete database
func Delete(workspace string) error {

	dbname := []string{"iac_" + workspace + "_workflow", "iac_" + workspace + "_project"}
	//database name
	if config.Conf.Service.Branch != "" {
		dbname = []string{"iac_" + config.Conf.Service.Branch + "_" + workspace + "_workflow", "iac_" + config.Conf.Service.Branch + "_" + workspace + "_project"}
	}

	// fetch data of values.yaml
	bytes, err := os.ReadFile(config.PersistStoragePath + "/ws_ingress/values.yaml")
	if err != nil {
		config.Log.Error(err)
		return err
	}
	var c Config
	if err := yaml.Unmarshal([]byte(bytes), &c); err != nil {
		config.Log.Error(err)
		return err
	}
	c.Database.Ssl = "disable"
	//database connection string
	str := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=%s",
		c.Database.Host,
		c.Database.Port,
		c.Database.User,
		c.Database.Pass,
		"postgres",
		c.Database.Ssl)
	// connecting with postgres database root db
	db, err := gorm.Open("postgres", str)
	if err != nil {
		config.Log.Error(err)
		return err
	}
	defer db.Close()
	//execute
	for i := 0; i < len(dbname); i++ {
		db.Exec("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '" + dbname[i] + "'")
		err = db.Exec("DROP DATABASE IF EXISTS " + dbname[i] + ";").Error
		if err != nil {
			config.Log.Error(err)
			return err
		}
	}
	return nil
}

// Manually create ENUM type in PostgreSQL before migration
//   - Running
//   - Inactive
func createJobStatusEnum(db *gorm.DB) error {
	err := db.Exec("CREATE TYPE status AS ENUM ('Running', 'Inactive');").Error
	if err != nil {
		config.Log.Error("Enum might already exist, skipping creation.")
	}
	return nil
}

func GetDB(c *gin.Context) *gorm.DB {
	if scoped, exists := c.Get("ScopedDB"); exists {
		if db, ok := scoped.(*gorm.DB); ok {
			return db
		}
	}
	return config.DB
}
