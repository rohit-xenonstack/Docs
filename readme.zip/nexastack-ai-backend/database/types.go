package database

import (
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
)

// Accounts is a strucutre to stores user information
type Accounts struct {
	// auto generated
	ID int `json:"id" gorm:"primary_key"`
	//If password is empty then the user registered from career forms.
	//User can register password in future using forgot password.
	Password string `json:"-"`
	//email of user
	Email string `json:"email" gorm:"not null;unique;"`
	//name of user
	Name string `json:"name"`
	// contact number of user
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	ContactNo   string `json:"contact_no"`
	//Verify_status can be verified, not_verified
	VerifyStatus string `json:"verify_status"`
	//this role id is used for auth portal management
	//value can be 'admin', 'user'
	RoleID string `json:"sys_role"`
	//account status can be active, new, deleted, blocked etc.
	AccountStatus string `json:"account_status"`
	//account creation date
	CreationDate int64
	UpdatedAt    time.Time `json:"-"`
	CreateAt     time.Time `json:"-"`
	ProjectId    string    `json:"project_id"`
}

// Activities is a structure to record user activties
type Activities struct {
	ID int `json:"-" gorm:"primary_key"`
	//If username entered incorrect then these activities will also be recorded.
	Email       string `json:"email" gorm:"index"`
	Name        string `json:"name"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	//can be login, failedlogin, signup
	ActivityName string    `json:"activity_name"`
	Status       string    `json:"status"`
	Reason       string    `json:"reason"`
	ClientIP     string    `json:"client_ip"`
	ClientAgent  string    `json:"client_agent"`
	Timestamp    int64     `json:"timestamp"`
	UpdatedAt    time.Time `json:"-"`
	CreatedAt    time.Time `json:"-"`
	ProjectId    int       `json:"project_id"`
}

// Tokens is a structure to stores token for verifcation, invite link, forgot password
type Tokens struct {
	ID          int    `json:"-" gorm:"primary_key"`
	Userid      int    `gorm:"index:idx_ut"`
	Token       string `gorm:"index:idx_ut"` //if you require to store token secret then append that to it with '&' symbol.
	TokenTask   string
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	Timestamp   int64
	UpdatedAt   time.Time `json:"-"`
	CreateAt    time.Time `json:"-"`
	ProjectId   int       `json:"project_id"`
}

// ActiveSessions is a structure to stores active sessions
type ActiveSessions struct {
	ID          int `json:"-" gorm:"primary_key"`
	SessionID   string
	Userid      int `gorm:"index"`
	ClientAgent string
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	Start       int64
	// if value is '0' then session is remembered.
	End       int64
	UpdatedAt time.Time `json:"-"`
	CreateAt  time.Time `json:"-"`
	ProjectId string    `json:"project_id"`
}

// InitAdminAccount is a function used to create admin account
func InitAdminAccount() Accounts {

	// fetching info from env variables
	adminEmail := config.Conf.Admin.Email
	if adminEmail == "" {
		adminEmail = "admin@xenonstack.com"
	}
	adminPass := config.Conf.Admin.Pass
	if adminPass == "" {
		adminPass = "admin"
	}
	// return struct with details of admin
	return Accounts{
		Name:          "admin",
		Password:      methods.HashForNewPassword(adminPass),
		Email:         adminEmail,
		RoleID:        "admin",
		AccountStatus: "active",
		VerifyStatus:  "verified",
		CreationDate:  time.Now().Unix()}
}

//=================Workspace =========

// Workspaces is a structure to stores workspace inofrmation
type Workspaces struct {
	ID int `json:"-" gorm:"primary_key"`
	// url of workspace
	WorkspaceID string `json:"workspace_url" gorm:"unique_index;not null" binding:"required"`
	// Status can be new, active, deleted, blocked
	Status      string `json:"status"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`

	//if not provided then intial of url is team name
	TeamName  string `json:"team_name"`
	TeamSize  string `json:"team_size"`
	TeamType  string `json:"team_type"`
	Created   int64  `json:"created" gorm:"not null"`
	ProjectId int    `json:"project_id"`
}

// WorkspaceMembers is a structure to store details abont members of a particular workspace
type WorkspaceMembers struct {
	ID          int    `json:"-" gorm:"primary_key"`
	WorkspaceID string `json:"workspace_id" gorm:"not null;unique_index:edq_idx"`
	MemberEmail string `json:"member_email" gorm:"not null;unique_index:edq_idx"`
	// admin or user
	Role        string `json:"workspace_role" gorm:"not null;unique_index:edq_idx"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	// date when user joined
	Joined    int64 `json:"created" gorm:"not null;default:0"`
	ProjectId int   `json:"project_id"`
}

type ComputeConfig struct {
	ID               int       `json:"id" gorm:"primary_key"`
	NodeRuntime      string    `json:"node_runtime" gorm:"not null" validate:"required"`
	ArchitectureType string    `json:"architecture_type" gorm:"not null" validate:"required"`
	AccessMode       string    `json:"access_mode" gorm:"not null" validate:"required"`
	UserEmail        string    `json:"user_email" gorm:"not null" validate:"required"`
	ResourcesPreset  string    `json:"resources_preset" gorm:"not null" validate:"required"`
	WorkspaceID      string    `json:"workspace_id" gorm:"not null;unique_index:edq_idx"`
	IsDeleted        bool      `json:"is_deleted" gorm:"not null; default:false"`
	NoteBookIngress  string    `json:"notebook_ingress" gorm:"not null" validate:"required"`
	CreateAt         time.Time `json:"-"`
	UpdatedAt        time.Time `json:"-"`
	NodeName         string    `json:"node_name" gorm:"not null"`
	Environment      string    `json:"environment"`
	ProjectId        string    `json:"project_id"`
}

type Instance struct {
	ID              int    `json:"-" gorm:"primary_key"`
	UserEmail       string `json:"user_email" gorm:"not null" validate:"required"`
	WorkspaceID     string `json:"workspace_id" gorm:"not null;unique_index:edq_idx"`
	IsDeleted       bool   `json:"is_deleted" gorm:"not null; default:false"`
	Capacity        string `json:"capacity"`
	Allocatable     string `json:"allocatable"`
	OperatingSystem string `json:"operating_system"`
	NodeName        string `json:"node_name" gorm:"not null"`
	ClusterName     string `json:"cluster_name" gorm:"not null;unique_index:edq_idx"`
	Environment     string `json:"environment"`
	ProjectId       string `json:"project_id"`
}

// ModelMarketplace represents the model_marketplace table
type ModelMarketplace struct {
	ID                  int       `json:"model_id" gorm:"primary_key;column:id"`
	DockerImage         string    `json:"docker_image" gorm:"not null" validate:"required"`
	ImageTag            string    `json:"image_tag" gorm:"not null" validate:"required"`
	ModelName           string    `json:"model_name" gorm:"not null"`
	Trending            bool      `json:"trending" gorm:"default:false;not null" validate:"required"`
	Provider            string    `json:"provider" gorm:"not null" validate:"required"`
	ProviderBase64Image string    `json:"provider_base64_image" gorm:"not null" validate:"required"`
	HFModelName         string    `json:"hf_model_name" gorm:"not null" validate:"required"`
	CPULimit            string    `json:"cpu_limit" gorm:"not null" validate:"required"`
	CPURequest          string    `json:"cpu_request" gorm:"not null" validate:"required"`
	MemoryLimit         string    `json:"memory_limit" gorm:"not null" validate:"required"`
	MemoryRequest       string    `json:"memory_request" gorm:"not null" validate:"required"`
	GPULimit            string    `json:"gpu_limit" gorm:"not null" validate:"required"`
	GPURequest          string    `json:"gpu_request" gorm:"not null" validate:"required"`
	ModelType           string    `json:"model_type" gorm:"not null" validate:"required"`
	ReleaseName         string    `json:"release_name"`
	DeploymentName      string    `json:"deployment_name" gorm:"not null" validate:"required"`
	DeploymentSubName   string    `json:"deployment_sub_name" gorm:"not null" validate:"required"`
	Description         string    `json:"description" validate:"required"`
	ValueYamlFile       string    `json:"value_yaml_file" gorm:"not null" validate:"required"`
	LastUpdated         time.Time `json:"-" gorm:"-"`
	Environment         string    `json:"environment"`
	ProjectId           string    `json:"project_id"`
	Processor           string    `json:"processor"`
	ProcessorType       string    `json:"processor_type"`
	Cores               string    `json:"cores"`
	GpuVram             string    `json:"gpu_vram"`
	Ram                 string    `json:"ram"`
	Storage             string    `json:"storage"`
	Nodes               string    `json:"nodes"`
	ClusterType         string    `json:"cluster_type"`
	UpdatedAt           time.Time `json:"updated_at"`
	Vulnerability       string    `json:"vulnerability"`
	Ranking             int       `json:"ranking"`
	CreatedBy           int       `json:"created_by"`
	Status              string    `json:"status"`
}

type Model struct {
	ID          int    `json:"model_id" gorm:"primary_key;column:id"`
	ModelName   string `json:"model_name" gorm:"not null"`
	HFModelName string `json:"hf_model_name" gorm:"not null" validate:"required"`
	Status      string `json:"status"`
	ModelPath   string `json:"model_path"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	ProjectId   string `json:"project_id"`
}

type Deployment struct {
	ID               int       `json:"id" gorm:"primary_key"`
	HFModelName      string    `json:"hf_model_name" gorm:"not null" validate:"required"`
	UserEmail        string    `json:"user_email" gorm:"not null"`
	WorkspaceID      string    `json:"workspace_id" gorm:"not null;unique_index:edq_idx"`
	DeployedAt       time.Time `json:"deployed_at" gorm:"not null"`
	Ingress          string    `json:"ingress" gorm:"not null"`
	ReleaseName      string    `json:"release_name" gorm:"not null"`
	ClusterName      string    `json:"cluster_name" gorm:"not null" validate:"required"`
	NodeName         string    `json:"node_name" gorm:"not null" validate:"required"`
	ApiKey           string    `json:"api_key" gorm:"not null"`
	Environment      string    `json:"environment"`
	ProjectId        int       `json:"project_id"`
	ObservabilityUrl string    `json:"observability_url" gorm:"-"`
	LogsUrl          string    `json:"logs_url" gorm:"-"`
	GovernanceUrl    string    `json:"governance_url" gorm:"-"`
	DeploymentName   string    `json:"deployment_name"`
	IngressSubUrl    string    `json:"ingress_sub_url"`
	Workspace        string    `json:"workspace"`
}

// NodeMetrics represents detailed metrics for a single node
type NodeMetrics struct {
	ID                 int       `json:"id" gorm:"primary_key"`
	InfraIntegrationID int       `json:"infra_integration_id" gorm:"index"`
	NodeName           string    `json:"node_name"`
	InternalIP         string    `json:"internal_ip"`
	CPUAllocatable     string    `json:"cpu_allocatable"`    // in millicores
	CPUUsed            string    `json:"cpu_used"`           // in millicores
	CPUUtilization     float64   `json:"cpu_utilization"`    // percentage
	MemoryAllocatable  string    `json:"memory_allocatable"` // in bytes
	MemoryUsed         string    `json:"memory_used"`        // in bytes
	MemoryUtilization  float64   `json:"memory_utilization"` // percentage
	GPUAllocatable     string    `json:"gpu_allocatable"`
	GPUUsed            string    `json:"gpu_used"`
	GPUUtilization     float64   `json:"gpu_utilization"` // percentage
	GPUModel           string    `json:"gpu_model"`
	CPUModel           string    `json:"cpu_model"`
	CreatedAt          time.Time `json:"created_at"`
	UpdatedAt          time.Time `json:"updated_at"`
}

type InfraIntegration struct {
	ID                    int               `json:"id" gorm:"primary_key"`
	ClusterName           string            `json:"cluster_name" gorm:"unique_index:unq_index" form:"cluster_name"`
	Workspace             string            `json:"workspace" form:"workspace" gorm:"unique_index:unq_index"`
	CloudType             string            `json:"cloud_type" form:"cloud_type"`
	Framework             string            `json:"framework"  form:"framework"`
	UserName              string            `json:"user_name" form:"user_name"`
	UserEmail             string            `json:"user_email" form:"user_email"`
	Platform              string            `json:"-" form:"platform"`
	Helm                  bool              `json:"-"`
	Terraform             bool              `json:"-"`
	Ansible               bool              `json:"-"`
	FrameStatus           map[string]Status `json:"frame_status" gorm:"-"`
	AddedAt               int64             `json:"created_at" gorm:"-"`
	UpdateAt              int64             `json:"updated_at" gorm:"-"`
	CreatedAt             time.Time         `json:"-"`
	UpdatedAt             time.Time         `json:"-"`
	Environment           string            `json:"environment"`
	ProjectId             int               `json:"project_id"`
	Gpu                   string            `json:"gpu" gorm:"-"`
	Storage               string            `json:"storage" gorm:"-"`
	Cpu                   string            `json:"cpu" gorm:"-"`
	Ram                   string            `json:"ram" gorm:"-"`
	Nodes                 string            `json:"nodes" gorm:"-"`
	ActiveModels          []string          `json:"active_models" gorm:"-"`
	GpuUtilization        string            `json:"gpu_utilization" gorm:"-"`
	CpuUtilization        string            `json:"cpu_utilization" gorm:"-"`
	IsSuffiecientResource bool              `json:"is_suffiecient_resource" gorm:"-"`
	NodeMetrics           []NodeMetrics     `json:"node_metrics" gorm:"foreignkey:InfraIntegrationID"`
	TotalCPUAllocatable   string            `json:"total_cpu_allocatable" gorm:"-"`
	TotalCPUUsed          string            `json:"total_cpu_used" gorm:"-"`
	TotalCPUUtilization   string            `json:"total_cpu_utilization" gorm:"-"`
	Ingress               string            `json:"ingress"  form:"ingress"`
	IngressClass          string            `json:"ingress_class"  form:"ingress_class"`
	ObservabilityUrl      string            `json:"observability_url" gorm:"-"`
	LogsUrl               string            `json:"logs_url" gorm:"-"`
	GovernanceUrl         string            `json:"governance_url" gorm:"-"`
}

type VmDetailes struct {
	ID             int    `json:"id" gorm:"primary_key"`
	Name           string `json:"vm_name" gorm:"unique_index:unq_index" validate:"required"`
	UserName       string `json:"user_name" valiadte:"requried"`
	ClusterName    string `json:"cluster_name" gorm:"not null" validate:"required"`
	Workspace      string `json:"workspace"`
	CreatedBy      string `json:"created_by"`
	NodeType       string `json:"node_type"`
	SSHPort        int    `json:"ssh_port" gorm:"not null" validate:"required" `
	VmIP           string `json:"vm_ip" gorm:"not null" validate:"required"`
	ClusterIP      string `json:"cluster_ip"`
	Token          string `json:"token"`
	DiscoveryToken string `json:"discovery_token"`
	Environment    string `json:"environment"`
	ProjectId      string `json:"project_id"`
}

// Status of the integration
type Status struct {
	Msg         string `json:"message"`
	Health      int    `json:"health"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
	ProjectId   int    `json:"project_id"`
}

// InfraActivites stores every activity of ticket
type InfraActivites struct {
	ID          int    `json:"id" gorm:"primary"`
	InfraID     int    `json:"-"`
	InfraName   string `json:"infra_integration_name"`
	Workspace   string `json:"workspace"`
	Action      string `json:"action"`
	UserName    string `json:"user_name"`
	UserEmail   string `json:"user_email"`
	Status      string `json:"status"`
	SystemIP    string `json:"system_ip"`
	Reason      string `json:"reason"`
	CreatedAT   int64  `json:"created_at"`
	Environment string `json:"environment"`
	ProjectId   string `json:"project_id"`
}
