package test

import (
	"bytes"
	"encoding/json"
	"errors"

	// "fmt"
	// "os/exec"
	"regexp"

	"net/http"
	"net/http/httptest"

	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"helm.sh/helm/v3/pkg/action"

	// "git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/vmonboarding"
	// "helm.sh/helm/v3/pkg/action"

	jwt "gopkg.in/dgrijalva/jwt-go.v3"

	// "github.com/DATA-DOG/go-sqlmock"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestSaveVmPrivateKey(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db
	t.Run("Missing JSON Payload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/save-vm-key", nil)
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.SaveVmPrivateKey(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Please pass VM name.", response["message"])
	})

	t.Run("JWT Claims Extraction Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		reqBody := `{"node_name": "test-vm", "user_name": "test-user"}`
		req := httptest.NewRequest("POST", "/save-vm-key", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-cluster"})

		api.SaveVmPrivateKey(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Please login again", response["message"])
	})

	// t.Run("VM Does Not Exist in Cluster (Using Monkey)", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	// Simulate JWT Claims
	// 	claims := jwt.MapClaims{"workspace": "test-workspace"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	// Monkey patch GetWorkspaceID function
	// 	patch := monkey.Patch(api.GetWorkspaceID, func(_ string) string {
	// 		return "mocked-workspace-id"
	// 	})
	// 	defer patch.Unpatch() // Restore original function after test

	// 	// Mock database query to return an empty result (No VM exists)
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND cluster_name = $3)`)).
	// 		WithArgs("test-vm", "mocked-workspace-id", "test-cluster").
	// 		WillReturnRows(sqlmock.NewRows([]string{"id"})) // No VM found

	// 	reqBody := `{"node_name": "test-vm", "user_name": "test-user"}`
	// 	req := httptest.NewRequest("POST", "/save-vm-key", bytes.NewBufferString(reqBody))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req
	// 	ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-cluster"})

	// 	api.SaveVmPrivateKey(ctx)

	// 	// Function should proceed, but since RunGenerateKeyCommand is not mocked here, it'll fail at that point
	// 	assert.Equal(t, http.StatusInternalServerError, w.Code) // Because next step is unmocked
	// })

	t.Run("Successful Key Generation (Using Monkey Patch)", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "test-workspace"}
		ctx.Set("JWT_PAYLOAD", claims)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND cluster_name = $3)`)).
			WithArgs("test-vm", "workspace-id", "test-cluster").
			WillReturnRows(sqlmock.NewRows([]string{"id"})) // No VM found

		// Monkey patch RunGenerateKeyCommand function
		patch := monkey.Patch(vmonboarding.RunGenerateKeyCommand,
			func(_ string, _ string, _ string, _ string) (map[string]interface{}, error) {
				return map[string]interface{}{"public_key": "mocked-public-key"}, nil
			})
		defer patch.Unpatch()

		reqBody := `{"node_name": "test-vm", "user_name": "test-user"}`
		req := httptest.NewRequest("POST", "/save-vm-key", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-cluster"})

		api.SaveVmPrivateKey(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "Public Key generated successfully", response["message"])
		assert.Equal(t, "mocked-public-key", response["public_key"])
	})

	t.Run("Key Generation Failure (Using Monkey Patch)", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "test-workspace"}
		ctx.Set("JWT_PAYLOAD", claims)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND cluster_name = $3)`)).
			WithArgs("test-vm", "workspace-id", "test-cluster").
			WillReturnRows(sqlmock.NewRows([]string{"id"})) // No VM found

		// Monkey patch RunGenerateKeyCommand to return an error
		patch := monkey.Patch(vmonboarding.RunGenerateKeyCommand,
			func(_ string, _ string, _ string, _ string) (map[string]interface{}, error) {
				return nil, errors.New("Failed to generate key")
			})
		defer patch.Unpatch()

		reqBody := `{"node_name": "test-vm", "user_name": "test-user"}`
		req := httptest.NewRequest("POST", "/save-vm-key", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-cluster"})

		api.SaveVmPrivateKey(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Failed to generate key", response["message"])
	})
}

func TestVmOnboardingVMAlreayExists(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("VmOnboarding", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"workspace": "test-workspace", "email": "test@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch GetWorkspaceID and GetNameSpace functions
		patch1 := monkey.Patch(api.GetWorkspaceID, func(workspace string) string {
			return "test-workspace-id"
		})
		defer patch1.Unpatch()

		patch2 := monkey.Patch(api.GetNameSpace, func(workspaceID string) string {
			return "nexa-prod-test-workspace"
		})
		defer patch2.Unpatch()

		// Mock SetInfraConfig function
		patch3 := monkey.Patch(kubernetes.SetInfraConfig, func(nameSpace, clusterName, workspaceID, email string) (*action.Configuration, string, int, error) {
			return &action.Configuration{}, "path", 200, nil
		})
		defer patch3.Unpatch()

		// Mock RunGenerateTokenCommand function
		patch4 := monkey.Patch(vmonboarding.RunGenerateTokenCommand, func(path, nameSpace, clusterName, workspaceID, email string) (map[string]interface{}, error) {
			return map[string]interface{}{"token": "kubeadm join 192.168.1.1:6443 --token abcdef --discovery-token-ca-cert-hash sha256:xyz"}, nil
		})
		defer patch4.Unpatch()

		// Mock database query to return a VM node
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND user_name = $3) ORDER BY "vm_detailes"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace", "cluster_name"}).
				AddRow(1, "test-node", "test-workspace-id", "test-cluster"))

		// Mock database insert operation to succeed
		mock.ExpectExec(regexp.QuoteMeta(`INSERT INTO "vm_detailes" ("name","user_name","cluster_name","workspace","created_by","node_type","ssh_port","vm_ip","cluster_ip","token","discovery_token")`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnResult(sqlmock.NewResult(1, 1))

		reqBody := `{"name": "test-node", "user_name": "test-user", "cluster_name": "test-cluster", "vm_ip": "192.168.1.100", "ssh_port": 22, "node_type": "worker", "namespace":"nexa-prod-test-workspace"}`
		req := httptest.NewRequest("POST", "/vm-onboarding", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.VmOnboarding(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Vm name already exists in this cluster", response["message"])
	})
}

func TestVmOnboardingFailedCreateNewRecord(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("VmOnboardingFailedCreateNewRecord", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"workspace": "test-workspace", "email": "test@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch GetWorkspaceID and GetNameSpace functions
		patch1 := monkey.Patch(api.GetWorkspaceID, func(workspace string) string {
			return "test-workspace-id"
		})
		defer patch1.Unpatch()

		patch2 := monkey.Patch(api.GetNameSpace, func(workspaceID string) string {
			return "nexa-prod-test-workspace"
		})
		defer patch2.Unpatch()

		// Mock SetInfraConfig function
		patch3 := monkey.Patch(kubernetes.SetInfraConfig, func(nameSpace, clusterName, workspaceID, email string) (*action.Configuration, string, int, error) {
			return &action.Configuration{}, "path", 200, nil
		})
		defer patch3.Unpatch()

		// Mock RunGenerateTokenCommand function
		patch4 := monkey.Patch(vmonboarding.RunGenerateTokenCommand, func(path, nameSpace, clusterName, workspaceID, email string) (map[string]interface{}, error) {
			return map[string]interface{}{"token": "kubeadm join 192.168.1.1:6443 --token abcdef --discovery-token-ca-cert-hash sha256:xyz"}, nil
		})
		defer patch4.Unpatch()

		// Mock database query to return no VM node
		// mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND user_name = $3) ORDER BY "vm_detailes"."id" ASC LIMIT 1`)).
		// 	WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
		// 	WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace", "cluster_name"}))

		// Mock database insert operation to succeed
		mock.ExpectExec(regexp.QuoteMeta(`INSERT INTO "vm_detailes" ("name","user_name","cluster_name","workspace","created_by","node_type","ssh_port","vm_ip","cluster_ip","token","discovery_token")`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnResult(sqlmock.NewResult(0, 0))

		reqBody := `{"name": "test-node", "user_name": "test-user", "cluster_name": "test-cluster", "vm_ip": "192.168.1.100", "ssh_port": 22, "node_type": "worker", "namespace":"nexa-prod-test-workspace"}`
		req := httptest.NewRequest("POST", "/vm-onboarding", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.VmOnboarding(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Failed to create new record", response["message"])
	})
}

func TestVmOnboarding(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, _, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Invalid JSON Payload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"invalid_json":}`
		req := httptest.NewRequest("POST", "/vm-onboarding", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.VmOnboarding(ctx)

		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Please pass required detailes", response["message"])
	})

	t.Run("User Not Authenticated", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"name": "test-vm", "user_name": "test-user"}`
		req := httptest.NewRequest("POST", "/vm-onboarding", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.VmOnboarding(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Please login again", response["message"])
	})

	// t.Run("VM Already Exists", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
}

func TestDeleteVmNode(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Invalid JSON Payload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"invalid_json":}`
		req := httptest.NewRequest("DELETE", "/delete/vm/node/test-node", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-node"})

		api.DeleteVmNode(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Please pass valid cluster name.", response["message"])
	})

	t.Run("User  Not Authenticated", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"cluster_name": "test-cluster"}`
		req := httptest.NewRequest("DELETE", "/delete/vm/node/test-node", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-node"})

		api.DeleteVmNode(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("VM Node Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"workspace": "test-workspace", "email": "test@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch GetWorkspaceID and GetNameSpace functions
		patch1 := monkey.Patch(api.GetWorkspaceID, func(workspace string) string {
			return "test-workspace-id"
		})
		defer patch1.Unpatch()

		patch2 := monkey.Patch(api.GetNameSpace, func(workspaceID string) string {
			return "nexa-prod-test-workspace"
		})
		defer patch2.Unpatch()

		// Mock DeleteVmNode function
		patch3 := monkey.Patch(vmonboarding.DeleteVmNode, func(vmName, clusterName, workspaceID, nameSpace, email string) (map[string]interface{}, error) {
			return map[string]interface{}{"message": "Node deleted successfully"}, nil
		})
		defer patch3.Unpatch()

		// Mock database query to return no VM node
		mock.ExpectQuery(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND cluster_name = $3) ORDER BY "vm_detailes"."id" ASC LIMIT 1`).
			WithArgs("test-node", "test-workspace-id", "test-cluster").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace", "cluster_name"}))

		reqBody := `{"cluster_name": "test-cluster"}`
		req := httptest.NewRequest("DELETE", "/delete/vm/node/test-node", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-node"})

		api.DeleteVmNode(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "VM Node not found", response["message"])
	})

}

func TestDeleteVmNodeFailed(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Failed to Delete Node from Cluster", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"workspace": "test-workspace", "email": "test@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch GetWorkspaceID and GetNameSpace functions
		patch1 := monkey.Patch(api.GetWorkspaceID, func(workspace string) string {
			return "test-workspace-id"
		})
		defer patch1.Unpatch()

		patch2 := monkey.Patch(api.GetNameSpace, func(workspaceID string) string {
			return "nexa-prod-test-workspace"
		})
		defer patch2.Unpatch()

		// Mock DeleteVmNode function
		patch3 := monkey.Patch(vmonboarding.DeleteVmNode, func(vmName, clusterName, workspaceID, nameSpace, email string) (map[string]interface{}, error) {
			return map[string]interface{}{"message": "Node deleted successfully"}, nil
		})
		defer patch3.Unpatch()

		// Add data to the database

		// Mock database query to return a VM node
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND cluster_name = $3) ORDER BY "vm_detailes"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace", "cluster_name"}).
				AddRow(1, "test-node", "test-workspace-id", "test-cluster"))

		// Mock database delete operation to fail
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "vm_detailes" WHERE name = $1 AND workspace = $2 AND cluster_name = $3`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnError(errors.New("delete failed"))

		reqBody := `{"cluster_name": "test-cluster"}`
		req := httptest.NewRequest("DELETE", "/delete/vm/node/test-node", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-node"})

		api.DeleteVmNode(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Failed to delete node from test-cluster", response["message"])
	})

}

func TestDeleteVmNodeSuccess(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := SetupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Successful Node Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"workspace": "test-workspace", "email": "test@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch GetWorkspaceID and GetNameSpace functions
		patch1 := monkey.Patch(api.GetWorkspaceID, func(workspace string) string {
			return "test-workspace-id"
		})
		defer patch1.Unpatch()

		patch2 := monkey.Patch(api.GetNameSpace, func(workspaceID string) string {
			return "nexa-prod-test-workspace"
		})
		defer patch2.Unpatch()

		// Mock DeleteVmNode function
		patch3 := monkey.Patch(vmonboarding.DeleteVmNode, func(vmName, clusterName, workspaceID, nameSpace, email string) (map[string]interface{}, error) {
			return map[string]interface{}{"message": "Node deleted successfully"}, nil
		})
		defer patch3.Unpatch()

		// Mock database query to return a VM node
		// Mock database query to return a VM node
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "vm_detailes" WHERE (name = $1 AND workspace = $2 AND cluster_name = $3) ORDER BY "vm_detailes"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace", "cluster_name"}).
				AddRow(1, "test-node", "test-workspace-id", "test-cluster"))

		// Mock database transaction to begin
		mock.ExpectBegin()

		// Mock database delete operation to succeed
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "vm_detailes" WHERE "vm_detailes"."id" = $1`)).
			WithArgs(sqlmock.AnyArg()).
			WillReturnResult(sqlmock.NewResult(1, 1))

		// Mock database transaction to commit
		mock.ExpectCommit()

		reqBody := `{"cluster_name": "test-cluster"}`
		req := httptest.NewRequest("DELETE", "/delete/vm/node/test-node", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-node"})

		api.DeleteVmNode(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		json.NewDecoder(w.Body).Decode(&response)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "test-node node deleted successfully from test-cluster", response["message"])
	})
}

func TestNewFunction(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("NewFunction", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		vm := database.VmDetailes{
			Name:      "test-node",
			UserName:  "test-user",
			NodeType:  "worker",
			SSHPort:   22,
			VmIP:      "192.168.1.100",
			Workspace: "test-workspace-id",
		}
		err := errors.New("test error")
		token := "test-token"
		workspaceID := "test-workspace-id"
		mapd := make(map[string]interface{})
		c, _ := gin.CreateTestContext(httptest.NewRecorder())

		// Mock UpdateYamlFile function
		patch1 := monkey.Patch(methods.UpdateYamlFile, func(ansiblePath string, changingValues map[string]interface{}, token string) error {
			return nil
		})
		defer patch1.Unpatch()

		// Mock CreateInventoryFile function
		patch2 := monkey.Patch(methods.CreateInventoryFile, func(vmIP string, userName string, sshPort int) error {
			return nil
		})
		defer patch2.Unpatch()

		ansiblePath, err, stop := api.Ansible(vm, err, token, workspaceID, mapd, c)
		assert.Equal(t, "ansible/main.yml", ansiblePath)
		assert.Nil(t, err)
		assert.False(t, stop)
	})

}
