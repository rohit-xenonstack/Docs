package test

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/signup"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

// SignupEndpoint is a api handler for creating accounts

func TestSignupEndpoint(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test when the request body is invalid
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with invalid JSON body (missing required fields)
		req := httptest.NewRequest("POST", "/signup", bytes.NewBufferString(`{"email":""}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SignupEndpoint handler
		api.SignupEndpoint(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for missing fields
		expectedResponse := `{"error":true,"message":"email, password and name are required fields."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when the email is invalid
	t.Run("Invalid Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock ValidateEmail to return false for invalid email
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return false
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with invalid email
		req := httptest.NewRequest("POST", "/signup", bytes.NewBufferString(`{"email":"invalid-email","password":"Test@1234","name":"John Doe"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SignupEndpoint handler
		api.SignupEndpoint(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for invalid email
		expectedResponse := `{"error":true,"message":"Please pass valid email address"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when the password is invalid
	t.Run("Invalid Password", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock CheckPassword to return false for invalid password
		monkey.Patch(methods.CheckPassword, func(password string) bool {
			return false
		})
		defer monkey.Unpatch(methods.CheckPassword)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with invalid password
		req := httptest.NewRequest("POST", "/signup", bytes.NewBufferString(`{"email":"test@example.com","password":"weakpass","name":"John Doe"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SignupEndpoint handler
		api.SignupEndpoint(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for invalid password
		expectedResponse := `{"error":true,"message":"Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when the signup fails
	t.Run("Signup Failed", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock Signup to return failure
		monkey.Patch(signup.Signup, func(acs database.Accounts) (string, bool) {
			return "Email already exists", false
		})
		defer monkey.Unpatch(signup.Signup)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with valid data but signup fails
		req := httptest.NewRequest("POST", "/signup", bytes.NewBufferString(`{"email":"test@example.com","password":"Test@1234","name":"John Doe"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SignupEndpoint handler
		api.SignupEndpoint(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for signup failure
		expectedResponse := `{"error":true,"message":"Email already exists"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when the signup is successful
	t.Run("Signup Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock Signup to return success
		monkey.Patch(signup.Signup, func(acs database.Accounts) (string, bool) {
			return "Signup successful", true
		})
		defer monkey.Unpatch(signup.Signup)

		monkey.Patch(api.AssignRoleToUser, func(signupdt models.SignupData) (err error) {
			return nil
		})

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with valid data
		req := httptest.NewRequest("POST", "/signup", bytes.NewBufferString(`{"email":"test@example.com","password":"Test@1234","name":"John Doe"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SignupEndpoint handler
		api.SignupEndpoint(ctx)

		// Assert that the response status code is 200 OK
		assert.Equal(t, http.StatusOK, w.Code)

		// Assert that the response contains the success message
		expectedResponse := `{"error":false,"message":"Signup successful"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}

func TestSendCodeAgain(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test when the request body is invalid
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with invalid JSON body (missing the email field)
		req := httptest.NewRequest("POST", "/send-code-again", bytes.NewBufferString(`{"email":""}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SendCodeAgain handler
		api.SendCodeAgain(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for missing email
		expectedResponse := `{"error":true,"message":"Email is required."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when the email is invalid
	t.Run("Invalid Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock ValidateEmail to return false for invalid email
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return false
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with an invalid email
		req := httptest.NewRequest("POST", "/send-code-again", bytes.NewBufferString(`{"email":"invalid-email"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SendCodeAgain handler
		api.SendCodeAgain(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for invalid email
		expectedResponse := `{"error":true,"message":"Please enter valid email id."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when sending the code again fails
	t.Run("Failed to Send Code Again", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock SendCodeAgain to return failure
		monkey.Patch(signup.SendCodeAgain, func(email string) (string, bool) {
			return "Unable to send verification code", false
		})
		defer monkey.Unpatch(signup.SendCodeAgain)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with valid email but SendCodeAgain fails
		req := httptest.NewRequest("POST", "/send-code-again", bytes.NewBufferString(`{"email":"test@example.com"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SendCodeAgain handler
		api.SendCodeAgain(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message for failure to send code
		expectedResponse := `{"error":true,"message":"Unable to send verification code"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when sending the code again is successful
	t.Run("Send Code Again Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock SendCodeAgain to return success
		monkey.Patch(signup.SendCodeAgain, func(email string) (string, bool) {
			return "Verification code sent successfully", true
		})
		defer monkey.Unpatch(signup.SendCodeAgain)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with valid email
		req := httptest.NewRequest("POST", "/send-code-again", bytes.NewBufferString(`{"email":"test@example.com"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the SendCodeAgain handler
		api.SendCodeAgain(ctx)

		// Assert that the response status code is 200 OK
		assert.Equal(t, http.StatusOK, w.Code)

		// Assert that the response contains the success message
		expectedResponse := `{"error":false,"message":"Verification code sent successfully"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}
