package test

import (
	"context"
	"errors"
	"fmt"
	"os"
	"reflect"
	"testing"

	"bou.ke/monkey"
	src_api "git.xenonstack.com/nexa-platform/accounts/src/api"
	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
	"google.golang.org/api/googleapi"

	"github.com/hashicorp/vault/api"

	"google.golang.org/api/container/v1"
	"google.golang.org/api/option"

	"github.com/stretchr/testify/assert"
)

// Mocked function that simulates the API call to list clusters.
func TestNewVaultClient(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setting environment variables for testing
	os.Setenv("VAULT_ADDR", "http://localhost:8200")
	os.Setenv("VAULT_TOKEN", "mock-token")

	t.Run("Successful Vault Client Creation", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Monkey patch the api.NewClient function to simulate successful client creation
		monkey.Patch(api.NewClient, func(config *api.Config) (*api.Client, error) {
			client := &api.Client{}
			return client, nil
		})
		defer monkey.Unpatch(api.NewClient)

		// Call NewVaultClient
		client, err := src_api.NewVaultClient()

		// Assertions
		assert.NoError(t, err)
		assert.NotNil(t, client)
		// assert.Equal(t, "mock-token", client.client.Token()) // Ensure the token is set correctly
	})

	t.Run("Vault Client Creation Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Monkey patch the api.NewClient function to simulate an error in client creation
		monkey.Patch(api.NewClient, func(config *api.Config) (*api.Client, error) {
			return nil, errors.New("failed to create client")
		})
		defer monkey.Unpatch(api.NewClient)

		// Call NewVaultClient
		client, err := src_api.NewVaultClient()

		// Assertions
		assert.Error(t, err)
		assert.Nil(t, client)
		assert.EqualError(t, err, "failed to create client")
	})
}

func TestStoreCredentials(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup environment variables for testing
	os.Setenv("VAULT_ADDR", "http://localhost:8200")
	os.Setenv("VAULT_TOKEN", "mock-token")

	// Initialize a mock VaultClient with a properly initialized api.Client
	client, err := api.NewClient(nil)
	if err != nil {
		t.Fatalf("Failed to initialize Vault client: %v", err)
	}
	vaultClient := &src_api.VaultClient{
		Client: client,
	}

	t.Run("Successful Store Credentials", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		logicalMock := client.Logical()

		// Monkey patch WriteWithContext method to simulate a successful write
		monkey.PatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string]interface{}) (*api.Secret, error) {
				return &api.Secret{}, nil
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext")

		// Call StoreCredentials with mock values
		err := vaultClient.StoreCredentials("customer123", "clusterABC", []byte("some-credentials"))

		// Assert that there is no error
		assert.NoError(t, err)
	})

	t.Run("Failed Store Credentials - Write Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		logicalMock := client.Logical()

		// Monkey patch WriteWithContext method to simulate a write failure
		monkey.PatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string]interface{}) (*api.Secret, error) {
				return nil, errors.New("failed to write credentials")
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext")

		// Call StoreCredentials with mock values
		err := vaultClient.StoreCredentials("customer123", "clusterABC", []byte("some-credentials"))

		// Assert that an error is returned
		assert.Error(t, err)
		assert.EqualError(t, err, "failed to write credentials")
	})

	t.Run("Failed Store Credentials - Invalid Path", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		logicalMock := client.Logical()

		// Monkey patch WriteWithContext method to simulate an invalid path error
		monkey.PatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string]interface{}) (*api.Secret, error) {
				if path != "gcp/customer123/clusterABC/credentials" {
					return nil, errors.New("invalid path")
				}
				return &api.Secret{}, nil
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext")

		// Call StoreCredentials with an incorrect path
		err := vaultClient.StoreCredentials("customer123", "wrongCluster", []byte("some-credentials"))

		// Assert that an error is returned for invalid path
		assert.Error(t, err)
		assert.EqualError(t, err, "invalid path")
	})
}

func TestGetCredentials(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Mock Vault Client
	mockClient, _ := api.NewClient(nil)                     // Ensure a non-nil client
	vaultClient := &src_api.VaultClient{Client: mockClient} // Use mockClient

	expectedPath := "gcp/customer123/clusterABC/credentials"
	mockCreds := "mocked-credentials-json"

	// Patch ReadWithDataWithContext
	monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
		func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
			if path != expectedPath {
				return nil, fmt.Errorf("unexpected path: %s", path)
			}
			return &api.Secret{Data: map[string]interface{}{"credentials": mockCreds}}, nil
		},
	)
	defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

	t.Run("Successful Get Credentials", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		creds, err := vaultClient.GetCredentials("customer123", "clusterABC")
		assert.NoError(t, err)
		assert.NotNil(t, creds)
		assert.Equal(t, []byte(mockCreds), creds)
	})

	t.Run("Failed Get Credentials - Read Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
				return nil, errors.New("vault read error")
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

		creds, err := vaultClient.GetCredentials("customer123", "clusterABC")
		assert.Error(t, err)
		assert.Nil(t, creds)
		assert.EqualError(t, err, "vault read error")
	})

	t.Run("Failed Get Credentials - No Data", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
				return nil, nil
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

		creds, err := vaultClient.GetCredentials("customer123", "clusterABC")
		assert.Error(t, err)
		assert.Nil(t, creds)
		assert.EqualError(t, err, fmt.Sprintf("no credentials found at %s", expectedPath))
	})

	t.Run("Failed Get Credentials - Invalid Format", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
				return &api.Secret{Data: map[string]interface{}{"credentials": 123}}, nil
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

		creds, err := vaultClient.GetCredentials("customer123", "clusterABC")
		assert.Error(t, err)
		assert.Nil(t, creds)
		assert.EqualError(t, err, "invalid credential format")
	})
}

func TestStoreClusterInfo(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Mock Vault API Client
	mockClient, _ := api.NewClient(nil) // Ensures the client is properly initialized
	client, err := api.NewClient(nil)
	if err != nil {
		t.Fatalf("Failed to initialize Vault client: %v", err)
	}
	vaultClient := &src_api.VaultClient{
		Client: mockClient,
	}

	clusterInfo := src_api.ClusterInfo{
		CustomerID:    "customer123",
		ClusterName:   "clusterABC",
		ProjectID:     "project-xyz",
		Location:      "us-central1",
		Endpoint:      "https://cluster-endpoint.com",
		MasterVersion: "1.24",
		NodeCount:     3,
	}

	t.Run("Successful Store Cluster Info", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		logicalMock := client.Logical()

		// Monkey patch Logical().Write to simulate success
		// Monkey patch WriteWithContext method to simulate a successful write
		monkey.PatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string]interface{}) (*api.Secret, error) {
				return &api.Secret{}, nil
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext")

		// Call StoreClusterInfo
		err := vaultClient.StoreClusterInfo(clusterInfo)

		// Assertions
		assert.NoError(t, err)
	})

	t.Run("Failed Store Cluster Info - Write Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		logicalMock := client.Logical()

		// Monkey patch Logical().Write to simulate success
		// Monkey patch WriteWithContext method to simulate a successful write
		monkey.PatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string]interface{}) (*api.Secret, error) {
				return nil, errors.New("failed to store cluster info")
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext")

		// Call StoreClusterInfo
		err := vaultClient.StoreClusterInfo(clusterInfo)

		// Assertions
		assert.Error(t, err)
		assert.EqualError(t, err, "failed to store cluster info")
	})

	t.Run("Failed Store Cluster Info - Invalid Path", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		logicalMock := client.Logical()

		monkey.PatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string]interface{}) (*api.Secret, error) {
				return nil, errors.New("invalid path")
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(logicalMock), "WriteWithContext")

		// Call StoreClusterInfo with incorrect ClusterName
		invalidClusterInfo := clusterInfo
		invalidClusterInfo.ClusterName = "wrongCluster"

		err := vaultClient.StoreClusterInfo(invalidClusterInfo)

		// Assertions
		assert.Error(t, err)
		assert.EqualError(t, err, "invalid path")
	})
}

func TestGetClusterInfo(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Mock Vault Client
	mockClient, _ := api.NewClient(nil)                     // Ensure a non-nil client
	vaultClient := &src_api.VaultClient{Client: mockClient} // Use mockClient

	expectedPath := "gcp/customer123/clusterABC/info"
	mockData := map[string]interface{}{
		"project_id":     "project-xyz",
		"location":       "us-central1",
		"endpoint":       "https://cluster-endpoint.com",
		"master_version": "1.24",
		"node_count":     3.0,
	}

	// Patch ReadWithDataWithContext instead of Read
	monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
		func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
			if path != expectedPath {
				return nil, fmt.Errorf("unexpected path: %s", path)
			}
			return &api.Secret{Data: mockData}, nil
		},
	)
	defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

	t.Run("Successful Get Cluster Info", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		info, err := vaultClient.GetClusterInfo("customer123", "clusterABC")

		// Assertions
		assert.NoError(t, err)
		assert.NotNil(t, info)
		assert.Equal(t, "project-xyz", info.ProjectID)
		assert.Equal(t, "us-central1", info.Location)
		assert.Equal(t, "https://cluster-endpoint.com", info.Endpoint)
		assert.Equal(t, "1.24", info.MasterVersion)
		assert.Equal(t, 3, info.NodeCount)
	})

	t.Run("Failed Get Cluster Info - Read Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Patch ReadWithDataWithContext to return an error
		monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
				return nil, errors.New("vault read error")
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

		// Call GetClusterInfo
		info, err := vaultClient.GetClusterInfo("customer123", "clusterABC")

		// Assertions
		assert.Error(t, err)
		assert.Nil(t, info)
		assert.EqualError(t, err, "vault read error")
	})

	t.Run("Failed Get Cluster Info - No Data", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Patch ReadWithDataWithContext to return nil
		monkey.PatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext",
			func(_ *api.Logical, ctx context.Context, path string, data map[string][]string) (*api.Secret, error) {
				return nil, nil
			},
		)
		defer monkey.UnpatchInstanceMethod(reflect.TypeOf(&api.Logical{}), "ReadWithDataWithContext")

		// Call GetClusterInfo
		info, err := vaultClient.GetClusterInfo("customer123", "clusterABC")

		// Assertions
		assert.Error(t, err)
		assert.Nil(t, info)
		assert.EqualError(t, err, fmt.Sprintf("no cluster info found at %s", expectedPath))
	})
}

func TestVerifyGCPCredentials(t *testing.T) {
	SetupLogging()
	ResetLogs()
	validCredentials := []byte(`{"type": "service_account", "project_id": "mock-project"}`)
	invalidCredentials := []byte(`{"invalid": "json"}`)

	projectID := "mock-project"
	location := "mock-location"
	clusterName := "mock-cluster"

	t.Run("Successful Verification", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Patch container.NewService to return a mock service
		monkey.Patch(container.NewService, func(ctx context.Context, opts ...option.ClientOption) (*container.Service, error) {
			return &container.Service{
				Projects: &container.ProjectsService{
					Locations: &container.ProjectsLocationsService{
						Clusters: &container.ProjectsLocationsClustersService{},
					},
				},
			}, nil
		})

		// Patch cluster request to simulate a successful API call
		monkey.PatchInstanceMethod(reflect.TypeOf(&container.ProjectsLocationsClustersGetCall{}), "Do",
			func(_ *container.ProjectsLocationsClustersGetCall, opts ...googleapi.CallOption) (*container.Cluster, error) {
				return &container.Cluster{Name: clusterName}, nil
			},
		)

		defer monkey.UnpatchAll()

		err := src_api.VerifyGCPCredentials(validCredentials, projectID, location, clusterName)
		assert.NoError(t, err)
	})

	t.Run("Invalid Credentials - Failed to Create Container Service", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(container.NewService, func(ctx context.Context, opts ...option.ClientOption) (*container.Service, error) {
			return nil, errors.New("failed to create container service")
		})
		defer monkey.Unpatch(container.NewService)

		err := src_api.VerifyGCPCredentials(invalidCredentials, projectID, location, clusterName)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "invalid credentials - failed to create container service")
	})

	t.Run("Invalid Credentials - Failed to Verify Cluster Access", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(container.NewService, func(ctx context.Context, opts ...option.ClientOption) (*container.Service, error) {
			return &container.Service{
				Projects: &container.ProjectsService{
					Locations: &container.ProjectsLocationsService{
						Clusters: &container.ProjectsLocationsClustersService{},
					},
				},
			}, nil
		})

		monkey.PatchInstanceMethod(reflect.TypeOf(&container.ProjectsLocationsClustersGetCall{}), "Do",
			func(_ *container.ProjectsLocationsClustersGetCall, opts ...googleapi.CallOption) (*container.Cluster, error) {
				return nil, errors.New("cluster access denied")
			},
		)

		defer monkey.UnpatchAll()

		err := src_api.VerifyGCPCredentials(validCredentials, projectID, location, clusterName)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "invalid credentials - failed to verify access to cluster")
	})
}

func TestOnboardGKECluster(t *testing.T) {
	SetupLogging()
	ResetLogs()
	clusterName := "mock-cluster"
	validCredentials := []byte(`{"type": "service_account", "project_id": "mock-project", "client_email": "user@example.com"}`)
	invalidCredentials := []byte(`{"invalid": "json"}`)
	customerID := "mock-customer"
	location := "mock-location"

	// Mock Vault Client
	mockVault := &src_api.VaultClient{}
	monkey.Patch(src_api.NewVaultClient, func() (*src_api.VaultClient, error) {
		return mockVault, nil
	})
	defer monkey.UnpatchAll()

	// Mock deriveCustomerID
	monkey.Patch(src_api.DeriveCustomerID, func(email string) string {
		if email == "user@example.com" {
			return customerID
		}
		return ""
	})

	// Mock container.NewService
	monkey.Patch(container.NewService, func(ctx context.Context, opts ...option.ClientOption) (*container.Service, error) {
		return &container.Service{
			Projects: &container.ProjectsService{
				Locations: &container.ProjectsLocationsService{
					Clusters: &container.ProjectsLocationsClustersService{},
				},
			},
		}, nil
	})

	// Mock findClusterLocation
	monkey.Patch(src_api.FindClusterLocation, func(service *container.Service, projectID, clusterName string) (string, error) {
		return location, nil
	})

	// Mock VerifyGCPCredentials
	monkey.Patch(src_api.VerifyGCPCredentials, func(credentials []byte, projectID, location, clusterName string) error {
		return nil
	})

	monkey.PatchInstanceMethod(reflect.TypeOf(&container.ProjectsLocationsClustersGetCall{}), "Do",
		func(_ *container.ProjectsLocationsClustersGetCall, opts ...googleapi.CallOption) (*container.Cluster, error) {
			return &container.Cluster{
				Endpoint:             "mock-endpoint",
				CurrentMasterVersion: "1.20",
				MasterAuth: &container.MasterAuth{
					ClusterCaCertificate: "mock-ca-cert",
				},
				NodePools: []*container.NodePool{
					{InitialNodeCount: 3},
					{InitialNodeCount: 2},
				},
			}, nil
		},
	)

	// Mock CheckKubernetesCluster
	monkey.Patch(src_api.CheckKubernetesCluster, func(endpoint string, credentials []byte, caCert string) error {
		return nil
	})

	// Mock Vault Methods
	monkey.PatchInstanceMethod(reflect.TypeOf(mockVault), "GetCredentials",
		func(_ *src_api.VaultClient, customerID, clusterName string) ([]byte, error) {
			return nil, errors.New("no credentials found")
		})

	monkey.PatchInstanceMethod(reflect.TypeOf(mockVault), "GetClusterInfo",
		func(_ *src_api.VaultClient, customerID, clusterName string) (*src_api.ClusterInfo, error) {
			return nil, errors.New("no cluster info found")
		})

	monkey.PatchInstanceMethod(reflect.TypeOf(mockVault), "StoreCredentials",
		func(_ *src_api.VaultClient, customerID, clusterName string, credentials []byte) error {
			return nil
		})

	monkey.PatchInstanceMethod(reflect.TypeOf(mockVault), "StoreClusterInfo",
		func(_ *src_api.VaultClient, info src_api.ClusterInfo) error {
			return nil
		})

	t.Run("Successful Onboarding", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		err := src_api.OnboardGKECluster(clusterName, validCredentials)
		assert.NoError(t, err)
	})

	t.Run("Vault Client Initialization Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(src_api.NewVaultClient, func() (*src_api.VaultClient, error) {
			return nil, errors.New("failed to initialize Vault client")
		})
		defer monkey.Unpatch(src_api.NewVaultClient)

		err := src_api.OnboardGKECluster(clusterName, validCredentials)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to initialize Vault client")
	})

	t.Run("Invalid Credentials JSON", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		err := src_api.OnboardGKECluster(clusterName, invalidCredentials)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "project_id missing in credentials JSON")
	})

	t.Run("Missing Project ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		missingProjectCreds := []byte(`{"client_email": "user@example.com"}`)
		err := src_api.OnboardGKECluster(clusterName, missingProjectCreds)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "project_id missing")
	})

	t.Run("Customer ID Derivation Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(src_api.DeriveCustomerID, func(email string) string {
			return ""
		})
		defer monkey.Unpatch(src_api.DeriveCustomerID)

		err := src_api.OnboardGKECluster(clusterName, validCredentials)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "could not derive customer_id")
	})

	t.Run("Failed to Create Container Service", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(container.NewService, func(ctx context.Context, opts ...option.ClientOption) (*container.Service, error) {
			return nil, errors.New("failed to create container service")
		})
		defer monkey.Unpatch(container.NewService)

		err := src_api.OnboardGKECluster(clusterName, validCredentials)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to create container service")
	})

	// t.Run("Cluster Location Determination Failure", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	monkey.Patch(src_api.FindClusterLocation, func(service *container.Service, projectID, clusterName string) (string, error) {
	// 		return "", errors.New("location not found")
	// 	})
	// 	defer monkey.Unpatch(src_api.FindClusterLocation)

	// 	err := src_api.OnboardGKECluster(clusterName, validCredentials)
	// 	assert.Error(t, err)
	// 	assert.Contains(t, err.Error(), "failed to determine cluster location")
	// })

	// t.Run("Failed Kubernetes Cluster Verification", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	monkey.Patch(src_api.CheckKubernetesCluster, func(endpoint string, credentials []byte, caCert string) error {
	// 		return errors.New("cluster verification failed")
	// 	})
	// 	defer monkey.Unpatch(src_api.CheckKubernetesCluster)

	// 	err := src_api.OnboardGKECluster(clusterName, validCredentials)
	// 	assert.Error(t, err)
	// 	assert.Contains(t, err.Error(), "failed to verify Kubernetes cluster")
	// })
}

// Mock credentials response
var mockToken = &oauth2.Token{
	AccessToken: "mock-access-token",
}

// Mock google.CredentialsFromJSON response
func mockCredentialsFromJSON(_ context.Context, _ []byte, _ ...string) (*google.Credentials, error) {
	return &google.Credentials{
		TokenSource: oauth2.StaticTokenSource(mockToken),
	}, nil
}

type MockTokenSource struct{}

// Mock Token() function to return a fake access token
func (m *MockTokenSource) Token() (*oauth2.Token, error) {
	return &oauth2.Token{AccessToken: "mock-access-token"}, nil
}

// Test for GenerateGKEAuthToken
func TestGenerateGKEAuthToken(t *testing.T) {
	SetupLogging()
	ResetLogs()
	ctx := context.Background()
	mockCredentials := []byte(`{"type": "service_account", "private_key": "mock-key"}`)

	monkey.Patch(google.CredentialsFromJSON, func(_ context.Context, _ []byte, _ ...string) (*google.Credentials, error) {
		return &google.Credentials{
			TokenSource: &MockTokenSource{},
		}, nil
	})

	// t.Run("Success", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	token, err := src_api.GenerateGKEAuthToken(ctx, mockCredentials)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "mock-access-token", token)
	// })

	// t.Run("Failure in CredentialsFromJSON", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	monkey.Patch(google.CredentialsFromJSON, func(_ context.Context, _ []byte, _ ...string) (*google.Credentials, error) {
	// 		return nil, errors.New("failed to create credentials")
	// 	})

	// 	_, err := src_api.GenerateGKEAuthToken(ctx, mockCredentials)
	// 	assert.Error(t, err)
	// 	assert.Contains(t, err.Error(), "failed to create token source from credentials")
	// })

	t.Run("Failure in Fetching Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.PatchInstanceMethod(reflect.TypeOf(&MockTokenSource{}), "Token",
			func(_ *MockTokenSource) (*oauth2.Token, error) {
				return nil, errors.New("failed to fetch token")
			})

		_, err := src_api.GenerateGKEAuthToken(ctx, mockCredentials)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to fetch token")
	})
}

func TestGetTotalNodeCount(t *testing.T) {
	SetupLogging()
	ResetLogs()
	tests := []struct {
		name     string
		cluster  *container.Cluster
		expected int
	}{
		{
			name: "Single node pool with nodes",
			cluster: &container.Cluster{
				NodePools: []*container.NodePool{
					{InitialNodeCount: 3},
				},
			},
			expected: 3,
		},
		{
			name: "Multiple node pools with nodes",
			cluster: &container.Cluster{
				NodePools: []*container.NodePool{
					{InitialNodeCount: 3},
					{InitialNodeCount: 5},
				},
			},
			expected: 8,
		},
		{
			name: "Cluster with no node pools",
			cluster: &container.Cluster{
				NodePools: []*container.NodePool{},
			},
			expected: 0,
		},
		{
			name: "Node pools with zero nodes",
			cluster: &container.Cluster{
				NodePools: []*container.NodePool{
					{InitialNodeCount: 0},
					{InitialNodeCount: 0},
				},
			},
			expected: 0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			result := src_api.GetTotalNodeCount(tt.cluster)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestDeriveCustomerID(t *testing.T) {
	SetupLogging()
	ResetLogs()
	tests := []struct {
		name     string
		email    string
		expected string
	}{
		{
			name:     "Valid email",
			email:    "user@example.com",
			expected: "example.com",
		},
		{
			name:     "Valid email with subdomain",
			email:    "user@sub.example.com",
			expected: "sub.example.com",
		},
		{
			name:     "Email without domain",
			email:    "user@", // Edge case
			expected: "",
		},
		{
			name:     "Email without username",
			email:    "@example.com", // Edge case
			expected: "example.com",
		},
		{
			name:     "Completely invalid email",
			email:    "invalid-email",
			expected: "",
		},
		{
			name:     "Empty email string",
			email:    "",
			expected: "",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			result := src_api.DeriveCustomerID(tt.email)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestFindClusterLocation(t *testing.T) {
	SetupLogging()
	ResetLogs()
	projectID := "test-project"
	clusterName := "test-cluster"
	expectedLocation := "us-central1-a"

	t.Run("Cluster found successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		patchListClusters([]*container.Cluster{
			{Name: clusterName, Location: expectedLocation},
		}, nil)
		defer monkey.UnpatchAll()

		mockService := &container.Service{
			Projects: &container.ProjectsService{
				Locations: &container.ProjectsLocationsService{
					Clusters: &container.ProjectsLocationsClustersService{},
				},
			},
		}
		location, err := src_api.FindClusterLocation(mockService, projectID, clusterName)

		assert.NoError(t, err)
		assert.Equal(t, expectedLocation, location)
	})

	t.Run("Cluster not found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		patchListClusters([]*container.Cluster{}, nil)
		defer monkey.UnpatchAll()

		mockService := &container.Service{
			Projects: &container.ProjectsService{
				Locations: &container.ProjectsLocationsService{
					Clusters: &container.ProjectsLocationsClustersService{},
				},
			},
		}
		_, err := src_api.FindClusterLocation(mockService, projectID, clusterName)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), fmt.Sprintf("cluster %s not found in project %s", clusterName, projectID))
	})

	t.Run("API call fails", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		patchListClusters(nil, errors.New("API failure"))
		defer monkey.UnpatchAll()

		mockService := &container.Service{
			Projects: &container.ProjectsService{
				Locations: &container.ProjectsLocationsService{
					Clusters: &container.ProjectsLocationsClustersService{},
				},
			},
		}
		_, err := src_api.FindClusterLocation(mockService, projectID, clusterName)

		assert.Error(t, err)
		assert.Contains(t, err.Error(), "failed to list clusters: API failure")
	})
}

// ✅ **Fix: Properly mock `List().Do()`**
func patchListClusters(mockClusters []*container.Cluster, mockErr error) {
	// Mock `service.Projects.Locations.Clusters.List(parent)`
	monkey.PatchInstanceMethod(
		reflect.TypeOf(&container.ProjectsLocationsClustersService{}), "List",
		func(_ *container.ProjectsLocationsClustersService, _ string) *container.ProjectsLocationsClustersListCall {
			return &container.ProjectsLocationsClustersListCall{}
		},
	)

	// Mock `service.Projects.Locations.Clusters.List(parent).Do()`
	monkey.PatchInstanceMethod(
		reflect.TypeOf(&container.ProjectsLocationsClustersListCall{}), "Do",
		func(_ *container.ProjectsLocationsClustersListCall, _ ...googleapi.CallOption) (*container.ListClustersResponse, error) {
			if mockErr != nil {
				return nil, mockErr
			}
			return &container.ListClustersResponse{Clusters: mockClusters}, nil
		},
	)
}

// MockClusterListCall mimics the API response
type MockClusterListCall struct {
	Clusters []*container.Cluster
	Err      error
}
