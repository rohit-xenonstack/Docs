package test

import (
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	// Import the Redis package

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

func TestCheckToken(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a mock Gin context and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Call the CheckToken handler
		api.CheckToken(ctx)

		// Assert the response is 200 with an empty JSON object
		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{}`, w.Body.String())
	})
}

func TestRefreshToken(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Token Refreshed Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "role": "admin"}
		ctx.Set("JWT_PAYLOAD", claims)

		ctx.Request = httptest.NewRequest("POST", "/refresh", nil)
		ctx.Request.Header.Set("Authorization", "Bearer old_token")

		// Mock ConvertID
		monkey.Patch(methods.ConvertID, func(_ interface{}) int { return 1 })
		defer monkey.Unpatch(methods.ConvertID)

		// Mock GetAccountForid
		monkey.Patch(accounts.GetAccountForid, func(_ int) database.Accounts {
			return database.Accounts{Name: "Test User", Email: "user@example.com", RoleID: "user"}
		})
		defer monkey.Unpatch(accounts.GetAccountForid)

		// Mock JwtRefreshToken
		monkey.Patch(jwtToken.JwtRefreshToken, func(claims map[string]interface{}) (map[string]interface{}, error) {
			return map[string]interface{}{"token": "new_token", "role": "new_role", "workspace_role": "workspace_role"}, nil
		})
		defer monkey.Unpatch(jwtToken.JwtRefreshToken)

		// Mock DeleteToken
		monkey.Patch(redisdb.DeleteToken, func(key string) error { return nil })
		defer monkey.Unpatch(redisdb.DeleteToken)

		api.RefreshToken(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		log.Println("response: ", response)

		assert.Equal(t, "new_token", response["token"])
		assert.Equal(t, "Test User", response["name"])
		assert.Equal(t, "user@example.com", response["email"])
	})

	t.Run("Failure - Error Generating Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "role": "admin"}
		ctx.Set("JWT_PAYLOAD", claims)

		ctx.Request = httptest.NewRequest("POST", "/refresh", nil)
		ctx.Request.Header.Set("Authorization", "Bearer old_token")

		// Mock ConvertID
		monkey.Patch(methods.ConvertID, func(_ interface{}) int { return 1 })
		defer monkey.Unpatch(methods.ConvertID)

		// Mock GetAccountForid
		monkey.Patch(accounts.GetAccountForid, func(_ int) database.Accounts {
			return database.Accounts{Name: "Test User", Email: "user@example.com", RoleID: "user"}
		})
		defer monkey.Unpatch(accounts.GetAccountForid)

		// Mock JwtRefreshToken (Return error)
		monkey.Patch(jwtToken.JwtRefreshToken, func(claims map[string]interface{}) (map[string]interface{}, error) {
			return nil, errors.New("token generation error")
		})
		defer monkey.Unpatch(jwtToken.JwtRefreshToken)

		api.RefreshToken(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		log.Println("response: ", response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "token generation error", response["message"])
	})

	t.Run("Failure - Error Deleting Old Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		temp := config.Conf.Service.IsLogoutOthers
		defer func() {
			config.Conf.Service.IsLogoutOthers = temp
		}()
		config.Conf.Service.IsLogoutOthers = "false"
		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "role": "admin"}
		ctx.Set("JWT_PAYLOAD", claims)

		ctx.Request = httptest.NewRequest("POST", "/refresh", nil)
		ctx.Request.Header.Set("Authorization", "Bearer old_token")

		// Mock ConvertID
		monkey.Patch(methods.ConvertID, func(_ interface{}) int { return 1 })
		defer monkey.Unpatch(methods.ConvertID)

		// Mock GetAccountForid
		monkey.Patch(accounts.GetAccountForid, func(_ int) database.Accounts {
			return database.Accounts{Name: "Test User", Email: "user@example.com", RoleID: "user"}
		})
		defer monkey.Unpatch(accounts.GetAccountForid)

		// Mock JwtRefreshToken
		monkey.Patch(jwtToken.JwtRefreshToken, func(claims map[string]interface{}) (map[string]interface{}, error) {
			return map[string]interface{}{"token": "new_token", "message": "Error in deleting old tokenj", "role": "new_role", "workspace_role": "workspace_role"}, nil
		})
		defer monkey.Unpatch(jwtToken.JwtRefreshToken)

		// Mock DeleteToken (Return error)
		monkey.Patch(redisdb.DeleteToken, func(key string) error { return errors.New("Error in deleting old token") })
		defer monkey.Unpatch(redisdb.DeleteToken)

		api.RefreshToken(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		log.Println("response: ", response)
		assert.Equal(t, "Error in deleting old token", response["message"].(string))
	})
}

func TestCheckTokenValidity(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Token is valid", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/protected", nil)
		ctx.Request.Header.Set("Authorization", "Bearer valid_token")

		// Mock CheckToken to return no error (valid token)
		monkey.Patch(redisdb.CheckToken, func(token string) error {
			if strings.TrimPrefix(token, "Bearer ") == "valid_token" {
				return nil
			}
			return errors.New("invalid token")
		})
		defer monkey.Unpatch(redisdb.CheckToken)

		api.CheckTokenValidity(ctx)

		// The middleware should pass, allowing the request to continue
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - Token is missing", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/protected", nil)

		// Mock CheckToken but it won't be called since no token is provided
		monkey.Patch(redisdb.CheckToken, func(_ string) error {
			return errors.New("invalid token")
		})
		defer monkey.Unpatch(redisdb.CheckToken)

		api.CheckTokenValidity(ctx)

		// The middleware should reject the request
		assert.Equal(t, http.StatusUnauthorized, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Expired auth token", response["message"])
	})

	t.Run("Failure - Expired or Invalid Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/protected", nil)
		ctx.Request.Header.Set("Authorization", "Bearer expired_token")

		// Mock CheckToken to return an error (expired token)
		monkey.Patch(redisdb.CheckToken, func(token string) error {
			return errors.New("expired token")
		})
		defer monkey.Unpatch(redisdb.CheckToken)

		api.CheckTokenValidity(ctx)

		// The middleware should reject the request
		assert.Equal(t, http.StatusUnauthorized, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Expired auth token", response["message"])
	})
}

func TestCheckAdmin(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - User is Admin", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/admin", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "sys_role": "admin"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckAdmin(ctx)

		// Middleware should pass and allow the request to continue
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - User is Not Admin", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/admin", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "sys_role": "user"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckAdmin(ctx)

		// Middleware should reject the request
		assert.Equal(t, http.StatusForbidden, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "You are not authorized", response["message"])
	})
}

func TestCheckUser(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - User is Authorized", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/user", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "sys_role": "user"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckUser(ctx)

		// Middleware should pass and allow the request to continue
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - User is Not Authorized", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/user", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "sys_role": "admin"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckUser(ctx)

		// Middleware should reject the request
		assert.Equal(t, http.StatusForbidden, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "You are not authorized", response["message"])
	})
}

func TestCheckOwner(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - User is Owner", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/owner", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "owner@example.com", "role": "owner"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckOwner(ctx)

		// Middleware should pass and allow the request to continue
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Success - User is Admin (Also Authorized)", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/owner", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "admin@example.com", "role": "admin"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckOwner(ctx)

		// Middleware should pass and allow the request to continue
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Failure - User is Not Authorized (Regular User)", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/owner", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "role": "user"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckOwner(ctx)

		// Middleware should reject the request
		assert.Equal(t, http.StatusForbidden, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "You are not authorized", response["message"])
	})

	t.Run("Failure - Role Not Found in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/owner", nil)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "unknown@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.CheckOwner(ctx)

		// Middleware should reject the request
		assert.Equal(t, http.StatusForbidden, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "You are not authorized", response["message"])
	})
}
