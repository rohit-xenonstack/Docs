package test

import (
	"bytes"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"regexp"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
)

func TestCreateRole(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/roles", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreateRole(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "error")
	})

	// Test case 2: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/roles", bytes.NewBufferString(`{"name":"admin"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock DB.Create
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."role" ("created_at","updated_at","name","domain","environment") VALUES ($1,$2,$3,$4,$5) RETURNING "roles"."role"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), "admin", "", "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		api.CreateRole(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Role created successfully")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 3: Database Error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/roles", bytes.NewBufferString(`{"name":"admin"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock DB.Create with error
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`NSERT INTO "roles"."role" ("created_at","updated_at","name","domain","environment") VALUES ($1,$2,$3,$4,$5) RETURNING "roles"."role"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), "admin", "", "").
			WillReturnError(gorm.ErrInvalidSQL)
		mock.ExpectRollback()

		api.CreateRole(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "error")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestCreatePermission(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/v1/permissions", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreatePermission(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "error")
	})

	// Test case 2: Success Case - Single Permission
	t.Run("Success Case - Single Permission", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/v1/permissions", bytes.NewBufferString(`[{
			"feature": "project",
			"action": "create"
		}]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock permission existence check
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT count(*) FROM "roles"."permission" WHERE (feature = $1 AND action = $2)`)).
			WithArgs("project", "create").
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

		// Mock DB.Create
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."permission" ("created_at","updated_at","feature","action","project_id","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING "roles"."permission"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), "project", "create", 0, "", "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		api.CreatePermission(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Permissions created successfully")
		assert.Contains(t, w.Body.String(), `"feature":"project"`)
		assert.Contains(t, w.Body.String(), `"action":"create"`)

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 3: Success Case - Multiple Permissions
	t.Run("Success Case - Multiple Permissions", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/v1/permissions", bytes.NewBufferString(`[
			{
				"feature": "project",
				"action": "create"
			},
			{
				"feature": "project",
				"action": "delete"
			}
		]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock permission existence checks
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT count(*) FROM "roles"."permission" WHERE (feature = $1 AND action = $2)`)).
			WithArgs("project", "create").
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT count(*) FROM "roles"."permission" WHERE (feature = $1 AND action = $2)`)).
			WithArgs("project", "delete").
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

		// Mock DB.Create for both permissions in a single transaction
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."permission" ("created_at","updated_at","feature","action","project_id","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING "roles"."permission"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), "project", "create", 0, "", "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."permission" ("created_at","updated_at","feature","action","project_id","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING "roles"."permission"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), "project", "delete", 0, "", "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(2))
		mock.ExpectCommit()

		api.CreatePermission(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Permissions created successfully")
		assert.Contains(t, w.Body.String(), `"feature":"project"`)
		assert.Contains(t, w.Body.String(), `"action":"create"`)
		assert.Contains(t, w.Body.String(), `"action":"delete"`)

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 4: Database Error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/v1/permissions", bytes.NewBufferString(`[{
			"feature": "project",
			"action": "create"
		}]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock permission existence check
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT count(*) FROM "roles"."permission" WHERE (feature = $1 AND action = $2)`)).
			WithArgs("project", "create").
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(0))

		// Mock DB.Create with error
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."permission" ("created_at","updated_at","feature","action","project_id","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING "roles"."permission"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), "project", "create", 0, "", "").
			WillReturnError(gorm.ErrInvalidSQL)
		mock.ExpectRollback()

		api.CreatePermission(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Failed to create permissions")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestAddPermissionToRole(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Invalid Role ID
	t.Run("Invalid Role ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, _, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "role_id", Value: "invalid"},
		}
		req := httptest.NewRequest("POST", "/v1/roles/invalid/permissions", bytes.NewBufferString(`[1]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.AddPermissionToRole(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Invalid role ID")
	})

	// Test case 2: Invalid Permission ID
	t.Run("Invalid Permission ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "role_id", Value: "1"},
		}
		req := httptest.NewRequest("POST", "/v1/roles/1/permissions", bytes.NewBufferString(`[0]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock DB.First for role
		roleRows := sqlmock.NewRows([]string{"id", "name"}).
			AddRow(1, "admin")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role" WHERE ("roles"."role"."id" = 1) ORDER BY "roles"."role"."id" ASC LIMIT 1`)).
			WillReturnRows(roleRows)

		// Mock DB.First for permissions (return empty result)
		permissionRows := sqlmock.NewRows([]string{"id", "feature", "action"})
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission" WHERE (id IN ($1))`)).
			WithArgs(0).
			WillReturnRows(permissionRows)

		api.AddPermissionToRole(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "One or more permissions not found")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 3: Role Not Found
	t.Run("Role Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "role_id", Value: "1"},
		}
		req := httptest.NewRequest("POST", "/v1/roles/1/permissions", bytes.NewBufferString(`[1]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock DB.First to return not found for role
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role" WHERE ("roles"."role"."id" = 1) ORDER BY "roles"."role"."id" ASC LIMIT 1`)).
			WillReturnError(gorm.ErrRecordNotFound)

		api.AddPermissionToRole(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Role not found")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 4: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "role_id", Value: "1"},
		}
		req := httptest.NewRequest("POST", "/v1/roles/1/permissions", bytes.NewBufferString(`[1, 2]`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock DB.First for role
		roleRows := sqlmock.NewRows([]string{"id", "name"}).
			AddRow(1, "admin")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role" WHERE ("roles"."role"."id" = 1) ORDER BY "roles"."role"."id" ASC LIMIT 1`)).
			WillReturnRows(roleRows)

		// Mock DB.First for permissions
		permissionRows := sqlmock.NewRows([]string{"id", "feature", "action"}).
			AddRow(1, "project", "create").
			AddRow(2, "project", "delete")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission" WHERE (id IN ($1,$2))`)).
			WillReturnRows(permissionRows)

		// Mock check for existing mappings (return empty result)
		mappingRows := sqlmock.NewRows([]string{"id", "role_id", "permission_id"})
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role_permission_mapping" WHERE (role_id = $1 AND permission_id IN ($2,$3))`)).
			WithArgs(1, 1, 2).
			WillReturnRows(mappingRows)

		// Mock DB.Create for role permission mapping
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."role_permission_mapping" ("created_at","updated_at","permission_id","role_id") VALUES ($1,$2,$3,$4) RETURNING "roles"."role_permission_mapping"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), 1, 1).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."role_permission_mapping" ("created_at","updated_at","permission_id","role_id") VALUES ($1,$2,$3,$4) RETURNING "roles"."role_permission_mapping"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), 2, 1).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(2))
		mock.ExpectCommit()

		api.AddPermissionToRole(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Permissions added to role successfully")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestAddRoleToUser(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Invalid User ID
	t.Run("Invalid User ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "user_id", Value: "invalid"},
			{Key: "role_id", Value: "1"},
		}
		req := httptest.NewRequest("POST", "/rbac/users/invalid/roles/1", nil)
		ctx.Request = req

		api.AddRoleToUser(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Invalid user ID")
	})

	// Test case 2: Invalid Role ID
	t.Run("Invalid Role ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "user_id", Value: "1"},
			{Key: "role_id", Value: "invalid"},
		}
		req := httptest.NewRequest("POST", "/rbac/users/1/roles/invalid", nil)
		ctx.Request = req

		api.AddRoleToUser(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Invalid role ID")
	})

	// Test case 3: User Not Found
	t.Run("User Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "user_id", Value: "1"},
			{Key: "role_id", Value: "1"},
		}
		req := httptest.NewRequest("POST", "/rbac/users/1/roles/1", nil)
		ctx.Request = req

		// Mock DB.First to return not found for user
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "users" WHERE ("users"."id" = 1) ORDER BY "users"."id" ASC LIMIT 1`)).
			WillReturnError(gorm.ErrRecordNotFound)

		api.AddRoleToUser(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "User not found")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 4: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "user_id", Value: "1"},
			{Key: "role_id", Value: "1"},
		}
		req := httptest.NewRequest("POST", "/rbac/users/1/roles/1", nil)
		ctx.Request = req

		// Mock DB.First for user
		userRows := sqlmock.NewRows([]string{"id", "name", "email"}).
			AddRow(1, "test user", "test@example.com")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "users" WHERE ("users"."id" = 1) ORDER BY "users"."id" ASC LIMIT 1`)).
			WillReturnRows(userRows)

		// Mock DB.First for role
		roleRows := sqlmock.NewRows([]string{"id", "name"}).
			AddRow(1, "admin")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role" WHERE ("roles"."role"."id" = 1) ORDER BY "roles"."role"."id" ASC LIMIT 1`)).
			WillReturnRows(roleRows)

		// Mock DB.Create for role permission mapping
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "roles"."role_permission_mapping" ("created_at","updated_at","permission_id","role_id") VALUES ($1,$2,$3,$4) RETURNING "roles"."role_permission_mapping"."id"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), 1, 1).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		api.AddRoleToUser(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Role added to user successfully")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestListRoles(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Successful role listing with permissions
	t.Run("Successful Role Listing", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock roles query
		roleRows := sqlmock.NewRows([]string{"id", "name"}).
			AddRow(1, "Admin").
			AddRow(2, "User")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role"`)).
			WillReturnRows(roleRows)

		// Mock role-permission mappings query
		mappingRows := sqlmock.NewRows([]string{"role_id", "permission_id"}).
			AddRow(1, 1).
			AddRow(1, 2).
			AddRow(2, 1)
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role_permission_mapping"`)).
			WillReturnRows(mappingRows)

		// Mock permissions query
		permissionRows := sqlmock.NewRows([]string{"id", "feature", "action"}).
			AddRow(1, "project", "create").
			AddRow(2, "project", "delete")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission"`)).
			WillReturnRows(permissionRows)

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/roles", nil)

		// Call the function
		api.ListRoles(c)

		// Verify response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Admin")
		assert.Contains(t, w.Body.String(), "User")
		assert.Contains(t, w.Body.String(), "project")
		assert.Contains(t, w.Body.String(), "create")
		assert.Contains(t, w.Body.String(), "delete")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 2: Database error when fetching roles
	t.Run("Database Error Fetching Roles", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock roles query to return error
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role"`)).
			WillReturnError(errors.New("database error"))

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/roles", nil)

		// Call the function
		api.ListRoles(c)

		// Verify response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "error")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 3: Database error when fetching role permissions
	t.Run("Database Error Fetching Role Permissions", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock roles query
		roleRows := sqlmock.NewRows([]string{"id", "name"}).
			AddRow(1, "Admin")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role"`)).
			WillReturnRows(roleRows)

		// Mock role-permission mappings query to return error
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role_permission_mapping"`)).
			WillReturnError(errors.New("database error"))

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/roles", nil)

		// Call the function
		api.ListRoles(c)

		// Verify response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "error")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 4: Role with no permissions
	t.Run("Role with No Permissions", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock roles query
		roleRows := sqlmock.NewRows([]string{"id", "name"}).
			AddRow(1, "Guest")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role"`)).
			WillReturnRows(roleRows)

		// Mock role-permission mappings query (empty)
		mappingRows := sqlmock.NewRows([]string{"role_id", "permission_id"})
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."role_permission_mapping"`)).
			WillReturnRows(mappingRows)

		// Mock permissions query (empty)
		permissionRows := sqlmock.NewRows([]string{"id", "feature", "action"})
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission"`)).
			WillReturnRows(permissionRows)

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/roles", nil)

		// Call the function
		api.ListRoles(c)

		// Verify response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Guest")
		assert.Contains(t, w.Body.String(), "permissions")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestListPermissions(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Successful permission listing
	t.Run("Successful Permission Listing", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock permissions query
		permissionRows := sqlmock.NewRows([]string{"id", "feature", "action"}).
			AddRow(1, "project", "create").
			AddRow(2, "project", "delete").
			AddRow(3, "workspace", "read").
			AddRow(4, "workspace", "write")
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission"`)).
			WillReturnRows(permissionRows)

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/permissions", nil)

		// Call the function
		api.ListPermissions(c)

		// Verify response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "project")
		assert.Contains(t, w.Body.String(), "workspace")
		assert.Contains(t, w.Body.String(), "create")
		assert.Contains(t, w.Body.String(), "delete")
		assert.Contains(t, w.Body.String(), "read")
		assert.Contains(t, w.Body.String(), "write")
	})

	// Test case 2: Database error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock permissions query to return error
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission"`)).
			WillReturnError(errors.New("database error"))

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/permissions", nil)

		// Call the function
		api.ListPermissions(c)

		// Verify response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "error")
	})

	// Test case 3: Empty permissions list
	t.Run("Empty Permissions List", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		// Mock permissions query to return empty result
		permissionRows := sqlmock.NewRows([]string{"id", "feature", "action"})
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "roles"."permission"`)).
			WillReturnRows(permissionRows)

		// Create a test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("GET", "/v1/permissions", nil)

		// Call the function
		api.ListPermissions(c)

		// Verify response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "permissions")
	})
}
