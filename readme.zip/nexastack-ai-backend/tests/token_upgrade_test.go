package test

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestUpgradeToken(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.POST("/v1/upgrade_token", api.UpgradeToken)

	// Test case: Invalid JSON Body - Missing required fields
	t.Run("Invalid JSON Body - Missing Fields", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		monkey.Patch(jwtToken.JwtRefreshToken, func(claims map[string]interface{}) (map[string]interface{}, error) {
			return map[string]interface{}{}, nil
		})

		req := httptest.NewRequest("POST", "/v1/upgrade_token", bytes.NewBufferString(`{"project_id":"3"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		api.UpgradeToken(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true, "message":"Invalid request body"}`, w.Body.String())
	})

	// Test case: Successful Upgrade
	t.Run("Successful Upgrade", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		monkey.Patch(jwtToken.JwtRefreshToken, func(claims map[string]interface{}) (map[string]interface{}, error) {
			return map[string]interface{}{
				"error":  false,
				"expire": "2025-04-08T21:47:55+05:30",
				"token":  "",
			}, nil
		})

		req := httptest.NewRequest("POST", "/v1/upgrade_token", bytes.NewBufferString(`{"project_id":3,"environment":"dev","workspace":"test_workspace"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		api.UpgradeToken(ctx)
		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false, "expire":"2025-04-08T21:47:55+05:30", "token":""}`, w.Body.String())
	})
}
