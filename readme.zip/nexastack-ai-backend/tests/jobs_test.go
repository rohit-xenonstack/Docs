package test

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"regexp"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
)

func TestGetJobs(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Missing Account ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/jobs/", nil)
		monkey.Patch(api.GetJobList, func(accountId string) ([]models.Jobs, error) {
			return nil, errors.New("database error")
		})
		api.GetJobs(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"error"`)
	})

	t.Run("Database Query Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/jobs/account123", nil)
		ctx.Params = append(ctx.Params, gin.Param{Key: "account_id", Value: "account123"})

		monkey.Patch(api.GetJobList, func(accountId string) ([]models.Jobs, error) {
			return nil, errors.New("database error")
		})
		defer monkey.UnpatchAll()

		api.GetJobs(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"error"`)
	})

	t.Run("Successful Job Retrieval", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/jobs/account123", nil)
		ctx.Params = append(ctx.Params, gin.Param{Key: "account_id", Value: "account123"})

		mockJobs := []models.Jobs{
			{ID: 1, Model: "Job1"},
			{ID: 2, Model: "Job2"},
		}

		monkey.Patch(api.GetJobList, func(accountId string) ([]models.Jobs, error) {
			return mockJobs, nil
		})
		defer monkey.UnpatchAll()

		api.GetJobs(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"error":false`)
		assert.Contains(t, w.Body.String(), `"jobs"`)
		assert.Contains(t, w.Body.String(), "Job1")
		assert.Contains(t, w.Body.String(), "Job2")
	})
}

func TestGetJobList(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gormDB, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = gormDB

	t.Run("Database Query Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		accountID := "12345"

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "jobs" WHERE (account_id = $1)`)).
			WithArgs(accountID).
			WillReturnError(gorm.ErrRecordNotFound)

		jobs, err := api.GetJobList(accountID)
		assert.Nil(t, jobs)
		assert.Error(t, err)
		assert.Equal(t, gorm.ErrRecordNotFound, err)

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	t.Run("Successful Job Retrieval", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		accountID := "12345"

		rows := sqlmock.NewRows([]string{"id", "model"}).
			AddRow("1", "Job1").
			AddRow("2", "Job2")

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "jobs" WHERE (account_id = $1)`)).
			WithArgs(accountID).
			WillReturnRows(rows)

		jobs, err := api.GetJobList(accountID)
		assert.NoError(t, err)
		assert.NotNil(t, jobs)
		assert.Len(t, jobs, 2)
		assert.Equal(t, "Job1", jobs[0].Model)
		assert.Equal(t, "Job2", jobs[1].Model)

		assert.NoError(t, mock.ExpectationsWereMet())
	})
}
