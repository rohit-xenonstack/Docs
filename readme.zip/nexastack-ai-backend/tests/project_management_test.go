package test

import (
	"bytes"
	"errors"
	"net/http"
	"net/http/httptest"
	"regexp"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	_ "github.com/jinzhu/gorm/dialects/postgres"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
	"gorm.io/gorm"
)

const (
	LoginAgainMessage = "Please login again"
	ClientAgentUser   = "User-Agent"
)

var ProjectMemberActivityWhereClause = []string{`Project created`, `Project updated`, `Project deleted`, `Project member invited`, `Project member joined`, `Project member removed`}

func TestCreateProject(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
			"email": "user@example.com",
		})

		api.CreateProject(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Please pass name of the project")
	})

	// Test case 2: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects", bytes.NewBufferString(`{"name":"Test Project"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
			"workspace": "demotestops",
		})

		// Mock ProjectPost function
		monkey.Patch(api.ProjectPost, func(project models.Project, email string, name string, ip string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   false,
				"message": "Project created successfully",
			}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		api.CreateProject(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Project created successfully")
	})
}

func TestShowProjectData(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 2: Project Not Found
	t.Run("Project Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, _, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "1"},
		}
		req := httptest.NewRequest("GET", "/projects/1", nil)
		ctx.Request = req

		// Mock GetProjectData function
		monkey.Patch(api.GetProjectData, func(id string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   true,
				"message": "Project not found",
			}, http.StatusBadRequest
		})
		defer monkey.UnpatchAll()

		api.ShowProjectData(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Project not found")
	})

	// Test case 3: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, _, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "1"},
		}
		req := httptest.NewRequest("GET", "/projects/1", nil)
		ctx.Request = req

		// Mock GetProjectData function
		monkey.Patch(api.GetProjectData, func(id string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   false,
				"message": "Project retrieved successfully",
				"data": models.Project{
					ID:   1,
					Name: "Test Project",
				},
			}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		api.ShowProjectData(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Test Project")
	})
}

func TestUpdateProject(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("PUT", "/projects/1", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.UpdateProject(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Please pass name of the project")
	})

	// Test case 2: Missing Email Claim
	t.Run("Missing Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("PUT", "/projects/1", bytes.NewBufferString(`{"name":"Updated Project"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.UpdateProject(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Please login again")
	})

	// Test case 3: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("PUT", "/projects/1", bytes.NewBufferString(`{"name":"Updated Project"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{
			"email": "test@example.com",
			"role":  "admin",
			"name":  "Test User",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		defer monkey.UnpatchAll()

		// Mock ProjectPost function
		monkey.Patch(api.Update, func(Project models.Project, email string, role string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   false,
				"message": "Project updated successfully",
			}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		api.UpdateProject(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Project updated successfully")
	})
}

func TestDeleteProject(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Missing ID Claim
	t.Run("Missing ID Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("DELETE", "/projects/1", nil)
		ctx.Request = req

		api.DeleteProject(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Please login again")
	})

	// Test case 2: Missing Email Claim
	t.Run("Missing Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("DELETE", "/projects/1", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"id": "1",
		}

		ctx.Set("JWT_PAYLOAD", claims)
		api.DeleteProject(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Please login again")
	})

	// Test case 3: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("DELETE", "/projects/1", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"id":    "1",
			"email": "test@example.com",
			"role":  "admin",
		}

		ctx.Set("JWT_PAYLOAD", claims)

		// Mock ProjectPost function
		monkey.Patch(api.Delete, func(Project models.Project, id string, email string, role string, ip string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   false,
				"message": "Project deleted successfully",
			}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		api.DeleteProject(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Project deleted successfully")
	})
}

func TestProjectSendInvite(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	monkey.Patch(api.UserIsAlreadyMemberOfProject, func(email string, projectId string) bool {
		return false
	})

	// Test case 1: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.ProjectSendInvite(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Invalid request data")
	})

	// Test case 2: Missing Email
	t.Run("Missing Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", bytes.NewBufferString(`{"project_id": "1", "name": "Test User"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(api.UserIsNotAlsoMemeberOfWorkspace, func(email string, workspace string) bool {
			return false
		})

		api.ProjectSendInvite(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Email is required")
	})

	// Test case 3: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock project existence check
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT count(*) FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id = $1))`)).
			WithArgs("1").
			WillReturnRows(sqlmock.NewRows([]string{"count"}).AddRow(1))

		// Mock transaction
		mock.ExpectBegin()

		monkey.Patch(api.UserIsNotAlsoMemeberOfWorkspace, func(email string, workspace string) bool {
			return false
		})

		// Mock project member creation
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "project_management"."project_members"`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))

		// Mock transaction commit
		mock.ExpectCommit()

		// Mock account lookup in SendInviteEmail
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (email = $1)`)).
			WithArgs("test@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "name"}).
				AddRow(1, "test@example.com", "Test User"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", bytes.NewBufferString(`{
			"email": "test@example.com",
			"name": "Test User",
			"project_id": "1",
			"role": "member",
			"workspace": "test-workspace"
		}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{
			"email":     "owner@example.com",
			"name":      "Project Owner",
			"workspace": "test-workspace",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		monkey.Patch(api.SendInviteEmail, func(c *gin.Context, data models.TempProjectMembers) (int, error) {
			return 0, nil
		})

		api.ProjectSendInvite(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Project member invited successfully")
	})
}

func TestGetProjectMembers(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Missing Project ID
	t.Run("Missing Project ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/projects/members", nil)
		ctx.Request = req

		api.GetProjectMembers(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Project ID is required")
	})

	// Test case 2: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock project members query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project_members" WHERE (project_id = $1)`)).
			WithArgs("1").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "name", "project_id", "role", "status"}).
				AddRow(1, "member1@example.com", "Member One", "1", "developer", "active"))

		// Mock environment permissions query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."environment_permissions" WHERE (member_id = $1)`)).
			WithArgs(1).
			WillReturnRows(sqlmock.NewRows([]string{"id", "member_id", "environment", "permissions"}).
				AddRow(1, 1, "dev", "{read}"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "1"},
		}
		req := httptest.NewRequest("GET", "/projects/1/members", nil)
		ctx.Request = req

		api.GetProjectMembers(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "member1@example.com")
		assert.Contains(t, w.Body.String(), "Member One")
	})
}

func TestGetProjectMemberByID(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Missing Member ID
	t.Run("Missing Member ID", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/projects/members/", nil)
		ctx.Request = req

		api.GetProjectMemberByID(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Member ID is required")
	})

	// Test case 2: Member Not Found
	t.Run("Member Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock First query to return record not found
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project_members" WHERE ("project_management"."project_members"."id" = $1) ORDER BY "project_management"."project_members"."id" ASC LIMIT 1`)).
			WithArgs("999").
			WillReturnError(gorm.ErrRecordNotFound)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "999"},
		}
		req := httptest.NewRequest("GET", "/projects/members/999", nil)
		ctx.Request = req

		api.GetProjectMemberByID(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "{\"error\":\"Failed to retrieve project member: record not found\"}")
	})

	// Test case 3: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock First query to return member
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project_members" WHERE ("project_management"."project_members"."id" = $1) ORDER BY "project_management"."project_members"."id" ASC LIMIT 1`)).
			WithArgs("1").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "name", "project_id"}).
				AddRow(1, "test@example.com", "Test Member", "1"))

		// Mock Where query for environment access
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."environment_permissions" WHERE (member_id = $1)`)).
			WithArgs(1).
			WillReturnRows(sqlmock.NewRows([]string{"id", "member_id", "environment", "permissions"}).
				AddRow(1, 1, "dev", "{read}"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "1"},
		}
		req := httptest.NewRequest("GET", "/projects/members/1", nil)
		ctx.Request = req

		api.GetProjectMemberByID(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "test@example.com")
		assert.Contains(t, w.Body.String(), "Test Member")
	})
}

func TestGetProjectActivities(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 2: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock activities query with multiple values in IN clause
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "activities" WHERE (project_id=$1 and activity_name in ($2,$3)) ORDER BY created_at DESC`)).
			WithArgs("1", "Project member invited", "Member added").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "activity_name", "project_id", "status", "created_at"}).
				AddRow(1, "test@example.com", "Project member invited", 1, "success", time.Now()))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "1"},
		}
		req := httptest.NewRequest("GET", "/projects/1/activities", nil)
		ctx.Request = req

		api.GetProjectActivities(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "test@example.com")
		assert.Contains(t, w.Body.String(), "Project member invited")
	})

	// Test case 3: Database Error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock activities query with error and multiple values in IN clause
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "activities" WHERE (project_id=$1 and activity_name in ($2,$3)) ORDER BY created_at DESC`)).
			WithArgs("1", "Project member invited", "Member added").
			WillReturnError(errors.New("database error"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = []gin.Param{
			{Key: "id", Value: "1"},
		}
		req := httptest.NewRequest("GET", "/projects/1/activities", nil)
		ctx.Request = req

		api.GetProjectActivities(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "error while getting acitvities database error")
	})
}

func TestSendInviteEmail(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Successful email send
	t.Run("Successful Email Send", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock account lookup
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (email=$1)`)).
			WithArgs("test@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "name"}).
				AddRow(1, "test@example.com", "Test User"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"email":     "owner@example.com",
			"name":      "Project Owner",
			"workspace": "test-workspace",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock mail.SendProjectInviteLink
		monkey.Patch(mail.SendProjectInviteLink, func(acc database.Accounts, workspace string, projectName string, ownerEmail string, ownerName string, projectId string) {
			// Mock successful email send
		})
		defer monkey.UnpatchAll()

		// Mock activities.RecordActivity
		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock successful activity recording
		})
		defer monkey.UnpatchAll()

		data := models.TempProjectMembers{
			Email:       "test@example.com",
			ProjectName: "Test Project",
			ProjectId:   "1",
		}

		_, err := api.SendInviteEmail(ctx, data)
		assert.NoError(t, err)
	})

	// Test case 2: Account not found
	t.Run("Account Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock account lookup to return no results
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (email=$1)`)).
			WithArgs("test@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "name"}))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"email":     "owner@example.com",
			"name":      "Project Owner",
			"workspace": "test-workspace",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		data := models.TempProjectMembers{
			Email:       "test@example.com",
			ProjectName: "Test Project",
			ProjectId:   "1",
		}

		_, err := api.SendInviteEmail(ctx, data)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "record not found")
	})

	// Test case 3: Missing email in claims
	t.Run("Missing Email in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"name":      "Project Owner",
			"workspace": "test-workspace",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		data := models.TempProjectMembers{
			Email:       "test@example.com",
			ProjectName: "Test Project",
			ProjectId:   "1",
		}

		_, err := api.SendInviteEmail(ctx, data)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "email not found in token")
	})

	// Test case 4: Missing name in claims
	t.Run("Missing Name in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"email":     "owner@example.com",
			"workspace": "test-workspace",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		data := models.TempProjectMembers{
			Email:       "test@example.com",
			ProjectName: "Test Project",
			ProjectId:   "1",
		}

		_, err := api.SendInviteEmail(ctx, data)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "name not found in token")
	})

	// Test case 5: Missing workspace in claims
	t.Run("Missing Workspace in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/projects/member/invite", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"email": "owner@example.com",
			"name":  "Project Owner",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		data := models.TempProjectMembers{
			Email:       "test@example.com",
			ProjectName: "Test Project",
			ProjectId:   "1",
		}

		_, err := api.SendInviteEmail(ctx, data)
		assert.Error(t, err)
		assert.Contains(t, err.Error(), "name not found in token")
	})
}

func TestProjectsByUserOrWorkspace(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 2: Using JWT claims
	t.Run("Using JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock project query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id in (select project_id::int from project_management.project_to_account_mapping ptam where ptam.account_id = 123) and workspace_id = 'test-workspace'))`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "description", "workspace_id", "organization_id"}).
				AddRow(1, "Test Project", "Test Description", "test-workspace", 123))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/user/projects", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"workspace": "test-workspace",
			"id":        123.0,
		}
		ctx.Set("JWT_PAYLOAD", claims)

		api.ProjectsByUserOrWorkspace(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "Test Project")
	})

	// Test case 3: Missing workspace in JWT claims
	t.Run("Missing Workspace in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/user/projects", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"id": 123.0,
		}
		ctx.Set("JWT_PAYLOAD", claims)

		api.ProjectsByUserOrWorkspace(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Please login again")
	})

	// Test case 4: Missing ID in JWT claims
	t.Run("Missing ID in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/user/projects", nil)
		ctx.Request = req

		claims := jwt.MapClaims{
			"workspace": "test-workspace",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		api.ProjectsByUserOrWorkspace(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Please login again")
	})

	// Test case 5: Database error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock project query with error
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id in (select project_id::int from project_management.project_to_account_mapping ptam where ptam.account_id = 123) and workspace_id = 'test-workspace'))`)).
			WillReturnError(errors.New("database error"))

		claims := jwt.MapClaims{
			"workspace": "test-workspace",
			"id":        123.0,
		}

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/user/projects?user_id=123&workspace=test-workspace", nil)
		ctx.Request = req

		ctx.Set("JWT_PAYLOAD", claims)
		api.ProjectsByUserOrWorkspace(ctx)

		assert.Equal(t, 400, w.Code)
		assert.Contains(t, w.Body.String(), "error")
	})
}

func TestGetUserRolesAndPermissions(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test case 1: Successful retrieval of roles and permissions
	// t.Run("Successful Retrieval", func(t *testing.T) {
	// 	SetupLogging()
	// 	ResetLogs()
	// 	// Setup mock DB
	// 	gormDB, mock, teardown := setupMockDB(t)
	// 	defer teardown()
	// 	config.DB = gormDB

	// 	// Mock the complex query that joins multiple tables
	// 	rows := sqlmock.NewRows([]string{"role_id", "role_name", "feature", "action"}).
	// 		AddRow(1, "Admin", "project", "create").
	// 		AddRow(1, "Admin", "project", "delete").
	// 		AddRow(2, "User", "project", "read")
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT roles.role.id as role_id, roles.role.name as role_name, roles.permission.feature as feature, roles.permission.action as action FROM "roles"."role" JOIN roles.account_role_mapping ON roles.role.id = roles.account_role_mapping.role_id JOIN roles.role_permission_mapping ON roles.role.id = roles.role_permission_mapping.role_id JOIN roles.permission ON roles.role_permission_mapping.permission_id = roles.permission.id WHERE (roles.account_role_mapping.account_id = $1)`)).
	// 		WithArgs("123").
	// 		WillReturnRows(rows)

	// 	// Call the function
	// 	responses, err := api.GetUserRolesAndPermissions("123")

	// 	// Verify results
	// 	assert.NoError(t, err)
	// 	assert.Len(t, responses, 2)

	// 	// Check Admin role
	// 	assert.Equal(t, 1, responses[0].Id)
	// 	assert.Equal(t, "Admin", responses[0].RoleName)
	// 	assert.Contains(t, responses[0].Permissions, "create")
	// 	assert.Contains(t, responses[0].Permissions, "delete")

	// 	// Check User role
	// 	assert.Equal(t, 2, responses[1].Id)
	// 	assert.Equal(t, "User", responses[1].RoleName)
	// 	assert.Contains(t, responses[1].Permissions, "read")

	// 	// Verify all expectations were met
	// 	if err := mock.ExpectationsWereMet(); err != nil {
	// 		t.Errorf("Unfulfilled expectations: %s", err)
	// 	}
	// })

	// Test case 2: Database error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock the query to return an error
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT roles.role.id as role_id, roles.role.name as role_name, roles.permission.feature as feature, roles.permission.action as action FROM "roles"."role" JOIN roles.account_role_mapping ON roles.role.id = roles.account_role_mapping.role_id JOIN roles.role_permission_mapping ON roles.role.id = roles.role_permission_mapping.role_id JOIN roles.permission ON roles.role_permission_mapping.permission_id = roles.permission.id WHERE (roles.account_role_mapping.account_id = $1)`)).
			WithArgs("123").
			WillReturnError(errors.New("database error"))

		// Call the function
		responses, err := api.GetUserRolesAndPermissions("123")

		// Verify results
		assert.Error(t, err)
		assert.Nil(t, responses)
		assert.Contains(t, err.Error(), "database error")

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Test case 3: No roles found
	t.Run("No Roles Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Mock the query to return no rows
		rows := sqlmock.NewRows([]string{"role_id", "role_name", "feature", "action"})
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT roles.role.id as role_id, roles.role.name as role_name, roles.permission.feature as feature, roles.permission.action as action FROM "roles"."role" JOIN roles.account_role_mapping ON roles.role.id = roles.account_role_mapping.role_id JOIN roles.role_permission_mapping ON roles.role.id = roles.role_permission_mapping.role_id JOIN roles.permission ON roles.role_permission_mapping.permission_id = roles.permission.id WHERE (roles.account_role_mapping.account_id = $1)`)).
			WithArgs("123").
			WillReturnRows(rows)

		// Call the function
		responses, err := api.GetUserRolesAndPermissions("123")

		// Verify results
		assert.NoError(t, err)
		assert.Empty(t, responses)

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}
