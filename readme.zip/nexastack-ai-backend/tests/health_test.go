package test

import (
	// Import go-sqlmock
	// Redis client

	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/health"
	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"               // Import GORM
	_ "github.com/jinzhu/gorm/dialects/postgres" // Import PostgreSQL dialect for GORM

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
)

type MockRedisClient struct {
	mock.Mock     // Embedding mock.Mock ensures that we can call `Called`
	*redis.Client // Embed the actual redis.Client

}

// Initialise simulates the Redis connection check (like `ping`)
func (m *MockRedisClient) Initialise() error {
	// Simulate a successful Redis connection
	return nil
}

// TestHealthz tests the health check API
func TestHealthz(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test when health check is successful
	t.Run("Health Check Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Create a new GET request for the /healthz endpoint
		req := httptest.NewRequest("GET", "/healthz", nil)
		ctx.Request = req

		// Mock the ServiceHealth function to simulate a successful health check
		monkey.Patch(health.ServiceHealth, func() error {
			return nil // No error, indicating service is healthy
		})
		defer monkey.Unpatch(health.ServiceHealth)

		// Manually set expected values for Build and Environment from the config
		expectedBuild := config.Conf.Service.Build
		expectedEnvironment := config.Conf.Service.Environment

		// Call the Healthz endpoint
		api.Healthz(ctx)

		// Assert that the response status code is 200 OK
		assert.Equal(t, http.StatusOK, w.Code)

		// Construct the expected JSON response
		expectedResponse := fmt.Sprintf(`{
			"error": false,
			"message": "All is okay",
			"build": "%s",
			"environment": "%s"
		}`, expectedBuild, expectedEnvironment)

		// Assert that the response body matches the expected JSON
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when health check fails
	t.Run("Health Check Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Create a new GET request for the /healthz endpoint
		req := httptest.NewRequest("GET", "/healthz", nil)
		ctx.Request = req

		// Mock the ServiceHealth function to simulate a failure in health check
		monkey.Patch(health.ServiceHealth, func() error {
			return fmt.Errorf("service is down") // Simulate a failure
		})
		defer monkey.Unpatch(health.ServiceHealth)

		// Call the Healthz endpoint
		api.Healthz(ctx)

		// Assert that the response status code is 500 Internal Server Error
		assert.Equal(t, http.StatusInternalServerError, w.Code)

		// Assert that the response contains the correct error message
		expectedResponse := `{
			"error": true,
			"message": "service is down"
		}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}
