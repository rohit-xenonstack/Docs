package test

import (
	"errors"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/src/compute"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"helm.sh/helm/v3/pkg/release"

	"github.com/stretchr/testify/assert"
	"helm.sh/helm/v3/pkg/action"
)

func TestUninstallCompute(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Successful Uninstall", func(t *testing.T) {
		SetupLogging()
		ResetLogs()

		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 200, nil
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		monkey.Patch(action.NewUninstall, func(cfg *action.Configuration) *action.Uninstall {
			return &action.Uninstall{}
		})
		defer monkey.Unpatch(action.NewUninstall)

		monkey.Patch((*action.Uninstall).Run, func(*action.Uninstall, string) (*release.UninstallReleaseResponse, error) {
			return &release.UninstallReleaseResponse{}, nil
		})
		defer monkey.Unpatch(action.NewUninstall)

		mapd, code := compute.UninstallCompute("test-namespace", "test-release")
		assert.Equal(t, 200, code)
		assert.False(t, mapd["error"].(bool))
	})

	t.Run("SetConfig Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 500, errors.New("config error")
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		monkey.Patch(action.NewUninstall, func(cfg *action.Configuration) *action.Uninstall {
			return &action.Uninstall{}
		})
		defer monkey.Unpatch(action.NewUninstall)

		monkey.Patch((*action.Uninstall).Run, func(*action.Uninstall, string) (*release.UninstallReleaseResponse, error) {
			return &release.UninstallReleaseResponse{}, nil
		})
		defer monkey.Unpatch(action.NewUninstall)

		mapd, code := compute.UninstallCompute("test-namespace", "test-release")
		assert.Equal(t, 500, code)
		assert.True(t, mapd["error"].(bool))
		assert.Equal(t, "config error", mapd["message"].(string))
	})

	t.Run("Uninstall Run Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 200, nil
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		monkey.Patch(action.NewUninstall, func(cfg *action.Configuration) *action.Uninstall {
			return &action.Uninstall{}
		})
		defer monkey.Unpatch(action.NewUninstall)

		monkey.Patch((*action.Uninstall).Run, func(*action.Uninstall, string) (*release.UninstallReleaseResponse, error) {
			return &release.UninstallReleaseResponse{}, errors.New("uninstall error")
		})
		defer monkey.Unpatch(action.NewUninstall)

		mapd, code := compute.UninstallCompute("test-namespace", "test-release")
		assert.Equal(t, 404, code)
		assert.True(t, mapd["error"].(bool))
		assert.Equal(t, "uninstall error", mapd["message"].(string))
	})
}
