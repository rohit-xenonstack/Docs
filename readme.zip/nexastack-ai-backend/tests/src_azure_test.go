package test

import (
	"errors"
	"regexp"
	"testing"

	// authorizationapi "k8s.io/api/authorization/v1"

	// "k8s.io/apimachinery/pkg/api/resource"

	"git.xenonstack.com/nexa-platform/accounts/src/vault"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/azures"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
)

func TestDeleteInfraIntegration(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	id := "123"
	workspace := "workspace1"
	name := "test-user"
	email := "user@example.com"
	ip := "192.168.1.1"
	framework := "terraform"
	whereCondition := "id=" + id + " and workspace='" + workspace + "'"

	t.Run("Vault Secret Deletion Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "infra_integrations" WHERE (` + whereCondition + `)`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace", "framework", "cluster_name"}).
				AddRow(id, workspace, framework, "cluster-1"))

		monkey.Patch(vault.DeleteSecret, func(w, c, f string) error { return errors.New("vault error") })
		defer monkey.Unpatch(vault.DeleteSecret)

		result, status := azures.DeleteInfraIntegration(id, workspace, name, email, ip)

		assert.Equal(t, 500, status)
		assert.True(t, result["error"].(bool))
		assert.Equal(t, "Unable to delete terraform. Please try again.", result["message"])
	})

	t.Run("Unsupported Framework", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "infra_integrations" WHERE (` + whereCondition + `)`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace", "framework", "cluster_name"}).
				AddRow(id, workspace, "unknown", "cluster-1"))

		result, status := azures.DeleteInfraIntegration(id, workspace, name, email, ip)

		assert.Equal(t, 400, status)
		assert.True(t, result["error"].(bool))
		assert.Equal(t, "Unsupported framework type", result["message"])
	})

	t.Run("Successful Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "infra_integrations" WHERE (` + whereCondition + `)`)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace", "framework", "cluster_name"}).
				AddRow(id, workspace, framework, "cluster-1"))

		monkey.Patch(vault.DeleteSecret, func(workspace string, cloud string, framework string) error {
			return nil
		})
		defer monkey.Unpatch(vault.DeleteSecret)

		monkey.Patch(azures.SaveAvtivity, func(id int, slug string, workspace string, userName string, userEmail string, action string, status string, reason string, sytemIP string) {
			// Do nothing
		})
		defer monkey.Unpatch(azures.SaveAvtivity)

		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "infra_integrations" WHERE (`+whereCondition+`)`)).
			WithArgs(id, workspace).
			WillReturnResult(sqlmock.NewResult(1, 1))

		result, status := azures.DeleteInfraIntegration(id, workspace, name, email, ip)

		assert.Equal(t, 200, status)
		assert.False(t, result["error"].(bool))
		assert.Equal(t, "cluster-1 Deleted Successfully", result["message"])
	})

	t.Run("No Integration Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "infra_integrations" WHERE (`+whereCondition+`)`)).
			WithArgs(id, workspace).
			WillReturnRows(sqlmock.NewRows([]string{}))

		result, status := azures.DeleteInfraIntegration(id, workspace, name, email, ip)

		assert.Equal(t, 400, status)
		assert.True(t, result["error"].(bool))
		assert.Equal(t, "No integration found", result["message"])
	})

}
