package test

import (
	"sync"

	"git.xenonstack.com/nexa-platform/accounts/config"
)

var (
	once        sync.Once
	LogMessages []string
)

// SetupLogging sets up the monkey patch for logging
func SetupLogging() {
	config.InitLogger()
}

// ResetLogs clears the captured logs
func ResetLogs() {
	LogMessages = []string{}
}
