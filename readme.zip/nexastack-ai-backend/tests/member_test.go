package test

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"

	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestMemberSignupEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode) // Run Gin in test mode

	t.Run("Missing Fields", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/membersignup", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.MemberSignupEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		expectedResponse := `{"error": true, "message": "Email and Workspace are required fields."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("Invalid Email Format", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/membersignup", bytes.NewBufferString(`{"workspace": "test-workspace", "email": "invalid-email"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Monkey patch ValidateEmail to always return false
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return false
		})
		defer monkey.Unpatch(methods.ValidateEmail) // Unpatch after test

		api.MemberSignupEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		expectedResponse := `{"error": true, "message": "Please enter valid email id."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("User Not Invited", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/membersignup", bytes.NewBufferString(`{"workspace": "test-workspace", "email": "user@example.com"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock ValidateEmail to return true
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Mock MemberSignup to return 404 error
		monkey.Patch(member.MemberSignup, func(email, wsID string) (int, string) {
			return 404, "You have not been invited in this workspace."
		})
		defer monkey.Unpatch(member.MemberSignup)

		api.MemberSignupEp(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		expectedResponse := `{"error": true, "message": "You have not been invited in this workspace."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("User Already Registered", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/membersignup", bytes.NewBufferString(`{"workspace": "test-workspace", "email": "user@example.com"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock ValidateEmail to return true
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Mock MemberSignup to return 209 status
		monkey.Patch(member.MemberSignup, func(email, wsID string) (int, string) {
			return 209, "You have already registered."
		})
		defer monkey.Unpatch(member.MemberSignup)

		api.MemberSignupEp(ctx)

		assert.Equal(t, 209, w.Code)
		expectedResponse := `{"error": true, "message": "You have already registered."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("Successful Signup", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/membersignup", bytes.NewBufferString(`{"workspace": "test-workspace", "email": "user@example.com"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock ValidateEmail to return true
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Mock MemberSignup to return success response
		monkey.Patch(member.MemberSignup, func(email, wsID string) (int, string) {
			return 200, "We have sent a link to your email, Please check your email."
		})
		defer monkey.Unpatch(member.MemberSignup)

		api.MemberSignupEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		expectedResponse := `{"error": false, "message": "We have sent a link to your email, Please check your email."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}

func TestMemberRegistration(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Missing Fields", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/memberregistration", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.MemberRegistration(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		expectedResponse := `{"error": true, "message": "name, contact, password, token and workspace are required field."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("Invalid Password Format", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/memberregistration", bytes.NewBufferString(`{"name": "John Doe", "contact": "1234567890", "password": "weakpassword", "token": "validToken", "workspace": "test-workspace"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock CheckPassword to return false (invalid password format)
		monkey.Patch(methods.CheckPassword, func(password string) bool {
			return false
		})
		defer monkey.Unpatch(methods.CheckPassword)

		api.MemberRegistration(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		expectedResponse := `{"error": true, "message": "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character."}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// t.Run("Successful Registration", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	req := httptest.NewRequest("POST", "/memberregistration", bytes.NewBufferString(`{"name": "John Doe", "contact": "1234567890", "password": "ValidPassword123!", "token": "validToken", "workspace": "test-workspace"}`))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	// Mock CheckToken to return a valid token
	// 	monkey.Patch(verifytoken.CheckToken, func(token string) (verifytoken.Token, error) {
	// 		return verifytoken.Token{
	// 			Userid:    1,
	// 			TokenTask: "invite_link",
	// 		}, nil
	// 	})
	// 	defer monkey.Unpatch(verifytoken.CheckToken)

	// 	// Mock database query to simulate that the user is invited to the workspace
	// 	monkey.PatchInstanceMethod(reflect.TypeOf(database.DB{}), "Select", func(db *database.DB, query string, args ...interface{}) *database.DB {
	// 		// Simulate a record found in workspace members
	// 		return db
	// 	})
	// 	defer monkey.UnpatchInstanceMethod(reflect.TypeOf(database.DB{}), "Select")

	// 	// Mock SaveMemberInfo to return success
	// 	monkey.Patch(member.SaveMemberInfo, func(token, password, wsID, name, contact string) (int, map[string]interface{}) {
	// 		return 200, map[string]interface{}{
	// 			"email": "user@example.com",
	// 			"name":  name,
	// 		}
	// 	})
	// 	defer monkey.Unpatch(member.SaveMemberInfo)

	// 	// Mock JWT token generation to succeed
	// 	monkey.Patch(jwtToken.JwtToken, func(acc database.Accounts, wsID, role string) (map[string]interface{}, error) {
	// 		return map[string]interface{}{
	// 			"token": "valid-jwt-token",
	// 		}, nil
	// 	})
	// 	defer monkey.Unpatch(jwtToken.JwtToken)

	// 	api.MemberRegistration(ctx)

	// 	assert.Equal(t, http.StatusOK, w.Code)
	// 	expectedResponse := `{"email": "user@example.com", "name": "John Doe"}`
	// 	assert.JSONEq(t, expectedResponse, w.Body.String())
	// })

	t.Run("Error in SaveMemberInfo", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/memberregistration", bytes.NewBufferString(`{"name": "John Doe", "contact": "1234567890", "password": "ValidPassword123!", "token": "validToken", "workspace": "test-workspace"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock CheckPassword to return true (valid password)
		monkey.Patch(methods.CheckPassword, func(password string) bool {
			return true
		})
		defer monkey.Unpatch(methods.CheckPassword)

		// Mock SaveMemberInfo to return an error (non-200 status)
		monkey.Patch(member.SaveMemberInfo, func(token, password, workspace, name, contact string) (int, map[string]interface{}) {
			return 500, map[string]interface{}{"error": "Internal Server Error"}
		})
		defer monkey.Unpatch(member.SaveMemberInfo)

		api.MemberRegistration(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": "Internal Server Error"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}
