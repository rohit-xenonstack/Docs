package test

import (
	"bytes"
	"encoding/json"
	"errors"

	// "fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"reflect"

	// "strings"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/azures"
	"git.xenonstack.com/nexa-platform/accounts/src/integrations"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

var file multipart.File
var fh *multipart.FileHeader

var jsonData, _ = json.Marshal(azures.KubeConfig{
	File: ValidKubeConfig,
	InfraIntegration: database.InfraIntegration{
		ID:          1,
		ClusterName: "mock-cluster",
		Workspace:   "mock-workspace",
		CloudType:   "azure",
		Framework:   "kubernetes",
		UserName:    "mock-user",
		UserEmail:   "mock-user@example.com",
		FrameStatus: map[string]database.Status{
			"mock-cluster": {
				Msg:    "success",
				Health: 1,
			},
		},
		AddedAt:  time.Now().Unix(),
		UpdateAt: time.Now().Unix(),
	},
})
var InfraIntegrationJsonData, _ = json.Marshal(database.InfraIntegration{
	ID:          1,
	ClusterName: "mock-cluster",
	Workspace:   "mock-workspace",
	CloudType:   "azure",
	Framework:   "kubernetes",
	UserName:    "mock-user",
	UserEmail:   "mock-user@example.com",
	FrameStatus: map[string]database.Status{
		"mock-cluster": {
			Msg:    "success",
			Health: 1,
		},
	},
	AddedAt:  time.Now().Unix(),
	UpdateAt: time.Now().Unix(),
},
)

const ValidKubeConfig = `{
	"apiVersion": "v1",
	"kind": "Config",
	"clusters": [{
		"name": "mock-cluster",
		"cluster": {
			"server": "https://127.0.0.1:6443"
		}
	}],
	"contexts": [{
		"name": "mock-context",
		"context": {
			"cluster": "mock-cluster",
			"user": "mock-user"
		}
	}],
	"current-context": "mock-context",
	"users": [{
		"name": "mock-user",
		"user": {
			"token": "mock-token"
		}
	}]
}`

func TestSaveKube(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, _, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	// Test case 1: Workspace not found
	t.Run("Workspace Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request with invalid workspace
		req := httptest.NewRequest("POST", "/save/config", bytes.NewBufferString(`{"File": "test"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock jwt claims
		claims := jwt.MapClaims{}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKube(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test case 2: Name not found
	t.Run("Name Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request with invalid name
		req := httptest.NewRequest("POST", "/save/config", bytes.NewBufferString(`{"File": "test"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock jwt claims
		claims := jwt.MapClaims{"workspace": "test"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKube(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test case 3: Email not found
	t.Run("Email Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request with invalid email
		req := httptest.NewRequest("POST", "/save/config", bytes.NewBufferString(`{"File": "test"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock jwt claims
		claims := jwt.MapClaims{"workspace": "test", "name": "test"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKube(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test case 4: Invalid kubeconfig data
	t.Run("Invalid Kubeconfig Data", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request with invalid kubeconfig data
		req := httptest.NewRequest("POST", "/save/config", bytes.NewBufferString(`{"File":123}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock jwt claims
		claims := jwt.MapClaims{"workspace": "test", "name": "test", "email": "test"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKube(ctx)

		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Invalid kubeconfig data.", response["message"])
	})

	// Test case 5: File not passed
	t.Run("File Not Passed", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request with no file
		req := httptest.NewRequest("POST", "/save/config", bytes.NewBufferString(`{"file":"","cloud_type":"test","framework":"test","cluster_name":"test"}}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock jwt claims
		claims := jwt.MapClaims{"workspace": "test", "name": "test", "email": "test"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKube(ctx)

		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Please pass the file", response["message"])
	})

	// t.Run("File Size Exceeds Limit", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	// Mock request with a large file
	// 	largeFile := strings.Repeat("a", 1024*1024+1) // 1MB + 1 byte
	// 	req := httptest.NewRequest("POST", "/save/config", bytes.NewBufferString(fmt.Sprintf(`{"File":"%s","cloud_type":"test","framework":"test","cluster_name":"test"}`, largeFile)))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	// Mock jwt claims
	// 	claims := jwt.MapClaims{"workspace": "test", "name": "test", "email": "test"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	// Patch the CheckFileSize function
	// 	patch := monkey.Patch(methods.CheckFileSize, func(size int) error {
	// 		if size > 1024*1024 {
	// 			return errors.New("File size exceeds 1MB limit")
	// 		}
	// 		return nil
	// 	})
	// 	defer patch.Unpatch()

	// 	api.SaveKube(ctx)

	// 	assert.Equal(t, 400, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Contains(t, response["message"].(string), "File size exceeds 1MB limit")
	// })

	// "File Size Validation Failure"

	// t.Run("Missing JWT Claims", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)
	// 	req, _ := http.NewRequest("POST", "/save-kube", nil)
	// 	ctx.Request = req
	// 	claims := jwt.MapClaims{"workspace": "workspace-123"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	api.SaveKube(ctx)

	// 	assert.Equal(t, 500, w.Code)
	// 	assert.Contains(t, w.Body.String(), "please login again")
	// })

	t.Run("API Call Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch((*azures.KubeConfig).ValidateKubeFileandSave, func(kc *azures.KubeConfig, data []uint8, workspace, email string) (map[string]interface{}, int) {
			return nil, http.StatusInternalServerError
		})

		defer monkey.UnpatchAll()

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("POST", "/save/kube", bytes.NewBuffer(jsonData))
		c.Request = req
		claims := jwt.MapClaims{"name": "john", "email": "test@test.com"}
		c.Set("JWT_PAYLOAD", claims)

		api.SaveKube(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch((*azures.KubeConfig).ValidateKubeFileandSave, func(kc *azures.KubeConfig, data []uint8, workspace, email string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"success": true,
				"message": "Kubeconfig validated and saved",
			}, 200
		})

		monkey.Patch(methods.CheckFileSize, func(size int) error {
			return errors.New("file too large")
		})
		defer monkey.UnpatchAll()

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("POST", "/save-kube", bytes.NewBuffer(jsonData))

		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{"workspace": "workspace-123", "name": "john", "email": "test@test.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKube(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "success")
	})
}

func TestSaveKubeFile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Mock database
	_, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer mock.ExpectClose()

	// "File Size Validation Failure"

	t.Run("API Call Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch((*azures.KubeConfig).ValidateKubeFileandSave, func(kc *azures.KubeConfig, data []uint8, workspace, email string) (map[string]interface{}, int) {
			return nil, http.StatusInternalServerError
		})
		defer monkey.UnpatchAll()

		monkey.Patch(api.FileForm, func(c *gin.Context) (azures.KubeConfig, []byte, error) {
			return azures.KubeConfig{}, nil, errors.New("invalid kubeconfig data")
		})

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("POST", "/save-kube", bytes.NewBuffer(jsonData))
		ctx.Request = req
		claims := jwt.MapClaims{"name": "john", "email": "test@test.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKubeFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(methods.CheckFileSize, func(size int) error {
			return nil
		})
		monkey.Patch((*azures.KubeConfig).ValidateKubeFileandSave, func(kc *azures.KubeConfig, data []uint8, workspace, email string) (map[string]interface{}, int) {
			return map[string]interface{}{"message": "success"}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		monkey.Patch(api.FileForm, func(c *gin.Context) (azures.KubeConfig, []byte, error) {
			return azures.KubeConfig{}, []byte{}, nil
		})

		monkey.Patch(api.GetTokenClaims, func(c *gin.Context) (string, string, string, bool) {
			return "workspace-123", "john", "test@test.com", false
		})

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("POST", "/save-kube", bytes.NewBuffer(jsonData))
		ctx.Request = req
		claims := jwt.MapClaims{"workspace": "workspace-123", "name": "john", "email": "test@test.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.SaveKubeFile(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "success")
	})
}

func TestFileForm(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Missing File Upload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/file-form", nil)
		ctx.Request = req

		_, _, err := api.FileForm(ctx)
		assert.Error(t, err)
		assert.Equal(t, "please pass all required fields", err.Error())
	})

	t.Run("Missing Form Data", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		writer.Close()

		req := httptest.NewRequest("POST", "/file-form", body)
		req.Header.Set("Content-Type", writer.FormDataContentType())
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Request = req

		monkey.PatchInstanceMethod(reflect.TypeOf(ctx), "MustBindWith", func(_ *gin.Context, _ interface{}, _ binding.Binding) error {
			return errors.New("binding error")
		})
		defer monkey.UnpatchAll()

		_, _, err := api.FileForm(ctx)
		assert.Error(t, err)
		assert.Equal(t, "please pass all required fields", err.Error())
	})

	// "File Size Exceeds Limit"

	t.Run("Failed to Open File", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		filePart, _ := writer.CreateFormFile("file", "test.kubeconfig")
		filePart.Write([]byte("fake kubeconfig content"))
		writer.Close()

		req := httptest.NewRequest("POST", "/file-form", body)
		req.Header.Set("Content-Type", writer.FormDataContentType())
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Request = req

		_, _, err := api.FileForm(ctx)
		assert.Error(t, err)
	})

	t.Run("Error Reading File Content", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		filePart, _ := writer.CreateFormFile("file", "test.kubeconfig")
		filePart.Write([]byte("fake kubeconfig content"))
		writer.Close()

		req := httptest.NewRequest("POST", "/file-form", body)
		req.Header.Set("Content-Type", writer.FormDataContentType())
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Request = req

		monkey.Patch(io.ReadAll, func(_ io.Reader) ([]byte, error) {
			return nil, errors.New("read error")
		})
		defer monkey.UnpatchAll()

		_, _, err := api.FileForm(ctx)
		assert.Error(t, err)
	})

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		body := &bytes.Buffer{}
		writer := multipart.NewWriter(body)
		filePart, _ := writer.CreateFormFile("file", "test.kubeconfig")
		filePart.Write([]byte("fake kubeconfig content"))
		writer.Close()

		req := httptest.NewRequest("POST", "/file-form", body)
		req.Header.Set("Content-Type", writer.FormDataContentType())
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Request = req

		monkey.PatchInstanceMethod(reflect.TypeOf(ctx), "MustBindWith", func(_ *gin.Context, _ interface{}, _ binding.Binding) error {
			log.Println("mock 2")
			return nil
		})
		defer monkey.UnpatchAll()

		_, fileBytes, err := api.FileForm(ctx)
		assert.NoError(t, err)
		assert.NotNil(t, fileBytes)
		assert.Equal(t, "fake kubeconfig content", string(fileBytes))
	})
}

func TestGetKubeFile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Missing Workspace in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/get-kube-file", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
			"email": "user@example.com",
		})

		api.GetKubeFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), api.LoginAgainMessage)
	})

	t.Run("Missing Email in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/get-kube-file", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
			"workspace": "test-workspace",
		})

		api.GetKubeFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), api.LoginAgainMessage)
	})

	t.Run("Integration GetFile Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/get-kube-file", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
			"workspace": "test-workspace",
			"email":     "user@example.com",
		})
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-cluster"})

		monkey.Patch(integrations.GetFile, func(name, workspace, email string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   true,
				"message": "File not found",
			}, http.StatusNotFound
		})
		defer monkey.UnpatchAll()

		api.GetKubeFile(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		assert.Contains(t, w.Body.String(), "File not found")
	})

	t.Run("Successful GetKubeFile Call", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/get-kube-file", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
			"workspace": "test-workspace",
			"email":     "user@example.com",
		})
		ctx.Params = append(ctx.Params, gin.Param{Key: "name", Value: "test-cluster"})

		monkey.Patch(integrations.GetFile, func(name, workspace, email string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"success": true,
				"data":    "mocked kubeconfig",
			}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		api.GetKubeFile(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "mocked kubeconfig")
	})
}

// func TestDeleteInfrastructure(t *testing.T) {
// SetupLogging()
// ResetLogs()
// 	gin.SetMode(gin.TestMode)

// 	t.Run("Missing Name in Claims", func(t *testing.T) {
//  SetupLogging()
// ResetLogs()
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		ctx.Request = httptest.NewRequest("DELETE", "/delete-infra", nil)
// 		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
// 			"email":     "user@example.com",
// 			"workspace": "test-workspace",
// 		})

// 		api.DeleteInfrastucture(ctx)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "please login again")
// 	})

// 	t.Run("Missing Email in Claims", func(t *testing.T) {
// SetupLogging()
// ResetLogs()
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		ctx.Request = httptest.NewRequest("DELETE", "/delete-infra", nil)
// 		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
// 			"name":      "test-name",
// 			"workspace": "test-workspace",
// 		})

// 		api.DeleteInfrastucture(ctx)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "please login again")
// 	})

// 	t.Run("Missing Workspace in Claims", func(t *testing.T) {
// SetupLogging()
// ResetLogs()
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		ctx.Request = httptest.NewRequest("DELETE", "/delete-infra", nil)
// 		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
// 			"name":  "test-name",
// 			"email": "user@example.com",
// 		})

// 		api.DeleteInfrastucture(ctx)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "please login again")
// 	})

// 	t.Run("DeleteInfraIntegration Error", func(t *testing.T) {
//  SetupLogging()
// ResetLogs()
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		ctx.Request = httptest.NewRequest("DELETE", "/delete-infra/test-id", nil)
// 		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
// 			"name":      "test-name",
// 			"email":     "user@example.com",
// 			"workspace": "test-workspace",
// 		})
// 		ctx.Params = append(ctx.Params, gin.Param{Key: "id", Value: "test-id"})

// 		monkey.Patch(azures.DeleteInfraIntegration, func(id, workspace, name, email, ip string) (map[string]interface{}, int) {
// 			return map[string]interface{}{
// 				"error":   true,
// 				"message": "Deletion failed",
// 			}, http.StatusInternalServerError
// 		})
// 		defer monkey.UnpatchAll()

// 		api.DeleteInfrastucture(ctx)

// 		assert.Equal(t, http.StatusInternalServerError, w.Code)
// 		assert.Contains(t, w.Body.String(), "Deletion failed")
// 	})

// 	t.Run("Successful DeleteInfrastructure Call", func(t *testing.T) {
//   SetupLogging()
//    ResetLogs()
// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)

// 		ctx.Request = httptest.NewRequest("DELETE", "/delete-infra/test-id", nil)
// 		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{
// 			"name":      "test-name",
// 			"email":     "user@example.com",
// 			"workspace": "test-workspace",
// 		})
// 		ctx.Params = append(ctx.Params, gin.Param{Key: "id", Value: "test-id"})

// 		monkey.Patch(azures.DeleteInfraIntegration, func(id, workspace, name, email, ip string) (map[string]interface{}, int) {
// 			return map[string]interface{}{
// 				"success": true,
// 				"message": "Infrastructure deleted",
// 			}, http.StatusOK
// 		})
// 		defer monkey.UnpatchAll()

// 		api.DeleteInfrastucture(ctx)

// 		assert.Equal(t, http.StatusOK, w.Code)
// 		assert.Contains(t, w.Body.String(), "Infrastructure deleted")
// 	})
// }

func TestDeleteInfrastructure(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gdb, _, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	gin.SetMode(gin.TestMode)

	t.Run("Successful Infrastructure Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "id", Value: "123"}}

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace1", "name": "user1", "id": "1"}
		c.Set("JWT_PAYLOAD", claims)

		// Mock DeleteInfraIntegration
		monkey.Patch(azures.DeleteInfraIntegration, func(id, workspace, name, email, ip string) (map[string]interface{}, int) {
			return map[string]interface{}{"success": true}, http.StatusOK
		})
		defer monkey.Unpatch(azures.DeleteInfraIntegration)

		api.DeleteInfrastucture(c)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestGetTokenClaims(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Successful Extraction", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace1", "name": "user1", "id": "1"}
		c.Set("JWT_PAYLOAD", claims)

		_, _, workspace, name, email, shouldReturn := api.GetTokenClaims(c)
		assert.Equal(t, "workspace1", workspace)
		assert.Equal(t, "user1", name)
		assert.Equal(t, "user@example.com", email)
		assert.False(t, shouldReturn)
	})

	t.Run("Missing Workspace Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"email": "user@example.com", "name": "user1"}
		c.Set("JWT_PAYLOAD", claims)

		_, _, workspace, _, _, shouldReturn := api.GetTokenClaims(c)
		assert.Equal(t, "", workspace)
		assert.True(t, shouldReturn)
	})

	t.Run("Missing Name Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"email": "user@example.com", "name": "user1"}
		c.Set("JWT_PAYLOAD", claims)

		_, _, _, name, _, shouldReturn := api.GetTokenClaims(c)
		assert.Equal(t, "", name)
		assert.True(t, shouldReturn)
	})

	t.Run("Missing Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace1", "name": "user1"}
		c.Set("JWT_PAYLOAD", claims)

		email := ""
		_, _, _, _, email, shouldReturn := api.GetTokenClaims(c)
		assert.Equal(t, "", email)
		assert.True(t, shouldReturn)
	})
}
