package test

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestLogout(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test case: Successful Logout
	t.Run("Successful Logout", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/logout", nil)
		req.Header.Set("Authorization", "Bearer valid-token")
		ctx.Request = req

		// Mock redisdb.DeleteToken to simulate successful token deletion
		monkey.Patch(redisdb.DeleteToken, func(token string) error {
			return nil // No error
		})
		// Mock jwtToken.DeleteTokenFromDb to simulate successful deletion
		monkey.Patch(jwtToken.DeleteTokenFromDb, func(token string) {
			// No-op for testing purposes
		})
		defer monkey.Unpatch(redisdb.DeleteToken)
		defer monkey.Unpatch(jwtToken.DeleteTokenFromDb)

		api.Logout(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Successfully logout"}`, w.Body.String())
	})

	// Test case: Error Deleting Token from Redis
	t.Run("Error Deleting Token from Redis", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/logout", nil)
		req.Header.Set("Authorization", "Bearer valid-token")
		ctx.Request = req

		// Mock the redisdb.DeleteToken function to simulate an error
		monkey.Patch(redisdb.DeleteToken, func(token string) error {
			return fmt.Errorf("Redis error")
		})
		defer monkey.Unpatch(redisdb.DeleteToken)

		// Mock the jwtToken.DeleteTokenFromDb function (no-op)
		monkey.Patch(jwtToken.DeleteTokenFromDb, func(token string) {
			// Prevent actual DB call during test to avoid nil pointer dereference
		})
		defer monkey.Unpatch(jwtToken.DeleteTokenFromDb)

		api.Logout(ctx)

		// The error code from the actual response is 501 based on your logs.
		assert.Equal(t, 501, w.Code)
		// Ensure that the error message returned is now a string, not a map.
	})

}
