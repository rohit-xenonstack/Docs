package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"os"
	"regexp"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
)

func TestAwsOnboardingHealthCheck(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(api.CallPythonAPI, func(endpoint string, method string, body []byte) ([]byte, error) {
			return []byte(`{"status":"healthy"}`), nil
		})
		defer monkey.UnpatchAll()

		req, _ := http.NewRequest("GET", "/aws-onboarding/health", nil)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		api.AwsOnboardingHealthCheck(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"status":"healthy"`)
	})

	t.Run("API Call Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(api.CallPythonAPI, func(endpoint string, method string, body []byte) ([]byte, error) {
			return nil, errors.New("API call failed")
		})
		defer monkey.UnpatchAll()

		req, _ := http.NewRequest("GET", "/aws-onboarding/health", nil)
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		api.AwsOnboardingHealthCheck(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "API call failed")
	})
}

func TestAwsOnboardingRegisterRole(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db)
	assert.NoError(t, err)
	config.DB = gormDB

	t.Run("Success - Existing Record Updated", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock SELECT query to return an existing record
		rows := sqlmock.NewRows([]string{"id", "user_id", "account_name", "account_id", "manage_access", "is_active", "user_resource_arn", "role_arn", "policy_arn", "region", "created_at", "updated_at", "deleted_at", "selected_cluster"}).
			AddRow(1, 1, "", "123456", false, false, "arn:aws:iam::123456:user/test", "arn:aws:role", "arn:aws:policy", "", time.Now(), time.Now(), nil, "")

		mock.ExpectQuery(regexp.QuoteMeta(
			`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1 and account_id = $2)) ORDER BY "aws_account_roles"."id" ASC LIMIT 1`)).
			WithArgs(1, "123456").
			WillReturnRows(rows) // Simulating record exists

		// Expect transaction BEGIN
		mock.ExpectBegin()

		// Mock UPDATE query expectation
		mock.ExpectExec(regexp.QuoteMeta(
			`UPDATE "aws_account_roles" SET "account_id" = $1, "policy_arn" = $2, "role_arn" = $3, "updated_at" = $4, "user_id" = $5, "user_resource_arn" = $6 WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $7 and account_id= $8))`)).
			WithArgs(
				"123456",                        // $1 - account_id
				"arn:aws:policy",                // $2 - policy_arn
				"arn:aws:role",                  // $3 - role_arn
				sqlmock.AnyArg(),                // $4 - updated_at
				1,                               // $5 - user_id
				"arn:aws:iam::123456:user/test", // $6 - user_resource_arn
				1,                               // $7 - user_id (WHERE clause)
				"123456",                        // $8 - account_id (WHERE clause)
			).WillReturnResult(sqlmock.NewResult(1, 1))

		// Expect transaction COMMIT
		mock.ExpectCommit()

		requestBody := models.AWSAccountRoles{
			UserId:          1,
			PolicyARN:       "arn:aws:policy",
			RoleARN:         "arn:aws:role",
			UserResourceARN: "arn:aws:iam::123456:user/test",
			AccountId:       "123456",
		}

		reqBodyBytes, _ := json.Marshal(requestBody)
		req, _ := http.NewRequest("POST", "/aws-onboarding/register-role", bytes.NewBuffer(reqBodyBytes))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		monkey.Patch(api.CallPythonAPI, func(endpoint string, method string, requestBody []byte) ([]byte, error) {
			return []byte(`{}`), nil
		})

		api.AwsOnboardingRegisterRole(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.NoError(t, mock.ExpectationsWereMet()) // Ensure all expectations were met
	})

	t.Run("Failure - Invalid JSON", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		req, _ := http.NewRequest("POST", "/aws-onboarding/register-role", bytes.NewBuffer([]byte("{invalid json}")))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r := gin.Default()
		r.POST("/aws-onboarding/register-role", api.AwsOnboardingRegisterRole)
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Invalid request body")
	})

	t.Run("Failure - Database Error on Update", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock SELECT query to return an existing record
		rows := sqlmock.NewRows([]string{"id", "user_id", "account_name", "account_id", "manage_access", "is_active", "user_resource_arn", "role_arn", "policy_arn", "region", "created_at", "updated_at", "deleted_at", "selected_cluster"}).
			AddRow(1, 1, "", "123456", false, false, "arn:aws:iam::123456:user/test", "arn:aws:role", "arn:aws:policy", "", time.Now(), time.Now(), nil, "")

		mock.ExpectQuery(regexp.QuoteMeta(
			`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1 and account_id = $2)) ORDER BY "aws_account_roles"."id" ASC LIMIT 1`)).
			WithArgs(1, "123456").
			WillReturnRows(rows) // Simulating record existsde

		// Expect transaction BEGIN
		mock.ExpectBegin()

		// Mock UPDATE query expectation
		mock.ExpectExec(regexp.QuoteMeta(
			`UPDATE "aws_account_roles" SET "account_id" = $1, "policy_arn" = $2, "role_arn" = $3, "updated_at" = $4, "user_id" = $5, "user_resource_arn" = $6 WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $7 and account_id= $8))`)).
			WithArgs(
				"123456",                        // $1 - account_id
				"arn:aws:policy",                // $2 - policy_arn
				"arn:aws:role",                  // $3 - role_arn
				sqlmock.AnyArg(),                // $4 - updated_at
				1,                               // $5 - user_id
				"arn:aws:iam::123456:user/test", // $6 - user_resource_arn
				1,                               // $7 - user_id (WHERE clause)
				"123456",                        // $8 - account_id (WHERE clause)
			).WillReturnError(errors.New("db update error"))

		// Expect transaction COMMIT
		mock.ExpectCommit()

		requestBody := models.AWSAccountRoles{UserId: 1, PolicyARN: "arn:aws:policy", RoleARN: "arn:aws:role", UserResourceARN: "arn:aws:iam::123456:user/test"}
		reqBodyBytes, _ := json.Marshal(requestBody)
		req, _ := http.NewRequest("POST", "/aws-onboarding/register-role", bytes.NewBuffer(reqBodyBytes))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		api.AwsOnboardingRegisterRole(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Failed to update role details")
	})
}

func TestAwsOnboardingListClusters(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db)
	assert.NoError(t, err)
	config.DB = gormDB

	t.Run("API Call Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1)) ORDER BY "aws_account_roles"."id" DESC LIMIT 1`)).
			WithArgs("user123").
			WillReturnRows(sqlmock.NewRows([]string{"user_resource_arn", "region"}).AddRow("arn:aws:iam::123456789012:role/test-role", "us-east-1"))

		monkey.Patch(api.CallPythonAPI, func(endpoint string, method string, body []byte) ([]byte, error) {
			return nil, errors.New("API call failed")
		})
		defer monkey.UnpatchAll()

		req, _ := http.NewRequest("GET", "/aws-onboarding/list-clusters?user_id=user123", nil)
		w := httptest.NewRecorder()
		r := gin.Default()
		r.GET("/aws-onboarding/list-clusters", api.AwsOnboardingListClusters)
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "API call failed")
	})

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1)) ORDER BY "aws_account_roles"."id" DESC LIMIT 1`)).
			WithArgs("user123").
			WillReturnRows(sqlmock.NewRows([]string{"user_resource_arn", "region"}).AddRow("arn:aws:iam::123456789012:role/test-role", "us-east-1"))

		monkey.Patch(api.CallPythonAPI, func(endpoint string, method string, body []byte) ([]byte, error) {
			return []byte(`{"clusters":["cluster-1", "cluster-2"]}`), nil
		})
		defer monkey.UnpatchAll()

		req, _ := http.NewRequest("GET", "/aws/clusters?user_id=user123", nil)
		w := httptest.NewRecorder()
		r := gin.Default()
		r.GET("/aws/clusters", api.AwsOnboardingListClusters)
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "cluster-1")
		assert.Contains(t, w.Body.String(), "cluster-2")
	})

	t.Run("Database Query Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles"  WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1)) ORDER BY "aws_account_roles"."id" ASC LIMIT 1`)).
			WithArgs("user123").
			WillReturnError(errors.New("database error"))

		req, _ := http.NewRequest("GET", "/aws-onboarding/list-clusters?user_id=user123", nil)
		w := httptest.NewRecorder()
		r := gin.Default()
		r.GET("/aws-onboarding/list-clusters", api.AwsOnboardingListClusters)
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Failed to get user resource ARN")
	})
}

func TestCallPythonAPI(t *testing.T) {
	SetupLogging()
	ResetLogs()
	os.Setenv("PYTHON_BACKEND_ENDPOINT", "http://mockserver")
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusOK)
			w.Write([]byte(`{"message":"success"}`))
		}))
		defer server.Close()

		os.Setenv("PYTHON_BACKEND_ENDPOINT", server.URL)
		resp, err := api.CallPythonAPI("/test-endpoint", "GET", nil)
		assert.NoError(t, err)
		assert.Contains(t, string(resp), "success")
	})

	t.Run("Request Creation Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		os.Setenv("PYTHON_BACKEND_ENDPOINT", "invalid://url")
		resp, err := api.CallPythonAPI("/test-endpoint", "GET", nil)
		assert.Error(t, err)
		assert.Nil(t, resp)
	})

	// t.Run("Response Read Failure", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
	// 		w.WriteHeader(http.StatusOK)
	// 		w.(http.Flusher).Flush()
	// 		w.Write([]byte(`{"message":"partial"}`))
	// 	}))
	// 	defer server.Close()

	// 	os.Setenv("PYTHON_BACKEND_ENDPOINT", server.URL)
	// 	resp, err := api.CallPythonAPI("/test-endpoint", "GET", nil)
	// 	assert.Error(t, err)
	// 	assert.Nil(t, string(resp))
	// })
}

func TestConstants(t *testing.T) {
	SetupLogging()
	ResetLogs()
	tests := []struct {
		name     string
		got      string
		expected string
	}{
		{"LoginAgainMessage", api.LoginAgainMessage, "Please login again"},
		{"ClientAgentUser", api.ClientAgentUser, "User-Agent"},
		{"NotAuthorizedMessage", api.NotAuthorizedMessage, "You are not authorized"},
		{"MinioEmailLog", api.MinioEmailLog, "===email==="},
		{"WorkspaceNotMatchMessage", api.WorkspaceNotMatchMessage, "Workspace does not match"},
		{"GetDeployModelWhereConditions", api.GetDeployModelWhereConditions, "workspace_id = ? AND member_email = ?"},
		{"WorkSpaceEmailError", api.WorkSpaceEmailError, "Email does not belong to the same workspace"},
		{"WorkspaceIdWhereCondition", api.WorkspaceIdWhereCondition, "workspace_id = ?"},
		{"InvalidData", api.InvalidData, "Invalid data"},
		{"NexaStackSubBasePath", api.NexaStackSubBasePath, ".nexastack.neuralcompany.team"},
		{"Http", api.Http, "https://"},
		{"NoteBookIngressNexaStackURL", api.NoteBookIngressNexaStackURL, ".nexastack.neuralcompany.team/"},
		{"ContentHeader", api.ContentHeader, "application/json; charset=utf-8"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			if tt.got != tt.expected {
				t.Errorf("Expected %s but got %s", tt.expected, tt.got)
			}
		})
	}
}

func TestGetAwsAccountsByUserId(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	gdb, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	t.Run("Successful Fetch", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "user_id", Value: "123"}}
		c.Request = httptest.NewRequest("GET", "/aws/accounts?limit=10&offset=0", nil)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles"  WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1)) LIMIT 10`)).
			WithArgs("123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "user_id"}).AddRow(1, "123"))

		api.GetAwsAccountsByUserId(c)

		assert.Equal(t, http.StatusOK, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.False(t, resp["error"].(bool))
	})

	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "user_id", Value: "123"}}
		c.Request = httptest.NewRequest("GET", "/aws/accounts", nil)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1)) LIMIT 10 OFFSET 0`)).
			WithArgs("123").
			WillReturnError(assert.AnError)

		api.GetAwsAccountsByUserId(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestAwsOnboardingClusterHealthCheck(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	gdb, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	// Success - Cluster Health Check
	t.Run("Success - Cluster Health Check", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		reqBody := models.ClusterRegister{UserId: "1", ClusterName: "test-cluster"}
		reqBodyBytes, _ := json.Marshal(reqBody)

		c.Request = httptest.NewRequest(http.MethodPost, "/aws/cluster-health", bytes.NewBuffer(reqBodyBytes))
		c.Request.Header.Set("Content-Type", "application/json")

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "aws_account_roles" SET "selected_cluster"`)).
			WithArgs("test-cluster", sqlmock.AnyArg(), "1").
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		rows := sqlmock.NewRows([]string{"id", "account_id", "user_id", "user_resource_arn", "region"}).
			AddRow(1, "123", "1", "arn:aws:iam::123456789012:role/TestRole", "us-west-2")

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1 and account_id = $2)) ORDER BY "aws_account_roles"."id" ASC LIMIT 1`)).
			WithArgs("1", "").
			WillReturnRows(rows)

		monkey.Patch(api.CallPythonAPI, func(endpoint string, method string, requestBody []byte) ([]byte, error) {
			return []byte(`{"status": "Cluster /check-cluster-health"}`), nil
		})
		defer monkey.Unpatch(api.CallPythonAPI)

		api.AwsOnboardingClusterHealthCheck(c)

		assert.Equal(t, http.StatusOK, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.Contains(t, resp["status"], "Cluster /check-cluster-health")

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Failure - Invalid JSON Request
	t.Run("Failure - Invalid JSON Request", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		c.Request = httptest.NewRequest(http.MethodPost, "/aws/cluster-health", bytes.NewBuffer([]byte(`{invalid_json`)))
		c.Request.Header.Set("Content-Type", "application/json")

		api.AwsOnboardingClusterHealthCheck(c)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true, "message":"Invalid request body"}`, w.Body.String())
	})

	// Failure - Database Update Error
	t.Run("Failure - Database Update Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		reqBody := models.ClusterRegister{UserId: "1", ClusterName: "test-cluster"}
		reqBodyBytes, _ := json.Marshal(reqBody)

		c.Request = httptest.NewRequest(http.MethodPost, "/aws/cluster-health", bytes.NewBuffer(reqBodyBytes))
		c.Request.Header.Set("Content-Type", "application/json")

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "aws_account_roles" SET "selected_cluster"`)).
			WithArgs("test-cluster", sqlmock.AnyArg(), "1").
			WillReturnError(errors.New("database update failed"))
		mock.ExpectRollback()

		api.AwsOnboardingClusterHealthCheck(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true, "message":"Failed to update selected cluster: database update failed"}`, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Failure - Database Query Error
	t.Run("Failure - Database Query Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		reqBody := models.ClusterRegister{UserId: "1", ClusterName: "test-cluster"}
		reqBodyBytes, _ := json.Marshal(reqBody)

		c.Request = httptest.NewRequest(http.MethodPost, "/aws/cluster-health", bytes.NewBuffer(reqBodyBytes))
		c.Request.Header.Set("Content-Type", "application/json")

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "aws_account_roles" SET "selected_cluster"`)).
			WithArgs("test-cluster", sqlmock.AnyArg(), "1").
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "aws_account_roles" WHERE "aws_account_roles"."deleted_at" IS NULL AND ((user_id = $1 and account_id = $2)) ORDER BY "aws_account_roles"."id" ASC LIMIT 1`)).
			WithArgs("1", "").
			WillReturnError(errors.New("database query failed"))

		api.AwsOnboardingClusterHealthCheck(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"message": "Failed to get user resource ARN: database query failed", "error": true}`, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})
}

func TestGetAwsOnboardRoleConfiguration(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		expectedAccountID := "arn:aws:iam::123456789012:role/NexaStackRole"

		// Mock os.Getenv to return a valid role ARN
		monkey.Patch(os.Getenv, func(key string) string {
			if key == "NEXASTACK_ASSUME_ROLE_ARN" {
				return expectedAccountID
			}
			return ""
		})
		defer monkey.UnpatchAll()

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("GET", "/aws-onboard-role", nil)
		ctx.Request = req

		api.GetAwsOnboardRoleConfiguration(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), expectedAccountID)
		assert.Contains(t, w.Body.String(), `"error":false`)
	})

	t.Run("Missing Environment Variable", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock os.Getenv to return an empty string
		monkey.Patch(os.Getenv, func(key string) string {
			if key == "NEXASTACK_ASSUME_ROLE_ARN" {
				return ""
			}
			return ""
		})
		defer monkey.UnpatchAll()

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req, _ := http.NewRequest("GET", "/aws-onboard-role", nil)
		ctx.Request = req

		api.GetAwsOnboardRoleConfiguration(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"AWS":""`)
		assert.Contains(t, w.Body.String(), `"error":false`)
	})
}

func TestGetAccountIDFromARN(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Valid ARN", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		arn := "arn:aws:iam::123456789012:role/NexaStackRole"
		expected := "123456789012"

		accountID, err := api.GetAccountIDFromARN(arn)
		assert.NoError(t, err)
		assert.Equal(t, expected, accountID)
	})

	t.Run("Valid ARN with different service", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		arn := "arn:aws:s3::098765432109:bucket/my-bucket"
		expected := "098765432109"

		accountID, err := api.GetAccountIDFromARN(arn)
		assert.NoError(t, err)
		assert.Equal(t, expected, accountID)
	})
}
