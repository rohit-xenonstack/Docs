package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/minioBucket"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/minio/minio-go/v7"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

type Bucket struct {
	BucketName string `json:"bucket_name"`
}

func createMultipartRequest() (*bytes.Buffer, string, error) {
	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)

	_ = writer.WriteField("bucket_name", "my-bucket")
	_ = writer.WriteField("email", "user@example.com")
	_ = writer.WriteField("workspace", "ws12345")

	// Simulate file upload
	part, _ := writer.CreateFormFile("upload_file", "test.txt")
	part.Write([]byte("dummy file content"))

	writer.Close()
	return body, writer.FormDataContentType(), nil
}

func TestDeleteMinioObject(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test Case 1: Missing JWT Claims
	t.Run("Missing JWT Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Create request body
		bucket := Bucket{BucketName: "my-test-bucket"}
		jsonData, _ := json.Marshal(bucket)

		req := httptest.NewRequest("DELETE", "/buckets/folder1/file1.txt", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Set params
		ctx.Params = []gin.Param{
			{Key: "folderName", Value: "folder1"},
			{Key: "fileName", Value: "file1.txt"},
		}

		claims := jwt.MapClaims{"workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.DeleteMinioObject(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test Case 2: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up request with invalid JSON body
		req := httptest.NewRequest("DELETE", "/buckets/folder1/file1.txt", strings.NewReader("invalid json"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Set params
		ctx.Params = []gin.Param{
			{Key: "folderName", Value: "folder1"},
			{Key: "fileName", Value: "file1.txt"},
		}

		// Set valid claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.DeleteMinioObject(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Bucket name is required.", response["message"]) // Assuming BucketNameRequired is "Bucket name is required"
	})

	// Test Case 3: Minio Error When Deleting Object
	t.Run("Minio Error When Deleting Object", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up request with valid JSON body
		validBucket := Bucket{
			BucketName: "test-bucket",
		}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("DELETE", "/buckets/folder1/file1.txt", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Set params
		ctx.Params = []gin.Param{
			{Key: "folderName", Value: "folder1"},
			{Key: "fileName", Value: "file1.txt"},
		}

		// Set valid claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock minioBucket.DeleteMinioObject to return an error
		patch := monkey.Patch(minioBucket.DeleteMinioObject, func(bucketName, folderName, fileName string) error {
			return errors.New("failed to delete object from minio")
		})
		defer patch.Unpatch()

		api.DeleteMinioObject(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Failed to delete object", response["message"])
	})

	// Test Case 4: Successfully Delete Object
	t.Run("Successfully Delete Object", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up request with valid JSON body
		validBucket := Bucket{
			BucketName: "test-bucket",
		}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("DELETE", "/buckets/folder1/file1.txt", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Set params
		ctx.Params = []gin.Param{
			{Key: "folderName", Value: "folder1"},
			{Key: "fileName", Value: "file1.txt"},
		}

		// Set valid claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock minioBucket.DeleteMinioObject to succeed
		patch := monkey.Patch(minioBucket.DeleteMinioObject, func(bucketName, folderName, fileName string) error {
			return nil
		})
		defer patch.Unpatch()

		api.DeleteMinioObject(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Object deleted successfully", response["message"])
	})

	// Test Case 5: Missing URL Parameters
	t.Run("Missing URL Parameters", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up request with valid JSON body
		validBucket := Bucket{
			BucketName: "test-bucket",
		}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("DELETE", "/buckets//", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Set empty params
		ctx.Params = []gin.Param{
			{Key: "folderName", Value: ""},
			{Key: "fileName", Value: ""},
		}

		// Set valid claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock minioBucket.DeleteMinioObject to check parameters
		patch := monkey.Patch(minioBucket.DeleteMinioObject, func(bucketName, folderName, fileName string) error {
			if folderName == "" || fileName == "" {
				return errors.New("invalid folder name or file name")
			}
			return nil
		})
		defer patch.Unpatch()

		api.DeleteMinioObject(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Failed to delete object", response["message"])
	})
}

func TestGetFilesInFolder(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test Case 1: Missing JWT Claims
	t.Run("Missing JWT Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		bucket := Bucket{BucketName: "test-bucket"}
		jsonData, _ := json.Marshal(bucket)
		req := httptest.NewRequest("POST", "/folders/folder1", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = []gin.Param{{Key: "folderName", Value: "folder1"}}

		claims := jwt.MapClaims{}
		ctx.Set("JWT_PAYLOAD", claims)

		api.GetFilesInFolder(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test Case 2: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/folders/folder1", strings.NewReader("invalid json"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = []gin.Param{{Key: "folderName", Value: "folder1"}}

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.GetFilesInFolder(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Bucket name is required.", response["message"])
	})

	// Test Case 3: Minio Error When Fetching Files
	t.Run("Minio Error When Fetching Files", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		validBucket := Bucket{BucketName: "test-bucket"}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("POST", "/folders/folder1", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = []gin.Param{{Key: "folderName", Value: "folder1"}}

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		patch := monkey.Patch(minioBucket.GetFilesInFolder, func(bucketName string, folderName string) ([]minio.ObjectInfo, error) {
			return nil, errors.New("failed to get files")
		})
		defer patch.Unpatch()

		api.GetFilesInFolder(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Failed to get files in folder", response["message"])
	})

	// Test Case 4: Successfully Fetch Files
	t.Run("Successfully Fetch Files", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		validBucket := Bucket{BucketName: "test-bucket"}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("POST", "/folders/folder1", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.Params = []gin.Param{{Key: "folderName", Value: "folder1"}}

		// Mock JWT Payload
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock GetFilesInFolder function
		patch := monkey.Patch(minioBucket.GetFilesInFolder, func(bucketName string, folderName string) ([]minio.ObjectInfo, error) {
			return []minio.ObjectInfo{
				{
					Key:  "file1.txt",
					Size: 1024,
					ETag: "12345",
				},
				{
					Key:  "file2.txt",
					Size: 2048,
					ETag: "67890",
				},
			}, nil
		})
		defer patch.Unpatch()

		// Call the API
		api.GetFilesInFolder(ctx)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Files in folder retrieved successfully", response["message"])

		// Extract file names from response
		files := response["files"].([]interface{})
		var fileNames []string
		for _, file := range files {
			fileMap := file.(map[string]interface{})                // Convert JSON object to map
			fileNames = append(fileNames, fileMap["name"].(string)) // Extract "name" field
		}

		assert.ElementsMatch(t, []string{"file1.txt", "file2.txt"}, fileNames)
	})

}

func TestGetMinioBucketContents(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Test Case 1: Missing JWT Claims
	t.Run("Missing JWT Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		bucket := Bucket{BucketName: "test-bucket"}
		jsonData, _ := json.Marshal(bucket)
		req := httptest.NewRequest("POST", "/minio/bucket", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{}
		ctx.Set("JWT_PAYLOAD", claims)

		api.GetMinioBucketContents(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test Case 2: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/minio/bucket", strings.NewReader("invalid json"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.GetMinioBucketContents(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Bucket name is required.", response["message"])
	})

	// Test Case 3: Minio Error When Fetching Contents
	t.Run("Minio Error When Fetching Contents", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		validBucket := Bucket{BucketName: "test-bucket"}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("POST", "/minio/bucket", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		patch := monkey.Patch(minioBucket.GetMinioBucketContents, func(bucketName string) ([]minio.ObjectInfo, error) {
			return nil, errors.New("failed to get bucket contents")
		})
		defer patch.Unpatch()

		api.GetMinioBucketContents(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Failed to get Minio bucket contents", response["message"])
	})

	// Test Case 4: Successfully Fetch Bucket Contents
	t.Run("Successfully Fetch Bucket Contents", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		validBucket := Bucket{BucketName: "test-bucket"}
		jsonData, _ := json.Marshal(validBucket)
		req := httptest.NewRequest("POST", "/minio/bucket", bytes.NewBuffer(jsonData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		patch := monkey.Patch(minioBucket.GetMinioBucketContents, func(bucketName string) ([]minio.ObjectInfo, error) {
			return []minio.ObjectInfo{
				{
					Key:  "file1.txt",
					Size: 1024,
					ETag: "12345",
				},
				{
					Key:  "file2.txt",
					Size: 2048,
					ETag: "67890",
				},
			}, nil
		})
		defer patch.Unpatch()

		api.GetMinioBucketContents(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Minio bucket contents retrieved successfully", response["message"])

		files := response["contents"].([]interface{})
		var fileNames []string
		for _, file := range files {
			fileMap := file.(map[string]interface{}) // Convert JSON object to map
			if name, ok := fileMap["name"].(string); ok {
				fileNames = append(fileNames, name) // Extract "name" field
			}
		}
		assert.ElementsMatch(t, []string{"file1.txt", "file2.txt"}, fileNames)
	})
}

func TestUploadFile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	mockDB, mock, closeDB := setupMockDB(t)
	defer closeDB()
	config.DB = mockDB

	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, _, _ := createMultipartRequest()

		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Invalid request body", response["message"])
	})

	t.Run("Missing JWT Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, contentType, _ := createMultipartRequest()
		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", contentType)
		ctx.Request = req

		// JWT payload without "email"
		claims := jwt.MapClaims{"workspace": "ws12345"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Missing JWT Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, contentType, _ := createMultipartRequest()
		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", contentType)
		ctx.Request = req

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Missing JWT Workspace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, contentType, _ := createMultipartRequest()
		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", contentType)
		ctx.Request = req

		// JWT payload without "workspace"
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Workspace Not Found in DB", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, contentType, _ := createMultipartRequest()
		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", contentType)
		ctx.Request = req

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "ws12345"}
		ctx.Set("JWT_PAYLOAD", claims)

		mock.ExpectQuery(`SELECT \* FROM workspaces WHERE (workspace_id = \$1)`).
			WithArgs("ws12345").
			WillReturnError(gorm.ErrRecordNotFound)

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Workspace does not match", response["message"])
	})

}

func TestUploadFileFailureAndSuccess(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	mockDB, mock, closeDB := setupMockDB(t)
	defer closeDB()
	config.DB = mockDB

	t.Run("Successful File Upload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, contentType, _ := createMultipartRequest()
		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", contentType)
		ctx.Request = req

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "ws12345"}
		ctx.Set("JWT_PAYLOAD", claims)

		rows := sqlmock.NewRows([]string{"workspace_id"}).AddRow("ws12345")

		mock.ExpectQuery(`SELECT \* FROM "workspaces" WHERE \(workspace_id = \$1\) ORDER BY "workspaces"."id" ASC LIMIT 1`).
			WithArgs("ws12345").
			WillReturnRows(rows)

			// Mock workspace members query
		memberRows := sqlmock.NewRows([]string{"id", "workspace_id", "member_email", "workspace_role", "created"}).
			AddRow(1, "ws12345", "user@example.com", "admin", 1710432000)

		mock.ExpectQuery(`SELECT \* FROM "workspace_members" WHERE .*member_email.*AND.*workspace_id.*`).
			WithArgs("user@example.com", "ws12345").
			WillReturnRows(memberRows)

		patch := monkey.Patch(minioBucket.InsertFileInMinio, func(bucketName string, file io.Reader, header *multipart.FileHeader) error {
			return nil
		})
		defer patch.Unpatch()

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
	})
	t.Run("Minio File Upload Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		body, contentType, _ := createMultipartRequest()
		req := httptest.NewRequest("POST", "/upload", body)
		req.Header.Set("Content-Type", contentType)
		ctx.Request = req

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "ws12345"}
		ctx.Set("JWT_PAYLOAD", claims)

		rows := sqlmock.NewRows([]string{"workspace_id"}).AddRow("ws12345")

		mock.ExpectQuery(`SELECT \* FROM "workspaces" WHERE \(workspace_id = \$1\) ORDER BY "workspaces"."id" ASC LIMIT 1`).
			WithArgs("ws12345").
			WillReturnRows(rows)

			// Mock workspace members query
		memberRows := sqlmock.NewRows([]string{"id", "workspace_id", "member_email", "workspace_role", "created"}).
			AddRow(1, "ws12345", "user@example.com", "admin", 1710432000)

		mock.ExpectQuery(`SELECT \* FROM "workspace_members" WHERE .*member_email.*AND.*workspace_id.*`).
			WithArgs("user@example.com", "ws12345").
			WillReturnRows(memberRows)

		patch := monkey.Patch(minioBucket.InsertFileInMinio, func(bucketName string, file io.Reader, header *multipart.FileHeader) error {
			return errors.New("upload failed")
		})
		defer patch.Unpatch()

		api.UploadFile(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Failed to upload file", response["message"])
	})
}

func TestCreateMinioBucket(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Minio Bucket Created", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Valid JSON request
		body := map[string]string{"bucket_name": "test-bucket"}
		jsonBody, _ := json.Marshal(body)
		req := httptest.NewRequest("POST", "/create-bucket", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock JWT claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch Minio function to return success
		patch := monkey.Patch(minioBucket.CreateMinioBucket, func(bucketName string) error {
			return nil
		})
		defer patch.Unpatch()

		api.CreateMinioBucket(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Minio bucket created successfully", response["message"])
	})

	t.Run("Failure - Missing JWT Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Valid JSON request
		body := map[string]string{"bucket_name": "test-bucket"}
		jsonBody, _ := json.Marshal(body)
		req := httptest.NewRequest("POST", "/create-bucket", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// No JWT claims
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{})

		api.CreateMinioBucket(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Failure - Minio Bucket Creation Fails", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Valid JSON request
		body := map[string]string{"bucket_name": "test-bucket"}
		jsonBody, _ := json.Marshal(body)
		req := httptest.NewRequest("POST", "/create-bucket", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock JWT claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch Minio function to return failure
		patch := monkey.Patch(minioBucket.CreateMinioBucket, func(bucketName string) error {
			return errors.New("minio bucket creation failed")
		})
		defer patch.Unpatch()

		api.CreateMinioBucket(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Failed to create Minio bucket", response["message"])
	})
}
