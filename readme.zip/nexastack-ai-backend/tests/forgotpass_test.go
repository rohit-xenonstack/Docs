package test

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	forgetpass "git.xenonstack.com/nexa-platform/accounts/src/forgotpass"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestForgotPassEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test case: Invalid JSON Body (State field is missing)
	t.Run("Invalid JSON Body - Missing State", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/forgot-password", bytes.NewBufferString(`{}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		api.ForgotPassEp(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"State field is missing."}`, w.Body.String())
	})

	// Test case: Invalid email (forgot state)
	t.Run("Invalid Email - Forgot State", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"state":"forgot", "email":"invalid-email", "workspace":"workspace1"}`
		req := httptest.NewRequest("POST", "/forgot-password", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock methods.ValidateEmail
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return false // Invalid email
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		api.ForgotPassEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please enter valid email id."}`, w.Body.String())
	})

	// Test case: Valid email (forgot state)
	t.Run("Valid Email - Forgot State", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"state":"forgot", "email":"valid@example.com", "workspace":"workspace1"}`
		req := httptest.NewRequest("POST", "/forgot-password", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock methods.ValidateEmail
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true // Valid email
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		// Mock forgetpass.ForgotPassChallenge
		monkey.Patch(forgetpass.ForgotPassChallenge, func(email, workspace string) (string, bool) {
			return "Password reset link sent", true
		})
		defer monkey.Unpatch(forgetpass.ForgotPassChallenge)

		api.ForgotPassEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Password reset link sent"}`, w.Body.String())
	})

	// Test case: Invalid token/password (reset state)
	t.Run("Invalid Token - Reset State", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"state":"reset", "token":"invalid-token", "password":"new-password", "workspace":"workspace1"}`
		req := httptest.NewRequest("POST", "/forgot-password", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock forgetpass.ResetForgottenPass
		monkey.Patch(forgetpass.ResetForgottenPass, func(token, password, workspace string) (string, string, bool) {
			return "", "Invalid token", false
		})
		defer monkey.Unpatch(forgetpass.ResetForgottenPass)

		api.ForgotPassEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Invalid token"}`, w.Body.String())
	})

	// Test case: Valid token/password (reset state)
	t.Run("Valid Token - Reset State", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"state":"reset", "token":"valid-token", "password":"new-password", "workspace":"workspace1"}`
		req := httptest.NewRequest("POST", "/forgot-password", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		// Mock forgetpass.ResetForgottenPass
		monkey.Patch(forgetpass.ResetForgottenPass, func(token, password, workspace string) (string, string, bool) {
			return "valid@example.com", "Password successfully reset", true
		})
		defer monkey.Unpatch(forgetpass.ResetForgottenPass)

		api.ForgotPassEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Password successfully reset"}`, w.Body.String())
	})

	// Test case: Invalid state value
	t.Run("Invalid State", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"state":"invalid", "email":"valid@example.com", "workspace":"workspace1"}`
		req := httptest.NewRequest("POST", "/forgot-password", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.ForgotPassEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"State field value should be forgot or reset only."}`, w.Body.String())
	})
}
