package test

import (
	"errors"
	"regexp"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/postgres"
	"github.com/stretchr/testify/assert"
)

// output structure for invite member requests
type out struct {
	Role    string `json:"role"`
	Name    string `json:"name"`
	Message string `json:"message"`
}

type status struct {
	Add    []out `json:"add"`
	NotAdd []out `json:"not_add"`
}

// setupMockDBForServices sets up a mock database for testing
func setupMockDBForServices(t *testing.T) (*gorm.DB, sqlmock.Sqlmock, func()) {
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("Failed to create mock database: %v", err)
	}

	gormDB, err := gorm.Open("postgres", db)
	if err != nil {
		t.Fatalf("Failed to open gorm database: %v", err)
	}

	cleanup := func() {
		db.Close()
	}

	return gormDB, mock, cleanup
}

func TestProjectPost(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Successful project creation
	t.Run("Successful Creation", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project existence check - return no existing project
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND (("project_management"."project"."name" = $1)) ORDER BY "project_management"."project"."id" ASC LIMIT 1`)).
			WithArgs("Test Project").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "description", "workspace_id"}))

		// Mock project creation
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "project_management"."project" ("workspace_id","name","description","created_by","updated_by","created_at","updated_at","deleted_at","organization_id","project_id","environment") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING "project_management"."project"."id"`)).
			WithArgs("1", "Test Project", "Test Description", uint(0), uint(0), sqlmock.AnyArg(), sqlmock.AnyArg(), nil, 123, 0, "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		// Mock project to account mapping error
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "project_management"."project_to_account_mapping" ("project_id","account_id","created_at","updated_at","deleted_at","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING "project_management"."project_to_account_mapping"."id"`)).
			WithArgs(1, 123, sqlmock.AnyArg(), sqlmock.AnyArg(), nil, "", "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		project := models.Project{
			Name:           "Test Project",
			Description:    "Test Description",
			WorkspaceID:    "1",
			OrganizationId: 123,
		}

		response, status := api.ProjectPost(project, "test@example.com", "Test User", "127.0.0.1")

		assert.Equal(t, 200, status)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "Project successfully created", response["message"])
		assert.Equal(t, "Test Project", response["name"])
	})

	// Test case 2: Successful project update
	t.Run("Successful Update", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project existence check - return existing project
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND (("project_management"."project"."name" = $1)) ORDER BY "project_management"."project"."id" ASC LIMIT 1`)).
			WithArgs("Test Project").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "description", "workspace_id", "organization_id"}).
				AddRow(1, "Test Project", "Old Description", "old-workspace", 123))

		// Mock project update
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "project_management"."project" SET "workspace_id" = $1, "name" = $2, "description" = $3, "created_by" = $4, "updated_by" = $5, "updated_at" = $6, "deleted_at" = $7, "organization_id" = $8, "project_id" = $9, "environment" = $10 WHERE "project_management"."project"."deleted_at" IS NULL AND "project_management"."project"."id" = $11`)).
			WithArgs("new-workspace", "Test Project", "New Description", uint(0), uint(0), sqlmock.AnyArg(), nil, 123, 0, "", 1).
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		project := models.Project{
			Name:           "Test Project",
			Description:    "New Description",
			WorkspaceID:    "new-workspace",
			OrganizationId: 123,
		}

		response, status := api.ProjectPost(project, "test@example.com", "Test User", "127.0.0.1")

		assert.Equal(t, 200, status)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "Project successfully created", response["message"])
		assert.Equal(t, "Test Project", response["name"])
	})

	// Test case 3: Database error during project creation
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project existence check - return no existing project
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND (("project_management"."project"."name" = $1)) ORDER BY "project_management"."project"."id" ASC LIMIT 1`)).
			WithArgs("Test Project").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "description", "workspace_id"}))

		// Mock project creation with error
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "project_management"."project" ("workspace_id","name","description","created_by","updated_by","created_at","updated_at","deleted_at","organization_id","project_id","environment") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING "project_management"."project"."id"`)).
			WithArgs("test-workspace", "Test Project", "Test Description", uint(0), uint(0), sqlmock.AnyArg(), sqlmock.AnyArg(), nil, 123, 0, "").
			WillReturnError(errors.New("database error"))
		mock.ExpectRollback()

		project := models.Project{
			Name:           "Test Project",
			Description:    "Test Description",
			WorkspaceID:    "test-workspace",
			OrganizationId: 123,
		}

		response, status := api.ProjectPost(project, "test@example.com", "Test User", "127.0.0.1")

		assert.Equal(t, 400, status)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Failed to assign project to account", response["message"])
	})

	// Test case 4: Error during project to account mapping
	t.Run("Mapping Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project existence check - return no existing project
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND (("project_management"."project"."name" = $1)) ORDER BY "project_management"."project"."id" ASC LIMIT 1`)).
			WithArgs("Test Project").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "description", "workspace_id"}))

		// Mock project creation
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "project_management"."project" ("workspace_id","name","description","created_by","updated_by","created_at","updated_at","deleted_at","organization_id","project_id","environment") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING "project_management"."project"."id"`)).
			WithArgs("test-workspace", "Test Project", "Test Description", uint(0), uint(0), sqlmock.AnyArg(), sqlmock.AnyArg(), nil, 123, 0, "").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		// Mock project to account mapping error
		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "project_management"."project_to_account_mapping" ("project_id","account_id","created_at","updated_at","deleted_at","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING "project_management"."project_to_account_mapping"."id"`)).
			WithArgs(1, 123, sqlmock.AnyArg(), sqlmock.AnyArg(), nil, "", "test-workspace").
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		project := models.Project{
			Name:           "Test Project",
			Description:    "Test Description",
			WorkspaceID:    "test-workspace",
			OrganizationId: 123,
		}

		response, status := api.ProjectPost(project, "test@example.com", "Test User", "127.0.0.1")

		assert.Equal(t, 400, status)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "Failed to assign project to account", response["message"])
	})
}

func TestGetProjectData(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Project not found
	t.Run("Project Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id=$1))`)).
			WithArgs("1").
			WillReturnRows(sqlmock.NewRows([]string{"id"}))

		response, status := api.GetProjectData("1")

		assert.Equal(t, 400, status)
		assert.True(t, response["error"].(bool))
		assert.Equal(t, "No Project Found", response["message"])
	})

	// Test case 2: Project found
	t.Run("Project Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id=$1))`)).
			WithArgs("1").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace_id", "description", "organization_id"}).
				AddRow(1, "Test Project", "test-workspace", "Test Description", 123))

		response, status := api.GetProjectData("1")

		assert.Equal(t, 200, status)
		assert.False(t, response["error"].(bool))
		project := response["project"].(models.Project)
		assert.Equal(t, "Test Project", project.Name)
		assert.Equal(t, "test-workspace", project.WorkspaceID)
		assert.Equal(t, "Test Description", project.Description)
		assert.Equal(t, 123, project.OrganizationId)
	})
}

func TestUpdate(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 2: Successful update
	t.Run("Successful Update", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND (("project_management"."project"."slug" = $1)) ORDER BY "project_management"."project"."id" ASC LIMIT 1`)).
			WithArgs("test-slug").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "slug", "email", "role"}).
				AddRow(1, "Test Project", "test-slug", "test@example.com", "admin"))

		// Mock project update
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "project_management"."project" SET "workspace_id" = $1, "name" = $2, "description" = $3, "created_by" = $4, "updated_by" = $5, "updated_at" = $6, "deleted_at" = $7, "organization_id" = $8, "project_id" = $9, "environment" = $10 WHERE "project_management"."project"."deleted_at" IS NULL AND "project_management"."project"."id" = $11`)).
			WithArgs("test-workspace", "Updated Project", "", uint(0), uint(0), sqlmock.AnyArg(), nil, 0, 0, "", 1).
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		project := models.Project{
			Name:        "Updated Project",
			WorkspaceID: "test-workspace",
		}

		response, status := api.Update(project, "test@example.com", "owner")

		assert.Equal(t, 200, status)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "Project updated successfully.", response["message"])
	})
}

func TestDelete(t *testing.T) {
	SetupLogging()
	ResetLogs()

	// Test case 2: Successful deletion
	t.Run("Successful Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND (("project_management"."project"."slug" = $1)) ORDER BY "project_management"."project"."id" ASC LIMIT 1`)).
			WithArgs("test-slug").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "slug", "email", "role"}).
				AddRow(1, "Test Project", "test-slug", "test@example.com", "owner"))

		// Mock project deletion
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "project_management"."project" WHERE "project_management"."project"."id" = $1`)).
			WithArgs(1).
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		// Patch the activity recording function
		patch := monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer patch.Unpatch()

		project := models.Project{
			WorkspaceID: "test-workspace",
		}

		response, status := api.Delete(project, "1", "test@example.com", "owner", "127.0.0.1")

		assert.Equal(t, 200, status)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "Project deleted successfully", response["message"])
	})
}

func TestDeleteAllProjects(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Successful deletion
	t.Run("Successful Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock project deletion
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "project_management"."project"`)).
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()

		response, status := api.DeleteAllProjects("127.0.0.1")

		assert.Equal(t, 200, status)
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "Deleted All Projects", response["message"])
	})
}

func TestGetProjectDataByUserId(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test case 1: Both userId and workspace provided
	t.Run("Both UserId and Workspace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock database query
		expectedQuery := `SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id in (select project_id::int from project_management.project_to_account_mapping ptam where ptam.account_id = 123) and workspace_id = 'test-workspace'))`
		mock.ExpectQuery(regexp.QuoteMeta(expectedQuery)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace_id", "description", "organization_id"}).
				AddRow(1, "Test Project", "test-workspace", "Test Description", 123))

		// Call the function
		result, status := api.GetProjectDataByUserId("123", "test-workspace")

		// Verify response
		assert.Equal(t, 200, status)
		assert.False(t, result["error"].(bool))
		assert.NotNil(t, result["project"])
		projects := result["project"].([]models.Project)
		assert.Equal(t, 1, len(projects))
		assert.Equal(t, "Test Project", projects[0].Name)
		assert.Equal(t, "test-workspace", projects[0].WorkspaceID)
	})

	// Test case 2: Only userId provided
	t.Run("Only UserId", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock database query
		expectedQuery := `SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id in (select project_id::int from project_management.project_to_account_mapping ptam where ptam.account_id = 123)))`
		mock.ExpectQuery(regexp.QuoteMeta(expectedQuery)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace_id", "description", "organization_id"}).
				AddRow(1, "Test Project 1", "workspace1", "Test Description 1", 123).
				AddRow(2, "Test Project 2", "workspace2", "Test Description 2", 123))

		// Call the function
		result, status := api.GetProjectDataByUserId("123", "")

		// Verify response
		assert.Equal(t, 200, status)
		assert.False(t, result["error"].(bool))
		assert.NotNil(t, result["project"])
		projects := result["project"].([]models.Project)
		assert.Equal(t, 2, len(projects))
	})

	// Test case 3: Only workspace provided
	t.Run("Only Workspace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock database query
		expectedQuery := `SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((workspace_id = 'test-workspace'))`
		mock.ExpectQuery(regexp.QuoteMeta(expectedQuery)).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "workspace_id", "description", "organization_id"}).
				AddRow(1, "Test Project", "test-workspace", "Test Description", 123))

		// Call the function
		result, status := api.GetProjectDataByUserId("", "test-workspace")

		// Verify response
		assert.Equal(t, 200, status)
		assert.False(t, result["error"].(bool))
		assert.NotNil(t, result["project"])
		projects := result["project"].([]models.Project)
		assert.Equal(t, 1, len(projects))
		assert.Equal(t, "test-workspace", projects[0].WorkspaceID)
	})

	// Test case 4: No projects found
	t.Run("No Projects Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock database query
		expectedQuery := `SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id in (select project_id::int from project_management.project_to_account_mapping ptam where ptam.account_id = 123) and workspace_id = 'test-workspace'))`
		mock.ExpectQuery(regexp.QuoteMeta(expectedQuery)).
			WillReturnError(errors.New(api.NoProjectFound))

		// Call the function
		result, status := api.GetProjectDataByUserId("123", "test-workspace")

		// Verify response
		assert.Equal(t, 400, status)
		assert.True(t, result["error"].(bool))
		assert.Equal(t, "No Project Found", result["message"])
	})

	// Test case 5: Database error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, mock, cleanup := setupMockDBForServices(t)
		defer cleanup()
		config.DB = gormDB

		// Mock database query to return error
		expectedQuery := `SELECT * FROM "project_management"."project" WHERE "project_management"."project"."deleted_at" IS NULL AND ((id in (select project_id::int from project_management.project_to_account_mapping ptam where ptam.account_id = 123) and workspace_id = 'test-workspace'))`
		mock.ExpectQuery(regexp.QuoteMeta(expectedQuery)).
			WillReturnError(errors.New("database error"))

		// Call the function
		result, status := api.GetProjectDataByUserId("123", "test-workspace")

		// Verify response
		assert.Equal(t, 400, status)
		assert.True(t, result["error"].(bool))
		assert.Equal(t, "No Project Found", result["message"])
	})
}
