package test

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/login"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/workspace"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestLoginEndpoint(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test case: Invalid JSON Body - Missing required fields
	t.Run("Invalid JSON Body - Missing Fields", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/login", bytes.NewBufferString(`{}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		api.LoginEndpoint(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please pass password and email"}`, w.Body.String())
	})

	// Test case: Missing required fields (email, password, workspace)
	t.Run("Missing Required Fields", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"","password":"","workspace":""}`
		req := httptest.NewRequest("POST", "/login", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.LoginEndpoint(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please pass password and email"}`, w.Body.String())
	})

	// Test case: Workspace not found (invalid workspace)
	t.Run("Workspace Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"test@example.com","password":"password123","workspace":"invalid_workspace"}`
		req := httptest.NewRequest("POST", "/login", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock the workspace.Login function to simulate a workspace not found scenario
		monkey.Patch(workspace.Login, func(wsURL string) (int, map[string]interface{}) {
			return http.StatusNotFound, gin.H{"error": true, "message": "Workspace not found."}
		})
		defer monkey.Unpatch(workspace.Login)

		api.LoginEndpoint(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Workspace not found."}`, w.Body.String())
	})

	// Test case: Invalid email format
	t.Run("Invalid Email Format", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"invalidemail","password":"password123","workspace":"valid_workspace"}`
		req := httptest.NewRequest("POST", "/login", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock the workspace.Login function to simulate a workspace not found scenario
		monkey.Patch(workspace.Login, func(wsURL string) (int, map[string]interface{}) {
			return http.StatusOK, gin.H{"error": false, "message": "Workspace found."}
		})

		api.LoginEndpoint(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please enter valid email id."}`, w.Body.String())
	})

	// Test case: Successful login
	t.Run("Successful Login", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup mock DB
		gormDB, _, cleanup := setupMockDB(t)
		defer cleanup()
		config.DB = gormDB

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"test@example.com","password":"password123","workspace":"valid_workspace"}`
		req := httptest.NewRequest("POST", "/login", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock the workspace.Login function to simulate a valid workspace
		monkey.Patch(workspace.Login, func(wsURL string) (int, map[string]interface{}) {
			return http.StatusOK, gin.H{"message": "Workspace found"}
		})
		defer monkey.Unpatch(workspace.Login)

		// Mock the methods.ValidateEmail function to simulate valid email
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Mock the login.NormalLogin function to simulate successful login
		monkey.Patch(login.NormalLogin, func(email string, password string, wsID string, environment string, projectId int) (int, map[string]interface{}) {
			return http.StatusOK, gin.H{
				"id":      1,
				"message": "Login successful",
				"name":    "John Doe",
				"email":   "test@example.com",
				"role":    "admin",
				"permissions": []map[string]interface{}{
					{
						"feature": "project",
						"action":  "create",
					},
					{
						"feature": "workspace",
						"action":  "read",
					},
				},
			}
		})
		defer monkey.Unpatch(login.NormalLogin)

		// Mock the activities.RecordActivity function
		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		// Mock the GetUserRolesAndPermissions function
		monkey.Patch(api.GetUserRolesAndPermissions, func(userID string) ([]models.RolePermissionResponse, error) {
			return []models.RolePermissionResponse{
				{
					RoleName:    "Admin",
					Permissions: []string{"create"},
				},
				{
					RoleName:    "User",
					Permissions: []string{"read"},
				},
			}, nil
		})
		defer monkey.Unpatch(api.GetUserRolesAndPermissions)

		api.LoginEndpoint(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		// Parse the response body
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		// Verify response content
		assert.Equal(t, "Login successful", response["message"])
		assert.Equal(t, "John Doe", response["name"])
		assert.Equal(t, "test@example.com", response["email"])
		assert.Equal(t, "admin", response["role"])

		// Verify permissions
		permissions, ok := response["permissions"].([]interface{})
		assert.True(t, ok)
		assert.Len(t, permissions, 2)

		// Verify first permission
		perm1, ok := permissions[0].(map[string]interface{})
		assert.True(t, ok)
		assert.Equal(t, "project", perm1["feature"])
		assert.Equal(t, "create", perm1["action"])

		// Verify second permission
		perm2, ok := permissions[1].(map[string]interface{})
		assert.True(t, ok)
		assert.Equal(t, "workspace", perm2["feature"])
		assert.Equal(t, "read", perm2["action"])
	})

	// Test case: Failed login (incorrect password or email)
	t.Run("Failed Login", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"test@example.com","password":"wrongpassword","workspace":"valid_workspace"}`
		req := httptest.NewRequest("POST", "/login", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock the workspace.Login function to simulate a valid workspace
		monkey.Patch(workspace.Login, func(wsURL string) (int, map[string]interface{}) {
			return http.StatusOK, gin.H{"message": "Workspace found"}
		})
		// Mock the login.NormalLogin function to simulate failed login
		monkey.Patch(login.NormalLogin, func(email string, password string, wsID string, environment string, projectId int) (int, map[string]interface{}) {
			return http.StatusUnauthorized, gin.H{"message": "Invalid email or password"}
		})

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)
		defer monkey.Unpatch(workspace.Login)
		defer monkey.Unpatch(login.NormalLogin)

		api.LoginEndpoint(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
		assert.JSONEq(t, `{"message":"Invalid email or password"}`, w.Body.String())
	})
}
