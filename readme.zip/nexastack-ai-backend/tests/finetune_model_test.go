package test

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"net/http/httptest"
	"os/exec"
	"reflect"
	"regexp"
	"strconv"
	"strings"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
)

// Echo server handler
var upgrader = websocket.Upgrader{}

func echo(w http.ResponseWriter, r *http.Request) {
	c, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	defer c.Close()
	for {
		mt, message, err := c.ReadMessage()
		if err != nil {
			break
		}
		// Echo the message back to the client
		err = c.WriteMessage(mt, message)
		if err != nil {
			break
		}
	}
}

func GetPythonPath() (string, error) {
	// Run the 'which python3' command to find the Python path
	cmd := exec.Command("which", "python3")
	output, err := cmd.CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("could not find python3: %v", err)
	}

	// The output is typically the path, so trim any whitespace and return
	pythonPath := strings.TrimSpace(string(output))
	if pythonPath == "" {
		return "", fmt.Errorf("python3 not found on system")
	}

	return pythonPath, nil
}

// SendMessage sends a text message over a WebSocket connection
func SendMessage(wsConn *websocket.Conn, message string) {
	if err := wsConn.WriteMessage(websocket.TextMessage, []byte(message)); err != nil {
		log.Println("Error sending message:", err)
	}
}

func TestPrepareCommand(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Define the test inputs
	userId := "user123"
	jobId := 1

	pythonPath, err := GetPythonPath()
	if err != nil {
		log.Fatalf("Error: %v", err)
	}

	t.Run("Valid Command Construction", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Call the PrepareCommand function with the dynamic Python path
		cmd, _, _, err := api.PrepareCommand(pythonPath, userId, jobId)
		if err != nil {
			t.Fatalf("Error preparing command: %v", err)
		}

		// Test that the command is correctly constructed
		if cmd.Path != pythonPath {
			t.Errorf("Expected command to be '%s', but got '%s'", pythonPath, cmd.Path)
		}

		expectedArgs := []string{"./src/python/main.py", userId, strconv.Itoa(jobId), "fine_tune"}
		for i, arg := range expectedArgs {
			if cmd.Args[i+1] != arg { // cmd.Args[0] is the command path itself
				t.Errorf("Expected argument %d to be '%s', but got '%s'", i+1, arg, cmd.Args[i+1])
			}
		}
	})

	t.Run("Valid Stdout and Stderr Pipes", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Call the PrepareCommand function
		_, stdout, stderr, err := api.PrepareCommand("python3", userId, jobId)
		if err != nil {
			t.Fatalf("Error preparing command: %v", err)
		}

		// Test that stdout and stderr pipes are not nil
		if stdout == nil {
			t.Error("Expected stdout pipe to be non-nil")
		}
		if stderr == nil {
			t.Error("Expected stderr pipe to be non-nil")
		}
	})

	t.Run("Error in Stdout Pipe Creation", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Simulate an invalid Python path to trigger an error in stdout pipe creation.
		// Using an empty string or a non-existent command to test error handling.
		pythonPath := "" // Invalid Python path

		// Call the PrepareCommand function with the invalid path
		_, stdout, stderr, err := api.PrepareCommand(pythonPath, userId, jobId)

		// Ensure that we get an error
		if err == nil {
			t.Error("Expected error in stdout pipe creation, but got nil")
		}

		// Check that both stdout and stderr are nil due to the error
		if stdout != nil {
			t.Error("Expected stdout to be nil due to error, but got a valid pipe")
		}
		if stderr != nil {
			t.Error("Expected stderr to be nil due to error, but got a valid pipe")
		}
	})
}

func TestHandleRealTimeOutput(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a test server with the echo handler
	s := httptest.NewServer(http.HandlerFunc(echo))
	defer s.Close()

	// Convert the HTTP URL to WebSocket URL
	u := "ws" + strings.TrimPrefix(s.URL, "http")

	// Connect to the server
	ws, _, err := websocket.DefaultDialer.Dial(u, nil)
	if err != nil {
		t.Fatalf("Failed to connect to WebSocket server: %v", err)
	}
	defer ws.Close()

	// Prepare the test data to be read from the io.Reader
	message := "Test message for WebSocket."
	prefix := ""

	// Create an io.Reader (simulating real-time data source)
	reader := bytes.NewBufferString(message)

	// Call HandleRealTimeOutput
	api.HandleRealTimeOutput(reader, ws, prefix)

	// Set read deadline to avoid hanging
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))

	// Read the message back from the server
	_, receivedMessage, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("Failed to read message: %v", err)
	}

	// Check if the received message matches the expected prefixed message
	expectedMessage := prefix + message
	if string(receivedMessage) != expectedMessage {
		t.Fatalf("Expected message '%s', but got '%s'", expectedMessage, string(receivedMessage))
	}
}

func TestSendMessage(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a test server with the echo handler
	s := httptest.NewServer(http.HandlerFunc(echo))
	defer s.Close()

	// Convert the HTTP URL to WebSocket URL
	u := "ws" + strings.TrimPrefix(s.URL, "http")

	// Connect to the server
	ws, _, err := websocket.DefaultDialer.Dial(u, nil)
	if err != nil {
		t.Fatalf("Failed to connect to WebSocket server: %v", err)
	}
	defer ws.Close()

	// Message to send
	message := "Hello, WebSocket!"

	// Send message using the sendMessage function
	api.SendMessage(ws, message)

	// Set read deadline to avoid hanging
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))

	// Read the message back from the server
	_, receivedMessage, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("Failed to read message: %v", err)
	}

	// Check if the received message matches the sent message
	if string(receivedMessage) != message {
		t.Fatalf("Expected message '%s', but got '%s'", message, string(receivedMessage))
	}
}

func TestStartTraining(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock WebSocket connection
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		upgrader := websocket.Upgrader{}
		conn, _ := upgrader.Upgrade(w, r, nil)
		defer conn.Close()
	}))
	defer server.Close()

	// Create a real WebSocket client
	u := "ws" + strings.TrimPrefix(server.URL, "http") // Convert URL to WebSocket format
	wsConn, _, _ := websocket.DefaultDialer.Dial(u, nil)
	jobId := 1
	defer wsConn.Close()

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock PrepareCommand to return a successful command
		monkey.Patch(api.PrepareCommand, func(commandName string, userId string, jobId int) (*exec.Cmd, io.ReadCloser, io.ReadCloser, error) {
			return exec.Command("echo", "success"), ioutil.NopCloser(strings.NewReader("output")), ioutil.NopCloser(strings.NewReader("")), nil
		})
		defer monkey.UnpatchAll()

		// Mock HandleRealTimeOutput to prevent actual execution
		monkey.Patch(api.HandleRealTimeOutput, func(reader io.Reader, wsConn *websocket.Conn, prefix string) {})
		monkey.Patch(api.UpdateJob, func(userId string, DB *gorm.DB, modelStatus models.Status, jobId int) (int, error) {
			return jobId, nil
		})

		api.StartTraining("user1", wsConn, jobId)
	})

	t.Run("PrepareCommand Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(api.PrepareCommand, func(commandName string, userId string, jobId int) (*exec.Cmd, io.ReadCloser, io.ReadCloser, error) {
			return nil, nil, nil, errors.New("command prep error")
		})
		defer monkey.UnpatchAll()
		monkey.Patch(api.UpdateJob, func(userId string, DB *gorm.DB, modelStatus models.Status, jobId int) (int, error) {
			return jobId, nil
		})
		api.StartTraining("user1", wsConn, jobId)
	})

	t.Run("Command Start Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(api.PrepareCommand, func(commandName string, userId string, jobId int) (*exec.Cmd, io.ReadCloser, io.ReadCloser, error) {
			c := exec.Command("false") // A command that fails immediately
			return c, ioutil.NopCloser(strings.NewReader("")), ioutil.NopCloser(strings.NewReader("")), nil
		})
		defer monkey.UnpatchAll()
		monkey.Patch(api.UpdateJob, func(userId string, DB *gorm.DB, modelStatus models.Status, jobId int) (int, error) {
			return jobId, nil
		})
		api.StartTraining("user1", wsConn, jobId)
	})

	t.Run("Command Wait Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(api.PrepareCommand, func(commandName string, userId string, jobId int) (*exec.Cmd, io.ReadCloser, io.ReadCloser, error) {
			c := exec.Command("false") // This will return an error on `Wait()`
			return c, ioutil.NopCloser(strings.NewReader("output")), ioutil.NopCloser(strings.NewReader("error")), nil
		})
		defer monkey.UnpatchAll()
		monkey.Patch(api.UpdateJob, func(userId string, DB *gorm.DB, modelStatus models.Status, jobId int) (int, error) {
			return jobId, nil
		})
		monkey.Patch(api.HandleRealTimeOutput, func(reader io.Reader, wsConn *websocket.Conn, prefix string) {})

		api.StartTraining("user1", wsConn, jobId)
	})
}

func TestFineTuneModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a test Gin context with request parameters
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/fine-tune/user1/config1", nil)
		c.Request = req
		c.Params = gin.Params{
			{Key: "user_id", Value: "user1"},
			{Key: "config_id", Value: "config1"},
		}

		// Mock WebSocket upgrader
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			upgrader := websocket.Upgrader{}
			conn, _ := upgrader.Upgrade(w, r, nil)
			defer conn.Close()
		}))
		defer server.Close()

		u := "ws" + strings.TrimPrefix(server.URL, "http") // Convert URL to WebSocket format
		wsConn, _, _ := websocket.DefaultDialer.Dial(u, nil)
		defer wsConn.Close()

		// Monkey patch WebSocket upgrader
		monkey.PatchInstanceMethod(reflect.TypeOf(&websocket.Upgrader{}), "Upgrade", func(_ *websocket.Upgrader, w http.ResponseWriter, r *http.Request, responseHeader http.Header) (*websocket.Conn, error) {
			return wsConn, nil
		})
		defer monkey.UnpatchAll()

		monkey.Patch(api.UpdateJob, func(userId string, DB *gorm.DB, modelStatus models.Status, jobId int) (int, error) {
			return jobId, nil
		})

		// Monkey patch StartTraining
		monkey.Patch(api.StartTraining, func(userId string, wsConn *websocket.Conn, jobId int) {})

		api.FineTuneModel(c)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("WebSocket Upgrade Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a test Gin context with request parameters
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/fine-tune/user1/config1", nil)
		c.Request = req
		c.Params = gin.Params{
			{Key: "user_id", Value: "user1"},
			{Key: "config_id", Value: "config1"},
		}

		// Monkey patch WebSocket upgrader to return an error
		monkey.PatchInstanceMethod(reflect.TypeOf(&websocket.Upgrader{}), "Upgrade", func(_ *websocket.Upgrader, w http.ResponseWriter, r *http.Request, responseHeader http.Header) (*websocket.Conn, error) {
			return nil, errors.New("upgrade failed")
		})
		defer monkey.UnpatchAll()

		api.FineTuneModel(c)

		// Validate response
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"error":"Failed to upgrade to WebSocket"`)
	})

	t.Run("Failed to Send Initial Message", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a test Gin context with request parameters
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/fine-tune/user1/config1", nil)
		c.Request = req
		c.Params = gin.Params{
			{Key: "user_id", Value: "user1"},
			{Key: "config_id", Value: "config1"},
		}

		// Mock WebSocket upgrader
		server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			upgrader := websocket.Upgrader{}
			conn, _ := upgrader.Upgrade(w, r, nil)
			defer conn.Close()
		}))
		defer server.Close()

		u := "ws" + strings.TrimPrefix(server.URL, "http") // Convert URL to WebSocket format
		wsConn, _, _ := websocket.DefaultDialer.Dial(u, nil)
		defer wsConn.Close()

		// Monkey patch WebSocket upgrader
		monkey.PatchInstanceMethod(reflect.TypeOf(&websocket.Upgrader{}), "Upgrade", func(_ *websocket.Upgrader, w http.ResponseWriter, r *http.Request, responseHeader http.Header) (*websocket.Conn, error) {
			return wsConn, nil
		})
		defer monkey.UnpatchAll()

		// Monkey patch WriteMessage to return an error
		monkey.PatchInstanceMethod(reflect.TypeOf(wsConn), "WriteMessage", func(_ *websocket.Conn, messageType int, data []byte) error {
			return errors.New("failed to send message")
		})

		api.FineTuneModel(c)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestUpdateJob(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gdb, mock, cleanup := setupMockDB(t)
	defer cleanup()

	userId := "1"
	userIdInt, _ := strconv.Atoi(userId) // Convert to int
	jobId := 1

	// Success - Create New Job
	t.Run("Success - Create New Job", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_model_configurations" WHERE (created_by = $1)`)).
			WithArgs(userId).
			WillReturnRows(sqlmock.NewRows([]string{"id", "model_name", "dataset", "created_by"}).
				AddRow(1, "TestModel", "TestDataset", userId))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "jobs" WHERE (id = $1) ORDER BY "jobs"."id" ASC LIMIT 1`)).
			WithArgs(jobId).
			WillReturnError(gorm.ErrRecordNotFound)

		mock.ExpectBegin()

		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "jobs" ("model","dataset","status","created_at","updated_at","account_id","project_id","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING "jobs"."id"`)).
			WithArgs("TestModel", "TestDataset", models.StatusInactive, sqlmock.AnyArg(), sqlmock.AnyArg(), userIdInt, sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))

		mock.ExpectCommit()

		id, err := api.UpdateJob(userId, gdb, models.StatusInactive, jobId)

		assert.NoError(t, err)
		assert.Equal(t, 1, id)
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Failure - FineTuneModelConfigurations Not Found
	t.Run("Failure - FineTuneModelConfigurations Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_model_configurations" WHERE (created_by = $1)`)).
			WithArgs(userId).
			WillReturnError(gorm.ErrRecordNotFound)

		id, err := api.UpdateJob(userId, gdb, models.StatusInactive, jobId)

		assert.Error(t, err)
		assert.Equal(t, 0, id)
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Failure - DB Error on Creating New Job
	t.Run("Failure - DB Error on Creating New Job", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_model_configurations" WHERE (created_by = $1)`)).
			WithArgs(userId).
			WillReturnRows(sqlmock.NewRows([]string{"id", "model_name", "dataset", "created_by"}).
				AddRow(1, "TestModel", "TestDataset", userId))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "jobs" WHERE (id = $1) ORDER BY "jobs"."id" ASC LIMIT 1`)).
			WithArgs(jobId).
			WillReturnError(gorm.ErrRecordNotFound)

		mock.ExpectBegin()

		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "jobs" ("model","dataset","status","created_at","updated_at","account_id","project_id","environment","workspace") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING "jobs"."id"`)).
			WithArgs("TestModel", "TestDataset", models.StatusInactive, sqlmock.AnyArg(), sqlmock.AnyArg(), userIdInt, sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnError(errors.New("DB Insert Error"))

		id, err := api.UpdateJob(userId, gdb, models.StatusInactive, jobId)

		assert.Error(t, err)
		assert.Equal(t, 0, id)
		assert.NoError(t, mock.ExpectationsWereMet())
	})
}
