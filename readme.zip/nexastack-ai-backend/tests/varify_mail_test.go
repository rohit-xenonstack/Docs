package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestVerifyMailEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	monkey.Patch(api.GetMemberInfo, func(tokendata api.EmailVerifyToken, mapd map[string]interface{}) ([]database.WorkspaceMembers, error) {
		// Mock behavior for GetMemberInfo
		return []database.WorkspaceMembers{
			{
				WorkspaceID: "testWorkspace",
				ID:          1,
				Role:        "user",
			},
		}, nil
	})

	// Test when email verification is successful
	t.Run("Email Verification Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock data for the request
		tokendata := api.EmailVerifyToken{
			Email:            "test@example.com",
			VerificationCode: "validCode",
		}

		tokenDataStr, _ := StructToString(tokendata)

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		// Mock the response of VerifyMail function
		monkey.Patch(mail.VerifyMail, func(email, code string) (database.Accounts, bool) {
			// Return mock account data
			return database.Accounts{
				ID:            1,
				Email:         "test@example.com",
				Name:          "John Doe",
				RoleID:        "user",
				AccountStatus: "active",
				VerifyStatus:  "verified",
				ContactNo:     "1234567890",
				CreationDate:  time.Now().Unix(),
			}, true
		})
		defer monkey.Unpatch(mail.VerifyMail)

		// Mock the response of GinJwtToken
		monkey.Patch(jwtToken.GinJwtToken, func(account database.Accounts) (map[string]interface{}, error) {
			// Return a mock JWT token map
			return map[string]interface{}{
				"token": "validJwtToken",
			}, nil
		})
		defer monkey.Unpatch(jwtToken.GinJwtToken)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with the email and verification code in the JSON body
		req := httptest.NewRequest("POST", "/verify-mail", bytes.NewBufferString(tokenDataStr))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the VerifyMailEp handler
		api.VerifyMailEp(ctx)

		// Assert that the response status code is 200 OK
		assert.Equal(t, http.StatusOK, w.Code)

		// Assert that the response contains the success message and token
		expectedResponse := `{"email":"test@example.com", "error":false, "id":1, "message":"Email verification done", "name":"John Doe", "role_id":"user", "token":"validJwtToken"}`

		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when email is invalid
	t.Run("Invalid Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock data for the request
		tokendata := api.EmailVerifyToken{
			Email:            "invalidemail",
			VerificationCode: "validCode",
		}

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with the email and verification code in the JSON body
		req := httptest.NewRequest("POST", "/verify-mail", nil)
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		ctx.ShouldBindJSON(&tokendata)

		// Call the VerifyMailEp handler
		api.VerifyMailEp(ctx)

		// Assert that the response status code is 400 Bad Request
		assert.Equal(t, http.StatusBadRequest, w.Code)

		// Assert that the response contains the error message
		expectedResponse := `{
			"error": true,
			"message": "Email and Verification Code are required field."
		}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test when the verification code is invalid or expired
	t.Run("Invalid or Expired Verification Code", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock data for the request
		tokendata := api.EmailVerifyToken{
			Email:            "test@example.com",
			VerificationCode: "invalidCode",
		}

		tokenDataStr, _ := StructToString(tokendata)

		// Mock the response of VerifyMail function to simulate invalid verification code
		monkey.Patch(mail.VerifyMail, func(email, code string) (database.Accounts, bool) {
			return database.Accounts{}, false // Simulate invalid verification code
		})
		defer monkey.Unpatch(mail.VerifyMail)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with the email and verification code in the JSON body
		req := httptest.NewRequest("POST", "/verify-mail", bytes.NewBufferString(tokenDataStr))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the VerifyMailEp handler
		api.VerifyMailEp(ctx)

		// Assert that the response status code is 401 Unauthorized
		assert.Equal(t, http.StatusUnauthorized, w.Code)

		// Assert that the response contains the error message
		expectedResponse := `{
			"error": true,
			"message": "Invalid or expired Verification Code."
		}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("JWT Token Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock data for the request
		tokendata := api.EmailVerifyToken{
			Email:            "test@example.com",
			VerificationCode: "invalidCode",
		}

		tokenDataStr, _ := StructToString(tokendata)

		// Mock the response of VerifyMail function to simulate invalid verification code
		monkey.Patch(mail.VerifyMail, func(email, code string) (database.Accounts, bool) {
			return database.Accounts{}, true // Simulate invalid verification code
		})
		defer monkey.Unpatch(mail.VerifyMail)

		// Mock the response of GinJwtToken
		monkey.Patch(jwtToken.GinJwtToken, func(account database.Accounts) (map[string]interface{}, error) {
			// Return a mock JWT token map
			return map[string]interface{}{
				"token": "validJwtToken",
			}, errors.New("Invalid JWT token")
		})
		defer monkey.Unpatch(jwtToken.GinJwtToken)

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the request with the email and verification code in the JSON body
		req := httptest.NewRequest("POST", "/verify-mail", bytes.NewBufferString(tokenDataStr))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Call the VerifyMailEp handler
		api.VerifyMailEp(ctx)

		// Assert that the response status code is 401 Unauthorized
		assert.Equal(t, 501, w.Code)

		// Assert that the response contains the error message
		expectedResponse := `{
			"error": true,
			"message": "Invalid JWT token"
		}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}

// Function to convert any struct to a string
func StructToString(v interface{}) (string, error) {
	// Convert to JSON
	data, err := json.Marshal(v)
	if err != nil {
		return "", err
	}

	log.Println("data: ", string(data))

	return string(data), nil
}

func TestChangeMail(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test when the email service toggle is successful
	t.Run("Email Service Toggle Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock data for the request

		// Mock the ToggleMail function
		monkey.Patch(mail.ToggleMail, func(value string) {
			// Mock behavior when the email service is toggled
			assert.Equal(t, "on", value) // Assert that the correct value is passed
		})
		defer monkey.Unpatch(mail.ToggleMail)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = append(ctx.Params, gin.Param{Key: "value", Value: "true"})
		// Set up the request with the toggle value as a URL parameter
		req := httptest.NewRequest("POST", "/change-mail/on", nil)
		ctx.Request = req

		// Call the ChangeMail handler
		api.ChangeMail(ctx)

		// Assert that the response status code is 200 OK (or a success code)
		assert.Equal(t, http.StatusOK, w.Code)
	})

	// Test when the email service toggle fails
}

func TestChangeOTP(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test when OTP service toggle is successful
	t.Run("OTP Service Toggle Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()

		// Mock the ToggleOTP function
		monkey.Patch(verifytoken.ToggleOTP, func(value string) {
			// Mock behavior when the OTP service is toggled
			assert.Equal(t, "on", value) // Assert that the correct value is passed
		})
		defer monkey.Unpatch(verifytoken.ToggleOTP)

		// Create a new response recorder and a test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = append(ctx.Params, gin.Param{Key: "value", Value: "true"})

		// Set up the request with the toggle value as a URL parameter
		req := httptest.NewRequest("POST", "/change-otp/on", nil)
		ctx.Request = req

		// Call the ChangeOTP handler
		api.ChangeOTP(ctx)

		// Assert that the response status code is 200 OK (or a success code)
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

// ==============================[[ AI GENERATED CODE ]]===================================
