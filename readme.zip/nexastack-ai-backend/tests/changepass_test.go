package test

import (
	"bytes"
	"encoding/json"
	"log"
	"net/http/httptest"
	"regexp"
	"testing"
	"time"

	"github.com/DATA-DOG/go-sqlmock"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

func TestChangePasswordEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Mock the JWT claims
	mockJwtClaims := map[string]interface{}{
		"id":    "1",
		"email": "user@example.com",
		"name":  "Test User",
	}

	mockGorm, mock, _ := setupMockDB(t)

	config.DB = mockGorm

	// Test data
	id := "1"
	// acc := models.Accounts{} // Assuming you have an Account model

	// Define the expected row data returned from the mock query
	expectedRow := sqlmock.NewRows([]string{"password", "id", "name", "email", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "create_at"}).
		AddRow("jhsIA.yDtbnxDbyVz83Q3FgOsxykQBH2Q=", 1, "Test User", "john@example.com", "1234567890", "verified", "admin", "active", 1616161616, time.Now(), time.Now())

	// Expectation: When db.Where("id=?", 1).Find(&acc) is called, we expect it to return the row data
	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (id=$1)`)).
		WithArgs(id).               // This matches the "id" argument passed in the query
		WillReturnRows(expectedRow) // Returning the mocked row data

	// Mock the INSERT INTO query for activities
	mock.ExpectExec(regexp.QuoteMeta(`INSERT INTO "activities" ("email","name","activity_name","status","reason","client_ip","client_agent","timestamp","updated_at","created_at") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`)).
		WithArgs(
			"user@example.com",                   // email
			"Test User",                          // name
			"change password",                    // activity_name
			"fail",                               // status
			"please pass valid current password", // reason
			"192.0.2.1",                          // client_ip
			"",                                   // client_agent
			int64(1741695338),                    // timestamp
			time.Now(),                           // updated_at
			time.Now(),                           // created_at
		).
		WillReturnResult(sqlmock.NewResult(1, 1)) // Return result with affected rows count (1)

		// Mock the update query for changing the password
	mock.ExpectExec(regexp.QuoteMeta(`UPDATE "accounts" SET "password"=$1 WHERE (id=$2)`)).
		WithArgs("newPassword123", id).           // Matching the new password update
		WillReturnResult(sqlmock.NewResult(0, 1)) // No ID to return, just ensure it was affected

	// Test case: Valid password change
	t.Run("Valid Password Change", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gin.SetMode(gin.TestMode)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims
		ctx.Set("id", mockJwtClaims["id"])
		ctx.Set("email", mockJwtClaims["email"])
		ctx.Set("name", mockJwtClaims["name"])

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123", "name": "Test User", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Create valid request body
		body := `{"old_password": "Demo@123", "new_password": "newPassword123"}`
		req := httptest.NewRequest("POST", "/change-password", bytes.NewBufferString(body))
		ctx.Request = req

		// Mock ChangePassword and RecordActivity
		api.ChangePasswordEp(ctx)

		// Assert response code and message
		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &response)

		log.Println("err ", &response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Password changed successfully", "Password changed successfully")

	})

	// Test case: Missing required fields in request body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		gin.SetMode(gin.TestMode)
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Create invalid request body (missing old_password)
		body := `{"new_password": "newPassword123"}`
		req := httptest.NewRequest("POST", "/change-password", bytes.NewBufferString(body))
		ctx.Request = req

		// Call the handler
		api.ChangePasswordEp(ctx)

		// Assert response code and message
		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &response)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Password is required field.", response["message"])
	})
}
