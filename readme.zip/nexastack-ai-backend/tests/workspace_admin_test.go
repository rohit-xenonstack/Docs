package test

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"net/http/httptest"
	"regexp"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"

	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
)

func TestListEmail(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db) // Use PostgreSQL dialect
	if err != nil {
		t.Fatalf("Failed to open gorm DB: %v", err)
	}

	config.DB = gormDB

	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock the database query to return a list of accounts
		rows := sqlmock.NewRows([]string{"id", "email", "name", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "created_at"}).
			AddRow(1, "test@example.com", "John Doe", "1234567890", "verified", "user", "active", 1643723400, time.Now(), time.Now())

		mock.ExpectQuery(`SELECT \* FROM "accounts"`).
			WillReturnRows(rows)

		// Call the ListEmail function
		accounts := api.ListEmail()

		// Assert that the function returns a list of accounts without any errors
		assert.NotNil(t, accounts)
		assert.Len(t, accounts, 1)
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	t.Run("Multiple Accounts Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock the database query to return multiple rows
		rows := sqlmock.NewRows([]string{"id", "email", "name", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "created_at"}).
			AddRow(1, "test1@example.com", "John Doe", "1234567890", "verified", "user", "active", 1643723400, time.Now(), time.Now()).
			AddRow(2, "test2@example.com", "Jane Doe", "9876543210", "verified", "user", "active", 1643723400, time.Now(), time.Now())

		mock.ExpectQuery(`SELECT \* FROM "accounts"`).
			WillReturnRows(rows)

		// Call the ListEmail function
		accounts := api.ListEmail()

		// Assert that the function returns a list of accounts without any errors
		assert.NotNil(t, accounts)
		assert.Len(t, accounts, 2)
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	t.Run("No Accounts Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock the database query to return no rows
		rows := sqlmock.NewRows([]string{"id", "email", "name", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "created_at"})

		mock.ExpectQuery(`SELECT \* FROM "accounts"`).
			WillReturnRows(rows)

		// Call the ListEmail function
		accounts := api.ListEmail()

		// Assert that the function returns an empty list of accounts without any errors
		assert.Empty(t, accounts)
		assert.NoError(t, mock.ExpectationsWereMet())
	})

}

func TestAccountsEmail(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Set up the Gin router and the handler
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db) // Use PostgreSQL dialect
	if err != nil {
		t.Fatalf("Failed to open gorm DB: %v", err)
	}

	config.DB = gormDB

	router := gin.Default()
	router.GET("/accounts/email", api.AccountsEmail)

	// Test case 1: Successful response with list of emails
	t.Run("Test Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock the database query to return a list of accounts
		rows := sqlmock.NewRows([]string{"id", "email", "name", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "created_at"}).
			AddRow(1, "test@example.com", "John Doe", "1234567890", "verified", "user", "active", 1643723400, time.Now(), time.Now())

		mock.ExpectQuery(`SELECT \* FROM "accounts"`).
			WillReturnRows(rows)

		// Call the handler
		req := httptest.NewRequest(http.MethodGet, "/accounts/email", nil)
		ctx.Request = req
		api.AccountsEmail(ctx)

		// Assert the response is 200 OK with correct list
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"error":false`)
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case 2: No accounts found
	t.Run("Test No Accounts Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Call the handler
		req := httptest.NewRequest(http.MethodGet, "/accounts/email", nil)
		ctx.Request = req
		api.AccountsEmail(ctx)

		// Assert the response is 200 OK with an empty list
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"error":false`)
		assert.Contains(t, w.Body.String(), `"list":[]`)
	})

	// Test case 3: Database error
	t.Run("Test Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Call the handler
		req := httptest.NewRequest(http.MethodGet, "/accounts/email", nil)
		ctx.Request = req

		// Recover from the panic
		defer func() {
			if r := recover(); r != nil {
				// Assert the response is 500 Internal Server Error
				assert.Equal(t, http.StatusInternalServerError, w.Code)
				assert.Contains(t, w.Body.String(), `"error":true`)
			}
		}()

		// Call the handler
		api.AccountsEmail(ctx)
	})

	// Test case 4: Invalid request (though not applicable directly for GET, could be for testing malformed data)
	t.Run("Test Invalid Request", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Simulate a malformed request (in this case, we might just use an invalid query param)
		req := httptest.NewRequest(http.MethodGet, "/accounts/email?invalidParam=true", nil)
		ctx.Request = req

		// Call the handler
		api.AccountsEmail(ctx)

		// In this case, since it is a GET request, we assume no error handling is done for this,
		// but you can adjust this depending on how your application should behave in case of invalid parameters.
		// Assert the response is 200 OK, as no invalid logic is expected here.
		assert.Equal(t, http.StatusOK, w.Code)
	})
}

func TestListWorkspaceMembers1(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm

	// Test case for database error (e.g., no members found)
	t.Run("Error Retrieving Members", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock expected database behavior to simulate an error
		// Mock the database query to return a list of workspace members

		mock.ExpectQuery(`SELECT \* FROM "workspace_members" WHERE \(workspace_id= \$1\) ORDER BY joined asc`).
			WithArgs("testing").
			WillReturnError(fmt.Errorf("database error"))

		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = gin.Params{gin.Param{Key: "workspace_id", Value: "testing"}}

		// Create the request
		req := httptest.NewRequest(http.MethodGet, "/workspace/workspace123/members", nil)
		ctx.Request = req

		// Call the handler
		api.ListWorkspaceMembers(ctx)

		// Assert the response code and error message
		assert.Equal(t, 501, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "database error", response["message"])
	})

	// Test case for workspace not found (empty list)
	t.Run("No Members Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock expected database behavior to simulate no members found
		// Mock the database query to return a list of workspace members
		rows := sqlmock.NewRows([]string{"id", "workspace_id", "member_email", "role", "joined"}).
			AddRow(1, "workspace123", "test@example.com", "admin", 1643723400)

		mock.ExpectQuery(`SELECT \* FROM "workspace_members" WHERE \(workspace_id= \$1\) ORDER BY joined asc`).
			WithArgs("workspace123").
			WillReturnRows(rows)

		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		ctx.Params = gin.Params{gin.Param{Key: "workspace_id", Value: "workspace123"}}

		// Create the request
		req := httptest.NewRequest(http.MethodGet, "/workspace/workspace123/members", nil)
		ctx.Request = req

		// Call the handler
		api.ListWorkspaceMembers(ctx)

		// Assert the response code and returned data
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		// Assert no errors and check for empty members list
		assert.Equal(t, false, response["error"])
		// assert.Equal(t, 0, len(response["members"].([]interface{})))
	})
}

func TestListWorkspaceMembersSuccess(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm

	// Test case for successful retrieval of members
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// Set the workspace ID in the Gin context
		ctx.Params = gin.Params{
			{Key: "workspace_id", Value: "testing"},
		}
		// Create the request
		req := httptest.NewRequest(http.MethodGet, "/workspace/workspace123/members", nil)
		ctx.Request = req

		// Mock the database query to return a list of workspace members
		rows := sqlmock.NewRows([]string{"id", "workspace_id", "member_email", "role", "joined"}).
			AddRow(1, "testing", "test@example.com", "admin", 1643723400)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id= $1) ORDER BY joined asc`)).
			WithArgs("testing").
			WillReturnRows(rows)
		// Mock the GetAccountForEmail function to return an account
		mock.ExpectQuery(`SELECT \* FROM "accounts" WHERE \(email=\$1\)`).
			WithArgs("test@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "email", "name", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "created_at"}).
				AddRow(1, "test@example.com", "John Doe", "1234567890", "verified", "user", "active", 1643723400, time.Now(), time.Now()))

		monkey.Patch(member.List, func(db *gorm.DB, workspace string) ([]member.MemList, error) {
			// Simulate a successful retrieval of members
			return []member.MemList{
				{
					Id:     1,
					Name:   "testing",
					Email:  "test@example.com",
					Role:   "admin",
					Joined: 1643723400,
				}}, nil
		})

		// Call the handler
		api.ListWorkspaceMembers(ctx)

		// Assert the response code and returned data
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		// Assert no errors and check the members data
		assert.Equal(t, false, response["error"])

		members := response["members"].([]interface{})
		log.Println("response => ", members)
		assert.Equal(t, 1, len(members))
		// assert.Equal(t, "John Doe", members[0].(map[string]interface{})["name"])
		// assert.Equal(t, "Jane Doe", members[1].(map[string]interface{})["name"])
	})
}
