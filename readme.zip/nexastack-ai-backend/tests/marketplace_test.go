package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"regexp"
	"strings"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/marketplace"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"helm.sh/helm/v3/pkg/action"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3" // Use the correct JWT package
	// "github.com/stretchr/testify/mock"
)

func TestDeleteModelWrapper(t *testing.T) {
	SetupLogging()
	ResetLogs()

	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db) // Use PostgreSQL dialect
	if err != nil {
		t.Fatalf("Failed to open gorm DB: %v", err)
	}

	model := database.ModelMarketplace{ID: 1}
	mapd := make(map[string]interface{})

	t.Run("Successful Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectBegin()
		mock.ExpectExec(`DELETE FROM "model_marketplaces" WHERE "model_marketplaces"."id" = \$1`).
			WithArgs(1).
			WillReturnResult(sqlmock.NewResult(0, 1)) // 1 row affected
		mock.ExpectCommit()

		err, resultMap := api.DeleteModelWrapper(gormDB, model, 1, mapd)

		assert.NoError(t, err)
		assert.False(t, resultMap["error"].(bool))
		assert.Equal(t, "Model deleted successfully", resultMap["message"])
		assert.NoError(t, mock.ExpectationsWereMet()) // Ensure all expectations were met
	})

	t.Run("Failed Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectBegin()
		mock.ExpectExec(`DELETE FROM "model_marketplaces" WHERE "model_marketplaces"."id" = \$1`).WithArgs(1).WillReturnError(errors.New("delete failed"))
		mock.ExpectRollback()

		err, mapd = api.DeleteModelWrapper(gormDB, model, 1, mapd)
		// assert.Error(t, err)
		assert.True(t, mapd["error"].(bool))
		assert.Equal(t, "Failed to delete model", mapd["message"].(string))
		assert.NoError(t, mock.ExpectationsWereMet())
	})
}

// setupMockDB initializes a mock database and returns gormDB, sqlmock, and a cleanup function.
func SetupMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock, func()) {
	// Create a mock SQL database using sqlmock
	db, mock, err := sqlmock.New() // Create a new mock *sql.DB
	if err != nil {
		t.Fatalf("Failed to create mock DB: %v", err)
	}
	// defer db.Close()

	// Create a *gorm.DB instance by wrapping the mock *sql.DB with the PostgreSQL dialect
	gormDB, err := gorm.Open("postgres", db) // Use PostgreSQL dialect
	if err != nil {
		t.Fatalf("Failed to open gorm DB: %v", err)
	}

	return gormDB, mock, func() {
		db.Close()
	}
}

func TestInstallModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup mock DB
	gormDB, mock, cleanup := SetupMockDB(t)
	defer cleanup()

	config.DB = gormDB

	monkey.Patch(util.CheckInterface, func(data interface{}) string {
		return "test"
	})

	// Test case: Invalid JSON body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/install", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.InstallModel(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please enter correct cluster_name and hf_model_name"}`, w.Body.String())
	})

	t.Run("Please login again", func(t *testing.T) {
		SetupLogging()
		ResetLogs()

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// Mock JWT claims
		body := `{"cluster_name": "test-cluster", "hf_model_name": "test-model"}`
		req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.InstallModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please login again"}`, w.Body.String())
	})

	// Test case: Workspace Not Found
	t.Run("Workspace Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		// Mock JWT claims
		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123"}
		ctx.Set("JWT_PAYLOAD", claims)
		body := `{"cluster_name": "test-cluster", "hf_model_name": "test-model"}`
		req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg()).
			WillReturnError(gorm.ErrRecordNotFound)
		api.InstallModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Workspace does not match"}`, w.Body.String())
	})

	t.Run("Failed to Generate API Key", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		// Mock RandomString function to return an empty string
		monkey.Patch(methods.RandomString, func(length int) string {
			return ""
		})

		// Call the function that generates the API key
		apiKey := strings.ToLower(methods.RandomString(16))
		if apiKey == "" {
			mapd := make(map[string]interface{})
			mapd["error"] = true
			mapd["message"] = "Failed to generate API key"
			c.JSON(500, mapd)
		}

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Failed to generate API key"}`, w.Body.String())
	})

	// t.Run("Failed to Install Model on Server", func(t *testing.T) {
	// 	SetupLogging()
	// 	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	c, _ := gin.CreateTestContext(w)
	// 	// Mock JWT claims
	// 	claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123"}
	// 	c.Set("JWT_PAYLOAD", claims)
	// 	body := `{"cluster_name": "test-cluster", "hf_model_name": "test-model", "apikey":"hbgvttcukvtcjvctj"}`
	// 	req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	c.Request = req
	// 	monkey.Patch(methods.RandomString, func(length int) string {
	// 		return "hbgvttcukvtcjvctj"
	// 	})
	// 	// Mock InstallModel function to return a non-200 status code
	// 	monkey.Patch(marketplace.InstallModel, func(email, nameSpace, workspace, releaseName, hfModelName, clusterName, apiKey string) (map[string]interface{}, int) {
	// 		return map[string]interface{}{
	// 			"deployment_sub_name": "test-sub-name",
	// 			"release_name":        "test-release-name",
	// 		}, 500
	// 	})

	// 	// Mock workspace retrieval to return successfully
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs(sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow(1, "workspace123"))
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
	// 		WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "member_email", "workspace_id"}).AddRow(1, "user@example.com", "workspace123"))

	// 	api.InstallModel(c)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var responseBody map[string]interface{}
	// 	err := json.Unmarshal(w.Body.Bytes(), &responseBody)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, true, responseBody["error"])
	// 	assert.Contains(t, responseBody["message"].(string), "Failed to install")
	// 	if responseBody["error_message"] != nil {
	// 		if str, ok := responseBody["error_message"].(string); ok {
	// 			assert.Contains(t, str, "Unknown error")
	// 		}
	// 	}
	// })

	// t.Run("Failed to Add Deployed Model to Database", func(t *testing.T) {
	// 	SetupLogging()
	// 	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	c, _ := gin.CreateTestContext(w)
	// 	// Mock JWT claims
	// 	claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123"}
	// 	c.Set("JWT_PAYLOAD", claims)
	// 	body := `{"cluster_name": "test-cluster", "hf_model_name": "test-model"}`
	// 	req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	c.Request = req

	// 	// Mock InstallModel function to return a non-200 status code
	// 	monkey.Patch(marketplace.InstallModel, func(email, nameSpace, workspace, releaseName, hfModelName, clusterName, apiKey string) (map[string]interface{}, int) {
	// 		return map[string]interface{}{
	// 			"deployment_sub_name": "test-sub-name",
	// 			"release_name":        "test-release-name",
	// 			"ingress":             "test-ingress",
	// 		}, 200
	// 	})

	// 	// Mock workspace retrieval to return successfully
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs(sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow(1, "workspace123"))
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
	// 		WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "member_email", "workspace_id"}).AddRow(1, "user@example.com", "workspace123"))

	// 	// Mock database error when creating deployment
	// 	mock.ExpectBegin()
	// 	mock.ExpectExec(regexp.QuoteMeta(`INSERT INTO "deployments"`)).
	// 		WillReturnError(errors.New("database error"))
	// 	mock.ExpectRollback()

	// 	// Mock UninstallModel function to return successfully
	// 	monkey.Patch(marketplace.UninstallModel, func(nameSpace, releaseName, clusterName, workspace, email string) (map[string]interface{}, int) {
	// 		return nil, 0
	// 	})

	// 	api.InstallModel(c)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.Unmarshal(w.Body.Bytes(), &response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "test-sub-name", response["deployment_sub_name"])
	// 	assert.Equal(t, true, response["error"])
	// 	assert.Equal(t, "Failed to Add the deployed model in database", response["message"])
	// 	assert.Equal(t, "test-release-name", response["release_name"])
	// })

}

// func TestInstallModelSuccessful(t *testing.T) {
// 	SetupLogging()
// 	ResetLogs()
// 	gormDB, mock, cleanup := SetupMockDB(t)
// 	defer cleanup()

// 	config.DB = gormDB
// 	t.Run("Successful Model Installation", func(t *testing.T) {
// 		SetupLogging()
// 		ResetLogs()
// 		w := httptest.NewRecorder()
// 		c, _ := gin.CreateTestContext(w)
// 		// Mock JWT claims
// 		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123"}
// 		c.Set("JWT_PAYLOAD", claims)
// 		body := `{"cluster_name": "test-cluster", "hf_model_name": "test-model"}`
// 		req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
// 		req.Header.Set("Content-Type", "application/json")
// 		c.Request = req

// 		// Mock InstallModel function to return a 200 status code
// 		monkey.Patch(marketplace.InstallModel, func(email string, nameSpace string, workspace string, releaseName string, modelName string, clusterName string, apiKey string) (map[string]interface{}, int) {
// 			return map[string]interface{}{
// 				"deployment_sub_name": "test-sub-name",
// 				"release_name":        "test-release-name",
// 				"ingress":             "test-ingress",
// 			}, 200
// 		})

// 		// Mock workspace retrieval to return successfully
// 		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
// 			WithArgs(sqlmock.AnyArg()).
// 			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow(1, "workspace123"))
// 		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
// 			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
// 			WillReturnRows(sqlmock.NewRows([]string{"id", "member_email", "workspace_id"}).AddRow(1, "user@example.com", "workspace123"))

// 		// Mock database insertion to return successfully
// 		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "deployments" WHERE (user_email = $1 AND workspace_id = $2 AND hf_model_name = $3 AND cluster_name = $4)`)).
// 			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
// 			WillReturnRows(sqlmock.NewRows([]string{})) // No model exists
// 		mock.ExpectBegin()
// 		mock.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "deployments" ("hf_model_name","user_email","workspace_id","deployed_at","ingress","release_name","cluster_name","node_name","api_key","environment","project_id") VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING "deployments"."id"`)).
// 			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
// 		mock.ExpectCommit()

// 		// Mock UninstallModel function to return successfully
// 		monkey.Patch(marketplace.UninstallModel, func(nameSpace, releaseName, clusterName, workspace, email string) (map[string]interface{}, int) {
// 			return nil, 0
// 		})

// 		api.InstallModel(c)

// 		assert.Equal(t, http.StatusOK, w.Code)
// 		var resp map[string]interface{}
// 		err := json.Unmarshal(w.Body.Bytes(), &resp)
// 		assert.NoError(t, err)
// 		assert.False(t, resp["error"].(bool))
// 		assert.Equal(t, "test-modelModel deployed successfully", resp["message"].(string))
// 		assert.NotNil(t, resp["model_ingress"])
// 		assert.NotNil(t, resp["api_key"])
// 	})

// }

func TestInstallModelUserNotFound(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gormDB, _, cleanup := SetupMockDB(t)
	defer cleanup()

	config.DB = gormDB
	// t.Run("User Not a Member", func(t *testing.T) {
	// 	SetupLogging()
	// 	ResetLogs()
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs(sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow("test-workspace"))

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE member_email= ? AND workspace_id= ?`)).
	// 		WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{})) // No match found

	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)
	// 	claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123"}
	// 	ctx.Set("JWT_PAYLOAD", claims)
	// 	body := `{"cluster_name": "test-cluster", "hf_model_name": "test-model"}`
	// 	req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	api.InstallModel(ctx)

	// 	assert.Equal(t, http.StatusUnauthorized, w.Code)
	// 	assert.JSONEq(t, `{"error":true,"message":"The user does not belong to this workspace."}`, w.Body.String())
	// })

}

// func TestInstallModelUserModelAlready(t *testing.T) {
// 	SetupLogging()
// 	ResetLogs()
// 	gormDB, mock, cleanup := SetupMockDB(t)
// 	defer cleanup()

// 	config.DB = gormDB

// 	t.Run("Model Already Deployed", func(t *testing.T) {
// 		SetupLogging()
// 		ResetLogs()
// 		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
// 			WithArgs(sqlmock.AnyArg()).
// 			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow("test-workspace"))

// 		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
// 			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
// 			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("user@example.com", "test-workspace"))

// 		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "deployments" WHERE (user_email = $1 AND workspace_id = $2 AND hf_model_name = $3 AND cluster_name = $4)`)).
// 			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg(), sqlmock.AnyArg()).
// 			WillReturnRows(sqlmock.NewRows([]string{"hf_model_name"}).AddRow("test-model"))

// 		w := httptest.NewRecorder()
// 		ctx, _ := gin.CreateTestContext(w)
// 		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123"}
// 		ctx.Set("JWT_PAYLOAD", claims)
// 		body := `{"cluster_name": "test-cluster", "Qwen/Qwen2.5-1.5B-Instruct": "test-model"}`
// 		req := httptest.NewRequest("POST", "/install", bytes.NewBufferString(body))
// 		req.Header.Set("Content-Type", "application/json")
// 		ctx.Request = req

// 		monkey.Patch(kubernetes.UpscaleDeployment, func(namespace string, deploymentName string) (map[string]interface{}, int) {
// 			return map[string]interface{}{}, 200
// 		})

// 		api.InstallModel(ctx)

// 		assert.Equal(t, http.StatusBadRequest, w.Code)
// 		assert.JSONEq(t, `{"error":true,"message": " model is already deployed."}`, w.Body.String())
// 	})

// }

func TestGetModelList(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Initialize mock DB
	db, _, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB

	t.Run("Successful Model Fetch - One Model", func(t *testing.T) {
		// Setup mock DB
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()
		config.DB = gormDB

		// Create a fixed timestamp for testing
		fixedTime := time.Date(2024, 3, 12, 12, 0, 0, 0, time.UTC)

		// Mock the database query with columns ordered to match ModelMarketplace struct
		rows := sqlmock.NewRows([]string{
			"id", "docker_image", "image_tag", "model_name", "trending",
			"provider", "provider_base64_image", "hf_model_name", "cpu_limit",
			"cpu_request", "memory_limit", "memory_request", "gpu_limit",
			"gpu_request", "model_type", "deployment_name", "description",
			"environment", "project_id", "processor", "cores", "gpu_vram",
			"ram", "storage", "nodes", "cluster_type", "updated_at", "deployment_sub_name",
		}).AddRow(
			1, "docker_image_test", "image_tag_test", "Hardcoded Model", false,
			"provider_test", "provider_base64_test", "hf_model_test", "",
			"", "", "", "", "", "model_type_test", "deployment_test", "Test Description",
			"", "", "", "", "", "", "", "", "", fixedTime, "",
		)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "model_marketplaces"`)).
			WillReturnRows(rows)

		// Create test context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("GET", "/models", nil)
		ctx.Request = req

		// Call the handler
		api.GetModelList(ctx)

		// Check response
		assert.Equal(t, http.StatusOK, w.Code)
		expectedResponse := map[string]interface{}{
			"error":   false,
			"message": "Models fetched successfully",
			"models": []interface{}{
				map[string]interface{}{
					"model_id":              float64(1),
					"model_name":            "Hardcoded Model",
					"model_type":            "model_type_test",
					"description":           "Test Description",
					"provider":              "provider_test",
					"provider_base64_image": "provider_base64_test",
					"docker_image":          "docker_image_test",
					"image_tag":             "image_tag_test",
					"hf_model_name":         "hf_model_test",
					"deployment_name":       "deployment_test",
					"deployment_sub_name":   "",
					"cpu_request":           "",
					"memory_request":        "",
					"gpu_request":           "",
					"cpu_limit":             "",
					"memory_limit":          "",
					"gpu_limit":             "",
					"environment":           "",
					"project_id":            "",
					"trending":              false,
					"cluster_type":          "",
					"cores":                 "",
					"release_name":          "",
					"gpu_vram":              "",
					"nodes":                 "",
					"processor":             "",
					"ram":                   "",
					"storage":               "",
					"updated_at":            fixedTime.Format(time.RFC3339),
					"value_yaml_file":       "",
					"vulnerability":         "",
				},
			},
		}

		var actualResponse map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &actualResponse)
		assert.NoError(t, err)

		// Remove processor_type from actual response if it exists
		if models, ok := actualResponse["models"].([]interface{}); ok && len(models) > 0 {
			if model, ok := models[0].(map[string]interface{}); ok {
				delete(model, "processor_type")
			}
		}

		assert.Equal(t, expectedResponse, actualResponse)
	})
}

func TestGetDeployedModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Initialize mock database
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB
	assert.NoError(t, err)

	t.Run("Successful Fetch of Deployed Models", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock workspace membership check
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
				AddRow(1, "test-workspace", "user@example.com"))

		// Use a fixed timestamp
		fixedTime := time.Date(2025, 3, 12, 12, 0, 0, 0, time.UTC)

		// Mock deployment fetch
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "deployments" WHERE (workspace_id = $1 )`)).
			WithArgs("test-workspace").
			WillReturnRows(sqlmock.NewRows([]string{
				"id", "workspace_id", "cluster_name", "deployed_at", "hf_model_name", "ingress", "release_name", "user_email", "api_key", "node_name", "environment",
			}).
				AddRow(1, "test-workspace", "test-cluster", fixedTime, "hf-modelA", "test-ingress", "test-release", "user@example.com", "", "test-node", "test-env"))

		// Create test recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Add JWT claims to context
		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Create request
		req := httptest.NewRequest("GET", "/deployed-models", nil)
		ctx.Request = req

		// Call the function
		api.GetDeployedModel(ctx)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)

		// Expected response with fixed timestamp
		expectedResponse := fmt.Sprintf(`{
			"error": false,
			"deployment": [
				{
					"api_key": "",
					"cluster_name": "test-cluster",
					"deployed_at": "%s",
					"hf_model_name": "hf-modelA",
					"ingress": "test-ingress",
					"node_name": "test-node",
					"release_name": "test-release",
					"user_email": "user@example.com",
					"workspace_id": "test-workspace",
					"environment": "test-env",
					"project_id": 0,
					"id": 1,
					"deployment_name":"",
					"governance_url": "",
					"logs_url": "",
					"observability_url": ""
				}
			],
			"message": "Deployed Models fetched successfully"
		}`, fixedTime.Format(time.RFC3339Nano))

		// Compare actual vs expected response
		assert.JSONEq(t, expectedResponse, w.Body.String())

		// Verify expectations
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	t.Run("Unauthorized User - Workspace Mismatch", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock workspace membership check (no results)
		mock.ExpectQuery(regexp.QuoteMeta(`ELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "unauthorized@example.com").
			WillReturnRows(sqlmock.NewRows([]string{})) // No match found

		// Create test recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Add JWT claims to context
		claims := jwt.MapClaims{"email": "unauthorized@example.com", "workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Create request
		req := httptest.NewRequest("GET", "/deployed-models", nil)
		ctx.Request = req

		// Call the function
		api.GetDeployedModel(ctx)

		// Validate response
		assert.Equal(t, http.StatusUnauthorized, w.Code)
		expectedResponse := `{"error":true,"message":"Email does not belong to the same workspace"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		// Verify expectations
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	t.Run("Database Error Fetching Deployments", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock workspace membership check
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
				AddRow(1, "test-workspace", "user@example.com"))

		// Simulate database error for deployment fetch
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "deployments" WHERE (workspace_id = $1 )`)).
			WithArgs("test-workspace").
			WillReturnError(sqlmock.ErrCancelled)

		// Create test recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Add JWT claims to context
		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Create request
		req := httptest.NewRequest("GET", "/deployed-models", nil)
		ctx.Request = req

		// Call the function
		api.GetDeployedModel(ctx)

		// Validate response
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error":true,"message":"canceling query due to user request"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		// Verify expectations
		assert.NoError(t, mock.ExpectationsWereMet())
	})
}

func TestDeleteDeployedModel(t *testing.T) {
	SetupLogging()
	ResetLogs()

	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB
	assert.NoError(t, err)

	// Test case: Missing JWT claims (User not authenticated)
	t.Run("User Not Authenticated", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("DELETE", "/deployed-models/1", nil)
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "model_id", Value: "1"})

		api.DeleteDeployedModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": true, "message": "Please login again"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test case: Invalid workspace in JWT claims
	t.Run("Invalid Workspace in JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("DELETE", "/deployed-models/1", nil)
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "model_id", Value: "1"})

		api.DeleteDeployedModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": true, "message": "Please login again"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test case: Invalid email in JWT claims
	t.Run("Invalid Email in JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("DELETE", "/deployed-models/1", nil)
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "model_id", Value: "1"})

		api.DeleteDeployedModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": true, "message": "Please login again"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test case: User not part of workspace
	t.Run("User Not Part of Workspace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnError(gorm.ErrRecordNotFound)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("DELETE", "/deployed-models/1", nil)
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "model_id", Value: "1"})

		api.DeleteDeployedModel(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
		expectedResponse := `{"error": true, "message": "Email does not belong to the same workspace"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case: Model not found
	t.Run("Model Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
				AddRow(1, "test-workspace", "user@example.com"))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "deployments" WHERE (id = $1 AND workspace_id = $2 ) ORDER BY "deployments"."id" ASC LIMIT 1`)).
			WithArgs("1", "test-workspace").
			WillReturnError(gorm.ErrRecordNotFound)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("DELETE", "/deployed-models/1", nil)
		ctx.Request = req
		ctx.Params = append(ctx.Params, gin.Param{Key: "model_id", Value: "1"})

		api.DeleteDeployedModel(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		expectedResponse := `{"error": true, "message": "Instance not found"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case: Successful deletion
	// t.Run("Successful Deletion of Deployed Model", func(t *testing.T) {

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
	// 		WithArgs("test-workspace", "user@example.com").
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
	// 			AddRow(1, "test-workspace", "user@example.com"))

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "deployments" WHERE (id = $1 AND workspace_id = $2) ORDER BY "deployments"."id" ASC LIMIT 1`)).
	// 		WithArgs("1", "test-workspace").
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "release_name"}).
	// 			AddRow(1, "test-workspace", "test-release"))

	// 	mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "deployments" WHERE "deployments"."id" = $1`)).
	// 		WithArgs(1).
	// 		WillReturnResult(sqlmock.NewResult(1, 1))

	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	req := httptest.NewRequest("DELETE", "/deployed-models/1", nil)
	// 	ctx.Request = req
	// 	ctx.Params = append(ctx.Params, gin.Param{Key: "model_id", Value: "1"})

	// 	api.DeleteDeployedModel(ctx)

	// 	assert.Equal(t, http.StatusOK, w.Code)

	// 	expectedResponse := `{"error": false, "message": "Deployed model deleted successfully"}`
	// 	assert.JSONEq(t, expectedResponse, w.Body.String())

	// 	assert.NoError(t, mock.ExpectationsWereMet())
	// })

}

func TestUpscaleModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB
	assert.NoError(t, err)

	// Test case: Invalid request body
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/upscale_model", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.UpscaleModel(ctx)

		// ✅ Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code) // Expect 400 Bad Request

		expectedResponse := `{"error": true, "message": "Please provide valid deployment name and replicas"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

	// Test case: Missing JWT Claims
	t.Run("Missing JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
		ctx.Request = req

		api.UpscaleModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": true, "message": "Please login again"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test case: Invalid Workspace in JWT Claims
	t.Run("Invalid Workspace in JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
		ctx.Request = req

		api.UpscaleModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": true, "message": "Please login again"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test case: User Not Part of Workspace
	t.Run("User Not Part of Workspace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnError(gorm.ErrRecordNotFound)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
		ctx.Request = req

		api.UpscaleModel(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
		expectedResponse := `{"error": true, "message": "Email does not belong to the same workspace"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case: Workspace Not Found
	t.Run("Workspace Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		workspace := "test-workspace" // Extracted from wsid

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
				AddRow(1, "test-workspace", "user@example.com"))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs(workspace).
			WillReturnError(gorm.ErrRecordNotFound)

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace"} // WSID contains `.domain`
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
		ctx.Request = req

		api.UpscaleModel(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		expectedResponse := `{"error": true, "message": "Workspace does not match"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case: Model Not Found in Marketplace
	t.Run("Model Not Found in Marketplace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
				AddRow(1, "test-workspace", "user@example.com"))
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("test-workspace").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).
				AddRow(1, "test-workspace"))

		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
		ctx.Request = req

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "model_marketplaces" WHERE (deployment_name = $1) ORDER BY "model_marketplaces"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg()).
			WillReturnError(gorm.ErrRecordNotFound)

		api.UpscaleModel(ctx)

		// assert.Equal(t, http.StatusNotFound, w.Code)
		assert.Equal(t, http.StatusOK, w.Code)

		expectedResponse := `{"error": true, "message": "Model not found"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())

		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case: No Ingress for Model
	// t.Run("No Ingress for Model", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
	// 		WithArgs("test-workspace", "user@example.com").
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email"}).
	// 			AddRow(1, "test-workspace", "user@example.com"))
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs("test-workspace").
	// 		WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).
	// 			AddRow(1, "test-workspace"))
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "model_marketplace" WHERE (deployment_name = $1) ORDER BY "model_marketplace"."id" ASC LIMIT 1`)).
	// 		WithArgs(sqlmock.AnyArg()).
	// 		WillReturnRows(sqlmock.NewRows([]string{"deployment_name", "hf_model_name"}).
	// 			AddRow("test-deployment", "unknown-model"))

	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
	// 	ctx.Request = req

	// 	api.UpscaleModel(ctx)

	// 	assert.Equal(t, http.StatusNotFound, w.Code)
	// 	expectedResponse := `{"error": true, "message": "No ingress exists for the given HFModelName"}`
	// 	assert.JSONEq(t, expectedResponse, w.Body.String())

	// 	assert.NoError(t, mock.ExpectationsWereMet())
	// })

	// Test case: Successful Upscale
	// t.Run("Successful Upscale", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "model_marketplace" WHERE (deployment_name = $1) ORDER BY "model_marketplace"."id" ASC LIMIT 1`)).
	// 		WithArgs("test-deployment").
	// 		WillReturnRows(sqlmock.NewRows([]string{"deployment_name", "hf_model_name"}).
	// 			AddRow("test-deployment", "Qwen/Qwen2.5-3B-Instruct"))

	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	claims := jwt.MapClaims{"email": "user@example.com", "workspace": "test-workspace.domain"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	req := httptest.NewRequest("POST", "/upscale_model", strings.NewReader(`{"deployment_name": "test-deployment"}`))
	// 	ctx.Request = req

	// 	api.UpscaleModel(ctx)

	// 	assert.Equal(t, http.StatusOK, w.Code)
	// })

}

func TestDownscaleModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, _, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB
	assert.NoError(t, err)

	// Test case: Invalid request body
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/downscale_model", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.DownscaleModel(ctx)

		// ✅ Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code) // Expect 400 Bad Request

		expectedResponse := `{"error": true, "message": "Please provide valid deployment name"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

}

func TestDeploymentStatus(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, _, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB
	assert.NoError(t, err)

	// Test case: Invalid request body
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/deployment_status", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.DeployemntStatus(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code) // Expect 400 Bad Request

		expectedResponse := `{"error": true, "message": "Please enter correct deployment_name"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/deployment_status", bytes.NewBufferString(`{"hf_model_name":"test","deployment_name":"test_deployment"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(kubernetes.CheckDeploymentStatus, func(namespace string, deploymentName string) (bool, error) {
			return true, nil
		})

		api.DeployemntStatus(ctx)

		// ✅ Validate response
		assert.Equal(t, http.StatusOK, w.Code) // Expect 400 Bad Request

		expectedResponse := `{"error":false, "ingress_model":"", "message":"Deployment running successfully", "model_name":"test"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

	t.Run("CheckDeploymentStatus Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/deployment_status", bytes.NewBufferString(`{"hf_model_name":"test","deployment_name":"test_deployment"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(kubernetes.CheckDeploymentStatus, func(namespace string, deploymentName string) (bool, error) {
			return false, errors.New("error")
		})

		api.DeployemntStatus(ctx)
		// assert.Equal(t, http.StatusInternalServerError, w.Code) // Expect 400 Bad Request
		assert.Equal(t, http.StatusOK, w.Code) // Expect 400 Bad Request

		expectedResponse := `{"error":true, "message":"Failed to fetch the state of the deployed model"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

	t.Run("deploymentRunning Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/deployment_status", bytes.NewBufferString(`{"hf_model_name":"test","deployment_name":"test_deployment"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(kubernetes.CheckDeploymentStatus, func(namespace string, deploymentName string) (bool, error) {
			return false, nil
		})

		api.DeployemntStatus(ctx)

		// ✅ Validate response
		assert.Equal(t, 200, w.Code) // Expect 200 Bad Request
		// assert.Equal(t, 500, w.Code) // Expect 200 Bad Request

		expectedResponse := `{"error":true, "message":"Deployment is not in running state"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

}

func TestCheckDeployedPodSatus(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, _, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB
	assert.NoError(t, err)

	t.Run("CheckDeploymentStatus Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/playground/podstatus", bytes.NewBufferString(`{"hf_model_name":"test","deployment_name":"test_deployment"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(kubernetes.CheckDeploymentStatus, func(namespace string, deploymentName string) (bool, error) {
			return true, errors.New("error")
		})

		api.CheckDeployedPodStatus(ctx)
		assert.Equal(t, http.StatusInternalServerError, w.Code)

		expectedResponse := `{"error":true, "message":"Failed to fetch the state of the deployed model"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	// Test case: Invalid request body
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/playground/podstatus", bytes.NewBufferString("{ invalid json }"))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CheckDeployedPodStatus(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code) // Expect 400 Bad Request

		expectedResponse := `{"error": true, "message": "Please enter correct deployment_name"}`
		assert.JSONEq(t, expectedResponse, w.Body.String()) // Compare JSON responses
	})

	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/playground/podstatus", bytes.NewBufferString(`{"hf_model_name":"test","deployment_name":"test_deployment"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(kubernetes.CheckPlaygroundModelPodStatus, func(deploymentName string) (bool, error) {
			return true, nil
		})

		api.CheckDeployedPodStatus(ctx)
		assert.Equal(t, http.StatusOK, w.Code)

		expectedResponse := `{"error":false, "message":"Deployment status downscaled"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})

	t.Run("deploymentRunning Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/playground/podstatus", bytes.NewBufferString(`{"hf_model_name":"test","deployment_name":"test_deployment"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		monkey.Patch(kubernetes.CheckPlaygroundModelPodStatus, func(deploymentName string) (bool, error) {
			return false, nil
		})

		api.CheckDeployedPodStatus(ctx)
		assert.Equal(t, 500, w.Code)

		expectedResponse := `{"error":true, "message":"Failed to downscale the deployed model"}`
		assert.JSONEq(t, expectedResponse, w.Body.String())
	})
}

// Mock JWT extraction function
func mockJWTMiddleware(c *gin.Context, workspaceID string) {
	claims := jwt.MapClaims{
		"workspace": workspaceID,
	}
	c.Set("JWT_PAYLOAD", claims)
}

func TestModelPodStatus(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, err := sqlmock.New()
	assert.NoError(t, err)
	defer db.Close()

	// Open a gorm DB connection
	gormDB, err := gorm.Open("postgres", db) // Using PostgreSQL dialect
	assert.NoError(t, err)

	// Replace the actual DB with the mock
	config.DB = gormDB

	// Test cases
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(`SELECT \* FROM "workspaces" WHERE \(workspace_id = \$1\) ORDER BY "workspaces"."id" ASC LIMIT 1`).
			WithArgs("workspace1").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow("workspace1"))

		mock.ExpectQuery(`SELECT \* FROM "deployments" WHERE \(workspace_id = \$1\)`).
			WithArgs("workspace1").
			WillReturnRows(sqlmock.NewRows([]string{"release_name", "hf_model_name"}).
				AddRow("model1", "hf-model1").
				AddRow("model2", "hf-model2"))

		patch1 := monkey.Patch(kubernetes.SetInfraConfig, func(namespace string, clusterName, workspace, email string) (*action.Configuration, string, int, error) {
			return nil, "path", 200, nil
		})
		defer patch1.Unpatch()

		patch2 := monkey.Patch(kubernetes.CheckModelPodStatus, func(path string, namespace string, releaseNames []string) (map[string]string, error) {
			return map[string]string{"model1-pod": "Running", "model2-pod": "Pending"}, nil
		})
		defer patch2.Unpatch()

		req, _ := http.NewRequest("POST", "/model-pod-status", bytes.NewBuffer([]byte(`{"workspace": "workspace1"}`)))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		mockJWTMiddleware(c, "workspace1")

		api.ModelPodStatus(c)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Pods status fetched successfully"`)
	})

	t.Run("Invalid JSON Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		req, _ := http.NewRequest("POST", "/model-pod-status", bytes.NewBuffer([]byte(`{invalid json}`)))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		r := gin.Default()
		r.POST("/model-pod-status", api.ModelPodStatus)
		r.ServeHTTP(w, req)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Invalid request body"`)
	})

	t.Run("Workspace Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(`SELECT \* FROM "workspaces" WHERE \(workspace_id = \$1\) ORDER BY "workspaces"."id" ASC LIMIT 1`).
			WithArgs("workspace1").
			WillReturnError(gorm.ErrRecordNotFound)

		req, _ := http.NewRequest("POST", "/model-pod-status", bytes.NewBuffer([]byte(`{"workspace": "workspace1"}`)))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		mockJWTMiddleware(c, "workspace1")

		api.ModelPodStatus(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Workspace does not match"`)
	})

	t.Run("Failed to Fetch Deployments", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(`SELECT \* FROM "workspaces" WHERE \(workspace_id = \$1\) ORDER BY "workspaces"."id" ASC LIMIT 1`).
			WithArgs("workspace1").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow("workspace1"))

		mock.ExpectQuery(`SELECT \* FROM "deployments" WHERE \(workspace_id = \$1\)`).
			WithArgs("workspace1").
			WillReturnError(errors.New("db error"))

		req, _ := http.NewRequest("POST", "/model-pod-status", bytes.NewBuffer([]byte(`{"workspace": "workspace1"}`)))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		mockJWTMiddleware(c, "workspace1")

		api.ModelPodStatus(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Failed to fetch deployments"`)
	})

	t.Run("Failed to Fetch Pod Status", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(`SELECT \* FROM "workspaces" WHERE \(workspace_id = \$1\) ORDER BY "workspaces"."id" ASC LIMIT 1`).
			WithArgs("workspace1").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow("workspace1"))

		mock.ExpectQuery(`SELECT \* FROM "deployments" WHERE \(workspace_id = \$1\)`).
			WithArgs("workspace1").
			WillReturnRows(sqlmock.NewRows([]string{"release_name", "hf_model_name"}).
				AddRow("model1", "hf-model1").
				AddRow("model2", "hf-model2"))

		patch1 := monkey.Patch(kubernetes.SetInfraConfig, func(namespace string, clusterName, workspace, email string) (*action.Configuration, string, int, error) {
			return nil, "path", 200, nil
		})
		defer patch1.Unpatch()
		patch2 := monkey.Patch(kubernetes.CheckModelPodStatus, func(path string, namespace string, releaseNames []string) (map[string]string, error) {
			return nil, errors.New("failed to get pod status")
		})
		defer patch2.Unpatch()

		req, _ := http.NewRequest("POST", "/model-pod-status", bytes.NewBuffer([]byte(`{"workspace": "workspace1"}`)))
		req.Header.Set("Content-Type", "application/json")

		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		mockJWTMiddleware(c, "workspace1")

		api.ModelPodStatus(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Failed to get pod status"`)
	})
}

func TestUploadModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	gdb, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	t.Run("Model Exists on Hugging Face Hub", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`{"name":"Test Model","hf_model_name":"model/model"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		// Mock CheckModelExists function to return true
		monkey.Patch(marketplace.CheckModelExists, func(hfName string) (bool, error) {
			return true, nil
		})

		// Call the function
		api.UploadModel(c)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("Model Does Not Exist on Hugging Face Hub", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`{"name":"Test Model","hf_model_name":"model/model"}`))
		c.Request.Header.Set("Content-Type", "application/json")
		// Mock CheckModelExists function to return false
		monkey.Patch(marketplace.CheckModelExists, func(hfName string) (bool, error) {
			return false, nil
		})

		// Call the function
		api.UploadModel(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		var resp map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &resp)
		assert.NoError(t, err)
		assert.Equal(t, "Model does not exist on Hugging Face Hub", resp["message"].(string))
	})

	t.Run("Failed to Check Model Existence", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`{"name":"Test Model","hf_model_name":"model/model"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		// Mock CheckModelExists function to return an error
		monkey.Patch(marketplace.CheckModelExists, func(hfName string) (bool, error) {
			return false, errors.New("failed to check model existence")
		})

		// Call the function
		api.UploadModel(c)

		// Validate response
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var resp map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &resp)
		assert.NoError(t, err)
		assert.Equal(t, "Failed to check model existence", resp["message"].(string))
	})

	t.Run("Invalid HF Model Name", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`{"name":"Test Model","hf_model_name":"invalid-model-name"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		// Mock CheckModelExists function to return true
		monkey.Patch(marketplace.CheckModelExists, func(hfName string) (bool, error) {
			return true, nil
		})
		// Call the function
		api.UploadModel(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		var resp map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &resp)
		assert.NoError(t, err)
		assert.Equal(t, "Invalid HF model name", resp["message"].(string))
	})

	t.Run("Model Already Exists in Database", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`{"name":"Test Model","hf_model_name":"model/model"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		// Create an existing model in the database
		existingModel := database.ModelMarketplace{
			ID:          1,
			HFModelName: "model/model",
		}
		db := config.DB
		db.Create(&existingModel)
		// Mock CheckModelExists function to return true
		monkey.Patch(marketplace.CheckModelExists, func(hfName string) (bool, error) {
			return true, nil
		})

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "model_marketplaces" WHERE (hf_model_name = $1) ORDER BY "model_marketplaces"."id" ASC LIMIT 1`)).
			WithArgs("model/model").
			WillReturnRows(sqlmock.NewRows([]string{"id", "hf_model_name"}).AddRow(1, "model/model"))

		// Call the function
		api.UploadModel(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		var resp map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &resp)
		assert.NoError(t, err)
		assert.Equal(t, "Model already exists in database", resp["message"].(string))
	})

	t.Run("Successful Model Upload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`{"name":"Test Model","hf_model_name":"model/model"}`))
		c.Request.Header.Set("Content-Type", "application/json")

		monkey.Patch(api.SetModel, func(db *gorm.DB, model database.ModelMarketplace, mapd map[string]interface{}) error {
			return nil
		})
		// Mock CheckModelExists function to return true
		monkey.Patch(marketplace.CheckModelExists, func(hfName string) (bool, error) {
			return true, nil
		})
		defer monkey.Unpatch(api.SetModel)

		api.UploadModel(c)

		assert.Equal(t, http.StatusOK, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.False(t, resp["error"].(bool))
		assert.Equal(t, "Model uploaded successfully", resp["message"])
	})

	t.Run("Invalid JSON Payload", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = httptest.NewRequest("POST", "/upload", bytes.NewBufferString(`invalid json`))
		c.Request.Header.Set("Content-Type", "application/json")

		api.UploadModel(c)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.True(t, resp["error"].(bool))
		assert.Equal(t, "Please enter correct model details", resp["message"])
	})
}

func TestDeleteModel(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	gdb, _, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	monkey.Patch(api.DeleteModelWrapper, func(db *gorm.DB, model database.ModelMarketplace, id int, mapd map[string]interface{}) (error, map[string]interface{}) {
		mapd["error"] = false
		mapd["message"] = "Model deleted successfully"
		return nil, mapd
	})
	defer monkey.UnpatchAll()

	t.Run("Successful Model Deletion", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "id", Value: "1"}}

		api.DeleteModel(c)

		assert.Equal(t, http.StatusOK, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.False(t, resp["error"].(bool))
		assert.Equal(t, "Model deleted successfully", resp["message"])
	})

	t.Run("Model Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "id", Value: "1"}}
		monkey.Patch(api.DeleteModelWrapper, func(db *gorm.DB, model database.ModelMarketplace, id int, mapd map[string]interface{}) (error, map[string]interface{}) {
			return assert.AnError, mapd
		})

		api.DeleteModel(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}

func TestGetSuitableCluster(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	gdb, _, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	monkey.Patch(marketplace.FindBestCluster, func(workspace string, namespace string, email string, hfModelName string) ([]models.BestClusters, error) {
		return []models.BestClusters{
			{
				ClusterName:           "",
				IsSuffiecientResource: true,
			},
		}, nil
	})
	defer monkey.UnpatchAll()

	monkey.Patch(marketplace.GetFullClusterDetails, func(namespace string, clusterNames []models.BestClusters, workspace string) ([]database.InfraIntegration, error) {
		return []database.InfraIntegration{{}}, nil
	})

	t.Run("Invalid Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/api/suitable-cluster?name=model-name", nil)
		c.Request.Header.Set("Authorization", "Bearer test-token")

		claims := map[string]interface{}{
			"email": 123,
		}
		c.Set("claims", claims)

		api.GetSuitableCluster(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.True(t, resp["error"].(bool))
		assert.Equal(t, "Please login again", resp["message"])
	})

	t.Run("Missing Email Claim", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/api/suitable-cluster?name=model-name", nil)
		c.Request.Header.Set("Authorization", "Bearer test-token")

		claims := map[string]interface{}{}
		c.Set("claims", claims)

		api.GetSuitableCluster(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.True(t, resp["error"].(bool))
		assert.Equal(t, "Please login again", resp["message"])
	})

	t.Run("Successful Cluster Retrieval", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/api/suitable-cluster?name=model-name", nil)
		c.Request.Header.Set("Authorization", "Bearer test-token")

		claims := jwt.MapClaims{"email": "test@email.com", "workspace": "workspace123"}
		c.Set("JWT_PAYLOAD", claims)

		api.GetSuitableCluster(c)

		assert.Equal(t, http.StatusOK, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.False(t, resp["error"].(bool))
		assert.NotNil(t, resp["suitable_clusters"])
		assert.Equal(t, "Clusters fetched successfully", resp["message"])
	})

	t.Run("Error in Finding Best Cluster", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/api/suitable-cluster?name=model-name", nil)
		c.Request.Header.Set("Authorization", "Bearer test-token")

		claims := jwt.MapClaims{"email": "test@email.com", "workspace": "workspace123"}
		c.Set("JWT_PAYLOAD", claims)

		monkey.Patch(marketplace.FindBestCluster, func(workspace string, namespace string, email string, hfModelName string) ([]models.BestClusters, error) {
			return []models.BestClusters{
				{
					ClusterName:           "",
					IsSuffiecientResource: true,
				},
			}, assert.AnError
		})
		defer monkey.UnpatchAll()

		api.GetSuitableCluster(c)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var resp map[string]interface{}
		json.Unmarshal(w.Body.Bytes(), &resp)
		assert.True(t, resp["error"].(bool))
		assert.Equal(t, "Failed to fetch suitable clusters", resp["message"])
	})

	t.Run("Error in Getting Full Cluster Details", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request, _ = http.NewRequest("GET", "/api/suitable-cluster?name=model-name", nil)
		c.Request.Header.Set("Authorization", "Bearer test-token")

		claims := jwt.MapClaims{"email": "test@email.com", "workspace": "workspace123"}
		c.Set("JWT_PAYLOAD", claims)

		monkey.Patch(marketplace.FindBestCluster, func(workspace string, namespace string, email string, hfModelName string) ([]models.BestClusters, error) {
			return []models.BestClusters{
				{
					ClusterName:           "",
					IsSuffiecientResource: true,
				},
			}, nil
		})
		defer monkey.UnpatchAll()

		monkey.Patch(marketplace.GetFullClusterDetails, func(namespace string, clusterNames []models.BestClusters, workspace string) ([]database.InfraIntegration, error) {
			return []database.InfraIntegration{}, assert.AnError
		})

		api.GetSuitableCluster(c)
		var resp map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &resp)
		assert.NoError(t, err)
		assert.True(t, resp["error"].(bool))
		assert.Equal(t, "Failed to fetch full cluster details", resp["message"])

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}
