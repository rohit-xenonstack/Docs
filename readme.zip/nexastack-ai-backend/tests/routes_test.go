package test

import (
	"io/ioutil"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/routes"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func setupRouter() *gin.Engine {
	r := gin.Default()
	r.GET("/end", routes.CheckToken, routes.ReadEnv)
	r.GET("/logs", routes.CheckToken, routes.ReadLogs)
	return r
}

// Full coverage for ReadEnv handler using environment variables
func TestReadEnvWithEnvVars(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("testSetupRouter", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		r := setupRouter()
		assert.NotNil(t, r, "Router should not be nil")
	})

	t.Run("testEnvVarPresence", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		os.Setenv("KEY", "value")
		t.Cleanup(func() {
			os.Unsetenv("KEY")
		})

		r := setupRouter()
		req, _ := http.NewRequest("GET", "/end", nil)
		req.Header.Set("Nexastack-TOKEN", "NexastackAgent1010")
		rr := httptest.NewRecorder()
		r.ServeHTTP(rr, req)

		expected := "KEY=value"
		assert.Contains(t, rr.Body.String(), expected, "Environment variable should be present in response")
	})
}

// Full coverage for ReadEnv handler using TOML file
func TestReadEnvWithTomlFile(t *testing.T) {
	SetupLogging()
	ResetLogs()

	t.Run("testCreateTomlFile", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		tmpFile, err := ioutil.TempFile("", "testfile*.toml")
		if err != nil {
			t.Fatalf("unable to create temporary file: %v", err)
		}
		defer os.Remove(tmpFile.Name())

		tomlContent := `[config]
key = "value"`
		if _, err := tmpFile.WriteString(tomlContent); err != nil {
			t.Fatalf("failed to write to temporary file: %v", err)
		}
		tmpFile.Close()
		config.TomlFile = tmpFile.Name() // Update the config with the temporary file path

		r := setupRouter()
		req, _ := http.NewRequest("GET", "/end", nil)
		req.Header.Set("Nexastack-TOKEN", "NexastackAgent1010")
		rr := httptest.NewRecorder()
		r.ServeHTTP(rr, req)

		assert.Equal(t, http.StatusOK, rr.Code, "Expected 200 for valid token and TOML config")
	})
}

// TestReadLogs - Test cases for ReadLogs function
func TestReadLogs(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("should serve file successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a Gin test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Mock HTTP request
		req := httptest.NewRequest("GET", "/read-logs", nil)
		c.Request = req

		// Monkey patch http.ServeFile
		var called bool
		patch := monkey.Patch(http.ServeFile, func(_ http.ResponseWriter, _ *http.Request, name string) {
			called = true
			assert.Equal(t, "info.txt", name)
		})
		defer patch.Unpatch()

		// Call the function
		routes.ReadLogs(c)

		// Validate response
		assert.True(t, called, "http.ServeFile should be called")
	})
}

// Full coverage for serving the correct response when TOML or environment vars are used in ReadEnv
func TestReadHandlers(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("ReadLogs should serve file successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create a Gin test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Mock HTTP request
		req := httptest.NewRequest("GET", "/read-logs", nil)
		c.Request = req

		// Monkey patch http.ServeFile
		var called bool
		patch := monkey.Patch(http.ServeFile, func(_ http.ResponseWriter, _ *http.Request, name string) {
			called = true
			assert.Equal(t, "info.txt", name)
		})
		defer patch.Unpatch()

		// Call the function
		routes.ReadLogs(c)

		// Validate function call
		assert.True(t, called, "http.ServeFile should be called with the correct filename")
	})

	t.Run("ReadEnv should return environment variables when TomlFile is empty", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Set TomlFile to empty
		config.TomlFile = ""

		// Create a Gin test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Mock HTTP request
		req := httptest.NewRequest("GET", "/read-env", nil)
		c.Request = req

		// Call the function
		routes.ReadEnv(c)

		// Parse the response
		assert.Equal(t, http.StatusOK, w.Code)
	})

	t.Run("ReadEnv should serve Toml file when TomlFile is set", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Set TomlFile to a dummy file path
		config.TomlFile = "config.toml"

		// Create a Gin test context
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)

		// Mock HTTP request
		req := httptest.NewRequest("GET", "/read-env", nil)
		c.Request = req

		// Monkey patch http.ServeFile
		var called bool
		patch := monkey.Patch(http.ServeFile, func(_ http.ResponseWriter, _ *http.Request, name string) {
			called = true
			assert.Equal(t, "config.toml", name)
		})
		defer patch.Unpatch()

		// Call the function
		routes.ReadEnv(c)

		// Validate function call
		assert.True(t, called, "http.ServeFile should be called with the correct Toml filename")
	})
}
