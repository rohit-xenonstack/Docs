package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

func TestWorkspaceList(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Workspace List Retrieved", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch UserWorkspace function to return a valid list
		patch := monkey.Patch(accounts.UserWorkspace, func(email string) []database.WorkspaceMembers {
			return []database.WorkspaceMembers{
				{WorkspaceID: "ws123", MemberEmail: "user@example.com", Role: "admin"},
				{WorkspaceID: "ws456", MemberEmail: "user@example.com", Role: "user"},
			}
		})
		defer patch.Unpatch()

		api.WorkspaceList(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, false, response["error"])
		assert.NotEmpty(t, response["list"])
		assert.Len(t, response["list"], 2)
	})

	t.Run("Success - UserWorkspace Returns Empty List", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{"email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Patch UserWorkspace function to return an empty list
		patch := monkey.Patch(accounts.UserWorkspace, func(email string) []database.WorkspaceMembers {
			return []database.WorkspaceMembers{}
		})
		defer patch.Unpatch()

		api.WorkspaceList(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, false, response["error"])
		assert.Empty(t, response["list"])
	})
}

func TestDeleteWorkspaceMember(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Member Deleted", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
			"email":     "admin@example.com",
			"name":      "Admin User",
		}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Request = httptest.NewRequest(http.MethodDelete, "/delete-member?email=user@example.com", nil)

		// Mock Delete function
		patchDelete := monkey.Patch(member.Delete, func(workspaceID, email string) error {
			return nil // Simulate successful deletion
		})
		defer patchDelete.Unpatch()

		// Mock RecordActivity function (no need to test it)
		patchActivity := monkey.Patch(activities.RecordActivity, func(activity database.Activities) {})
		defer patchActivity.Unpatch()

		api.DeleteWorkspaceMember(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Member deleted Successfully.", response["message"])
	})

	t.Run("Failure - Missing Workspace in JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// JWT missing workspace claim
		claims := jwt.MapClaims{"email": "admin@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		api.DeleteWorkspaceMember(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Failure - Database Error When Deleting Member", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
			"email":     "admin@example.com",
			"name":      "Admin User",
		}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Request = httptest.NewRequest(http.MethodDelete, "/delete-member?email=user@example.com", nil)

		// Mock Delete function to return an error
		patchDelete := monkey.Patch(member.Delete, func(workspaceID, email string) error {
			return errors.New("failed to delete member")
		})
		defer patchDelete.Unpatch()

		// Mock RecordActivity function
		patchActivity := monkey.Patch(activities.RecordActivity, func(activity database.Activities) {})
		defer patchActivity.Unpatch()

		api.DeleteWorkspaceMember(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "failed to delete member", response["message"])
	})
}

func TestWorkspaceCheckMember(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Member Exists", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
		}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Request = httptest.NewRequest(http.MethodGet, "/check-member?email=user@example.com", nil)

		// Mock member.Check function to simulate success
		patchCheck := monkey.Patch(member.Check, func(workspaceID, email string) error {
			return nil // No error means member exists
		})
		defer patchCheck.Unpatch()

		api.WorkspaceCheckMember(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, false, response["error"])
	})

	t.Run("Failure - Missing Workspace in JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// JWT missing workspace claim
		claims := jwt.MapClaims{}
		ctx.Set("JWT_PAYLOAD", claims)

		api.WorkspaceCheckMember(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Failure - Member Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
		}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Request = httptest.NewRequest(http.MethodGet, "/check-member?email=user@example.com", nil)

		// Mock member.Check function to return an error (member not found)
		patchCheck := monkey.Patch(member.Check, func(workspaceID, email string) error {
			return errors.New("user is not a member of this workspace")
		})
		defer patchCheck.Unpatch()

		api.WorkspaceCheckMember(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "user is not a member of this workspace", response["message"])
	})
}

func TestWorkspaceMembers(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Members Retrieved Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock database connection
		mockDB := &gorm.DB{}
		config.DB = mockDB // Injecting mock DB

		// Mock member.List function to return a valid list
		patch := monkey.Patch(member.List, func(db *gorm.DB, workspaceID string) ([]member.MemList, error) {
			return []member.MemList{
				{Email: "user@example.com", Role: "admin"},
			}, nil
		})
		defer patch.Unpatch()

		api.WorkspaceMembers(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, false, response["error"])
		assert.NotEmpty(t, response["members"])
		assert.Equal(t, float64(1), response["total_count"])
	})

	t.Run("Failure - Missing Workspace in JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// JWT missing workspace claim
		claims := jwt.MapClaims{}
		ctx.Set("JWT_PAYLOAD", claims)

		api.WorkspaceMembers(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Failure - Database Error While Fetching Members", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock database connection
		mockDB := &gorm.DB{}
		config.DB = mockDB // Injecting mock DB

		patch := monkey.Patch(member.List, func(db *gorm.DB, workspaceID string) ([]member.MemList, error) {
			return []member.MemList{
				{Email: "user@example.com", Role: "admin"},
			}, errors.New("database error")
		})
		defer patch.Unpatch()

		api.WorkspaceMembers(ctx)

		assert.Equal(t, 501, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Unable to read data from db", response["message"])
	})
}

func TestInviteWorkspaceMembers(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Members Invited Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
			"email":     "owner@example.com",
			"name":      "Owner Name",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock request body with RoleId
		reqBody := `[{"email": "user@example.com", "role": "admin", "RoleId": 1}]`
		ctx.Request = httptest.NewRequest("POST", "/invite", bytes.NewBufferString(reqBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		// Mock Invite function to return success
		patch := monkey.Patch(member.Invite, func(data interface{}, ownerEmail string, ownerName string, wsID string) (int, map[string]interface{}) {
			return 200, map[string]interface{}{
				"error":   false,
				"message": "Invites sent successfully",
			}
		})
		defer patch.Unpatch()

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		api.InviteWorkspaceMembers(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Invites sent successfully", response["message"])
	})

	t.Run("Failure - Bad Request (Invalid JSON)", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT claims
		claims := jwt.MapClaims{
			"workspace": "ws123",
			"email":     "owner@example.com",
			"name":      "Owner Name",
		}
		ctx.Set("JWT_PAYLOAD", claims)

		// Invalid JSON body
		ctx.Request = httptest.NewRequest("POST", "/invite", bytes.NewBufferString(`invalid json`))
		ctx.Request.Header.Set("Content-Type", "application/json")

		api.InviteWorkspaceMembers(ctx)

		assert.Equal(t, 400, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Bad Request.", response["message"])
	})
}
