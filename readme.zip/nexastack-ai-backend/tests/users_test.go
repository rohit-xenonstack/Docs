package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"testing"
	"time"

	"net/http/httptest"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

// Test the Gin handler function with query parameters
func TestTestGinContexts(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Test with "hi" query parameter provided
	t.Run("Test with hi query parameter", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Set up recorder and Gin context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set query parameter "hi"
		u := url.Values{}
		u.Add("hi", "hello")

		// Set the request to be a GET with the query string
		ctx.Request = &http.Request{
			Method: "GET",
			URL:    &url.URL{RawQuery: u.Encode()},
		}

		// Call the function
		api.TestGinContexts(ctx)

		// Assert the response status code
		assert.Equal(t, http.StatusOK, w.Code)

		// Assert the response body message
		assert.JSONEq(t, `{"message": "Gin Context Test Passed"}`, w.Body.String())

		// Optional: Test that the query parameter was correctly logged
		// Here, we can't directly check the log, but you can manually verify the output in your test run logs.
	})

	// Test without the "hi" query parameter
	t.Run("Test without hi query parameter", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Set up recorder and Gin context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// No query parameters set
		ctx.Request = &http.Request{
			Method: "GET",
			URL:    &url.URL{},
		}

		// Call the function
		api.TestGinContexts(ctx)

		// Assert the response status code
		assert.Equal(t, http.StatusOK, w.Code)

		// Assert the response body message
		assert.JSONEq(t, `{"message": "Gin Context Test Passed"}`, w.Body.String())

		// Optional: Test that the query parameter was empty, and the function still works
	})
}

func TestValidViewProfile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup the Gin router in test mode
	gin.SetMode(gin.TestMode)
	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm
	// Mock JWT claims
	mockJwtClaims := map[string]interface{}{
		"id":    "1",
		"email": "user@example.com",
		"name":  "Test User",
	}

	// Test the ViewProfile handler
	t.Run("Valid Profile Fetch", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims in the context
		ctx.Set("email", mockJwtClaims["email"])

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123", "name": "Test User", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Expectation: Query to fetch account based on email
		expectedRow := sqlmock.NewRows([]string{"id", "email", "name", "contact_no", "verify_status", "sys_role", "account_status", "creation_date", "updated_at", "create_at"}).
			AddRow(1, "user@example.com", "Test User", "1234567890", "verified", "user", "active", 1616161616, time.Now(), time.Now())

		mock.ExpectQuery(`SELECT \* FROM \"accounts\" WHERE \(email=\$1\)`).
			WithArgs("user@example.com").
			WillReturnRows(expectedRow)

		// Create a valid request (no body required for this API)
		req := httptest.NewRequest(http.MethodGet, "/profile", nil)
		ctx.Request = req

		monkey.Patch(accounts.GetAccountForEmail, func(email string) (database.Accounts, error) {
			return database.Accounts{
				ID:            1,
				Email:         "user@example.com",
				Name:          "Test User",
				ContactNo:     "1234567890",
				VerifyStatus:  "verified",
				AccountStatus: "active",
				UpdatedAt:     time.Now(),
			}, nil
		})

		// Call the handler
		api.ViewProfile(ctx)

		// Assert the response code and message
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)

		log.Println(`response: `, response)

		assert.NoError(t, err)

		assert.Equal(t, false, response["error"])
		// assert.Equal(t, "Test User", response["account"].(map[string]interface{})["name"])
	})

}
func TestViewProfile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup the Gin router in test mode
	gin.SetMode(gin.TestMode)

	// Mock JWT claims
	mockJwtClaims := map[string]interface{}{
		"id":    "1",
		"email": "user@example.com",
		"name":  "Test User",
	}

	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm

	// Test case for error when no account is found
	t.Run("Account Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims in the context
		ctx.Set("email", mockJwtClaims["email"])

		claims := jwt.MapClaims{"email": "user@example1.com", "workspace": "workspace123", "name": "Test User", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Update mock to simulate no rows returned
		mock.ExpectQuery(`SELECT \* FROM \"accounts\" WHERE \(email=\$1\)`).
			WithArgs("user@example1.com").
			WillReturnRows(sqlmock.NewRows([]string{}))

		// Create a request with the same email
		req := httptest.NewRequest(http.MethodGet, "/profile", nil)
		ctx.Request = req
		monkey.Patch(accounts.GetAccountForEmail, func(email string) (database.Accounts, error) {
			return database.Accounts{}, errors.New("no account found")
		})

		// Call the handler
		api.ViewProfile(ctx)

		// Assert the response code and error message
		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "no account found", response["message"])
	})
}

func TestUpdateProfile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup the Gin router in test mode
	gin.SetMode(gin.TestMode)

	// Mock JWT claims
	mockJwtClaims := map[string]interface{}{
		"id":    "1",
		"email": "user@example.com",
		"name":  "Test User",
	}

	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm

	// Test case for invalid request data
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims in the context
		ctx.Set("email", mockJwtClaims["email"])

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123", "name": "Test User", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Create invalid request body (missing required fields)
		body := `{"name": 1}`
		req := httptest.NewRequest(http.MethodPost, "/update-profile", bytes.NewBufferString(body))
		ctx.Request = req

		// Call the handler
		api.UpdateProfile(ctx)

		// Assert the response code and error message
		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Please pass valid name and contact number", response["message"])
	})

	// Test case for a valid profile update
	t.Run("Valid Profile Update", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims in the context
		ctx.Set("email", mockJwtClaims["email"])

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123", "name": "Updated Name", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock transaction start (begin)
		mock.ExpectBegin()

		// Use fmt.Sprintf and regexp.QuoteMeta for flexible SQL query matching
		escapedSQL := fmt.Sprintf(`UPDATE "accounts" SET "name" = $1, "updated_at" = $2 WHERE (email=$3)`)
		escapedSQL = regexp.QuoteMeta(escapedSQL) // Escape the query to handle special characters

		// Custom matcher for time.Time argument to allow small precision differences
		mock.ExpectExec(fmt.Sprintf(escapedSQL)).
			WithArgs("Updated Name", sqlmock.AnyArg(), "user@example.com").
			WillReturnResult(sqlmock.NewResult(1, 1)) // Assuming the update is successful

		// Mock transaction commit (commit the changes)
		mock.ExpectCommit()

		// Create a valid request body
		body := `{"name": "Updated Name", "contact": ""}`
		req := httptest.NewRequest(http.MethodPost, "/update-profile", bytes.NewBufferString(body))
		ctx.Request = req

		// Call the handler
		api.UpdateProfile(ctx)

		// Assert the response code and message
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Profile Updated Succesfully", response["message"])
	})

	// Test case for successful profile update with contact number
	t.Run("Profile Update with Contact Only", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims in the context
		ctx.Set("email", mockJwtClaims["email"])

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123", "name": "Updated Name", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock transaction start (begin)
		mock.ExpectBegin()

		// Use fmt.Sprintf and regexp.QuoteMeta for flexible SQL query matching
		escapedSQL3 := fmt.Sprintf(`UPDATE "accounts" SET "contact_no" = $1, "updated_at" = $2 WHERE (email=$3)`)
		escapedSQL3 = regexp.QuoteMeta(escapedSQL3) // Escape the query to handle special characters

		// Custom matcher for time.Time argument to allow small precision differences
		mock.ExpectExec(fmt.Sprintf(escapedSQL3)).
			WithArgs("9876543210", sqlmock.AnyArg(), "user@example.com").
			WillReturnResult(sqlmock.NewResult(1, 1)) // Assuming the update is successful

		// Mock transaction commit (commit the changes)
		mock.ExpectCommit()

		// Create a request body with only contact
		body := `{"name": "", "contact": "9876543210"}`
		req := httptest.NewRequest(http.MethodPost, "/update-profile", bytes.NewBufferString(body))
		ctx.Request = req

		// Call the handler
		api.UpdateProfile(ctx)

		// Assert the response code and message
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Profile Updated Succesfully", response["message"])
	})
}

func TestUpdateProfileNoAccountFound(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Mock JWT claims
	mockJwtClaims := map[string]interface{}{
		"id":    "1",
		"email": "user@example.com",
		"name":  "Test User",
	}

	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm

	// Test case for no account found in database
	t.Run("No Account Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup a test HTTP request and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JWT Claims in the context
		ctx.Set("email", mockJwtClaims["email"])

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace123", "name": "Test User", "id": "1"}
		ctx.Set("JWT_PAYLOAD", claims)
		// Mock transaction start (begin)
		mock.ExpectBegin()
		// Update mock to simulate no rows affected
		mock.ExpectExec(`UPDATE "accounts" SET "name"=\$1 WHERE email=\$2`).
			WithArgs("Updated Name", "user@example.com").
			WillReturnResult(sqlmock.NewResult(0, 0)) // No rows updated
		mock.ExpectCommit()
		// Create a valid request body
		body := `{"name": "Updated Name", "contact": "9876543210"}`
		req := httptest.NewRequest(http.MethodPost, "/update-profile", bytes.NewBufferString(body))
		ctx.Request = req

		// Call the handler
		api.UpdateProfile(ctx)

		// Assert the response code and error message
		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.Unmarshal(w.Body.Bytes(), &response)
		assert.NoError(t, err)

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "no account found", response["message"])
	})
}

func TestUpdateProfileHandler(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup mock DB
	// Setup the mock database and expectations
	mockGorm, mock, _ := setupMockDB(t)
	config.DB = mockGorm

	// Test case for a successful profile update
	t.Run("Valid Profile Update", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Expect an UPDATE query for updating the user's name

		// Mock transaction start (begin)
		mock.ExpectBegin()

		// Use fmt.Sprintf and regexp.QuoteMeta for flexible SQL query matching
		escapedSQL := fmt.Sprintf(`UPDATE "accounts" SET "name" = $1, "updated_at" = $2 WHERE (email=$3)`)
		escapedSQL = regexp.QuoteMeta(escapedSQL) // Escape the query to handle special characters

		// Custom matcher for time.Time argument to allow small precision differences
		mock.ExpectExec(fmt.Sprintf(escapedSQL)).
			WithArgs("Updated Name", sqlmock.AnyArg(), "user@example.com").
			WillReturnResult(sqlmock.NewResult(1, 1)) // Assuming the update is successful

		// // Mock transaction commit (commit the changes)
		mock.ExpectCommit()

		// Mock transaction start (begin)
		mock.ExpectBegin()

		// Use fmt.Sprintf and regexp.QuoteMeta for flexible SQL query matching
		escapedSQL3 := fmt.Sprintf(`UPDATE "accounts" SET "contact_no" = $1, "updated_at" = $2 WHERE (email=$3)`)
		escapedSQL3 = regexp.QuoteMeta(escapedSQL3) // Escape the query to handle special characters

		// Custom matcher for time.Time argument to allow small precision differences
		mock.ExpectExec(fmt.Sprintf(escapedSQL3)).
			WithArgs("1234567890", sqlmock.AnyArg(), "user@example.com").
			WillReturnResult(sqlmock.NewResult(1, 1)) // Assuming the update is successful

		// Mock transaction commit (commit the changes)
		mock.ExpectCommit()

		// Call the function with valid data
		err := accounts.UpdateProfile("user@example.com", "Updated Name", "1234567890")

		// Assert no error occurred
		assert.NoError(t, err)
	})

	// Test case for when no account is found
	t.Run("No Account Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Expect an UPDATE query for updating the user's name, but simulate no rows affected (i.e., no account found)
		mock.ExpectExec("UPDATE \"accounts\" SET \"name\" = \\$1 WHERE email=\\$2").
			WithArgs("Updated Name", "user@example.com").
			WillReturnResult(sqlmock.NewResult(0, 0)) // Simulating no rows affected

		// Call the function with valid data
		err := accounts.UpdateProfile("user@example.com", "Updated Name", "")

		// Assert the expected error is returned
		assert.Error(t, err)
		assert.Equal(t, "no account found", err.Error())
	})

}
