package test

import (
	// "encoding/json"
	// "net/http"

	"bytes"
	"encoding/json"
	"log"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/workspace"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

// Mock ExtractClaims using monkey patch to simulate missing email claim
func TestCreateWorkSpaceEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Setup mock database
	gormDB, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gormDB

	// Test case 1: Invalid JSON request body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Invalid JSON body (missing workspace data)
		req := httptest.NewRequest("POST", "/workspace", bytes.NewBufferString(`{}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreateWorkSpaceEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "WorkSpace URL is required.", response["message"])
	})

	// Test case 2: Missing JWT claims (missing email)
	t.Run("Missing JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock JwtRefreshToken
		monkey.Patch(jwtToken.JwtRefreshToken, func(claims map[string]interface{}) (map[string]interface{}, error) {
			return nil, nil
		})
		defer monkey.Unpatch(jwtToken.JwtRefreshToken)

		// Mock request with valid JSON body
		requestData := `{"workspace_url": "http://workspace.com"}`
		req := httptest.NewRequest("POST", "/workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreateWorkSpaceEp(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Please login again", response["message"])
	})

	// Test case 3: Successful workspace creation
	t.Run("Successful Workspace Creation", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		monkey.Patch(workspace.CreateWorkspace, func(c *gin.Context, email string, token string, data database.Workspaces) (int, map[string]interface{}) {
			return http.StatusOK, map[string]interface{}{
				"error":   false,
				"message": "Workspace created successfully",
			}
		})

		// Mock ProjectPost
		monkey.Patch(api.ProjectPost, func(project models.Project, email string, name string, ip string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   false,
				"message": "Project created successfully",
			}, http.StatusOK
		})
		defer monkey.Unpatch(api.ProjectPost)

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "name": "john doe", "id": 1}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock request with valid JSON body
		requestData := `{"workspace_url": "http://workspace.com"}`
		req := httptest.NewRequest("POST", "/workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreateWorkSpaceEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Workspace created successfully", response["message"])
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case 4: Failed workspace creation (internal error)
	t.Run("Failed Workspace Creation - Internal Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		monkey.Patch(workspace.CreateWorkspace, func(c *gin.Context, email string, token string, data database.Workspaces) (int, map[string]interface{}) {
			return http.StatusInternalServerError, map[string]interface{}{
				"error":   true,
				"message": "Failed to create workspace",
			}
		})

		// Mock ProjectPost to return error
		monkey.Patch(api.ProjectPost, func(project models.Project, token, role, ip string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   true,
				"message": "Failed to create workspace",
			}, http.StatusInternalServerError
		})
		defer monkey.Unpatch(api.ProjectPost)

		monkey.Patch(activities.RecordActivity, func(activity database.Activities) {
			// Mock recording activity
		})
		defer monkey.Unpatch(activities.RecordActivity)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "name": "john doe"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock request with valid JSON body
		requestData := `{"workspace_url": "http://workspace.com"}`
		req := httptest.NewRequest("POST", "/workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreateWorkSpaceEp(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Failed to create workspace", response["message"])
		assert.NoError(t, mock.ExpectationsWereMet())
	})

	// Test case 5: Failed workspace creation due to missing authorization
	t.Run("Failed Workspace Creation - Missing Authorization", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		monkey.Patch(workspace.CreateWorkspace, func(c *gin.Context, email string, token string, data database.Workspaces) (int, map[string]interface{}) {
			return 401, map[string]interface{}{
				"error":   true,
				"message": "Unauthorized",
			}
		})
		// Mock ProjectPost to return unauthorized
		monkey.Patch(api.ProjectPost, func(project models.Project, token, role, ip string) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   true,
				"message": "Unauthorized",
			}, http.StatusUnauthorized
		})
		defer monkey.Unpatch(api.ProjectPost)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com", "name": "john doe", "id": 1}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock request with valid JSON body
		requestData := `{"workspace_url": "http://workspace.com"}`
		req := httptest.NewRequest("POST", "/workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.CreateWorkSpaceEp(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Unauthorized", response["message"])
		assert.NoError(t, mock.ExpectationsWereMet())
	})
}

func TestWorkspaceAvailability(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Workspace Available", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request body
		reqBody := database.Workspaces{WorkspaceID: "workspace-available"}
		jsonBody, _ := json.Marshal(reqBody)
		ctx.Request = httptest.NewRequest("POST", "/workspace/availability", bytes.NewBuffer(jsonBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		// Mock CheckWorkspaceAvailability function
		monkey.Patch(workspace.CheckWorkspaceAvailability, func(data database.Workspaces) (int, string) {
			return http.StatusOK, "Workspace is available"
		})
		defer monkey.Unpatch(workspace.CheckWorkspaceAvailability)

		api.WorkspaceAvailability(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Workspace is available", response["message"])
	})

	t.Run("Failure - Missing Workspace URL", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Empty request body
		ctx.Request = httptest.NewRequest("POST", "/workspace/availability", bytes.NewBuffer([]byte("{}")))
		ctx.Request.Header.Set("Content-Type", "application/json")

		api.WorkspaceAvailability(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "workspace_url is required.", response["message"])
	})

	t.Run("Failure - Workspace Not Available", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request body
		reqBody := database.Workspaces{WorkspaceID: "workspace-taken"}
		jsonBody, _ := json.Marshal(reqBody)
		ctx.Request = httptest.NewRequest("POST", "/workspace/availability", bytes.NewBuffer(jsonBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		// Mock CheckWorkspaceAvailability function to return an error
		monkey.Patch(workspace.CheckWorkspaceAvailability, func(data database.Workspaces) (int, string) {
			return http.StatusConflict, "Workspace is already taken"
		})
		defer monkey.Unpatch(workspace.CheckWorkspaceAvailability)

		api.WorkspaceAvailability(ctx)

		assert.Equal(t, http.StatusConflict, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Workspace is already taken", response["message"])
	})
}

func TestWorkSpaceLoginEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Workspace Login Successful", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request body
		reqBody := database.Workspaces{WorkspaceID: "workspace-123"}
		jsonBody, _ := json.Marshal(reqBody)
		ctx.Request = httptest.NewRequest("POST", "/workspace/login", bytes.NewBuffer(jsonBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		// Mock Login function
		monkey.Patch(workspace.Login, func(workspaceID string) (int, map[string]interface{}) {
			return http.StatusOK, map[string]interface{}{
				"error":   false,
				"message": "Login successful",
				"token":   "new_token",
			}
		})
		defer monkey.Unpatch(workspace.Login)

		api.WorkSpaceLoginEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, false, response["error"])
		assert.Equal(t, "Login successful", response["message"])
		assert.Equal(t, "new_token", response["token"])
	})

	t.Run("Failure - Missing Workspace URL", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Empty request body
		ctx.Request = httptest.NewRequest("POST", "/workspace/login", bytes.NewBuffer([]byte("{}")))
		ctx.Request.Header.Set("Content-Type", "application/json")

		api.WorkSpaceLoginEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "WorkSpace URL is required.", response["message"])
	})

	t.Run("Failure - Workspace Login Failed", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Mock request body
		reqBody := database.Workspaces{WorkspaceID: "invalid-workspace"}
		jsonBody, _ := json.Marshal(reqBody)
		ctx.Request = httptest.NewRequest("POST", "/workspace/login", bytes.NewBuffer(jsonBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		// Mock Login function to return an error
		monkey.Patch(workspace.Login, func(workspaceID string) (int, map[string]interface{}) {
			return http.StatusUnauthorized, map[string]interface{}{
				"error":   true,
				"message": "Invalid workspace credentials",
			}
		})
		defer monkey.Unpatch(workspace.Login)

		api.WorkSpaceLoginEp(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)

		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		if err != nil {
			log.Println(err.Error())
		}

		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Invalid workspace credentials", response["message"])
	})
}
