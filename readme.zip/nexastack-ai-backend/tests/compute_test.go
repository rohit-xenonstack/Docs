package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"net/http/httptest"
	"reflect"
	"regexp"
	"testing"

	"helm.sh/helm/v3/pkg/action"
	"helm.sh/helm/v3/pkg/chart"
	"helm.sh/helm/v3/pkg/release"
	"k8s.io/client-go/rest"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/compute"
	"git.xenonstack.com/nexa-platform/accounts/src/helm"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/resource"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

// Test PodStatus handler
func TestPodStatus(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	// Test case 1: Invalid request body
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Invalid JSON body (missing workspace data)
		req := httptest.NewRequest("POST", "/podstatus", bytes.NewBufferString(`{"workspace":123}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.PodStatus(ctx)

		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Invalid request body", response["message"])
	})

	// Test case 2: Missing JWT claims (missing workspace claim)
	// t.Run("Missing JWT Claims", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	// Mock request with valid JSON body
	// 	requestData := `{"workspace": "workspace-123"}`
	// 	req := httptest.NewRequest("POST", "/podstatus", bytes.NewBufferString(requestData))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req
	// 	api.PodStatus(ctx)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "Please login again", response["message"])
	// })

	// Test case 3: Workspace not valid
	t.Run("Workspace Not Valid", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Expected workspace data
		expectedWorkspace := database.Workspaces{
			ID:          1,
			WorkspaceID: "workspace-123",
			Status:      "active",
			TeamName:    "Team A",
			TeamSize:    "10",
			TeamType:    "Remote",
			Created:     1700000000,
		}

		// Mocking the SQL query using regexp.QuoteMeta
		query := regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)
		mock.ExpectQuery(query).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "status", "team_name", "team_size", "team_type", "created"}).
				AddRow(expectedWorkspace.ID, expectedWorkspace.WorkspaceID, expectedWorkspace.Status, expectedWorkspace.TeamName, expectedWorkspace.TeamSize, expectedWorkspace.TeamType, expectedWorkspace.Created))

		// Mock request with a different workspace
		requestData := `{"workspace": "workspace-999"}`
		req := httptest.NewRequest("POST", "/podstatus", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.PodStatus(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Workspace not valid!", response["message"])
	})

	// Test case 5: Pods are not running
	t.Run("Pods Not Running", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Expected workspace data
		expectedWorkspace := database.Workspaces{
			ID:          1,
			WorkspaceID: "workspace-123",
			Status:      "active",
			TeamName:    "Team A",
			TeamSize:    "10",
			TeamType:    "Remote",
			Created:     1700000000,
		}

		// Mocking the SQL query using regexp.QuoteMeta
		query := regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)
		mock.ExpectQuery(query).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "status", "team_name", "team_size", "team_type", "created"}).
				AddRow(expectedWorkspace.ID, expectedWorkspace.WorkspaceID, expectedWorkspace.Status, expectedWorkspace.TeamName, expectedWorkspace.TeamSize, expectedWorkspace.TeamType, expectedWorkspace.Created))

		// Mock kubernetes.CheckPodStatus to simulate pod not running
		monkey.Patch(kubernetes.CheckPodStatus, func(namespace, releaseName string) (bool, error) {
			return false, nil // Simulate pod not running
		})
		defer monkey.Unpatch(kubernetes.CheckPodStatus)

		// Mock request with valid workspace
		requestData := `{"workspace": "workspace-123"}`
		req := httptest.NewRequest("POST", "/podstatus", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.PodStatus(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Pods are not running", response["message"])
	})

	// Test case 6: Pods running successfully
	t.Run("Pods Running Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Expected workspace data
		expectedWorkspace := database.Workspaces{
			ID:          1,
			WorkspaceID: "workspace-123",
			Status:      "active",
			TeamName:    "Team A",
			TeamSize:    "10",
			TeamType:    "Remote",
			Created:     1700000000,
		}

		// Mocking the SQL query using regexp.QuoteMeta
		query := regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)
		mock.ExpectQuery(query).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "status", "team_name", "team_size", "team_type", "created"}).
				AddRow(expectedWorkspace.ID, expectedWorkspace.WorkspaceID, expectedWorkspace.Status, expectedWorkspace.TeamName, expectedWorkspace.TeamSize, expectedWorkspace.TeamType, expectedWorkspace.Created))

		monkey.Patch(kubernetes.CheckPodStatus, func(namespace, releaseName string) (bool, error) {
			return true, nil // Simulate pod running
		})
		defer monkey.Unpatch(kubernetes.CheckPodStatus)

		// Mock request with valid workspace
		requestData := `{"workspace": "workspace-123"}`
		req := httptest.NewRequest("POST", "/podstatus", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.PodStatus(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Pods running successfully", response["message"])
	})
}

func TestGetPodDetails(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	// Test case 1: Invalid Request Body
	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/getpoddetails", bytes.NewBufferString(`{"workspace":123}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.GetPodDetails(ctx)

		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Invalid request body", response["message"])
	})

	// // Test case 3: Workspace Not Found
	// t.Run("Workspace Not Found", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)
	// 	claims := jwt.MapClaims{"workspace": "workspace-123"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs("workspace-123").
	// 		WillReturnError(errors.New("record not found"))

	// 	req := httptest.NewRequest("POST", "/getpoddetails", bytes.NewBufferString(`{"workspace": "workspace-123"}`))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	api.GetPodDetails(ctx)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "Workspace does not match", response["message"])
	// })

	// Test case 4: Error Retrieving Pod Details
	t.Run("Error Retrieving Pod Details", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		expectedWorkspace := database.Workspaces{WorkspaceID: "workspace-123"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(expectedWorkspace.WorkspaceID))

		monkey.Patch(kubernetes.GetPodInfo, func(namespace string, podNamePrefix string) (map[string]interface{}, error) {
			return nil, errors.New("Pod info retrieval failed")
		})
		defer monkey.Unpatch(kubernetes.GetPodInfo)

		req := httptest.NewRequest("POST", "/getpoddetails", bytes.NewBufferString(`{"workspace": "workspace-123"}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.GetPodDetails(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Pod info retrieval failed", response["message"])
	})
}

func TestGetComputeList(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	// Test case 1: Missing JWT Claims
	// t.Run("Missing JWT Claims", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	req := httptest.NewRequest("GET", "/getcomputelist", nil)
	// 	ctx.Request = req

	// 	api.GetComputeList(ctx)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "Please login again", response["message"])
	// })

	// Test case 2: Workspace Not Found
	// t.Run("Workspace Not Found", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)
	// 	claims := jwt.MapClaims{"workspace": "workspace-123"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs("workspace-123").
	// 		WillReturnError(errors.New("record not found"))

	// 	req := httptest.NewRequest("GET", "/getcomputelist", nil)
	// 	ctx.Request = req

	// 	api.GetComputeList(ctx)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "Workspace does not match", response["message"])
	// })

	// Test case 3: No Compute Configurations Found
	t.Run("No Compute Configurations Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		expectedWorkspace := database.Workspaces{WorkspaceID: "workspace-123"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(expectedWorkspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "compute_configs" WHERE (workspace_id = $1 AND is_deleted = $2)`)).
			WithArgs("workspace-123", false).
			WillReturnRows(sqlmock.NewRows([]string{}))

		req := httptest.NewRequest("GET", "/getcomputelist", nil)
		ctx.Request = req

		api.GetComputeList(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "No compute configurations found", response["message"])
	})
}

func TestDeleteCompute(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	// t.Run("Missing JWT Claims", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	req := httptest.NewRequest("DELETE", "/compute/123", nil)
	// 	ctx.Request = req
	// 	ctx.Params = gin.Params{{Key: "computeId", Value: "123"}}

	// 	api.DeleteCompute(ctx)

	// 	assert.Equal(t, http.StatusInternalServerError, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, "Please login again", response["message"])
	// })

	t.Run("Workspace Email Mismatch", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Params = gin.Params{{Key: "computeId", Value: "123"}}

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123", "user@example.com").
			WillReturnError(errors.New("error"))
		req := httptest.NewRequest("DELETE", "/compute/123", nil)
		ctx.Request = req

		api.DeleteCompute(ctx)

		assert.Equal(t, http.StatusUnauthorized, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Email does not belong to the same workspace", response["message"])
	})

	t.Run("Compute Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Params = gin.Params{{Key: "computeId", Value: "123"}}

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY "workspace_members"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id", "member_email"}).AddRow("workspace-123", "user@example.com"))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "compute_configs" WHERE (id = $1 AND workspace_id = $2) ORDER BY "compute_configs"."id" ASC LIMIT 1`)).
			WithArgs("123", "workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow("123", "workspace-123"))

		req := httptest.NewRequest("DELETE", "/compute/123", nil)
		ctx.Request = req

		api.DeleteCompute(ctx)

		assert.Equal(t, http.StatusNotFound, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Compute not found", response["message"])
	})
}

func TestDeleteComputeUninstallComputeFailure(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db
	t.Run("Uninstall Compute Failure", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)
		ctx.Params = gin.Params{{Key: "computeId", Value: "123"}}

		mock.ExpectQuery(regexp.QuoteMeta("SELECT * FROM \"workspace_members\" WHERE (workspace_id = $1 AND member_email = $2) ORDER BY \"workspace_members\".\"id\" ASC LIMIT 1")).
			WithArgs("workspace-123", "user@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id", "member_email"}).AddRow("workspace-123", "user@example.com"))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "compute_configs"  WHERE (id = $1 AND workspace_id = $2 ) ORDER BY "compute_configs"."id" ASC LIMIT 1`)).
			WithArgs("123", "workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow("123", "workspace-123"))

		monkey.Patch(compute.UninstallCompute, func(namespace string, releaseName string) (map[string]interface{}, int) {
			return nil, 500
		})
		defer monkey.Unpatch(compute.UninstallCompute)

		req := httptest.NewRequest("DELETE", "/compute/123", nil)
		ctx.Request = req

		api.DeleteCompute(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
	})
}

func TestUpdateResourcesPreset(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, _, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	// Test Case 1: Invalid JSON Input
	t.Run("Invalid JSON Input", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBufferString(`{invalid json}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.UpdateResourcesPreset(ctx)

		assert.Equal(t, 400, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Invalid JSON input", response["error"])
	})

	// Test Case 2: Missing JWT Claims
	// t.Run("Missing JWT Claims", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	reqBody := database.ComputeConfig{
	// 		UserEmail:       "test@example.com",
	// 		ResourcesPreset: "medium",
	// 		NodeRuntime:     "python3",
	// 	}
	// 	jsonBody, _ := json.Marshal(reqBody)
	// 	req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	api.UpdateResourcesPreset(ctx)

	// 	assert.Equal(t, 500, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, true, response["error"])
	// 	assert.Equal(t, "Please login again", response["message"])
	// })

	// Test Case 3: Workspace Not Found
	// t.Run("Workspace Not Found", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)
	// 	claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
	// 	ctx.Set("JWT_PAYLOAD", claims)

	// 	reqBody := database.ComputeConfig{
	// 		UserEmail:       "test@example.com",
	// 		ResourcesPreset: "medium",
	// 		NodeRuntime:     "python3",
	// 	}
	// 	jsonBody, _ := json.Marshal(reqBody)
	// 	req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs("test.example.com").
	// 		WillReturnError(errors.New("record not found"))

	// 	api.UpdateResourcesPreset(ctx)

	// 	assert.Equal(t, 500, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, true, response["error"])
	// 	assert.Equal(t, "Workspace does not match", response["message"])
	// })

	// Test Case 5: Invalid ResourcesPreset Value
	// t.Run("Invalid ResourcesPreset Value", func(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// 	w := httptest.NewRecorder()
	// 	ctx, _ := gin.CreateTestContext(w)

	// 	// Set JWT claims
	// 	ctx.Set("JWT_PAYLOAD", map[string]interface{}{"workspace": "test.example.com"})

	// 	reqBody := database.ComputeConfig{
	// 		UserEmail:       "test@example.com",
	// 		ResourcesPreset: "invalid-preset", // Invalid preset value
	// 		NodeRuntime:     "python3",
	// 	}
	// 	jsonBody, _ := json.Marshal(reqBody)
	// 	req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
	// 	req.Header.Set("Content-Type", "application/json")
	// 	ctx.Request = req

	// 	workspace := database.Workspaces{WorkspaceID: "test.example.com"}
	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
	// 		WithArgs("test.example.com").
	// 		WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

	// 	mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE member_email= $1 AND workspace_id= $2`)).
	// 		WithArgs("test@example.com", "test.example.com").
	// 		WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("test@example.com", "test.example.com"))

	// 	// Mock DownloadCharts
	// 	monkey.Patch(resource.DownlaodCharts, func(bucketName, fileName string) {
	// 		// Do nothing
	// 	})
	// 	defer monkey.Unpatch(resource.DownlaodCharts)

	// 	// Mock FetchChart
	// 	monkey.Patch(helm.FetchChart, func(companyFQDN, workspace, nameSpace string) (*chart.Chart, string, error) {
	// 		return &chart.Chart{}, "mock-value", nil
	// 	})
	// 	defer monkey.Unpatch(helm.FetchChart)

	// 	api.UpdateResourcesPreset(ctx)

	// 	assert.Equal(t, 400, w.Code)
	// 	var response map[string]interface{}
	// 	err := json.NewDecoder(w.Body).Decode(&response)
	// 	assert.NoError(t, err)
	// 	assert.Equal(t, true, response["error"])
	// 	assert.Equal(t, "Invalid ResourcesPreset value", response["message"])
	// })
}

func TestUpdateResourcePresetCase1(t *testing.T) {
	SetupLogging()
	ResetLogs()

	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db
	t.Run("Error Setting Kubernetes Config", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		reqBody := database.ComputeConfig{
			UserEmail:       "test@example.com",
			ResourcesPreset: "medium",
			NodeRuntime:     "python3",
		}
		jsonBody, _ := json.Marshal(reqBody)
		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		workspace := database.Workspaces{WorkspaceID: "test.example.com"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
			WithArgs("test@example.com", "test.example.com").
			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("test@example.com", "test.example.com"))

		// Mock SetConfig to return an error
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return nil, 500, errors.New("failed to set kubernetes config")
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		api.UpdateResourcesPreset(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "failed to set kubernetes config", response["message"])
	})

	// Test Case 7: No Suitable Node with Sufficient Resources
	t.Run("No Suitable Node with Sufficient Resources", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		reqBody := database.ComputeConfig{
			UserEmail:       "test@example.com",
			ResourcesPreset: "medium",
			NodeRuntime:     "python3",
		}
		jsonBody, _ := json.Marshal(reqBody)
		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		workspace := database.Workspaces{WorkspaceID: "test.example.com"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
			WithArgs("test@example.com", "test.example.com").
			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("test@example.com", "test.example.com"))

		// Mock SetConfig
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 200, nil
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		// Mock DownloadCharts
		monkey.Patch(resource.DownlaodCharts, func(bucketName string, fileName string) (map[string]interface{}, int) {
			// Do nothing
			return nil, 0
		})
		defer monkey.Unpatch(resource.DownlaodCharts)

		// Mock FetchChart
		monkey.Patch(helm.FetchChart, func(companyFQDN, workspace, nameSpace string) (*chart.Chart, map[string]interface{}, error) {
			return &chart.Chart{}, nil, nil
		})
		defer monkey.Unpatch(helm.FetchChart)

		// Mock GetNodesNames to return some nodes
		monkey.Patch(kubernetes.GetNodesNames, func(workspace string) ([]string, error) {
			return []string{"node1", "node2"}, nil
		})
		defer monkey.Unpatch(kubernetes.GetNodesNames)

		// Mock HasSufficientResources to always return false (no suitable node)
		monkey.Patch(kubernetes.HasSufficientResources, func(nodeName string, resources map[string]string) bool {
			return false
		})
		defer monkey.Unpatch(kubernetes.HasSufficientResources)

		api.UpdateResourcesPreset(ctx)

		assert.Equal(t, 500, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "Resources not available on the specified node", response["message"])
	})
	t.Run("User Not a Member of Workspace", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		reqBody := database.ComputeConfig{
			UserEmail:       "test@example.com",
			ResourcesPreset: "medium",
			NodeRuntime:     "python3",
		}
		jsonBody, _ := json.Marshal(reqBody)
		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		workspace := database.Workspaces{WorkspaceID: "workspace-123"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE member_email= $1 AND workspace_id= $2`)).
			WithArgs("test@example.com", "workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}))

		api.UpdateResourcesPreset(ctx)

		assert.Equal(t, 401, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, true, response["error"])
		assert.Equal(t, "The user does not belong to this workspace.", response["message"])
	})
}

func TestUpdateResourcePresetSucessCase1(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = db
	t.Run("Success Case Release Non Null Cae", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		reqBody := database.ComputeConfig{
			UserEmail:       "test@example.com",
			ResourcesPreset: "medium",
			NodeRuntime:     "python3",
		}
		jsonBody, _ := json.Marshal(reqBody)
		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		workspace := database.Workspaces{WorkspaceID: "test.example.com"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
			WithArgs("test@example.com", "test.example.com").
			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("test@example.com", "test.example.com"))

		// Mock SetConfig
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 200, nil
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		// Mock DownloadCharts
		monkey.Patch(resource.DownlaodCharts, func(bucketName string, fileName string) (map[string]interface{}, int) {
			// Do nothing
			return nil, 0
		})
		defer monkey.Unpatch(resource.DownlaodCharts)

		// Mock FetchChart
		monkey.Patch(helm.FetchChart, func(companyFQDN, workspace, nameSpace string) (*chart.Chart, map[string]interface{}, error) {
			return &chart.Chart{}, nil, nil
		})
		defer monkey.Unpatch(helm.FetchChart)

		// Mock GetNodesNames to return some nodes
		monkey.Patch(kubernetes.GetNodesNames, func(workspace string) ([]string, error) {
			return []string{"node1", "node2"}, nil
		})
		defer monkey.Unpatch(kubernetes.GetNodesNames)

		monkey.Patch(rest.InClusterConfig, func() (*rest.Config, error) {
			return &rest.Config{
				Host: "https://mock-kubernetes",
			}, nil
		})

		// Mock HasSufficientResources to always return false (no suitable node)
		monkey.Patch(kubernetes.HasSufficientResources, func(nodeName string, resources map[string]string) bool {
			return true
		})
		defer monkey.Unpatch(kubernetes.HasSufficientResources)

		monkey.PatchInstanceMethod(reflect.TypeOf(&action.Get{}), "Run",
			func(_ *action.Get, releaseName string) (*release.Release, error) {
				if releaseName == "existing-release" {
					return &release.Release{Name: "existing-release"}, nil
				}
				return nil, nil
			},
		)
		defer monkey.UnpatchAll()

		monkey.PatchInstanceMethod(reflect.TypeOf(&action.Install{}), "Run",
			func(_ *action.Install, ch *chart.Chart, values map[string]interface{}) (*release.Release, error) {
				if ch == nil {
					log.Println("Mocked Install.Run received nil chart")
					return nil, errors.New("mocked installation error: chart is nil")
				}
				if ch.Metadata == nil {
					log.Println("Mocked Install.Run received chart with nil Metadata")
					return nil, nil
				}
				log.Printf("Mocked Install.Run called with chart: %s", ch.Metadata.Name)

				if ch.Metadata.Name == "valid-chart" {
					return &release.Release{Name: "mocked-installation"}, nil
				}
				return nil, errors.New("mocked installation error")
			},
		)

		monkey.Patch(kubernetes.CheckPodExists, func(namespace string, podNamePrefix string) (bool, error) {
			if namespace == "mock-namespace" && podNamePrefix == "mock-pod" {
				return true, nil // Simulate pod exists
			}
			return true, nil
		})

		// Ensure unpatching after the test
		defer monkey.UnpatchAll()

		monkey.Patch(kubernetes.RestartPod, func(namespace string, podNamePrefix string) error {
			if namespace == "mock-namespace" && podNamePrefix == "mock-pod" {
				return nil // Simulate successful restart
			}
			return nil
		})

		api.UpdateResourcesPreset(ctx)

		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "compute_configs" WHERE (id = $1 AND workspace_id = $2) ORDER BY "compute_configs"."id" ASC LIMIT 1`)).
			WithArgs("123", "workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow("123", "workspace-123"))
		mock.ExpectCommit()
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "ResourcesPreset successfully updated in values.yaml", response["message"])
	})

}

func TestUpdateResourcePresetSucessCase2(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		reqBody := database.ComputeConfig{
			UserEmail:       "test@example.com",
			ResourcesPreset: "medium",
			NodeRuntime:     "python3",
		}
		jsonBody, _ := json.Marshal(reqBody)
		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		workspace := database.Workspaces{WorkspaceID: "test.example.com"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
			WithArgs("test@example.com", "test.example.com").
			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("test@example.com", "test.example.com"))

		// Mock SetConfig
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 200, nil
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		// Mock DownloadCharts
		monkey.Patch(resource.DownlaodCharts, func(bucketName string, fileName string) (map[string]interface{}, int) {
			// Do nothing
			return nil, 0
		})
		defer monkey.Unpatch(resource.DownlaodCharts)

		// Mock FetchChart
		monkey.Patch(helm.FetchChart, func(companyFQDN, workspace, nameSpace string) (*chart.Chart, map[string]interface{}, error) {
			return &chart.Chart{}, nil, nil
		})
		defer monkey.Unpatch(helm.FetchChart)

		// Mock GetNodesNames to return some nodes
		monkey.Patch(kubernetes.GetNodesNames, func(workspace string) ([]string, error) {
			return []string{"node1", "node2"}, nil
		})
		defer monkey.Unpatch(kubernetes.GetNodesNames)

		monkey.Patch(rest.InClusterConfig, func() (*rest.Config, error) {
			return &rest.Config{
				Host: "https://mock-kubernetes",
			}, nil
		})

		// Mock HasSufficientResources to always return false (no suitable node)
		monkey.Patch(kubernetes.HasSufficientResources, func(nodeName string, resources map[string]string) bool {
			return true
		})
		defer monkey.Unpatch(kubernetes.HasSufficientResources)

		monkey.PatchInstanceMethod(reflect.TypeOf(&action.Get{}), "Run",
			func(_ *action.Get, releaseName string) (*release.Release, error) {
				if releaseName == "existing-release" {
					return &release.Release{Name: "existing-release"}, nil
				}
				return nil, errors.New("error")
			},
		)
		defer monkey.UnpatchAll()

		monkey.PatchInstanceMethod(reflect.TypeOf(&action.Install{}), "Run",
			func(_ *action.Install, ch *chart.Chart, values map[string]interface{}) (*release.Release, error) {
				if ch == nil {
					log.Println("Mocked Install.Run received nil chart")
					return nil, errors.New("mocked installation error: chart is nil")
				}
				if ch.Metadata == nil {
					log.Println("Mocked Install.Run received chart with nil Metadata")
					return nil, nil
				}
				log.Printf("Mocked Install.Run called with chart: %s", ch.Metadata.Name)

				if ch.Metadata.Name == "valid-chart" {
					return &release.Release{Name: "mocked-installation"}, nil
				}
				return nil, errors.New("mocked installation error")
			},
		)

		monkey.Patch(kubernetes.CheckPodExists, func(namespace string, podNamePrefix string) (bool, error) {
			if namespace == "mock-namespace" && podNamePrefix == "mock-pod" {
				return true, nil // Simulate pod exists
			}
			return true, nil
		})

		// Ensure unpatching after the test
		defer monkey.UnpatchAll()

		monkey.Patch(kubernetes.RestartPod, func(namespace string, podNamePrefix string) error {
			if namespace == "mock-namespace" && podNamePrefix == "mock-pod" {
				return nil // Simulate successful restart
			}
			return nil
		})

		api.UpdateResourcesPreset(ctx)

		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "compute_configs" WHERE (id = $1 AND workspace_id = $2) ORDER BY "compute_configs"."id" ASC LIMIT 1`)).
			WithArgs("123", "workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow("123", "workspace-123"))
		mock.ExpectCommit()
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "ResourcesPreset successfully updated in values.yaml", response["message"])
	})
}

func TestUpdateResourcePresetSucessCase3(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Success Case Else condition", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"workspace": "workspace-123", "email": "user@example.com"}
		ctx.Set("JWT_PAYLOAD", claims)

		reqBody := database.ComputeConfig{
			UserEmail:       "test@example.com",
			ResourcesPreset: "medium",
			NodeRuntime:     "python3",
		}
		jsonBody, _ := json.Marshal(reqBody)
		req := httptest.NewRequest("POST", "/update-resources-preset", bytes.NewBuffer(jsonBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		workspace := database.Workspaces{WorkspaceID: "test.example.com"}
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspaces" WHERE (workspace_id = $1) ORDER BY "workspaces"."id" ASC LIMIT 1`)).
			WithArgs("workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"workspace_id"}).AddRow(workspace.WorkspaceID))

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email= $1 AND workspace_id= $2)`)).
			WithArgs("test@example.com", "test.example.com").
			WillReturnRows(sqlmock.NewRows([]string{"member_email", "workspace_id"}).AddRow("test@example.com", "test.example.com"))

		// Mock SetConfig
		monkey.Patch(kubernetes.SetConfig, func(nameSpace string) (*action.Configuration, int, error) {
			return &action.Configuration{}, 200, nil
		})
		defer monkey.Unpatch(kubernetes.SetConfig)

		// Mock DownloadCharts
		monkey.Patch(resource.DownlaodCharts, func(bucketName string, fileName string) (map[string]interface{}, int) {
			// Do nothing
			return nil, 0
		})
		defer monkey.Unpatch(resource.DownlaodCharts)

		// Mock FetchChart
		monkey.Patch(helm.FetchChart, func(companyFQDN, workspace, nameSpace string) (*chart.Chart, map[string]interface{}, error) {
			return &chart.Chart{}, nil, nil
		})
		defer monkey.Unpatch(helm.FetchChart)

		// Mock GetNodesNames to return some nodes
		monkey.Patch(kubernetes.GetNodesNames, func(workspace string) ([]string, error) {
			return []string{"node1", "node2"}, nil
		})
		defer monkey.Unpatch(kubernetes.GetNodesNames)

		monkey.Patch(rest.InClusterConfig, func() (*rest.Config, error) {
			return &rest.Config{
				Host: "https://mock-kubernetes",
			}, nil
		})

		// Mock HasSufficientResources to always return false (no suitable node)
		monkey.Patch(kubernetes.HasSufficientResources, func(nodeName string, resources map[string]string) bool {
			return true
		})
		defer monkey.Unpatch(kubernetes.HasSufficientResources)

		monkey.PatchInstanceMethod(reflect.TypeOf(&action.Get{}), "Run",
			func(_ *action.Get, releaseName string) (*release.Release, error) {
				if releaseName == "existing-release" {
					return &release.Release{
						Name:      "existing-release",
						Namespace: "default",
						Version:   1,
						Manifest:  "mocked-manifest",
						Info: &release.Info{
							Status:      release.StatusDeployed,
							Description: "Mocked Helm release",
						},
						Chart: &chart.Chart{
							Metadata: &chart.Metadata{
								Name:    "mocked-chart",
								Version: "1.0.0",
							},
						},
						Config: map[string]interface{}{
							"key1": "value1",
							"key2": "value2",
						},
						Hooks: []*release.Hook{
							{
								Name:   "mocked-hook",
								Events: []release.HookEvent{release.HookPreInstall},
							},
						},
						Labels: map[string]string{
							"app": "mocked-app",
						},
					}, nil
				}
				return &release.Release{
					Name:      "failed-release",
					Namespace: "error-ns",
					Version:   0,
					Manifest:  "",
					Info: &release.Info{
						Status:      release.StatusFailed,
						Description: "Mocked error release",
					},
				}, errors.New("mocked error retrieving release")
			},
		)
		defer monkey.UnpatchAll()

		monkey.PatchInstanceMethod(reflect.TypeOf(&action.Install{}), "Run",
			func(_ *action.Install, ch *chart.Chart, values map[string]interface{}) (*release.Release, error) {
				if ch == nil {
					log.Println("Mocked Install.Run received nil chart")
					return nil, errors.New("mocked installation error: chart is nil")
				}
				if ch.Metadata == nil {
					log.Println("Mocked Install.Run received chart with nil Metadata")
					return nil, nil
				}
				log.Printf("Mocked Install.Run called with chart: %s", ch.Metadata.Name)

				if ch.Metadata.Name == "valid-chart" {
					return &release.Release{Name: "mocked-installation"}, nil
				}
				return nil, errors.New("mocked installation error")
			},
		)

		monkey.Patch(kubernetes.CheckPodExists, func(namespace string, podNamePrefix string) (bool, error) {
			if namespace == "mock-namespace" && podNamePrefix == "mock-pod" {
				return true, nil // Simulate pod exists
			}
			return true, nil
		})

		// Ensure unpatching after the test
		defer monkey.UnpatchAll()

		monkey.Patch(kubernetes.RestartPod, func(namespace string, podNamePrefix string) error {
			if namespace == "mock-namespace" && podNamePrefix == "mock-pod" {
				return nil // Simulate successful restart
			}
			return nil
		})

		api.UpdateResourcesPreset(ctx)

		mock.ExpectBegin()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "compute_configs" WHERE (id = $1 AND workspace_id = $2) ORDER BY "compute_configs"."id" ASC LIMIT 1`)).
			WithArgs("123", "workspace-123").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id"}).AddRow("123", "workspace-123"))
		mock.ExpectCommit()
		assert.Equal(t, 200, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, false, response["error"])
		assert.Equal(t, "ResourcesPreset successfully updated in values.yaml", response["message"])
	})
}
