package test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/integrations"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

func TestListInfrastructure(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Missing Workspace in Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/list-infra", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{})

		api.ListInfrastucture(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "please login again")
	})

	t.Run("Invalid Page Number", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/list-infra?page=invalid", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{"workspace": "test-workspace"})

		api.ListInfrastucture(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Please pass valid page number")
	})

	t.Run("Invalid Limit Number", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/list-infra?limit=invalid", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{"workspace": "test-workspace"})

		api.ListInfrastucture(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), "Please pass valid limit number")
	})

	t.Run("Integration Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/list-infra?page=1&limit=10", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{"workspace": "test-workspace"})

		monkey.Patch(integrations.ListInfrastucture, func(workspace, infraType, search string, limit, page int) (map[string]interface{}, int) {
			return map[string]interface{}{
				"error":   true,
				"message": "Failed to fetch infrastructure",
			}, http.StatusInternalServerError
		})
		defer monkey.UnpatchAll()

		api.ListInfrastucture(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), "Failed to fetch infrastructure")
	})

	t.Run("Successful ListInfrastructure Call", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("GET", "/list-infra?page=1&limit=10", nil)
		ctx.Set("JWT_PAYLOAD", jwt.MapClaims{"workspace": "test-workspace"})

		monkey.Patch(integrations.ListInfrastucture, func(workspace, infraType, search string, limit, page int) (map[string]interface{}, int) {
			return map[string]interface{}{
				"success": true,
				"data":    []string{"infra1", "infra2"},
			}, http.StatusOK
		})
		defer monkey.UnpatchAll()

		api.ListInfrastucture(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), "infra1")
		assert.Contains(t, w.Body.String(), "infra2")
	})
}
