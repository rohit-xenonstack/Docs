package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"regexp"
	"testing"
	"time"

	"bou.ke/monkey"
	"github.com/DATA-DOG/go-sqlmock"

	"github.com/stretchr/testify/mock"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"

	"git.xenonstack.com/nexa-platform/accounts/models"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/stretchr/testify/assert"
)

// Mock DB function
type MockDB struct {
	mock.Mock
}

// Mock setup helper function
func setupMockDB(t *testing.T) (*gorm.DB, sqlmock.Sqlmock, func()) {
	// Create a mock SQL database using sqlmock
	db, mock, err := sqlmock.New() // Create a new mock *sql.DB
	if err != nil {
		t.Fatalf("Failed to create mock DB: %v", err)
	}
	// defer db.Close()

	// Create a *gorm.DB instance by wrapping the mock *sql.DB with the PostgreSQL dialect
	gormDB, err := gorm.Open("postgres", db) // Use PostgreSQL dialect
	if err != nil {
		t.Fatalf("Failed to open gorm DB: %v", err)
	}

	return gormDB, mock, func() {
		db.Close()
	}
}

func TestUpdateFieldsInDB(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "1"
		field := models.FineTuneFieldMetadata{
			Id:   1,
			Name: "Updated Field",
		}

		rows := sqlmock.NewRows([]string{"id", "name", "section", "input_type", "field_type", "description", "created_at", "updated_at", "created_by"}).
			AddRow(1, "Original Field", "Section", "text", "string", "Description", time.Now(), time.Now(), 123)

		// Using the exact SQL format that GORM generates with AnyArg for type flexibility
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata" WHERE "fine_tune_field_metadata"."id" = $1 AND ((id =$2)) ORDER BY "fine_tune_field_metadata"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(rows)

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "fine_tune_field_metadata" SET`)).
			WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		// Execute
		result, err := api.UpdateFieldsInDB(gormDB, id, field)

		// Assert
		assert.Equal(t, "", result)
		assert.NoError(t, err)

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Record Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "999"
		field := models.FineTuneFieldMetadata{
			Id:   999,
			Name: "Non-existent Field",
		}

		// Using the exact SQL format that GORM generates with AnyArg for type flexibility
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata" WHERE "fine_tune_field_metadata"."id" = $1 AND ((id =$2)) ORDER BY "fine_tune_field_metadata"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnError(gorm.ErrRecordNotFound)

		// Execute
		result, err := api.UpdateFieldsInDB(gormDB, id, field)

		// Assert
		assert.Equal(t, "Field metadata not found.", result)
		assert.Error(t, err)
		assert.Equal(t, gorm.ErrRecordNotFound.Error(), err.Error())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Update Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "1"
		field := models.FineTuneFieldMetadata{
			Id:   1,
			Name: "Updated Field",
		}

		rows := sqlmock.NewRows([]string{"id", "name", "section", "input_type", "field_type", "description", "created_at", "updated_at", "created_by"}).
			AddRow(1, "Original Field", "Section", "text", "string", "Description", time.Now(), time.Now(), 123)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata" WHERE "fine_tune_field_metadata"."id" = $1 AND ((id =$2)) ORDER BY "fine_tune_field_metadata"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()). // Use AnyArg to accept any argument type
			WillReturnRows(rows)

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "fine_tune_field_metadata" SET`)).
			WillReturnError(errors.New("database error"))
		mock.ExpectRollback()

		// Execute
		result, err := api.UpdateFieldsInDB(gormDB, id, field)

		// Assert
		assert.Equal(t, "Error while updating field metadata.", result)
		assert.Error(t, err)
		assert.Equal(t, "database error", err.Error())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

// ===============[[ FINETUNE API TESTING ]] ====================

// Setup tests for CreateFieldConfigurationInDB
// Setup tests for CreateFieldConfigurationInDB
func TestCreateFieldConfigurationInDB(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		// Create mock data
		fieldValues := models.TempFineTuneModelConfigurations{
			ModelName: "test-model",
			ModelPath: "/path/to/model",
			FieldConfigurations: []models.FineTuneFieldValues{
				{FieldId: 1, Value: "{\"key\":\"value1\"}"},
				{FieldId: 2, Value: "{\"key\":\"value2\"}"},
			},
			CreatedBy: 123,
		}

		// Mock the actual SQL query that gets executed
		mock.ExpectExec(`INSERT INTO fine_tune_field_values \(field_id, model_config_id, value, created_by\).*ON CONFLICT.*`).
			WillReturnResult(sqlmock.NewResult(1, 2))

		// Mock the Create call for the new configurations
		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "fine_tune_model_configurations"`).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mock.ExpectCommit()

		// Execute
		result, err := api.CreateFieldConfigurationInDB(gormDB, fieldValues)

		// Assert
		assert.NoError(t, err)
		assert.Equal(t, "", result)

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Upsert Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		// Create mock data
		fieldValues := models.TempFineTuneModelConfigurations{
			ModelName: "test-model",
			FieldConfigurations: []models.FineTuneFieldValues{
				{FieldId: 1, Value: "{\"key\":\"value1\"}"},
			},
		}

		// Mock the actual SQL query with an error
		mock.ExpectExec(`INSERT INTO fine_tune_field_values \(field_id, model_config_id, value, created_by\).*ON CONFLICT.*`).
			WillReturnError(errors.New("upsert error"))

		// Execute
		result, err := api.CreateFieldConfigurationInDB(gormDB, fieldValues)

		// Assert
		assert.Error(t, err)
		assert.Equal(t, "Error while creating new field values", result)
		assert.Equal(t, "upsert error", err.Error())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Create Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		// Create mock data
		fieldValues := models.TempFineTuneModelConfigurations{
			ModelName: "test-model",
			FieldConfigurations: []models.FineTuneFieldValues{
				{FieldId: 1, Value: "{\"key\":\"value1\"}"},
			},
		}

		// Mock the actual SQL query
		mock.ExpectExec(`INSERT INTO fine_tune_field_values \(field_id, model_config_id, value, created_by\).*ON CONFLICT.*`).
			WillReturnResult(sqlmock.NewResult(1, 1))

		// Mock the Create call with an error
		mock.ExpectBegin()
		mock.ExpectQuery(`INSERT INTO "fine_tune_model_configurations"`).
			WillReturnError(errors.New("create error"))
		mock.ExpectRollback()

		// Execute
		result, err := api.CreateFieldConfigurationInDB(gormDB, fieldValues)

		// Assert
		assert.Error(t, err)
		assert.Equal(t, "", result)
		assert.Equal(t, "create error", err.Error())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

// Setup tests for HandlerUpdateIndividualFieldValuesByUser

// Setup tests for GetFinetuneConfigByIDFromDB
func TestGetFinetuneConfigByIDFromDB(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock DB for config.DB
	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("Failed to create mock DB: %v", err)
	}
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db)
	if err != nil {
		t.Fatalf("Failed to open gorm DB: %v", err)
	}

	// Set the mock DB as config.DB (assuming config.DB is a global variable)
	originalDB := config.DB
	config.DB = gormDB
	defer func() { config.DB = originalDB }()

	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		userId := "123"

		// Mock the raw query - use the actual SQL pattern instead of a named query
		rows := sqlmock.NewRows([]string{"data"}).
			AddRow("{\"field1\":\"value1\",\"field2\":\"value2\"}")

		// Use the actual SQL query pattern to match against
		mock.ExpectQuery(`select json_build_object\(\s*'id', id,\s*'model_name', model_name`).
			WithArgs(userId).
			WillReturnRows(rows)

		// Execute - function now returns the FieldsJsonData struct directly
		fields, err := api.GetFinetuneConfigByIDFromDB(userId)

		// Assert
		assert.NoError(t, err)
		assert.Equal(t, "{\"field1\":\"value1\",\"field2\":\"value2\"}", fields.Data)

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		userId := "123"

		// Mock the raw query with an error - use the actual SQL pattern
		mock.ExpectQuery(`select json_build_object\(\s*'id', id,\s*'model_name', model_name`).
			WithArgs(userId).
			WillReturnError(errors.New("database error"))

		// Execute
		fields, err := api.GetFinetuneConfigByIDFromDB(userId)

		// Assert
		assert.Error(t, err)
		assert.Equal(t, "database error", err.Error())
		assert.Empty(t, fields.Data) // The Data field should be empty on error

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

// These are stub implementations to make the tests compile
// In real code, these would be imported from your codebase

func GenerateUpsertQuery(values []models.FineTuneFieldValues) string {
	return "UPSERT QUERY"
}

// ============================[[ FIELDS AND FINETUNE CONTEXT API TESTS ]]=================================

func (m *MockDB) CreateNewFieldInDB(DB *gorm.DB, field models.FineTuneFieldMetadata) error {
	args := m.Called(DB, field)
	return args.Error(0)
}

func TestCreateFields1(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock DB
	// mockDB := new(MockDB)

	// Test case 1: Invalid JSON body
	t.Run("Test Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Send an invalid JSON body (missing required fields)
		req := httptest.NewRequest("POST", "/create-field", bytes.NewBufferString("{ invalid }"))
		ctx.Request = req

		// Call the handler
		api.CreateFields(ctx)

		// Assert the response is 400 with correct error message
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Invalid data"}`, w.Body.String())
	})
}

func TestCreateFields(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Setup: Initialize mock DB
	gormDB, mockDB, cleanup := setupMockDB(t)
	defer cleanup()

	// Test case 1: Invalid JSON body (missing required fields)
	t.Run("Test Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Send an invalid JSON body (missing required fields)
		req := httptest.NewRequest("POST", "/create-field", bytes.NewBufferString("{ invalid }"))
		ctx.Request = req

		// Call the handler
		api.CreateFields(ctx)

		// Assert the response is 400 with the correct error message
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Invalid data"}`, w.Body.String())
	})

	// Test case 2: Valid JSON body and successful creation
	t.Run("Test Valid JSON Body and Successful Field Creation", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Use the mock DB for the handler
		config.DB = gormDB

		fieldData := models.FineTuneFieldMetadata{
			Id:          1,
			Name:        "Test Field",
			Section:     "Test Section",
			InputType:   "text",
			FieldType:   "string",
			Description: "Test Description",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			CreatedBy:   123,
		}

		reqBody, _ := json.Marshal(fieldData)
		req := httptest.NewRequest("POST", "/create-field", bytes.NewBuffer(reqBody))
		ctx.Request = req

		mockDB.ExpectBegin()
		mockDB.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "fine_tune_field_metadata"`)).
			WillReturnRows(sqlmock.NewRows([]string{"id"}).AddRow(1))
		mockDB.ExpectCommit()

		// Call the handler
		api.CreateFields(ctx)

		// Assert the response is 200 with the success message
		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Field Test Field created successfully"}`, w.Body.String())

		// Verify that the mock expectations were met
		if err := mockDB.ExpectationsWereMet(); err != nil {
			t.Errorf("there were unmet expectations: %s", err)
		}
	})

	// Test case 3: Database error during field creation
	t.Run("Test Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create recorder and context
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Use the mock DB for the handler
		config.DB = gormDB
		fieldData := models.FineTuneFieldMetadata{
			Id:          1,
			Name:        "Test Field",
			Section:     "Test Section",
			InputType:   "text",
			FieldType:   "string",
			Description: "Test Description",
			CreatedAt:   time.Now(),
			UpdatedAt:   time.Now(),
			CreatedBy:   123,
		}

		reqBody, _ := json.Marshal(fieldData)
		req := httptest.NewRequest("POST", "/create-field", bytes.NewBuffer(reqBody))
		ctx.Request = req

		mockDB.ExpectBegin()
		mockDB.ExpectQuery(regexp.QuoteMeta(`INSERT INTO "fine_tune_field_metadata"`)).
			WillReturnError(errors.New("Error while creating new field metadata."))
		mockDB.ExpectRollback()

		// Call the handler
		api.CreateFields(ctx)

		// Assert the response is 500 with the correct error message
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Error while creating new field metadata."}`, w.Body.String())

		// Verify that the mock expectations were met
		if err := mockDB.ExpectationsWereMet(); err != nil {
			t.Errorf("there were unmet expectations: %s", err)
		}
	})
}

func TestUpdateFieldsInDBContext(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "1"
		field := models.FineTuneFieldMetadata{
			Id:   1,
			Name: "Updated Field",
		}

		rows := sqlmock.NewRows([]string{"id", "name", "section", "input_type", "field_type", "description", "created_at", "updated_at", "created_by"}).
			AddRow(1, "Original Field", "Section", "text", "string", "Description", time.Now(), time.Now(), 123)

		// Using the exact SQL format that GORM generates with AnyArg for type flexibility
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata" WHERE "fine_tune_field_metadata"."id" = $1 AND ((id =$2)) ORDER BY "fine_tune_field_metadata"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnRows(rows)

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "fine_tune_field_metadata" SET`)).
			WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		// Execute the UpdateFieldsInDB function
		result, err := api.UpdateFieldsInDB(gormDB, id, field)

		// Assert that no error occurred and the result is correct
		assert.Equal(t, "", result)
		assert.NoError(t, err)

		// Verify that all mock expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Record Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "999"
		field := models.FineTuneFieldMetadata{
			Id:   999,
			Name: "Non-existent Field",
		}

		// Using the exact SQL format that GORM generates with AnyArg for type flexibility
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata" WHERE "fine_tune_field_metadata"."id" = $1 AND ((id =$2)) ORDER BY "fine_tune_field_metadata"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()).
			WillReturnError(gorm.ErrRecordNotFound)

		// Execute the UpdateFieldsInDB function
		result, err := api.UpdateFieldsInDB(gormDB, id, field)

		// Assert that the error and result are correct
		assert.Equal(t, "Field metadata not found.", result)
		assert.Error(t, err)
		assert.Equal(t, gorm.ErrRecordNotFound.Error(), err.Error())

		// Verify that all mock expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Update Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "1"
		field := models.FineTuneFieldMetadata{
			Id:   1,
			Name: "Updated Field",
		}

		rows := sqlmock.NewRows([]string{"id", "name", "section", "input_type", "field_type", "description", "created_at", "updated_at", "created_by"}).
			AddRow(1, "Original Field", "Section", "text", "string", "Description", time.Now(), time.Now(), 123)

		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata" WHERE "fine_tune_field_metadata"."id" = $1 AND ((id =$2)) ORDER BY "fine_tune_field_metadata"."id" ASC LIMIT 1`)).
			WithArgs(sqlmock.AnyArg(), sqlmock.AnyArg()). // Use AnyArg to accept any argument type
			WillReturnRows(rows)

		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "fine_tune_field_metadata" SET`)).
			WillReturnError(errors.New("database error"))
		mock.ExpectRollback()

		// Execute the UpdateFieldsInDB function
		result, err := api.UpdateFieldsInDB(gormDB, id, field)

		// Assert that the error is as expected
		assert.Equal(t, "Error while updating field metadata.", result)
		assert.Error(t, err)
		assert.Equal(t, "database error", err.Error())

		// Verify that all mock expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestGetAllFields(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		// Simulate a list of fields being returned from the database

		// fields := []models.FineTuneFieldMetadata{}

		rows := sqlmock.NewRows([]string{"id", "name", "section", "input_type", "field_type", "description", "created_at", "updated_at", "created_by"}).
			AddRow(1, "Field 1", "Section 1", "text", "string", "Description 1", time.Now(), time.Now(), 123).
			AddRow(2, "Field 2", "Section 2", "select", "int", "Description 2", time.Now(), time.Now(), 123)
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata"`)).
			WillReturnRows(rows)

		// Create a mock Gin context and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the mock DB in the config
		config.DB = gormDB

		// Execute the handler
		api.GetAllFields(ctx)

		// Assert the response is 200 with the correct fields in JSON format
		assert.Equal(t, http.StatusOK, w.Code)

		// Verify that all mock expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Error Retrieving Fields", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		// Simulate an error during the field retrieval
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_metadata"`)).
			WillReturnError(errors.New("No field metadata found."))

		// Create a mock Gin context and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the mock DB in the config
		config.DB = gormDB

		// Execute the handler
		api.GetAllFields(ctx)

		// Assert the response is 404 with the correct error message
		assert.Equal(t, http.StatusNotFound, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"No field metadata found."}`, w.Body.String())

		// Verify that all mock expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestRemoveFieldHandler(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "1"
		// field := models.FineTuneFieldMetadata{}

		// Simulate a successful DELETE operation
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "fine_tune_field_metadata" WHERE (id =$1)`)).
			WithArgs(id).
			WillReturnResult(sqlmock.NewResult(0, 1))
		mock.ExpectCommit()

		// Create a mock Gin context and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the mock DB in the config
		config.DB = gormDB

		// Set the id parameter in the request
		ctx.Params = gin.Params{{Key: "id", Value: id}}

		// Execute the handler
		api.RemoveField(ctx)

		// Assert the response is 200 with success message
		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Field metadata deleted successfully."}`, w.Body.String())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Record Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "999"
		// field := models.FineTuneFieldMetadata{}

		// Simulate no rows affected by DELETE operation (record not found)
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "fine_tune_field_metadata" WHERE (id =$1)`)).
			WithArgs(id).
			WillReturnResult(sqlmock.NewResult(0, 0)) // No rows affected
		mock.ExpectCommit()

		// Create a mock Gin context and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the mock DB in the config
		config.DB = gormDB

		// Set the id parameter in the request
		ctx.Params = gin.Params{{Key: "id", Value: id}}

		// Execute the handler
		api.RemoveField(ctx)

		// Assert the response is 500 with the correct error message
		// assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Field metadata deleted successfully."}`, w.Body.String())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		id := "1"
		// field := models.FineTuneFieldMetadata{}

		// Simulate a database error during DELETE operation
		mock.ExpectBegin()
		mock.ExpectExec(regexp.QuoteMeta(`DELETE FROM "fine_tune_field_metadata" WHERE (id =$1)`)).
			WithArgs(id).
			WillReturnError(errors.New("database error"))
		mock.ExpectRollback()

		// Create a mock Gin context and response recorder
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Set up the mock DB in the config
		config.DB = gormDB

		// Set the id parameter in the request
		ctx.Params = gin.Params{{Key: "id", Value: id}}

		// Execute the handler
		api.RemoveField(ctx)

		// Assert the response is 500 with the correct error message
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Error while deleting field metadata."}`, w.Body.String())

		// Verify all expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestGetFieldDataHandler(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Success Test Case
	t.Run("Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup: Mock database connection and query expectations
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		userId := "123"
		fields := []models.FineTuneFieldValues{}

		rows := sqlmock.NewRows([]string{"id", "field_id", "model_config_id", "value"}).
			AddRow(1, 1, 1, "{\"value\":\"test\"}")

		// Mock the query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_values" WHERE (created_by =$1)`)).
			WithArgs(userId).
			WillReturnRows(rows)

		// Execute the function under test
		err := api.GetFieldData(gormDB, userId, fields)

		// Assert no errors occurred
		assert.NoError(t, err)

		// Verify expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})

	// Database Error Test Case
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Setup: Mock database connection and query expectations
		gormDB, mock, teardown := setupMockDB(t)
		defer teardown()

		userId := "123"
		fields := []models.FineTuneFieldValues{}

		// Simulate a database error in the query
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "fine_tune_field_values" WHERE (created_by =$1)`)).
			WithArgs(userId).
			WillReturnError(errors.New("database error"))

		// Execute the function under test
		err := api.GetFieldData(gormDB, userId, fields)

		// Assert that an error occurred and the message is correct
		assert.Error(t, err)
		assert.Equal(t, "database error", err.Error())

		// Verify expectations were met
		if err := mock.ExpectationsWereMet(); err != nil {
			t.Errorf("Unfulfilled expectations: %s", err)
		}
	})
}

func TestGetFieldsByUserId(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock database
	gormDB, _, teardown := setupMockDB(t) // No need for `mock` since we are patching
	defer teardown()

	// Replace the actual DB with the mock
	config.DB = gormDB

	// Test Case 2: No Records Found
	t.Run("No Records Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock GetFieldData to simulate no records found
		monkey.Patch(api.GetFieldData, func(DB *gorm.DB, userId string, fields []models.FineTuneFieldValues) error {
			return gorm.ErrRecordNotFound
		})
		defer monkey.UnpatchAll()

		// Create request
		req, _ := http.NewRequest("GET", "/fields/2", nil)

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Params = []gin.Param{{Key: "id", Value: "2"}}
		c.Request = req

		// Call function
		api.GetFieldsByUserId(c)

		// Validate response
		assert.Equal(t, http.StatusNotFound, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"No field metadata found for given user 2"`)
	})
}

func TestCreateFieldConfiguration(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock database
	gormDB, _, teardown := setupMockDB(t) // No need for `mock` since we are patching
	defer teardown()

	// Replace the actual DB with the mock
	config.DB = gormDB

	// Test Case 1: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock CreateFieldConfigurationInDB to return success
		monkey.Patch(api.CreateFieldConfigurationInDB, func(DB *gorm.DB, fieldValues models.TempFineTuneModelConfigurations) (string, error) {
			return "Success: ", nil
		})
		defer monkey.UnpatchAll()

		// Create a request body
		requestBody := `{"field_id": 10, "model_config_id": 20, "value": "some_value"}`
		req, _ := http.NewRequest("POST", "/fields/config", bytes.NewBufferString(requestBody))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.CreateFieldConfiguration(c)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Field configuration created successfully"`)
	})

	// Test Case 2: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create an invalid JSON request
		req, _ := http.NewRequest("POST", "/fields/config", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.CreateFieldConfiguration(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Invalid data"`)
	})

	// Test Case 3: Database Error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock CreateFieldConfigurationInDB to simulate a DB error
		monkey.Patch(api.CreateFieldConfigurationInDB, func(DB *gorm.DB, fieldValues models.TempFineTuneModelConfigurations) (string, error) {
			return "Failure: ", errors.New("DB error")
		})
		defer monkey.UnpatchAll()

		// Create a valid request body
		requestBody := `{"field_id": 10, "model_config_id": 20, "value": "some_value"}`
		req, _ := http.NewRequest("POST", "/fields/config", bytes.NewBufferString(requestBody))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.CreateFieldConfiguration(c)

		// Validate response
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Failure: DB error"`)
	})
}

func TestUpdateIndividualFieldValuesByUser(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock database
	gormDB, _, teardown := setupMockDB(t) // No need for `mock` since we are patching
	defer teardown()

	// Replace the actual DB with the mock
	config.DB = gormDB

	// Test Case 1: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock HandlerUpdateIndividualFieldValuesByUser to return success
		monkey.Patch(api.HandlerUpdateIndividualFieldValuesByUser, func(DB *gorm.DB, fieldValues models.FineTuneFieldValues) error {
			return nil
		})
		defer monkey.UnpatchAll()

		// Create a request body
		requestBody := `{"id": 1, "field_id": 10, "model_config_id": 20, "value": "new_value"}`
		req, _ := http.NewRequest("PUT", "/fields/update", bytes.NewBufferString(requestBody))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.UpdateIndividualFieldValuesByUser(c)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Field value updated successfully"`)
	})

	// Test Case 2: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create an invalid JSON request
		req, _ := http.NewRequest("PUT", "/fields/update", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.UpdateIndividualFieldValuesByUser(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Invalid data"`)
	})

	// Test Case 3: Database Error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock HandlerUpdateIndividualFieldValuesByUser to simulate a DB error
		monkey.Patch(api.HandlerUpdateIndividualFieldValuesByUser, func(DB *gorm.DB, fieldValues models.FineTuneFieldValues) error {
			return errors.New("DB error")
		})
		defer monkey.UnpatchAll()

		// Create a valid request body
		requestBody := `{"id": 1, "field_id": 10, "model_config_id": 20, "value": "new_value"}`
		req, _ := http.NewRequest("PUT", "/fields/update", bytes.NewBufferString(requestBody))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.UpdateIndividualFieldValuesByUser(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Error while updating field value DB error"`)
	})
}

func TestCreateFieldConfiguration1(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock database
	gormDB, _, teardown := setupMockDB(t) // No need for `mock` since we are patching
	defer teardown()

	// Replace the actual DB with the mock
	config.DB = gormDB

	// Test Case 1: Success Case
	t.Run("Success Case", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock CreateFieldConfigurationInDB to return success
		monkey.Patch(api.CreateFieldConfigurationInDB, func(DB *gorm.DB, fieldValues models.TempFineTuneModelConfigurations) (string, error) {
			return "", nil
		})
		defer monkey.UnpatchAll()

		// Create a request body
		requestBody := `{"id": 1, "config_name": "test_config", "params": {"param1": "value1"}}`
		req, _ := http.NewRequest("POST", "/fields/create", bytes.NewBufferString(requestBody))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.CreateFieldConfiguration(c)

		// Validate response
		assert.Equal(t, http.StatusOK, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Field configuration created successfully"`)
	})

	// Test Case 2: Invalid JSON Body
	t.Run("Invalid JSON Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Create an invalid JSON request
		req, _ := http.NewRequest("POST", "/fields/create", bytes.NewBufferString(`{"invalid_json"`))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.CreateFieldConfiguration(c)

		// Validate response
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"Invalid data"`)
	})

	// Test Case 3: Database Error
	t.Run("Database Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		// Mock CreateFieldConfigurationInDB to simulate a DB error
		monkey.Patch(api.CreateFieldConfigurationInDB, func(DB *gorm.DB, fieldValues models.TempFineTuneModelConfigurations) (string, error) {
			return "DB error: ", errors.New("unable to insert data")
		})
		defer monkey.UnpatchAll()

		// Create a valid request body
		requestBody := `{"id": 1, "config_name": "test_config", "params": {"param1": "value1"}}`
		req, _ := http.NewRequest("POST", "/fields/create", bytes.NewBufferString(requestBody))
		req.Header.Set("Content-Type", "application/json")

		// Create response recorder
		w := httptest.NewRecorder()
		c, _ := gin.CreateTestContext(w)
		c.Request = req

		// Call function
		api.CreateFieldConfiguration(c)

		// Validate response
		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.Contains(t, w.Body.String(), `"message":"DB error: unable to insert data"`)
	})
}
