package test

import (
	"regexp"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	forgetpass "git.xenonstack.com/nexa-platform/accounts/src/forgotpass"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
)

func TestForgotPass(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gdb, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	t.Run("Successful Password Reset", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts"  WHERE (email=$1)`)).
			WithArgs("verified@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"email", "verify_status", "account_status"}).
				AddRow("verified@example.com", "verified", "active"))

		monkey.Patch(mail.SendForgotPassMail, func(account database.Accounts) {})
		defer monkey.Unpatch(mail.SendForgotPassMail)

		message, success := forgetpass.ForgotPass("verified@example.com")
		assert.True(t, success)
		assert.Equal(t, "We have sent a password reset link on your mail.", message)
	})

	t.Run("Email Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (email=$1)`)).
			WithArgs("nonexistent@example.com").
			WillReturnRows(sqlmock.NewRows([]string{"email", "verify_status", "account_status"}))

		message, success := forgetpass.ForgotPass("nonexistent@example.com")
		assert.False(t, success)
		assert.Equal(t, "Email doesn't exists.", message)
	})
}

func TestResetForgottenPassword(t *testing.T) {
	SetupLogging()
	ResetLogs()
	t.Run("Invalid Password Format", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(methods.CheckPassword, func(password string) bool { return false })
		defer monkey.Unpatch(methods.CheckPassword)

		_, message, success := forgetpass.ResetForgottenPassword("token123", "weakpass")
		assert.False(t, success)
		assert.Equal(t, "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character.", message)
	})

	t.Run("Invalid or Expired Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(verifytoken.CheckToken, func(token string) (database.Tokens, error) {
			return database.Tokens{}, assert.AnError
		})
		defer monkey.Unpatch(verifytoken.CheckToken)

		_, message, success := forgetpass.ResetForgottenPassword("invalidToken", "Valid@123")
		assert.False(t, success)
		assert.Equal(t, assert.AnError.Error(), message)
	})

	t.Run("Successful Password Reset", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(verifytoken.CheckToken, func(token string) (database.Tokens, error) {
			return database.Tokens{Userid: 1, TokenTask: "forgot_pass"}, nil
		})
		monkey.Patch(forgetpass.UpdateDatabase, func(userID int, password string) (string, error) {
			return "user@example.com", nil
		})
		monkey.Patch(verifytoken.DeleteToken, func(token string) {})

		defer monkey.Unpatch(verifytoken.CheckToken)
		defer monkey.Unpatch(forgetpass.UpdateDatabase)
		defer monkey.Unpatch(verifytoken.DeleteToken)

		email, message, success := forgetpass.ResetForgottenPassword("validToken", "Valid@123")
		assert.True(t, success)
		assert.Equal(t, "user@example.com", email)
		assert.Equal(t, "Password reset successfully.", message)
	})
}

func TestUpdateDatabase(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gdb, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = gdb

	t.Run("Account Exists and Updates Password", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts"  WHERE (id= $1)`)).
			WithArgs(1).
			WillReturnRows(sqlmock.NewRows([]string{"id", "email"}).
				AddRow(1, "user@example.com"))

		mock.ExpectExec(regexp.QuoteMeta(`UPDATE "accounts" SET (password=$1)`)).
			WithArgs(sqlmock.AnyArg(), 1).
			WillReturnResult(sqlmock.NewResult(1, 1))

		email, err := forgetpass.UpdateDatabase(1, "NewSecure@123")
		assert.NoError(t, err)
		assert.Equal(t, "user@example.com", email)
	})

	t.Run("Account Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(regexp.QuoteMeta(`SELECT * FROM "accounts"  WHERE (id= $1)`)).
			WithArgs(2).
			WillReturnRows(sqlmock.NewRows([]string{"id", "email"}))

		email, err := forgetpass.UpdateDatabase(2, "NewSecure@123")
		assert.Error(t, err)
		assert.Equal(t, "", email)
		assert.Equal(t, "Account not found", err.Error())
	})
}
