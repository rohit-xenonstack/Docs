package test

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"reflect"
	"testing"

	"bou.ke/monkey"

	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/gin-gonic/gin"
	"github.com/sashabaranov/go-openai"
	"github.com/stretchr/testify/assert"
)

func TestChatResponse(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	t.Run("Success - Chat Completion Returns a Response", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"message": "Hello AI", "model": "gpt-3.5-turbo", "ingress_url": "http://test-url"}`
		ctx.Request = httptest.NewRequest("POST", "/chat", bytes.NewBufferString(reqBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		patch := monkey.PatchInstanceMethod(
			reflect.TypeOf(&openai.Client{}),
			"CreateChatCompletion",
			func(_ *openai.Client, _ context.Context, _ openai.ChatCompletionRequest) (openai.ChatCompletionResponse, error) {
				return openai.ChatCompletionResponse{
					Choices: []openai.ChatCompletionChoice{
						{Message: openai.ChatCompletionMessage{Content: "Hello, how can I help?"}},
					},
				}, nil
			})
		defer patch.Unpatch()

		api.ChatResponse(ctx)

		assert.Equal(t, http.StatusOK, w.Code)

		var response map[string]interface{}
		_ = json.NewDecoder(w.Body).Decode(&response)

		assert.NotEmpty(t, response["responses"])
		responses := response["responses"].([]interface{})
		assert.Len(t, responses, 2)
	})

	t.Run("Failure - Invalid JSON Input", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		ctx.Request = httptest.NewRequest("POST", "/chat", bytes.NewBufferString(`invalid json`))
		ctx.Request.Header.Set("Content-Type", "application/json")

		api.ChatResponse(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	t.Run("Failure - OpenAI Client Returns an Error", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"message": "Hello AI", "model": "gpt-3.5-turbo", "ingress_url": "http://test-url"}`
		ctx.Request = httptest.NewRequest("POST", "/chat", bytes.NewBufferString(reqBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		patch := monkey.PatchInstanceMethod(
			reflect.TypeOf(&openai.Client{}),
			"CreateChatCompletion",
			func(_ *openai.Client, _ context.Context, _ openai.ChatCompletionRequest) (openai.ChatCompletionResponse, error) {
				return openai.ChatCompletionResponse{}, errors.New("API error")
			})
		defer patch.Unpatch()

		api.ChatResponse(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})

	t.Run("Failure - No Choices in Response", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		reqBody := `{"message": "Hello AI", "model": "gpt-3.5-turbo", "ingress_url": "http://test-url"}`
		ctx.Request = httptest.NewRequest("POST", "/chat", bytes.NewBufferString(reqBody))
		ctx.Request.Header.Set("Content-Type", "application/json")

		patch := monkey.PatchInstanceMethod(
			reflect.TypeOf(&openai.Client{}),
			"CreateChatCompletion",
			func(_ *openai.Client, _ context.Context, _ openai.ChatCompletionRequest) (openai.ChatCompletionResponse, error) {
				return openai.ChatCompletionResponse{Choices: []openai.ChatCompletionChoice{}}, nil
			})
		defer patch.Unpatch()

		api.ChatResponse(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
	})
}
