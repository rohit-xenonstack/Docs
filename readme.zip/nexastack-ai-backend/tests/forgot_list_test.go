package test

import (
	"bytes"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/workspace"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
)

func TestForgotWorkspaceEp(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test case: Invalid JSON Body (missing email)
	t.Run("Invalid JSON Body - Missing Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/forgot-workspace", bytes.NewBufferString(`{"email":123}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		api.ForgotWorkspaceEp(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
	})

	// Test case: Invalid email (email format is not valid)
	t.Run("Invalid Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"invalid-email"}`
		req := httptest.NewRequest("POST", "/forgot-workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock methods.ValidateEmail
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return false // Invalid email
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		api.ForgotWorkspaceEp(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Please enter valid email id."}`, w.Body.String())
	})

	// Test case: Error while sending the recovery email
	t.Run("Error Sending Recovery Email", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"valid@example.com"}`
		req := httptest.NewRequest("POST", "/forgot-workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock methods.ValidateEmail
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true // Valid email
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Mock workspace.Forgot to simulate an error in sending recovery email
		monkey.Patch(workspace.Forgot, func(email string) error {
			return fmt.Errorf("Failed to send recovery email") // Simulate error
		})
		defer monkey.Unpatch(workspace.Forgot)

		api.ForgotWorkspaceEp(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Failed to send recovery email"}`, w.Body.String())
	})

	// Test case: Valid email (success case)
	t.Run("Valid Email - Success", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"email":"valid@example.com"}`
		req := httptest.NewRequest("POST", "/forgot-workspace", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock methods.ValidateEmail
		monkey.Patch(methods.ValidateEmail, func(email string) bool {
			return true // Valid email
		})
		defer monkey.Unpatch(methods.ValidateEmail)

		// Mock workspace.Forgot to simulate successful email sending
		monkey.Patch(workspace.Forgot, func(email string) error {
			return nil // Simulate success
		})
		defer monkey.Unpatch(workspace.Forgot)

		api.ForgotWorkspaceEp(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"We have emailed a special link to recover your workspaces. Please check your email."}`, w.Body.String())
	})
}

func TestGetWorkspaceList(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Ensure the Gin framework is set to testing mode
	gin.SetMode(gin.TestMode)

	// Test case: Invalid JSON Body (missing token)
	t.Run("Invalid JSON Body - Missing Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		req := httptest.NewRequest("POST", "/get-workspace-list", bytes.NewBufferString(`{}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req
		api.GetWorkspaceList(ctx)
		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Token is required."}`, w.Body.String())
	})

	// Test case: Missing Token (token field is empty)
	t.Run("Missing Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"token":""}`
		req := httptest.NewRequest("POST", "/get-workspace-list", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.GetWorkspaceList(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Token is required."}`, w.Body.String())
	})

	// Test case: Error During Workspace Recovery (invalid token)
	t.Run("Error During Workspace Recovery - Invalid Token", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"token":123}`
		req := httptest.NewRequest("POST", "/get-workspace-list", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock workspace.RecoverWorkspace to simulate an error
		monkey.Patch(workspace.RecoverWorkspace, func(token string) (int, map[string]interface{}) {
			return 404, gin.H{"error": true, "message": "Token is required."}
		})
		defer monkey.Unpatch(workspace.RecoverWorkspace)

		api.GetWorkspaceList(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		assert.JSONEq(t, `{"error":true,"message":"Token is required."}`, w.Body.String())
	})

	// Test case: Successful Workspace Recovery (valid token)
	t.Run("Successful Workspace Recovery", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)
		requestData := `{"token":"validToken"}`
		req := httptest.NewRequest("POST", "/get-workspace-list", bytes.NewBufferString(requestData))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		// Mock workspace.RecoverWorkspace to simulate success
		monkey.Patch(workspace.RecoverWorkspace, func(token string) (int, map[string]interface{}) {
			return http.StatusOK, gin.H{"error": false, "message": "Workspace recovered successfully.", "workspaces": []string{"Workspace1", "Workspace2"}}
		})
		defer monkey.Unpatch(workspace.RecoverWorkspace)

		api.GetWorkspaceList(ctx)

		assert.Equal(t, http.StatusOK, w.Code)
		assert.JSONEq(t, `{"error":false,"message":"Workspace recovered successfully.","workspaces":["Workspace1","Workspace2"]}`, w.Body.String())
	})
}
