package test

import (
	"bytes"
	"encoding/json"
	"regexp"

	"fmt"
	"net/http"
	"net/http/httptest"

	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"

	// "git.xenonstack.com/nexa-platform/accounts/src/kubernetes"

	// "git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	// "github.com/stretchr/testify/require"

	"github.com/DATA-DOG/go-sqlmock"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"

	// "github.com/jinzhu/gorm/dialects/postgres"
	"github.com/stretchr/testify/assert"
	jwt "gopkg.in/dgrijalva/jwt-go.v3"
)

func TestGetNodes(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	db, mock, cleanup := setupMockDB(t)
	defer cleanup()
	config.DB = db

	t.Run("Missing JWT Claims", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		req := httptest.NewRequest("POST", "/getnodes", nil)
		ctx.Request = req

		api.GetNodes(ctx)

		assert.Equal(t, http.StatusInternalServerError, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "Please login again", response["message"])
	})

	t.Run("Invalid Request Body", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		claims := jwt.MapClaims{"email": "user@example.com", "workspace": "workspace-123"}
		ctx.Set("JWT_PAYLOAD", claims)

		req := httptest.NewRequest("POST", "/getnodes", bytes.NewBufferString(`{}`))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.GetNodes(ctx)

		assert.Equal(t, http.StatusBadRequest, w.Code)
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)
		assert.Equal(t, "cluster name is required", response["message"])
	})

	t.Run("Successful Node Retrieval", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		w := httptest.NewRecorder()
		ctx, _ := gin.CreateTestContext(w)

		// Updated JWT claims
		claims := jwt.MapClaims{"email": "amarjit@xenonstack.com", "workspace": "aiops", "namespace": "nexa-prod-aiops", "cluster_name": "test-cluster"}
		ctx.Set("JWT_PAYLOAD", claims)

		// Mock database query for instances
		mock.ExpectQuery(regexp.QuoteMeta(
			`SELECT * FROM "instances" WHERE (workspace_id = $1 AND node_name = $2 AND cluster_name = $3) ORDER BY "instances"."id" ASC LIMIT 1`)).
			WithArgs("nexa-prod-aiops", "node-1", "test-cluster").
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "node_name", "cluster_name"}).
				AddRow(1, "nexa-prod-aiops", "node-1", "test-cluster"))

		// Mock Kubernetes node retrieval function
		monkey.Patch(kubernetes.GetNodes, func(namespace, clusterName, workspace, email string) ([]map[string]interface{}, error) {
			fmt.Println("Mocked GetNodes function called!") // Debugging print
			return []map[string]interface{}{
				{
					"Name": "aks-agentpool-35707114-vmss000003",
					"CPU": map[string]interface{}{
						"Capacity":        "2",
						"Allocatable":     "1900m",
						"architecture":    "arm64",
						"operatingSystem": "linux",
					},
				},
			}, nil
		})
		defer monkey.Unpatch(kubernetes.GetNodes)

		// Corrected request body structure
		reqBody := `{"name": "test-cluster", "namespace": "nexa-prod-aiops"}`
		req := httptest.NewRequest("POST", "/nodes?name=test-cluster", bytes.NewBufferString(reqBody))
		req.Header.Set("Content-Type", "application/json")
		ctx.Request = req

		api.GetNodes(ctx)

		// Verify response status code
		assert.Equal(t, http.StatusOK, w.Code)

		// Decode response safely
		var response map[string]interface{}
		err := json.NewDecoder(w.Body).Decode(&response)
		assert.NoError(t, err)

		// Validate response fields
		assert.False(t, response["error"].(bool))
		assert.Equal(t, "amarjit@xenonstack.com", response["email"])
		assert.Equal(t, "nexa-prod-aiops", response["namespace"])
		// Print the complete response
		responseJson, err := json.MarshalIndent(response, "", "  ")
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println("======response====")
			fmt.Println(string(responseJson))
		}
		// // Verify nodes exist in response
		nodes, ok := response["nodes"].([]interface{})
		assert.True(t, ok)
		assert.Len(t, nodes, 1)

		node, _ := nodes[0].(map[string]interface{})
		assert.Equal(t, "aks-agentpool-35707114-vmss000003", node["Name"])

	})

}

func TestCheckEmailBelongsToWorkspace(t *testing.T) {
	SetupLogging()
	ResetLogs()
	// Create a mock database

	db, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("error creating sqlmock: %v", err)
	}
	defer db.Close()
	assert.NoError(t, err)
	defer db.Close()

	gormDB, err := gorm.Open("postgres", db)
	assert.NoError(t, err)
	config.DB = gormDB

	// Assign the mock DB to the global config
	config.DB = gormDB

	tests := []struct {
		name          string
		workspaceID   string
		email         string
		mockQuery     func()
		expectedError error
	}{
		{
			name:        "Email belongs to workspace",
			workspaceID: "test-workspace",
			email:       "test@example.com",
			mockQuery: func() {
				mock.ExpectQuery(`(?i)SELECT \* FROM "workspace_members" WHERE \(workspace_id = \$1 AND member_email = \$2\) ORDER BY "workspace_members"."id" ASC LIMIT 1`).
					WithArgs("test-workspace", "test@example.com").
					WillReturnRows(sqlmock.NewRows([]string{"workspace_id", "member_email"}).
						AddRow("test-workspace", "test@example.com"))
			},
			expectedError: nil,
		},
		{
			name:        "Email does not belong to workspace",
			workspaceID: "test-workspace",
			email:       "other@example.com",
			mockQuery: func() {
				mock.ExpectQuery(`(?i)SELECT \* FROM "workspace_members" WHERE \(workspace_id = \$1 AND member_email = \$2\) ORDER BY "workspace_members"."id" ASC LIMIT 1`).
					WithArgs("test-workspace", "other@example.com").
					WillReturnError(gorm.ErrRecordNotFound)
			},
			expectedError: fmt.Errorf("Email does not belong to the same workspace"),
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			test.mockQuery() // Set up the mock behavior

			err := api.CheckEmailBelongsToWorkspace(test.workspaceID, test.email)
			assert.Equal(t, test.expectedError, err)

			// Ensure all expectations were met
			if err := mock.ExpectationsWereMet(); err != nil {
				t.Errorf("there were unfulfilled expectations: %s", err)
			}
		})
	}
}

func TestGetNameSpace(t *testing.T) {
	SetupLogging()
	ResetLogs()
	tests := []struct {
		name         string
		workspaceID  string
		expectedName string
	}{
		{
			name:         "Default branch",
			workspaceID:  "test-workspace",
			expectedName: "nexa-prod-test-workspace",
		},
		{
			name:         "Custom branch",
			workspaceID:  "test-workspace",
			expectedName: "nexa-dev-test-workspace",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			// Set the branch for the second test case
			if test.expectedName == "nexa-dev-test-workspace" {
				config.Conf.Service.Branch = "dev"
			}

			name := api.GetNameSpace(test.workspaceID)
			assert.Equal(t, test.expectedName, name)
		})
	}
}

func TestGetWorkspaceID(t *testing.T) {
	SetupLogging()
	ResetLogs()
	tests := []struct {
		name       string
		wsid       string
		expectedID string
	}{
		{
			name:       "Valid workspace URL",
			wsid:       "test-workspace.example.com",
			expectedID: "test-workspace",
		},
		{
			name:       "Invalid workspace URL",
			wsid:       "invalid",
			expectedID: "invalid",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			id := api.GetWorkspaceID(test.wsid)
			assert.Equal(t, test.expectedID, id)
		})
	}
}
