package test

import (
	"errors"
	"regexp"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
)

func TestGetAccountForid(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	accountID := 1
	expectedQuery := regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (id= $1)`)

	t.Run("Account Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "name", "email"}).
			AddRow(accountID, "Test User", "test@example.com")

		mock.ExpectQuery(expectedQuery).
			WithArgs(accountID).
			WillReturnRows(rows)

		result := accounts.GetAccountForid(accountID)
		assert.Equal(t, accountID, result.ID)
		assert.Equal(t, "Test User", result.Name)
		assert.Equal(t, "test@example.com", result.Email)
	})

	t.Run("Account Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(expectedQuery).
			WithArgs(accountID).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "email"}))

		result := accounts.GetAccountForid(accountID)
		assert.Equal(t, database.Accounts{}, result)
	})

	assert.NoError(t, mock.ExpectationsWereMet())
}

func TestGetAccountForEmail(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	email := "test@example.com"
	expectedQuery := regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (email=$1)`)

	t.Run("Account Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "name", "email"}).
			AddRow(1, "Test User", email)

		mock.ExpectQuery(expectedQuery).
			WithArgs(email).
			WillReturnRows(rows)

		result, err := accounts.GetAccountForEmail(email)
		assert.NoError(t, err)
		assert.Equal(t, 1, result.ID)
		assert.Equal(t, "Test User", result.Name)
		assert.Equal(t, email, result.Email)
	})

	t.Run("Account Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(expectedQuery).
			WithArgs(email).
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "email"}))

		result, err := accounts.GetAccountForEmail(email)
		assert.Error(t, err)
		assert.Equal(t, errors.New("no account found"), err)
		assert.Equal(t, database.Accounts{}, result)
	})

	assert.NoError(t, mock.ExpectationsWereMet())
}

func TestGetAllAccounts(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	expectedQuery := regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (role_id=$1 AND verify_status=$2)`)

	t.Run("Accounts Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "name", "email", "role_id", "verify_status"}).
			AddRow(1, "User One", "user1@example.com", "user", "verified").
			AddRow(2, "User Two", "user2@example.com", "user", "verified")

		mock.ExpectQuery(expectedQuery).
			WithArgs("user", "verified").
			WillReturnRows(rows)

		accounts, err := accounts.GetAllAccounts()
		assert.NoError(t, err)
		assert.Len(t, accounts, 2)
		assert.Equal(t, "User One", accounts[0].Name)
		assert.Equal(t, "user1@example.com", accounts[0].Email)
		assert.Equal(t, "User Two", accounts[1].Name)
		assert.Equal(t, "user2@example.com", accounts[1].Email)
	})

	t.Run("No Accounts Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(expectedQuery).
			WithArgs("user", "verified").
			WillReturnRows(sqlmock.NewRows([]string{"id", "name", "email", "role_id", "verify_status"}))

		accounts, err := accounts.GetAllAccounts()
		assert.NoError(t, err)
		assert.Empty(t, accounts)
	})

	assert.NoError(t, mock.ExpectationsWereMet())
}

func TestDeleteAccount(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	email := "test@example.com"
	// accountID := 1
	// expectedSessionQuery := regexp.QuoteMeta(`SELECT * FROM "active_sessions" WHERE (id=$1)`)
	// expectedDeleteAccountQuery := regexp.QuoteMeta(`DELETE FROM "accounts" WHERE (id=$1)`)
	// expectedDeleteTokensQuery := regexp.QuoteMeta(`DELETE FROM "tokens" WHERE (id=$1)`)
	// expectedDeleteActivitiesQuery := regexp.QuoteMeta(`DELETE FROM "activities" WHERE (email=$1)`)
	// expectedDeleteSessionsQuery := regexp.QuoteMeta(`DELETE FROM "active_sessions" WHERE (id=$1)`)

	t.Run("Admin Account Cannot Be Deleted", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(accounts.GetAccountForEmail, func(email string) (database.Accounts, error) {
			return database.Accounts{RoleID: "admin"}, nil
		})

		err := accounts.DeleteAccount(email)
		assert.Error(t, err)
		assert.Equal(t, "you cannot delete admin account", err.Error())
	})

	t.Run("Account Not Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(accounts.GetAccountForEmail, func(email string) (database.Accounts, error) {
			return database.Accounts{}, errors.New("no account found")
		})

		err := accounts.DeleteAccount(email)
		assert.Error(t, err)
		assert.Equal(t, "no account found", err.Error())
	})

	assert.NoError(t, mock.ExpectationsWereMet())
}

func TestChangePassword(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	id := "123"
	oldPassword := "OldPass@123"
	newPassword := "NewPass@456"
	expectedQuery := regexp.QuoteMeta(`SELECT * FROM "accounts" WHERE (id=$1)`)

	t.Run("Password Changed Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "password"}).AddRow(id, "hashed_new_password")
		mock.ExpectQuery(expectedQuery).WithArgs(id).WillReturnRows(rows)

		monkey.Patch(methods.CheckHashForPassword, func(passwordHash string, password string) bool { return true })
		monkey.Patch(methods.CheckPassword, func(pass string) bool { return true })
		monkey.Patch(methods.HashForNewPassword, func(pass string) string { return "hashed_new_password" })

		expectedUpdateQuery := regexp.QuoteMeta("update accounts set password= '" + "hashed_new_password" + "' where id= '" + id + "';")

		mock.ExpectExec(expectedUpdateQuery).WillReturnResult(sqlmock.NewResult(1, 1))

		status, success, msg := accounts.ChangePassword(id, oldPassword, newPassword)
		assert.Equal(t, 200, status)
		assert.True(t, success)
		assert.Equal(t, "Password updated successfully.", msg)
	})

	t.Run("Incorrect Old Password", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "password"}).AddRow(id, "hashed_new_password")
		mock.ExpectQuery(expectedQuery).WithArgs(id).WillReturnRows(rows)

		monkey.Patch(methods.CheckHashForPassword, func(hashed, plain string) bool { return false })

		status, success, msg := accounts.ChangePassword(id, oldPassword, newPassword)
		assert.Equal(t, 400, status)
		assert.False(t, success)
		assert.Equal(t, "please pass valid current password", msg)
	})
}

func TestAccountUpdateProfile(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	email := "test@example.com"
	name := "New Name"
	contact := "1234567890"

	expectedUpdateContactQuery := regexp.QuoteMeta(`UPDATE "accounts" SET "contact_no" = $1, "updated_at" = $2 WHERE (email=$3)`)
	expectedUpdateNameQuery := regexp.QuoteMeta(`UPDATE "accounts" SET "name" = $1, "updated_at" = $2 WHERE (email=$3)`)

	t.Run("Profile Updated Successfully - Name", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectBegin()
		mock.ExpectExec(expectedUpdateNameQuery).
			WithArgs(name, sqlmock.AnyArg(), email).
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()
		err := accounts.UpdateProfile(email, name, "")
		assert.NoError(t, err)
	})

	t.Run("Profile Updated Successfully - Contact", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectBegin()
		mock.ExpectExec(expectedUpdateContactQuery).
			WithArgs(contact, sqlmock.AnyArg(), email).
			WillReturnResult(sqlmock.NewResult(1, 1))
		mock.ExpectCommit()
		err := accounts.UpdateProfile(email, "", contact)
		assert.NoError(t, err)
	})

	t.Run("No Account Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectExec(expectedUpdateNameQuery).
			WithArgs(name, sqlmock.AnyArg(), email).
			WillReturnResult(sqlmock.NewResult(0, 0))

		err := accounts.UpdateProfile(email, name, "")
		assert.Error(t, err)
		assert.Equal(t, "no account found", err.Error())
	})
}

func TestUserWorkspace(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	email := "user@example.com"
	expectedQuery := regexp.QuoteMeta(`SELECT * FROM "workspace_members" WHERE (member_email=$1)`)

	t.Run("Workspace Members Retrieved Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "workspace_id", "member_email", "workspace_role", "created"}).
			AddRow(1, "ws-123", email, "admin", 162354)
		mock.ExpectQuery(expectedQuery).
			WithArgs(email).
			WillReturnRows(rows)

		members := accounts.UserWorkspace(email)
		assert.Len(t, members, 1)
		assert.Equal(t, "ws-123", members[0].WorkspaceID)
	})

	t.Run("No Workspace Members Found", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		mock.ExpectQuery(expectedQuery).
			WithArgs(email).
			WillReturnRows(sqlmock.NewRows([]string{"id", "workspace_id", "member_email", "workspace_role", "created"}))

		members := accounts.UserWorkspace(email)
		assert.Empty(t, members)
	})
}
