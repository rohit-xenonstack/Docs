package test

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"net/http/httptest"
	"testing"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"github.com/gin-gonic/gin"
	va "github.com/hashicorp/vault/api"
	"github.com/stretchr/testify/assert"
)

// MockVaultClient represents a mock implementation of Vault client.
type MockVaultClient struct {
	LogicalData map[string]*va.Secret
}

// Mock Logical().List
func (m *MockVaultClient) List(path string) (*va.Secret, error) {
	if secret, ok := m.LogicalData[path]; ok {
		return secret, nil
	}
	return nil, fmt.Errorf("failed to list: %s", path)
}

// Mock GetClusterInfo
func (m *MockVaultClient) GetClusterInfo(customerID, clusterName string) (interface{}, error) {
	if customerID == "valid-customer" && clusterName == "valid-cluster" {
		return map[string]interface{}{"info": "dummy-data"}, nil
	}
	return nil, fmt.Errorf("cluster info not found")
}

func mockOnboardGKECluster(clusterName string, credentials []byte) error {
	if clusterName == "fail-cluster" {
		return errors.New("Failed to onboard GKE cluster")
	}
	return nil
}

func TestOnboardGKE(t *testing.T) {
	SetupLogging()
	ResetLogs()
	gin.SetMode(gin.TestMode)

	// Patch the OnboardGKECluster function
	monkey.Patch(api.OnboardGKECluster, mockOnboardGKECluster)
	defer monkey.Unpatch(api.OnboardGKECluster)

	// Test cases
	tests := []struct {
		name          string
		clusterName   string
		fileContent   string
		expectedCode  int
		expectedError bool
		expectedMsg   string
	}{
		{
			name:         "✅ Successful onboarding",
			clusterName:  "test-cluster",
			fileContent:  `{"project_id": "test-project"}`, // Mock JSON credentials
			expectedCode: http.StatusOK,
			expectedMsg:  "Cluster onboarded successfully",
		},
		{
			name:          "❌ Missing cluster_name",
			clusterName:   "",
			fileContent:   `{"project_id": "test-project"}`,
			expectedCode:  http.StatusBadRequest,
			expectedError: true,
			expectedMsg:   "cluster_name is required",
		},
		{
			name:          "❌ Missing credentials_file",
			clusterName:   "test-cluster",
			fileContent:   "",
			expectedCode:  http.StatusBadRequest,
			expectedError: true,
			expectedMsg:   "credentials_file is required",
		},
		{
			name:          "❌ Onboarding failure",
			clusterName:   "fail-cluster",
			fileContent:   `{"project_id": "test-project"}`,
			expectedCode:  http.StatusInternalServerError,
			expectedError: true,
			expectedMsg:   "Failed to onboard GKE cluster",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			SetupLogging()
			ResetLogs()
			// Create a buffer to hold the form data
			body := &bytes.Buffer{}
			writer := multipart.NewWriter(body)

			// Add cluster_name to form data
			_ = writer.WriteField("cluster_name", tc.clusterName)

			// Add credentials_file if applicable
			if tc.fileContent != "" {
				part, _ := writer.CreateFormFile("credentials_file", "gke_credentials.json")
				_, _ = io.Copy(part, bytes.NewBufferString(tc.fileContent))
			}

			writer.Close()

			// Create test request
			req := httptest.NewRequest("POST", "/onboard/gke", body)
			req.Header.Set("Content-Type", writer.FormDataContentType())

			// Setup response recorder
			w := httptest.NewRecorder()
			c, _ := gin.CreateTestContext(w)
			c.Request = req

			// Call the function under test
			api.OnboardGKE(c)

			// Validate response
			assert.Equal(t, tc.expectedCode, w.Code)

			var response map[string]interface{}
			_ = json.Unmarshal(w.Body.Bytes(), &response)

			if tc.expectedError {
				assert.True(t, response["error"].(bool))
			} else {
				assert.False(t, response["error"].(bool))
			}
			assert.Equal(t, tc.expectedMsg, response["message"])
		})
	}
}
