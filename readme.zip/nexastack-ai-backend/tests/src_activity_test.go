package test

import (
	"encoding/json"
	"regexp"
	"testing"
	"time"

	"bou.ke/monkey"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/stretchr/testify/assert"
)

func TestGetLoginActivities(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	email := "user@example.com"
	expectedQuery := regexp.QuoteMeta(`SELECT * FROM "activities" WHERE (email=$1) ORDER BY timestamp desc`)

	t.Run("Login Activities Retrieved Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		rows := sqlmock.NewRows([]string{"id", "email", "name", "activity_name", "status", "reason", "client_ip", "client_agent", "timestamp"}).
			AddRow(1, email, "Test User", "login", "success", "valid credentials", "192.168.1.1", "Mozilla/5.0", time.Now().Unix())
		mock.ExpectQuery(expectedQuery).
			WithArgs(email).
			WillReturnRows(rows)

		activities, err := activities.GetLoginActivities(email)
		assert.NoError(t, err)
		assert.Len(t, activities, 1)
	})
}

func TestGetActivity(t *testing.T) {
	SetupLogging()
	ResetLogs()
	db, _, cleanup := setupMockDB(t)
	defer cleanup()

	config.DB = db

	mockedActivities := []database.Activities{
		{Email: "user@example.com", ActivityName: "login", Status: "success", Timestamp: time.Now().Unix()},
	}

	byteData, _ := json.Marshal("user@example.com")

	t.Run("Get Activity Successfully", func(t *testing.T) {
		SetupLogging()
		ResetLogs()
		monkey.Patch(activities.GetLoginActivities, func(email string) ([]database.Activities, error) {
			return mockedActivities, nil
		})
		defer monkey.Unpatch(activities.GetLoginActivities)

		result, err := activities.GetAvtivity(byteData)
		assert.NoError(t, err)
		assert.NotNil(t, result)
	})
}
