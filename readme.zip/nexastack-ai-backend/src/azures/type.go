package azures

import (
	// "mime/multipart"

	"git.xenonstack.com/nexa-platform/accounts/database"
)

// Config is a structure contains kube config and meta information
// type KubeConfig struct {
// 	File *multipart.FileHeader `form:"file" binding:"required"`
// 	database.InfraIntegration
// }

type KubeConfig struct {
	File string `json:"content"`
	database.InfraIntegration
}


