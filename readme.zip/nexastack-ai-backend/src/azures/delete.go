package azures

import (
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"
)

func DeleteInfraIntegration(id, workspace, name, email, ip string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})

	// Database connection
	db := config.DB
	var infra []database.InfraIntegration

	// Validate input
	if id == "" || workspace == "" {
		mapd["error"] = true
		mapd["message"] = "No integration found in workspace"
		return mapd, 400
	}

	// Fetch integration
	query := "id=" + id + " and workspace='" + workspace + "'"
	db.Debug().Where(query).Find(&infra)
	if len(infra) == 0 {
		mapd["error"] = true
		mapd["message"] = "No integration found"
		return mapd, 400
	}

	// Check if any resources are using the node
	var resources []database.Deployment
	db.Debug().Where("cluster_name = ? AND workspace_id = ?", infra[0].ClusterName, workspace).Find(&resources)
	if len(resources) > 0 {
		mapd["error"] = true
		mapd["message"] = "Cannot delete Infrastructure, it is being used by the following resources:"
		mapd["resources"] = resources
		return mapd, 400
	}

	// Delete based on framework
	framework := strings.ToLower(infra[0].Framework)
	if framework != "" {
		var vaultErr error
		switch framework {
		case "terraform":
			infra[0].Terraform = false
			vaultErr = vault.DeleteSecret(infra[0].Workspace, infra[0].ClusterName, "terraform")
		case "helm":
			infra[0].Helm = false
			vaultErr = vault.DeleteSecret(infra[0].Workspace, infra[0].ClusterName, "helm")
		case "ansible":
			infra[0].Ansible = false
			vaultErr = vault.DeleteSecret(infra[0].Workspace, infra[0].ClusterName, "ansible")
		default:
			mapd["error"] = true
			mapd["message"] = "Unsupported framework type"
			return mapd, 400
		}

		// Handle vault delete errors
		if vaultErr != nil {
			mapd["error"] = true
			mapd["message"] = "Unable to delete " + framework + ". Please try again."
			return mapd, 500
		}

		// Delete from DB
		db.Where(query).Delete(&infra[0])

		// Log activity
		SaveAvtivity(infra[0].ID, infra[0].ClusterName, infra[0].Workspace, name, email, "delete infrastucture", "pass", "", ip)

		mapd["error"] = false
		mapd["message"] = infra[0].ClusterName + " Deleted Successfully"
		return mapd, 200
	}

	// Default fallback
	mapd["error"] = false
	mapd["message"] = "Deleted Successfully"
	return mapd, 200
}
