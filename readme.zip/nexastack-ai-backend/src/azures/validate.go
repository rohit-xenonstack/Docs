package azures

import (
	"context"
	"encoding/json"
	"errors"

	"fmt"
	"reflect"

	"os"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"
	"github.com/ghodss/yaml"
	authorizationapi "k8s.io/api/authorization/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

func ValidateFile(data []byte, name string) error {
	// use the current context in kubeconfig
	//path of file
	// Create directory if not exists
	if err := os.MkdirAll("data/.azure", 0777); err != nil {
		config.Log.Error(err)
		return err
	}
	path := "/app/data/.azure/config"
	f, err := os.Create(path)
	if err != nil {
		config.Log.Error(err)
		return err
	}
	defer f.Close() // close the file to prevent leaks
	// defer os.Remove(path) // remove the file after use

	_, err = f.Write(data)
	if err != nil {
		config.Log.Error(err)
		return err
	}

	var configRest *rest.Config

	configRest, err = clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		config.Log.Error(err)
		return err
	}

	var clientset *kubernetes.Clientset

	clientset, err = kubernetes.NewForConfig(configRest)
	if err != nil {
		config.Log.Error(err)
		return err
	}

	var resource authorizationapi.ResourceAttributes
	resource.Resource = "*"
	resource.Verb = "*"
	resource.Group = "*"
	resource.Version = "*"
	resource.Namespace = "all"
	var spec authorizationapi.SelfSubjectAccessReviewSpec
	spec.ResourceAttributes = &resource

	meta := metav1.TypeMeta{}
	meta.Kind = "SelfSubjectRulesReview"
	meta.APIVersion = "v1"

	authorizationV1Client := clientset.AuthorizationV1()

	review := &authorizationapi.SelfSubjectAccessReview{
		TypeMeta: meta,
		Spec:     spec,
	}

	result, err := authorizationV1Client.SelfSubjectAccessReviews().Create(context.TODO(), review, metav1.CreateOptions{})
	if err != nil {
		errStr := err.Error()
		if strings.Contains(errStr, "host") {
			return errors.New("no such host. Please enter correct kube API server address")
		}
		if strings.Contains(errStr, "connection refused") {
			return errors.New("connection to the kube API server is refused")
		}
		if strings.Contains(errStr, "timeout") {
			return errors.New("connection timeout to the kube API server")
		}
		return err
	}
	config.Log.Info(fmt.Sprintf("%v", result.Status.DeepCopy()))

	opts := metav1.ListOptions{}
	namespaceList, err := clientset.CoreV1().Namespaces().List(context.TODO(), opts)
	if err != nil {
		errStr := err.Error()
		if strings.Contains(errStr, "host") {
			return errors.New("no such host. Please enter correct kube API server address")
		}
		if strings.Contains(errStr, "connection refused") {
			return errors.New("connection timeout to the kube API server")
		}
		if strings.Contains(errStr, "timeout") {
			return errors.New("connection timeout to the kube API server")
		}
		if strings.Contains(errStr, `cannot list resource "namespaces" in API group "" at the cluster scope`) {
			config.Log.Info("User does not have permission to list namespaces, but access review succeeded.")
			return nil
		}
		return err
	}

	// Print namespaces
	config.Log.Info("Namespaces in the cluster:")
	for _, ns := range namespaceList.Items {
		config.Log.Info(" -", ns.Name)
	}

	return nil
}

func CheckConfigAlreadyPresent(data []byte, workspace string) error {
	// Fetch all the clusters present in the workspace
	clusters, err := fetchClustersFromWorkspace(workspace)
	if err != nil {
		return err
	}

	// For each cluster, fetch the config files
	for _, cluster := range clusters {
		configFile, err := fetchConfigFilesFromCluster(cluster, workspace)
		if err != nil {
			return err
		}

		// Convert the new config file into a map interface
		var newData map[string]interface{}
		ydata, err := yaml.YAMLToJSON(data)
		if err == nil {
			json.Unmarshal(ydata, &newData)
		} else {
			err = json.Unmarshal(data, &newData)
			if err != nil {
				return err
			}
		}

		// Convert the existing config file into a map interface
		var existingData map[string]interface{}
		ydata, err = yaml.YAMLToJSON(configFile)
		if err == nil {
			json.Unmarshal(ydata, &existingData)
		} else {
			err = json.Unmarshal(configFile, &existingData)
			if err != nil {
				return err
			}
		}

		// Compare the config files
		if reflect.DeepEqual(newData, existingData) {
			return errors.New("config file already present")
		}

	}

	return nil
}
func fetchClustersFromWorkspace(workspace string) ([]string, error) {
	// Connect to database
	db := config.DB

	// Fetch all clusters from the database
	var clusters []database.InfraIntegration
	err := db.Debug().Model(&database.InfraIntegration{}).Where("workspace = ?", workspace).Find(&clusters).Error
	if err != nil {
		return nil, err
	}

	var clusterNames []string

	for _, name := range clusters {
		clusterNames = append(clusterNames, name.ClusterName)
	}
	return clusterNames, nil
}

func fetchConfigFilesFromCluster(cluster, workspace string) ([]byte, error) {
	mapd := make(map[string]interface{})
	mapd["error"] = false
	// Connect to database
	db := config.DB
	var clusters database.InfraIntegration
	err := db.Debug().Model(&database.InfraIntegration{}).Where("workspace = ? AND cluster_name = ?", workspace, cluster).Find(&clusters).Error
	if err != nil {
		return nil, err
	}

	value, err := vault.ViewSecret(workspace, cluster, clusters.Framework)
	if err != nil {
		return nil, err
	}

	byteData, err := json.Marshal(&value)
	if err != nil {
		return nil, err
	}

	println("===filebyte==", byteData)

	return byteData, nil
}
