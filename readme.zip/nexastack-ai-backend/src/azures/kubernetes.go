package azures

import (
	"strings"

	// authorizationapi "k8s.io/api/authorization/v1"
	contex "context"

	"git.xenonstack.com/nexa-platform/accounts/config"
	v1 "k8s.io/api/core/v1"

	// "k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

// CreateNamespace function used for Create new namespace

func CreateNamespace(name string, path string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	logConfig := config.Log

	var config *rest.Config
	config, err := clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 401
	}
	var clientset *kubernetes.Clientset
	clientset, err = kubernetes.NewForConfig(config)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 401
	}
	// Set name in ObjectMeta
	opts := metav1.ObjectMeta{
		Name: name,
	}
	// Set namespace in Namespace
	namespace := v1.Namespace{
		ObjectMeta: opts,
	}
	// Create a context
	ctx := contex.Background()
	// Set CreateOptions (can be empty if not needed)
	createOptions := metav1.CreateOptions{}

	// Send request
	_, err = clientset.CoreV1().Namespaces().Create(ctx, &namespace, createOptions)
	if err != nil {
		if !strings.Contains(err.Error(), "already") {
			logConfig.Error("namespace.....", err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			return mapd, 500
		}
	}
	return mapd, 200
}

func CreateClinetSet(path string) (*kubernetes.Clientset, error) {
	var config *rest.Config
	config, err := clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		return nil, err
	}
	var clientset *kubernetes.Clientset
	clientset, err = kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	return clientset, nil
}
