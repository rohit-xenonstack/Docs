package azures

import (
	"encoding/base64"
	"encoding/json"
	"errors"

	"log"
	"os"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"
	"github.com/ghodss/yaml"
	"github.com/kr/pretty"
)

// ValidateKubeFileandSave is a method for validate kube config and add that config in database
func (kc *KubeConfig) ValidateKubeFileandSave(data []byte, ip, workspace string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	//replace space with -
	kc.ClusterName = strings.ReplaceAll(kc.ClusterName, " ", "-")
	// Check if the cluster name already exists in the database
	db := config.DB
	var existingCluster database.InfraIntegration
	err := db.Debug().Where("cluster_name = ? AND workspace = ?", kc.ClusterName, workspace).Find(&existingCluster).Error
	if err == nil {
		mapd["error"] = true
		mapd["message"] = "Cluster name already present"
		return mapd, 400
	}
	// Check if the kube config is already present in the workspace
	if err := CheckConfigAlreadyPresent(data, workspace); err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	// Check if the cloud type matches the type of kube file
	kubeConfigType := GetKubeConfigType(data)
	if kubeConfigType != kc.CloudType {
		mapd["error"] = true
		mapd["message"] = "Cloud type does not match the type of kube file. Type of entered file: " + kubeConfigType
		return mapd, 400
	}

	// validate kube config file
	err = ValidateFile(data, kc.ClusterName)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	println("===cluster name===", kc.ClusterName)
	// add data in database
	integ := database.InfraIntegration{}
	integ.ClusterName = kc.ClusterName
	integ.IngressClass = kc.IngressClass
	integ.Ingress = kc.Ingress
	integ.CloudType = kc.CloudType
	integ.Framework = kc.Framework
	integ.Workspace = kc.Workspace
	integ.UserEmail = kc.UserEmail
	integ.UserName = kc.UserName
	integ.ProjectId = kc.ProjectId
	integ.Environment = kc.Environment
	integ.CreatedAt = time.Now()
	integ.Terraform = true

	//save in database
	err = SaveKube(&integ)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	// write in vault
	value := make(map[string]interface{})
	ydata, err := yaml.YAMLToJSON(data)
	if err == nil {
		json.Unmarshal(ydata, &value)

	} else {
		err = json.Unmarshal(data, &value)
		if err != nil {
			integ.Terraform = false
			RemoveInfrastucture(&integ)
			config.Log.Error(err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			return mapd, 500
		} else {
			// Print the value for confirmation
			log.Printf("Parsed value: %+v\n", value)
		}
	}
	// Print the value for confirmation
	log.Printf("Parsed value: %+v\n", value)
	err = vault.AddSecret(kc.Workspace, kc.ClusterName, kc.Framework, value)
	if err != nil {
		integ.Terraform = false
		RemoveInfrastucture(&integ)
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	if err := os.MkdirAll("data/.azure", 0777); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	path := "data/.azure/config"
	f, err := os.Create(path)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer f.Close()       // close the file to prevent leaks
	defer os.Remove(path) // remove the file after use

	_, err = f.Write(data)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	nameSpace := "nexa-" + branch + "-" + strings.Replace(kc.Workspace, "_", "-", -1)
	result, code := CreateNamespace(nameSpace, path)
	if code != 200 {
		config.Log.Error(result, code)
		mapd["workspace created :- "] = "Error to create workspace"
		mapd["result"] = result
		mapd["error"] = true
		return mapd, code
	}

	SaveAvtivity(integ.ID, integ.ClusterName, integ.Workspace, integ.UserName, integ.UserEmail, "add infrastucture", "pass", "", ip)

	mapd["error"] = false
	mapd["message"] = "Kube Config Added Successfully"
	return mapd, 200
}

func GetPrivateKey(workspace, clsuterName, nodeName, userName string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	value, err := vault.ViewSecretKey(workspace, clsuterName, nodeName, userName)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 404
	}

	privateKey := value["private_key"].(string)

	// Decode the private key using Base64
	decodedPrivateKey, err := base64.StdEncoding.DecodeString(privateKey)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	// Create a temporary file in the key folder
	if err := os.MkdirAll("data/key", 0600); err != nil {
		config.Log.Error(err)
		return nil, 500
	}
	path := "data/key/" + nodeName
	tmpFile, err := os.Create(path)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	// Make the file protected
	if err := os.Chmod(path, 0600); err != nil {
		config.Log.Error(err)
		return nil, 500
	}
	defer tmpFile.Close()

	// Write the private key to the temporary file
	_, err = tmpFile.Write(decodedPrivateKey)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	mapd["error"] = false
	mapd["message"] = "Private key fetched successfully."
	mapd["private_key_path"] = "data/key/" + nodeName
	return mapd, 200
}

// SaveKube function used to save kube config in infrastucture database
func SaveKube(integ *database.InfraIntegration) error {

	pretty.Println(integ)

	//connect to db
	db := config.DB
	inte := []database.InfraIntegration{}
	query := "cluster_name=? and cloud_type=? and workspace=?"
	db.Debug().Where(query, integ.ClusterName, integ.CloudType, integ.Workspace).Find(&inte)
	//check if exist
	if len(inte) == 0 {
		err := db.Debug().Create(&integ).Error
		if err != nil {
			if strings.Contains(err.Error(), "duplicate key") {
				return errors.New("integration name already exists")
			}
			return err
		}

	} else {
		//check if infrastucture terraform integration
		infra := []database.InfraIntegration{}
		db.Where(query+"and terraform=true", integ.ClusterName, integ.CloudType, integ.Workspace).Find(&infra)
		//if infrastucture terraform integration in not integrated
		if len(infra) == 0 {
			inte[0].Terraform = true
			err := db.Where(query, integ.ClusterName, integ.CloudType, integ.Workspace).Save(&inte[0]).Error
			if err != nil {
				return err
			}
			integ = &inte[0]
		}
	}
	return nil
}

// RemoveInfrastucture function used to remove infrastructure from database
func RemoveInfrastucture(integ *database.InfraIntegration) error {
	db := config.DB

	// Delete the infrastructure from the database
	result := db.Delete(&integ)

	// Check for errors
	if result.Error != nil {
		config.Log.Error("error removing infrastructure:", result.Error)
		return result.Error
	}

	log.Printf("Infrastructure removed successfully: %+v\n", integ)
	return nil
}

// SaveAvtivity function used to store every activity of the infrastucture Integration
func SaveAvtivity(id int, slug, workspace, userName, userEmail, action, status, reason, sytemIP string) {

	//connection todb
	db := config.DB
	act := database.InfraActivites{}
	act.InfraID = id
	act.InfraName = slug
	act.Workspace = workspace
	act.Action = action
	act.Status = status
	act.Reason = reason
	act.SystemIP = sytemIP
	act.UserEmail = userEmail
	act.UserName = userName
	act.CreatedAT = time.Now().Unix()
	db.Create(&act)
}

// KubeConfig represents the kubeconfig structure needed to extract the server URL
type KubeConfigServer struct {
	Clusters []struct {
		Cluster struct {
			Server string `yaml:"server" json:"server"`
		} `yaml:"cluster" json:"cluster"`
	} `yaml:"clusters" json:"clusters"`
}

// GetKubeConfigType identifies the type of Kubernetes cluster from YAML or JSON data
func GetKubeConfigType(data []byte) string {
	var kubeConfigServer KubeConfigServer

	// Try parsing as YAML
	err := yaml.Unmarshal(data, &kubeConfigServer)
	if err != nil || len(kubeConfigServer.Clusters) == 0 {
		// If YAML fails, try JSON
		err = json.Unmarshal(data, &kubeConfigServer)
		if err != nil || len(kubeConfigServer.Clusters) == 0 {
			return "unknown"
		}
	}

	server := strings.ToLower(kubeConfigServer.Clusters[0].Cluster.Server)

	switch {
	case strings.Contains(server, "azmk8s.io"):
		return "azure"
	case strings.Contains(server, "eks.amazonaws.com") || strings.Contains(server, "amazonaws.com"):
		return "aws"
	case strings.Contains(server, "gke.googleapis.com") || strings.Contains(server, "cloud.google.com"):
		return "gcp"
	default:
		return "on-prem"
	}
}
