package minioBucket

import (
	"errors"
	"fmt"
	"io"
	"mime/multipart"
	"path/filepath"
	"strings"

	contex "context"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

// CreateMinioBucket creates a Minio bucket with the given name
func CreateMinioBucket(bucketName string) error {
	// Initialize Minio client
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		return err
	}

	// Check if the bucket already exists
	exists, err := minioClient.BucketExists(contex.Background(), bucketName)
	if err != nil {
		return err
	}

	// If the bucket exists, delete it
	if exists {
		err = minioClient.RemoveBucket(contex.Background(), bucketName)
		if err != nil {
			return err
		}
	}

	// Create a new bucket
	err = minioClient.MakeBucket(contex.Background(), bucketName, minio.MakeBucketOptions{})
	if err != nil {
		return err
	}

	return nil
}

func InsertFileInMinio(bucketName string, file io.Reader, header *multipart.FileHeader) error {
	// Create a Minio client
	minioClient, err := minio.New("172.17.0.2:9000", &minio.Options{
		Creds:  credentials.NewStaticV4("minioadmin", "minioadmin", ""),
		Secure: false,
	})
	if err != nil {
		return err
	}

	// Check if the bucket exists in Minio
	exists, err := minioClient.BucketExists(contex.Background(), bucketName)
	if err != nil {
		return err
	}

	if !exists {
		err = minioClient.MakeBucket(contex.Background(), bucketName, minio.MakeBucketOptions{})
		if err != nil {
			return err
		}
	}

	// Get the file extension
	ext := filepath.Ext(header.Filename)
	folderName := strings.TrimPrefix(ext, ".")

	// Upload the file to the bucket
	_, err = minioClient.PutObject(contex.Background(), bucketName, fmt.Sprintf("%s/%s", folderName, header.Filename), file, header.Size, minio.PutObjectOptions{})
	return err
}

func GetMinioBucketContents(bucketName string) ([]minio.ObjectInfo, error) {
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		return nil, err
	}

	objects := minioClient.ListObjects(contex.Background(), bucketName, minio.ListObjectsOptions{})
	var contents []minio.ObjectInfo
	for obj := range objects {
		contents = append(contents, obj)
	}

	return contents, nil
}

func GetFilesInFolder(bucketName string, folderName string) ([]minio.ObjectInfo, error) {
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		return nil, err
	}

	objects := minioClient.ListObjects(contex.Background(), bucketName, minio.ListObjectsOptions{
		Prefix: folderName + "/",
	})
	var files []minio.ObjectInfo
	for obj := range objects {
		if obj.Key != folderName+"/" {
			files = append(files, obj)
		}
	}

	return files, nil
}

func DeleteMinioObject(bucketName string, folderName string, fileName string) error {
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		return err
	}

	// Check if the file exists in the specified folder
	objects := minioClient.ListObjects(contex.Background(), bucketName, minio.ListObjectsOptions{
		Prefix: folderName + "/" + fileName,
	})
	if objects == nil {
		return errors.New("file not found")
	}

	// Remove the object
	err = minioClient.RemoveObject(contex.Background(), bucketName, folderName+"/"+fileName, minio.RemoveObjectOptions{})
	if err != nil {
		return err
	}

	return nil
}