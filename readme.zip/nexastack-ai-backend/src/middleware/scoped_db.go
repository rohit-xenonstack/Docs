package middleware

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// InjectScopedDB is a middleware that injects a scoped database connection
// based on project_id and environment from the JWT claims and enriches request bodies
func InjectScopedDB() gin.HandlerFunc {
	return func(c *gin.Context) {
		claims := jwt.ExtractClaims(c)

		projectID, hasProjectID := claims["project_id"]
		environment, hasEnvironment := claims["environment"]
		workspace, hasWorkSpace := claims["workspace"]

		// Create scoped DB with filters
		scopedDB := config.DB.New()
		if hasProjectID {
			scopedDB = scopedDB.Where("project_id = ?", projectID)
		}
		if hasEnvironment {
			scopedDB = scopedDB.Where("environment = ?", environment)
		}
		if hasWorkSpace {
			scopedDB = scopedDB.Where("workspace = ?", workspace)
		}

		config.DB = scopedDB

		// Store scoped DB in context
		c.Set("ScopedDB", scopedDB)

		// Enrich request body for POST, PUT, PATCH, and DELETE methods
		method := c.Request.Method
		if (method == "POST" || method == "PUT" || method == "PATCH" || method == "DELETE") &&
			strings.Contains(c.GetHeader("Content-Type"), "application/json") {

			// Read the request body
			body, err := ioutil.ReadAll(c.Request.Body)
			if err != nil {
				// If there's an error reading the body, continue with the original request
				c.Next()
				return
			}

			// Restore the request body for subsequent middleware/handlers
			c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(body))

			// Skip if body is empty
			if len(body) == 0 {
				c.Next()
				return
			}

			// Parse the body into a map
			var bodyMap map[string]interface{}
			if err := json.Unmarshal(body, &bodyMap); err != nil {
				// If there's an error parsing the body, continue with the original request
				c.Next()
				return
			}

			// Enrich the body with project_id and environment if they don't exist
			modified := false
			if hasProjectID && bodyMap["project_id"] == nil {
				bodyMap["project_id"] = projectID
				modified = true
			}
			if hasEnvironment && bodyMap["environment"] == nil {
				bodyMap["environment"] = environment
				modified = true
			}

			if hasEnvironment && bodyMap["workspace"] == nil {
				bodyMap["workspace"] = workspace
				modified = true
			}

			config.Log.Debug("modified: ", bodyMap)

			// If the body was modified, update the request body
			if modified {
				// Marshal the modified body back to JSON
				newBody, err := json.Marshal(bodyMap)
				if err != nil {
					// If there's an error marshaling the body, continue with the original request
					c.Next()
					return
				}

				// Replace the request body with the modified one
				c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(newBody))

				// Update Content-Length header
				c.Request.ContentLength = int64(len(newBody))
			}
		}

		c.Next()
	}
}

func InjectDefaultDB() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Inject the unscoped default DB into context
		config.DB = config.DefaultDb
		c.Next()
	}
}
