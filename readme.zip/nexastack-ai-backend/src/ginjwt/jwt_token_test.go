package ginjwt

import (
	"testing"
)

func TestJwtToken(t *testing.T) {

	mapd := make(map[string]interface{})
	mapd["message"] = "test"
	mapd, _ = GinJwtToken(mapd)
	if len(mapd) == 2 {
		t.Error("test case fail")
	}
}
