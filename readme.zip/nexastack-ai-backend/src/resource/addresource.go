package resource

import (
	"context"
	"io"
	"io/ioutil"
	"log"

	// "net/http"
	"os"

	// "gopkg.in/yaml.v3"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

// DownlaodCharts function for dwonload the charts
func DownlaodCharts(bucketName, fileName string) (map[string]interface{}, int) {

	// // Set your Bitbucket username and app password
	// username := config.Conf.Bitbucket.Username
	// appPassword := config.Conf.Bitbucket.Password

	// config.Log.Error("downloading charts. ! Please Wait......")
	// mapd := make(map[string]interface{})
	// // download charts from zip
	// req, err := http.NewRequest("GET", config.Conf.ChartHelm.Address, nil)
	// println("====bitbucket req=====", req.Response)
	// if err != nil {
	// 	config.Log.Error(err)
	// 	mapd["error"] = true
	// 	mapd["message"] = err.Error()
	// 	return mapd, 500
	// }
	// // Set basic authentication
	// req.SetBasicAuth(username, appPassword)
	// token := config.Conf.ChartHelm.Token
	// if token != "" {
	// 	req.Header.Set("Authorization", "Bearer "+token)
	// }
	// resp, err := http.DefaultClient.Do(req)
	// println("====bitbucket req res=====", resp.Body)
	// if err != nil {
	// 	config.Log.Error(err)
	// 	mapd["error"] = true
	// 	mapd["message"] = err.Error()
	// 	return mapd, 400
	// }
	// defer resp.Body.Close()
	// if resp.StatusCode != 200 {
	// 	config.Log.Error("====respo===", resp)
	// 	config.Log.Error(err, resp.StatusCode)
	// 	mapd["error"] = true
	// 	mapd["message"] = "Bad Request"
	// 	return mapd, resp.StatusCode
	// }

	config.Log.Error("downloading jupyter helm from MinIO! Please Wait......")
	mapd := make(map[string]interface{})
	// Initialize MinIO client
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// Fetch the .zip file from MinIO
	object, err := minioClient.GetObject(context.Background(), bucketName, fileName, minio.GetObjectOptions{})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer object.Close()

	// create tmp directory
	// create tmp directory
	tmpDir := "tmp" + randomString(10)
	tmpDirPath := config.PersistStoragePath + "/" + tmpDir
	// Create the tmp dir path
	err = os.MkdirAll(tmpDirPath, 0777)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// Create the ws charts path
	err = os.MkdirAll(tmpDirPath+"/ws_charts", 0777)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	defer func() {
		os.RemoveAll(tmpDirPath)
	}()

	// create emtpy zip file
	f, err := os.Create(tmpDirPath + "/ws_chart.zip")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer f.Close()
	// copy git file to empty file
	num, err := io.Copy(f, object)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	config.Log.Debug(num)
	// unzip file to tmp dir
	err = unzipFile(tmpDirPath+"/ws_chart.zip", tmpDirPath+"/ws_charts")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// fetch directory name
	dirName := ""
	names, err := os.ReadDir(tmpDirPath + "/ws_charts")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	for _, f := range names {
		if f.IsDir() {
			dirName = f.Name()
			break
		}
	}
	if dirName == "" {
		mapd["error"] = true
		mapd["message"] = "No directory found in the unzipped files"
		return mapd, 500
	}

	//======================
	os.RemoveAll(config.PersistStoragePath + "/ws_ingress")
	os.MkdirAll(config.PersistStoragePath+"/ws_ingress", 0777)
	err = CopyDir(tmpDirPath+"/ws_charts/"+dirName, config.PersistStoragePath+"/ws_ingress")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	mapd["chart_downlaod"] = "Success fully"
	return mapd, 200

}

func DownloadChartsMinio1(bucketName, fileName string) (map[string]interface{}, int) {
	config.Log.Debug("downloading charts from MinIO! Please Wait......")
	mapd := make(map[string]interface{})

	// Initialize MinIO client
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	config.Log.Debug("bucket name " + bucketName + " and filename: " + fileName)

	// Fetch the .zip file from MinIO
	object, err := minioClient.GetObject(context.Background(), bucketName, fileName, minio.GetObjectOptions{})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer object.Close()

	objState, _ := object.Stat()
	log.Println("object: ", objState.ContentType)

	// Create temporary directory
	tmpDir := "tmp" + randomString(10)
	tmpDirPath := "data/model-helm" + "/" + tmpDir
	err = os.MkdirAll(tmpDirPath+"/model_chart", 0777)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	// defer func() {
	// 	os.RemoveAll(tmpDirPath)
	// }()

	// Create empty zip file
	f, err := os.Create(tmpDirPath + "/model_chart.zip")

	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer f.Close()

	// Copy MinIO object to the empty file
	num, err := io.Copy(f, object)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	config.Log.Debug(num)

	// Unzip file to tmp dir
	err = unzipFile(tmpDirPath+"/model_chart.zip", tmpDirPath+"/model_charts")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// Fetch directory name
	dirName := ""
	names, err := ioutil.ReadDir(tmpDirPath + "/model_charts")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	for _, f := range names {
		if f.IsDir() {
			dirName = f.Name()
			break
		}
	}
	if dirName == "" {
		mapd["error"] = true
		mapd["message"] = "No directory found in the unzipped files"
		return mapd, 500
	}

	os.RemoveAll("data/model-helm" + "/ws_ingress")
	err = CopyDir(tmpDirPath+"/model_charts/"+dirName, "data/model-helm"+"/model_ingress")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	mapd["chart_download"] = "Successfully"
	return mapd, 200
}

func DownloadAnsibleFolder(bucketName, fileName string) (map[string]interface{}, int) {
	config.Log.Debug("downloading jupyter helm from MinIO! Please Wait......")
	mapd := make(map[string]interface{})
	// Initialize MinIO client
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// Fetch the .zip file from MinIO
	object, err := minioClient.GetObject(context.Background(), bucketName, fileName, minio.GetObjectOptions{})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer object.Close()

	// create tmp directory
	// create tmp directory
	tmpDir := "tmp" + randomString(10)
	tmpDirPath := config.PersistStoragePath + "/" + tmpDir
	// Create the tmp dir path
	err = os.MkdirAll(tmpDirPath, 0777)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// Create the ws charts path
	err = os.MkdirAll(tmpDirPath+"/ws_charts", 0777)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	defer func() {
		os.RemoveAll(tmpDirPath)
	}()

	// create emtpy zip file
	f, err := os.Create(tmpDirPath + "/ws_chart.zip")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer f.Close()
	// copy git file to empty file
	num, err := io.Copy(f, object)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	config.Log.Error(num)
	// unzip file to tmp dir
	err = unzipFile(tmpDirPath+"/ws_chart.zip", tmpDirPath+"/ws_charts")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// fetch directory name
	dirName := ""
	names, err := os.ReadDir(tmpDirPath + "/ws_charts")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	for _, f := range names {
		if f.IsDir() {
			dirName = f.Name()
			break
		}
	}
	if dirName == "" {
		mapd["error"] = true
		mapd["message"] = "No directory found in the unzipped files"
		return mapd, 500
	}

	//======================
	os.RemoveAll(config.PersistStoragePath + "/ws_ingress")
	os.MkdirAll(config.PersistStoragePath+"/ws_ingress", 0777)
	err = CopyDir(tmpDirPath+"/ws_charts/"+dirName, config.PersistStoragePath+"/ws_ingress")
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	mapd["chart_downlaod"] = "Success fully"
	return mapd, 200
}

// func DownlaodCharts(user string) (map[string]interface{}, int) {

// 	// Set your Bitbucket username and app password
// 	username := "demo0818-admin"
// 	appPassword := "ATBBdhNyC3hyZNVGz5yvNXM2CmJyE3368606"

// 	config.Log.Error("downloading charts. ! Please Wait......")
// 	mapd := make(map[string]interface{})
// 	// download charts from zip
// 	req, err := http.NewRequest("GET", config.Conf.ChartHelm.Address, nil)
// 	println("====bitbucket req=====", req.Response)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	// Set basic authentication
// 	req.SetBasicAuth(username, appPassword)
// 	token := config.Conf.ChartHelm.Token
// 	if token != "" {
// 		req.Header.Set("Authorization", "Bearer "+token)
// 	}
// 	resp, err := http.DefaultClient.Do(req)
// 	println("====bitbucket req res=====", resp.Body)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 400
// 	}
// 	defer resp.Body.Close()
// 	if resp.StatusCode != 200 {
// 		config.Log.Error("====respo===", resp)
// 		config.Log.Error(err, resp.StatusCode)
// 		mapd["error"] = true
// 		mapd["message"] = "Bad Request"
// 		return mapd, resp.StatusCode
// 	}

// 	// create tmp directory
// 	tmpDir := "tmp" + randomString(10)
// 	tmpDirPath := config.PersistStoragePath + "/" + tmpDir
// 	os.Mkdir(config.PersistStoragePath, 0777)
// 	err = os.MkdirAll(tmpDirPath+"/ws_charts", 0777)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	defer func() {
// 		os.RemoveAll(tmpDirPath)
// 	}()

// 	// create emtpy zip file
// 	f, err := os.Create(tmpDirPath + "/ws_chart.zip")
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	defer f.Close()
// 	// copy git file to empty file
// 	num, err := io.Copy(f, resp.Body)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	config.Log.Error(num)
// 	// unzip file to tmp dir
// 	err = unzipFile(tmpDirPath+"/ws_chart.zip", tmpDirPath+"/ws_charts")
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}

// 	// fetch directory name
// 	dirName := ""
// 	names, err := os.ReadDir(tmpDirPath + "/ws_charts")
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	for _, f := range names {
// 		if f.IsDir() {
// 			dirName = f.Name()
// 			break
// 		}
// 	}
// 	if dirName == "" {
// 		mapd["error"] = true
// 		mapd["message"] = "No directory found in the unzipped files"
// 		return mapd, 500
// 	}

// 	// Update values.yaml
// 	valuesFilePath := tmpDirPath + "/ws_charts/" + "/values.yaml"
// 	valuesFile, err := os.Open(valuesFilePath)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	defer valuesFile.Close()

// 	valuesData, err := io.ReadAll(valuesFile)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}

// 	var values map[string]interface{}
// 	err = yaml.Unmarshal(valuesData, &values)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}

// 	// Update the `adminUser ` variable with the provided `user` value

// 	println("====username====", user)
// 	values["hub"].(map[string]interface{})["adminUser"] = user

// 	// Marshal updated values to YAML
// 	updatedValuesData, err := yaml.Marshal(values)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}

// 	// Write updated values to file
// 	err = os.WriteFile(valuesFilePath, updatedValuesData, 0644)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}

// 	//======================
// 	os.RemoveAll(config.PersistStoragePath + "/ws_ingress")
// 	os.MkdirAll(config.PersistStoragePath+"/ws_ingress", 0777)
// 	err = CopyDir(tmpDirPath+"/ws_charts/", config.PersistStoragePath+"/ws_ingress")
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, 500
// 	}
// 	mapd["chart_download"] = "Successfully"
// 	return mapd, 200
// }
