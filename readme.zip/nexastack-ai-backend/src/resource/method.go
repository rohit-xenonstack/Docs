package resource

import (
	"archive/zip"
	"io"
	"io/ioutil"
	"math/rand"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"text/template"
	"text/template/parse"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
)

// Random Strings Generation
func randomString(l int) string {
	rand.Seed(time.Now().UTC().UnixNano())
	bytes := make([]byte, l)
	for i := 0; i < l; i++ {
		bytes[i] = byte(randInt())
	}
	return string(bytes)
}

func randInt() int {
	rdInt := rand.Intn(51)
	if rdInt <= 25 {
		rdInt = rdInt + 65
	} else {
		rdInt = rdInt + 71
	}
	return rdInt
}

func createStrAndRemoveDuplicate(dVs []string) string {
	str := ""
	for i := 0; i < len(dVs); i++ {
		str += " " + dVs[i]
	}
	varSlice := strings.Split(str, " ")
	var finalVarSlice []string
	for i := 0; i < len(varSlice); i++ {
		if !(isSliceContainsString(finalVarSlice, varSlice[i])) && varSlice[i] != "" {
			finalVarSlice = append(finalVarSlice, varSlice[i])
		}
	}
	finalStr := ""
	for i := 0; i < len(finalVarSlice); i++ {
		if finalStr != "" {
			finalStr += " "
		}
		finalStr += finalVarSlice[i]
	}
	return finalStr
}

func slugOfName(name string) (string, bool) {

	name = strings.TrimSpace(strings.ToLower(name))
	for i := 0; i < len(name); i++ {
		if !((name[i] > 47 && name[i] < 58) || (name[i] > 64 && name[i] < 91) || (name[i] > 96 && name[i] < 123) || name[i] == 32 || name[i] == 45 || name[i] == 95) {
			return "", false
		}

		if name[i] == 32 {
			name = name[:i] + "-" + name[i+1:]
		}
	}
	return name, true
}

func getTemplateVarsString(completeFilePath string) string {
	resFile, err := ioutil.ReadFile(completeFilePath)
	if err != nil {
		config.Log.Error("\n\nread file error :\n\n", err)
		return ""
	}

	tmpl, err := template.New("resource_template").Parse(string(resFile))
	if err != nil {
		return ""
	}

	fields := listNodeFields(tmpl.Tree.Root, nil)

	var varSlice []string
	for i := 0; i < len(fields); i++ {
		varName := getVarNameFromField(fields[i])
		//varName 'Name' will not be shown to user
		if (!isSliceContainsString(varSlice, varName)) && varName != "" && varName != "Name" {
			varSlice = append(varSlice, varName)
		}
	}

	finalStr := ""
	for i := 0; i < len(varSlice); i++ {
		if i != 0 {
			finalStr += " "
		}
		finalStr += varSlice[i]
	}
	return finalStr
}

func getVarNameFromField(str string) string {
	re := regexp.MustCompile("{{.*?[.]([a-z|A-Z|_|0-9]*).*?}}")
	match := re.FindStringSubmatch(str)
	if len(match) == 2 {
		return match[1]
	}
	return ""
}

func isSliceContainsString(strSlice []string, str string) bool {
	for i := 0; i < len(strSlice); i++ {
		if strSlice[i] == str {
			return true
		}
	}
	return false
}

func listNodeFields(node parse.Node, res []string) []string {
	if node.Type() == parse.NodeAction {
		res = append(res, node.String())
	}

	if ln, ok := node.(*parse.ListNode); ok {
		for _, n := range ln.Nodes {
			res = listNodeFields(n, res)
		}
	}
	return res
}

//====================================================================

func CopyFile(source string, dest string) (err error) {
	sourcefile, err := os.Open(source)
	if err != nil {
		return err
	}

	defer sourcefile.Close()

	destfile, err := os.Create(dest)
	if err != nil {
		return err
	}

	defer destfile.Close()

	_, err = io.Copy(destfile, sourcefile)
	if err == nil {
		sourceinfo, err := os.Stat(source)
		if err != nil {
			err = os.Chmod(dest, sourceinfo.Mode())
		}

	}

	return
}

func unzipFile(src, dest string) error {
	r, err := zip.OpenReader(src)
	if err != nil {
		config.Log.Error(err)
		return err
	}
	defer func() {
		if err := r.Close(); err != nil {
			config.Log.Error(err)
		}
	}()

	os.MkdirAll(dest, 0755)

	// Closure to address file descriptors issue with all the deferred .Close() methods
	extractAndWriteFile := func(f *zip.File) error {
		rc, err := f.Open()
		if err != nil {
			return err
		}
		defer func() {
			if err := rc.Close(); err != nil {
				config.Log.Error(err)
			}
		}()

		path := filepath.Join(dest, f.Name)

		if f.FileInfo().IsDir() {
			os.MkdirAll(path, f.Mode())
		} else {
			os.MkdirAll(filepath.Dir(path), f.Mode())
			f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, f.Mode())
			if err != nil {
				return err
			}
			defer func() {
				if err := f.Close(); err != nil {
					config.Log.Error(err)
				}
			}()

			_, err = io.Copy(f, rc)
			if err != nil {
				return err
			}
		}
		return nil
	}

	for _, f := range r.File {
		err := extractAndWriteFile(f)
		if err != nil {
			return err
		}
	}

	return nil
}

// CopyDir function used for copy the dir.
func CopyDir(source string, dest string) (err error) {

	// get properties of source dir
	sourceinfo, err := os.Stat(source)
	if err != nil {
		return err
	}

	// create dest dir

	err = os.MkdirAll(dest, sourceinfo.Mode())
	if err != nil {
		return err
	}

	directory, _ := os.Open(source)

	objects, err := directory.Readdir(-1)

	for _, obj := range objects {

		sourcefilepointer := source + "/" + obj.Name()

		destinationfilepointer := dest + "/" + obj.Name()

		if obj.IsDir() {
			// create sub-directories - recursively
			err = CopyDir(sourcefilepointer, destinationfilepointer)
			if err != nil {
				config.Log.Error(err)
			}
		} else {
			// perform copy
			err = CopyFile(sourcefilepointer, destinationfilepointer)
			if err != nil {
				config.Log.Error(err)
			}
		}

	}
	return
}
