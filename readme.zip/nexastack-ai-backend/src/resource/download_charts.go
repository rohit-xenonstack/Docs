package resource

import (
	"context"
	"io"
	"io/ioutil"
	"os"
	"path/filepath"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
	"gopkg.in/yaml.v3"
)

func DownloadChartsMinio(bucketName, fileName string) (map[string]interface{}, int) {
	config.Log.Debug("downloading charts from MinIO! Please Wait......")
	mapd := make(map[string]interface{})

	// Initialize MinIO client
	minioClient, err := minio.New(config.Conf.Minio.Endpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(config.Conf.Minio.AccessKey, config.Conf.Minio.SecretKey, ""),
		Secure: false,
	})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	// Create base directory for Helm charts
	baseDir := "data/model-helm/model_ingress"
	if err := os.MkdirAll(baseDir, 0755); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to create base directory"
		return mapd, 500
	}

	// Download the zip file
	object, err := minioClient.GetObject(context.Background(), bucketName, fileName, minio.GetObjectOptions{})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer object.Close()

	// Create zip file
	zipPath := filepath.Join(baseDir, "model_chart.zip")
	zipFile, err := os.Create(zipPath)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to create zip file"
		return mapd, 500
	}
	defer zipFile.Close()

	// Copy content to zip file
	if _, err := io.Copy(zipFile, object); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to copy zip content"
		return mapd, 500
	}

	// Unzip to temporary directory
	extractPath := filepath.Join(baseDir, "extracted")
	if err := unzipFile(zipPath, baseDir); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to extract zip file"
		return mapd, 500
	}

	// Find the chart directory
	chartDir := ""
	files, err := ioutil.ReadDir(extractPath)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to read extracted directory"
		return mapd, 500
	}

	for _, file := range files {
		if file.IsDir() {
			// Verify it's a valid Helm chart
			chartPath := filepath.Join(extractPath, file.Name())
			if isValidHelmChart(chartPath) {
				chartDir = file.Name()
				break
			}
		}
	}

	if chartDir == "" {
		mapd["error"] = true
		mapd["message"] = "No valid Helm chart found in the zip file"
		return mapd, 500
	}

	// Remove existing chart directory if it exists
	targetDir := filepath.Join(baseDir, "model_ingress")
	if err := os.RemoveAll(targetDir); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to remove existing chart directory"
		return mapd, 500
	}

	// Copy the chart to the final location
	if err := CopyDir(filepath.Join(extractPath, chartDir), targetDir); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Failed to copy chart to final location"
		return mapd, 500
	}

	// Ensure values.yaml exists and has release name
	valuesPath := filepath.Join(targetDir, "values.yaml")
	if _, err := os.Stat(valuesPath); os.IsNotExist(err) {
		config.Log.Error("values.yaml not found in chart")
		mapd["error"] = true
		mapd["message"] = "values.yaml not found in chart"
		return mapd, 500
	}

	// Read and parse values.yaml
	valuesData, err := os.ReadFile(valuesPath)
	if err != nil {
		config.Log.Error("Failed to read values.yaml:", err)
		mapd["error"] = true
		mapd["message"] = "Failed to read values.yaml"
		return mapd, 500
	}

	var values map[string]interface{}
	if err := yaml.Unmarshal(valuesData, &values); err != nil {
		config.Log.Error("Failed to parse values.yaml:", err)
		mapd["error"] = true
		mapd["message"] = "Failed to parse values.yaml"
		return mapd, 500
	}

	// Log the values for debugging
	config.Log.Debug("Values from chart:", values)

	// Ensure release name is set
	if _, ok := values["releaseName"]; !ok {
		values["releaseName"] = "model-release"
		updatedValues, err := yaml.Marshal(values)
		if err != nil {
			config.Log.Error("Failed to marshal updated values:", err)
			mapd["error"] = true
			mapd["message"] = "Failed to update values.yaml"
			return mapd, 500
		}
		if err := os.WriteFile(valuesPath, updatedValues, 0644); err != nil {
			config.Log.Error("Failed to write updated values:", err)
			mapd["error"] = true
			mapd["message"] = "Failed to write updated values.yaml"
			return mapd, 500
		}
		config.Log.Debug("Added default release name to values.yaml")
	}

	mapd["chart_download"] = "Successfully"
	return mapd, 200
}

// isValidHelmChart checks if a directory contains a valid Helm chart
func isValidHelmChart(dirPath string) bool {
	requiredFiles := []string{
		"Chart.yaml",
		"values.yaml",
		"templates",
	}

	for _, file := range requiredFiles {
		path := filepath.Join(dirPath, file)
		if _, err := os.Stat(path); os.IsNotExist(err) {
			return false
		}
	}

	// Check if templates directory contains required files
	templatesDir := filepath.Join(dirPath, "templates")
	requiredTemplates := []string{
		"deployment.yaml",
		"service.yaml",
		"ingress.yaml",
	}

	for _, template := range requiredTemplates {
		path := filepath.Join(templatesDir, template)
		if _, err := os.Stat(path); os.IsNotExist(err) {
			return false
		}
	}

	return true
}
