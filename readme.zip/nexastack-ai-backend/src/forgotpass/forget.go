package forgetpass

import (
	"errors"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
)

//==============================================================================

// ForgotPass is a method for sending reset-password link in mail
func ForgotPass(email string) (string, bool) {

	db := config.DB

	//checking whether email exist or not
	var acc []database.Accounts
	db.Debug().Where("email=?", email).Find(&acc)
	if len(acc) != 0 {
		if acc[0].VerifyStatus == "verified" && acc[0].AccountStatus == "active" {
			go mail.SendForgotPassMail(acc[0])
			return "We have sent a password reset link on your mail.", true
		}
	}
	return "Email doesn't exists.", false
}

// ==============================================================================

// ResetForgottenPassword is method to reset password in database
// but before updating token and password is checked
func ResetForgottenPassword(token, password string) (string, string, bool) {
	if !methods.CheckPassword(password) {
		return "", "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character.", false
	}

	//Checking token in database
	tok, err := verifytoken.CheckToken(token)
	if err != nil {
		return "", err.Error(), false
	}

	if tok.TokenTask == "forgot_pass" {
		// update in database
		email, err := UpdateDatabase(tok.Userid, password)
		if err != nil {
			return "", err.Error(), false
		}
		// delete used and expired tokens
		go verifytoken.DeleteToken(token)

		//password reset done.
		return email, "Password reset successfully.", true
	}
	return "", "Invalid or expired token.", false
}

//==============================================================================

// UpdateDatabase is method to update password in database on basis of id
func UpdateDatabase(id int, password string) (string, error) {

	// connecting to db
	db := config.DB

	// check account exist
	var acs []database.Accounts
	db.Debug().Where("id= ?", id).Find(&acs)
	if len(acs) == 0 {
		return "", errors.New("Account not found")
	}
	// hash the simple password and then update password in database
	db.Model(&database.Accounts{}).Where("id=?", id).Update("password", methods.HashForNewPassword(password))

	return acs[0].Email, nil
}
