package forgetpass

import (
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
)

//==============================================================================

// ForgotPassChallenge is a method for sending reset-password link in mail with workspace
func ForgotPassChallenge(email, wsID string) (string, bool) {

	// when workspace id is not send
	if wsID == "" {
		msg, ok := ForgotPass(email)
		return msg, ok
	}

	//checking whether email exist or not
	acc, err := accounts.GetAccountForEmail(email)
	if err != nil {
		config.Log.Error("when no account is there")
		return "Email doesn't exists.", false
	}

	//split workspace name
	wsParts := strings.Split(wsID, ".")

	if acc.VerifyStatus == "verified" && acc.AccountStatus == "active" {
		// check member exist in workspace
		if member.CheckMember(acc.Email, wsParts[0]) {
			//send forgot password mail
			go mail.SendForgotPassMAIL(acc, wsID)
			return "We have sent a password reset link on your mail.", true
		}
		config.Log.Debug("when workspace not match")
	}
	return "Email doesn't exists.", false
}

// ==============================================================================

// ResetForgottenPass is method to reset password in database
// first check request is with workspace or without
// but before updating token and password is checked
func ResetForgottenPass(token, password, wsID string) (string, string, bool) {
	// if wsID is not present
	if wsID == "" {
		email, msg, ok := ResetForgottenPassword(token, password)
		return email, msg, ok
	}

	//validation check on password
	if !methods.CheckPassword(password) {
		return "", "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character.", false
	}

	//Checking token in database
	tok, err := verifytoken.CheckToken(token)
	if err != nil {
		return "", err.Error(), false
	}

	//split workspace name
	wsParts := strings.Split(wsID, ".")

	if tok.TokenTask == "forgot_pass" {
		//fetch account informtion on basis of id
		acc := accounts.GetAccountForid(tok.Userid)
		// check member exist in workspace
		if member.CheckMember(acc.Email, wsParts[0]) {
			// update in database
			email, err := UpdateDatabase(tok.Userid, password)
			if err != nil {
				return "", err.Error(), false
			}

			// delete used and expired tokens
			go verifytoken.DeleteToken(token)

			//password reset done.
			return email, "Password reset successfully.", true
		}
	}
	return "", "Invalid or expired token.", false
}
