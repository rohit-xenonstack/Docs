package login

import (
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	member1 "git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/signin"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
)

// NormalLogin is a method to login with workpsace
func NormalLogin(email, password, wsID, environment string, projectId int) (int, map[string]interface{}) {
	mapd := make(map[string]interface{})

	//connection to db
	db := config.DB
	// check email and password
	isAccLocked, login, msg, acc := signin.SimpleSignin(strings.ToLower(email), password)

	// when account is locked or email or password is wrong
	if isAccLocked || !login {
		mapd["error"] = true
		mapd["message"] = msg
		return 401, mapd
	}

	// check if default project is assigned or not
	// if not then add this account to project member
	var isProjectMember bool
	var wscount int
	projectName := "nexastack_" + wsID

	err := config.DB.Debug().
		Table("project_management.project_members").
		Joins("JOIN project_management.project ON project.id = project_members.project_id::int").
		Where("project.name = ? AND project_members.email = ?", projectName, email).
		Count(&wscount).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return 400, mapd
	} else {
		isProjectMember = wscount > 0
	}

	var isWorkspaceMember bool
	var count int
	err = config.DB.Debug().
		Model(&database.WorkspaceMembers{}).
		Where("workspace_id = ? AND member_email = ?", wsID, email).
		Count(&count).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return 400, mapd
	} else {
		isWorkspaceMember = count > 0
	}

	config.Log.Info("isProjectMember ", isProjectMember)
	config.Log.Info("isWorkspaceMember ", isWorkspaceMember)

	if !isProjectMember && isWorkspaceMember {
		config.Log.Info("should create memeber....")
		err, mapd = member1.AssignDefaultProjectToWorkspaceMember(wsID, mapd, acc)
		if err != nil {
			return 400, mapd
		}
	} else {
		config.Log.Info("should not create memeber....")
	}

	// if workspace is passed
	if wsID != "" {
		//check workspace
		var work []database.Workspaces
		db.Where("workspace_id = ?", wsID).Find(&work)
		if len(work) == 0 {
			//when not a member
			mapd["error"] = true
			mapd["message"] = "invalid email and password"
			return 501, mapd
		}

		//check user is member of that workspace
		member := []database.WorkspaceMembers{}
		db.Where("member_email= ? AND workspace_id= ?", acc.Email, wsID).Find(&member)
		if len(member) == 0 {
			//when not a member
			mapd["error"] = true
			mapd["message"] = "invalid email and password"
			return 401, mapd
		}

		//generate jwt token
		mapd, err := jwtToken.JwtToken(acc, wsID, member[0].Role, environment, projectId)
		if err != nil {
			mapd["error"] = true
			mapd["message"] = err.Error()
			return 503, mapd
		}
		mapd["id"] = acc.ID
		mapd["name"] = acc.Name
		mapd["workspace_role"] = member[0].Role
		mapd["workspace_name"] = work[0].TeamName
		mapd["workspace_id"] = wsID
		mapd["role_id"] = acc.RoleID
		mapd["email"] = acc.Email
		return 200, mapd
	} else {
		// when workspace is empty
		// check user belongs to any WorkSpace
		isWs, token := checkUser(acc)
		//generate jwt token
		mapd, err := jwtToken.JwtToken(acc, "", "", environment, projectId)
		if err != nil {
			mapd["error"] = true
			mapd["message"] = err.Error()
			return 503, mapd
		}
		mapd["id"] = acc.ID
		mapd["name"] = acc.Name
		mapd["role_id"] = acc.RoleID
		mapd["email"] = acc.Email
		mapd["isWorkspace"] = isWs
		mapd["workspace_id"] = wsID
		mapd["workspace_token"] = token
		return 200, mapd
	}
}

// checkUser is a method to check user belongs to any WorkSpace
// if yes follow recover workspace process
func checkUser(acc database.Accounts) (bool, string) {
	// connecting to db
	db := config.DB

	// cheking id in workspace member table
	var wm []database.WorkspaceMembers
	db.Where("member_email= ?", acc.Email).Find(&wm)

	var is bool
	// if there is no user in this table then return false
	if len(wm) == 0 {
		return false, ""
	}
	is = false
	// when there is user in worksapce member check role of user for that workspace
	for i := 0; i < len(wm); i++ {
		if wm[i].Role == "owner" {
			is = true
		}
	}
	if !is {
		return is, ""
	}
	// getting token to recover workspace used to directly login in workspace.
	token := verifytoken.CheckSentToken(acc.ID, "recover_workspace")

	return is, token
}
