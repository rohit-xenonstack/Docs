package helm

import (
	"fmt"
	"os"

	"github.com/ghodss/yaml"

	"helm.sh/helm/v3/pkg/strvals"
)

// This file only for update value.yaml or
//
// change values from value.yaml file according to user
func ChangeValueFile(valueFiles string, values []string) (map[string]interface{}, error) {
	base := map[string]interface{}{}

	// User specified a values files via -f/--values
	currentMap := map[string]interface{}{}
	bytes, err := os.ReadFile(valueFiles)
	if err != nil {
		return nil, err
	}
	if err := yaml.Unmarshal(bytes, &currentMap); err != nil {
		return nil, fmt.Errorf("failed to parse %s: %s", valueFiles, err)
	}

	// Merge with the previous map
	base = mergeValues(base, currentMap)

	// User specified a value via --set
	for _, value := range values {
		if err := strvals.ParseInto(value, base); err != nil {
			return nil, fmt.Errorf("failed parsing --set data: %s", err)
		}
	}

	//set value.yaml in value map in yaml format
	// bytes, err = yaml.Marshal(base)
	// if err != nil {
	// 	return nil, err
	// }
	// mapd := make(map[string]interface{})
	// if err := yaml.Unmarshal(bytes, &mapd); err != nil {
	// 	return nil, err
	// }
	// return mapd, nil

	
	// Marshal the updated map back to YAML
	updatedYAML, err := yaml.Marshal(base)
	if err != nil {
		return nil, err
	}

	// Write the updated YAML back to the file
	if err := os.WriteFile(valueFiles, updatedYAML, 0644); err != nil {
		return nil, fmt.Errorf("failed to write updated values to %s: %s", valueFiles, err)
	}

	// Return the updated map
	mapd := make(map[string]interface{})
	if err := yaml.Unmarshal(updatedYAML, &mapd); err != nil {
		return nil, err
	}
	return mapd, nil
}




//==================================

func mergeValues(dest map[string]interface{}, src map[string]interface{}) map[string]interface{} {
	for k, v := range src {
		// If the key doesn't exist already, then just set the key to that value
		if _, exists := dest[k]; !exists {
			dest[k] = v
			continue
		}
		nextMap, ok := v.(map[string]interface{})
		// If it isn't another map, overwrite the value
		if !ok {
			dest[k] = v
			continue
		}
		// If the key doesn't exist already, then just set the key to that value
		if _, exists := dest[k]; !exists {
			dest[k] = nextMap
			continue
		}
		// Edge case: If the key exists in the destination, but isn't a map
		destMap, isMap := dest[k].(map[string]interface{})
		// If the source map has a map for this key, prefer it
		if !isMap {
			dest[k] = v
			continue
		}
		// If we got to this point, it is a map in both, so merge them
		dest[k] = mergeValues(destMap, nextMap)
	}
	return dest
}
