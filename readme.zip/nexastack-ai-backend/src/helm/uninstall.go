package helm

import (
	"encoding/json"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	// "git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"helm.sh/helm/v3/pkg/action"
)

// DeleteWorkspace function for delete Release
func DeleteWorkspace(workspaceURL string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})
	mapd["error"] = false

	wsURLParts := strings.Split(workspaceURL, ".")
	workspace := wsURLParts[0]

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}

	// Set nameSpace
	nameSpace := *config.Conf.Kube.Namespace

	// namespace
	if !config.Conf.Service.IsNSCreate {
		nameSpace = "icp-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
	}

	// set kube-config and generate actionConfiguration
	actionConfig, code, err := kubernetes.SetConfig(nameSpace)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = false
		mapd["message"] = err.Error()
		return mapd, code
	}

	// Set Uninstall release on server
	icli := action.NewUninstall(actionConfig)
	_, err = icli.Run(strings.Replace(workspace, "_", "-", -1) + "-" + branch)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = false
		mapd["message"] = err.Error()
		return mapd, 404
	}

	mapd["helm_chart_delete"] = true

	// delete database related to workspace
	// err = database.Delete(strings.Replace(workspace, "-", "_", -1))
	// if err != nil {
	// 	log.Println(err)
	// 	mapd["database_delete"] = err.Error()
	// } else {
	// 	mapd["database_delete"] = true
	// }

	//delete namespace
	if !config.Conf.Service.IsNSDelete {
		result, code := kubernetes.DeleteNamespace(nameSpace)
		if code != 200 {
			mapd["namespace_delete"] = result
			return mapd, 200
		}

		mapd["namespace_delete"] = true
	}

	return mapd, 200
}

// DeleteWorkspaceUsingNats function used for delete the workspace using the nats-service
func DeleteWorkspaceUsingNats(byteData []byte) []byte {

	mapd := make(map[string]interface{})
	mapd["error"] = false
	if string(byteData) == "" {
		return []byte("please pass the valid workspace name")
	}
	config.Log.Debug("request for delete the workspace:-", string(byteData))
	mapd, code := DeleteWorkspace(string(byteData))
	mapd["code"] = code
	byteData, err := json.Marshal(mapd)
	config.Log.Error("error :-", err)
	config.Log.Debug(string(byteData))
	return byteData
}
