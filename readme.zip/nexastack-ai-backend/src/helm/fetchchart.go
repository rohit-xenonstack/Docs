package helm

import (
	"errors"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"helm.sh/helm/v3/pkg/chart"
	"helm.sh/helm/v3/pkg/chart/loader"
)

// FetchChart function for fetch chart for relese
func FetchChart(companyFQDN, workspace, namespace string) (*chart.Chart, map[string]interface{}, error) {

	// load chart value from chart.yaml
	chart, err := loader.LoadDir(config.PersistStoragePath + "/ws_ingress")
	if err != nil {
		config.Log.Error(err)
		return nil, nil, errors.New("no such file or directory")
	}

	rawVals := make(map[string]interface{})
	// rawVals["teamSlug"] = workspace
	// rawVals["namespace"] = namespace

	return chart, rawVals, nil
}

// func FetchModelChart(workspace, namespace string) (*chart.Chart, map[string]interface{}, error) {

// 	// load chart value from chart.yaml
// 	chart, err := loader.LoadDir("data/model-helm/model_ingress")
// 	if err != nil {
// 		config.Log.Error(err)
// 		return nil, nil, errors.New("no such file or directory")
// 	}

// 	rawVals := make(map[string]interface{})
// 	rawVals["teamSlug"] = workspace
// 	rawVals["namespace"] = namespace

// 	config.Log.Debug("rawVals", rawVals)

// 	return chart, rawVals, nil
// }
