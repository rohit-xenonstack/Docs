package helm

import (
	// "encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"

	// "git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	// "git.xenonstack.com/nexa-platform/accounts/src/resource"
	// "helm.sh/helm/v3/pkg/action"

	"gopkg.in/yaml.v3"
	"helm.sh/helm/v3/pkg/chart"
	"helm.sh/helm/v3/pkg/chart/loader"
)

// InstallWorkspace function install a Release
func InstallWorkspace(ws ReleaseConfig, vals map[string][]string, username string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})
	mapd["error"] = false

	// companyFQDN := ws.WorkspaceURL
	wsURLParts := strings.Split(ws.WorkspaceURL, ".")
	workspace := wsURLParts[0]

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	// Set nameSpace
	nameSpace := *config.Conf.Kube.Namespace

	// create namespace
	if !config.Conf.Service.IsNSCreate {
		nameSpace = "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
		println("====namespace====", nameSpace)
		//create a new workspace
		// result, code := kubernetes.CreateNamespace(nameSpace)
		// if code != 200 {
		// 	config.Log.Error(result, code)
		// 	mapd["workspace created :- "] = "Error to create workspace"
		// 	mapd["result"] = result
		// 	mapd["error"] = true
		// 	return mapd, code
		// }
	}

	// set kube-config and generate actionConfiguration
	// actionConfig, code, err := kubernetes.SetConfig(nameSpace)
	// if err != nil {
	// 	config.Log.Error("kubeconfig set :- ", err)
	// 	mapd["error"] = false
	// 	mapd["message"] = err.Error()
	// 	return mapd, code
	// }

	//Downlaod the Charts
	// resource.DownlaodCharts(username)

	//fetchChart from charts and modifiy values.yaml
	// chart, val, err := FetchChart(companyFQDN, workspace, nameSpace)
	// // println("===chart,val====", chart, len(val))
	// if err != nil {
	// 	config.Log.Error(err)
	// 	mapd["error"] = false
	// 	mapd["message"] = err.Error()
	// 	return mapd, 404
	// }

	// //set install release on server
	// iCli := action.NewInstall(actionConfig)
	// println("=====icli====", iCli.CaFile)
	// iCli.Namespace = nameSpace
	// iCli.ReleaseName = strings.Replace(workspace, "_", "-", -1) + "-" + branch
	// iCli.DryRun = ws.Dry
	// _, err = iCli.Run(chart, val)
	// if err != nil {
	// 	config.Log.Error(err)
	// 	mapd["error"] = false
	// 	mapd["message"] = err.Error()
	// 	return mapd, 500
	// }
	mapd["workspace created :- "] = "Workpsace created successfully"
	mapd["error"] = false
	return mapd, 200
}

// FetchModelChart fetches the model chart and returns the chart object and values
func FetchModelChart(workspace, namespace, valueYamlFile string, infraIntegration database.InfraIntegration) (*chart.Chart, map[string]interface{}, error) {
	// Get the base directory from config or use default
	baseDir := "data/model-helm"
	config.Log.Debug("Base directory:", baseDir)

	// Construct the chart directory path
	chartDir := filepath.Join(baseDir, "model_ingress")
	config.Log.Debug("Chart directory:", chartDir)

	// Verify the chart directory exists
	if _, err := os.Stat(chartDir); os.IsNotExist(err) {
		config.Log.Error("Chart directory does not exist:", chartDir)
		return nil, nil, fmt.Errorf("chart directory not found: %s", chartDir)
	}

	// Load the chart
	chart, err := loader.LoadDir(chartDir)
	if err != nil {
		config.Log.Error("Failed to load chart:", err)
		return nil, nil, fmt.Errorf("failed to load chart: %v", err)
	}
	config.Log.Debug("Loaded chart:", chart.Metadata.Name, "version:", chart.Metadata.Version)

	// Verify the chart is valid
	if chart.Metadata == nil {
		return nil, nil, errors.New("invalid chart: missing metadata")
	}

	// Construct the values file path
	valuesFile := filepath.Join(chartDir, valueYamlFile)
	config.Log.Debug("Looking for values file:", valuesFile)

	// Check if the values file exists
	if _, err := os.Stat(valuesFile); os.IsNotExist(err) {
		config.Log.Error("Values file does not exist:", valuesFile)
		return nil, nil, fmt.Errorf("values file not found: %s", valuesFile)
	}
	config.Log.Debug("Found values file:", valuesFile)

	// Load the values file
	values, err := os.ReadFile(valuesFile)
	if err != nil {
		config.Log.Error("Failed to read values file:", err)
		return nil, nil, fmt.Errorf("failed to read values file: %v", err)
	}
	config.Log.Debug("Successfully read values file")

	// Parse the values file
	rawVals := make(map[string]interface{})
	if err := yaml.Unmarshal(values, &rawVals); err != nil {
		config.Log.Error("Failed to parse values file:", err)
		return nil, nil, fmt.Errorf("failed to parse values file: %v", err)
	}
	config.Log.Debug("Successfully parsed values file")
	config.Log.Debug("Raw values content:", rawVals)

	// Process ingress configuration for both release name and domain
	if ingress, ok := rawVals["ingress"].(map[string]interface{}); ok {
		if hosts, ok := ingress["hosts"].([]interface{}); ok && len(hosts) > 0 {
			if host, ok := hosts[0].(map[string]interface{}); ok {
				if hostName, ok := host["host"].(string); ok {
					// Extract release name from host
					parts := strings.Split(hostName, ".")
					if len(parts) > 0 {
						// Generate a random 4-character suffix
						const charset = "abcdefghijklmnopqrstuvwxyz0123456789"
						suffix := make([]byte, 4)
						for i := range suffix {
							suffix[i] = charset[rand.Intn(len(charset))]
						}
						releaseName := parts[0] + "-" + string(suffix)
						config.Log.Debug("Setting release name from ingress host with random suffix:", releaseName)
						rawVals["releaseName"] = releaseName
						// Also set fullnameOverride to the same value
						rawVals["fullnameOverride"] = releaseName

						// Update ingress hosts with the new release name
						if ingress, ok := rawVals["ingress"].(map[string]interface{}); ok {
							if hosts, ok := ingress["hosts"].([]interface{}); ok && len(hosts) > 0 {
								if host, ok := hosts[0].(map[string]interface{}); ok {
									// Update the host with the new release name
									domain := strings.Join(parts[1:], ".")
									newHost := releaseName + "." + domain
									host["host"] = newHost
									config.Log.Debug("Updated ingress host:", newHost)

									// Update TLS hosts if present
									if tls, ok := ingress["tls"].([]interface{}); ok && len(tls) > 0 {
										if tlsConfig, ok := tls[0].(map[string]interface{}); ok {
											if tlsHosts, ok := tlsConfig["hosts"].([]interface{}); ok && len(tlsHosts) > 0 {
												tlsConfig["hosts"] = []interface{}{newHost}
												config.Log.Debug("Updated TLS hosts")
											}
										}
									}
								}
							}
						}
					}

					// Update domain if in nexastack environment
					// if ingressPath := os.Getenv("INGRESS_PATH"); ingressPath == "nexastack" {
					config.Log.Debug("Updating ingress host domain for nexastack environment")
					newHost := strings.Replace(hostName, ".lab.neuralcompany.team", infraIntegration.Ingress, 1)
					host["host"] = newHost
					config.Log.Debug("Updated ingress host:", newHost)

					// Update ingress className to nginx
					if className, ok := ingress["className"].(string); ok && className == "webapprouting.kubernetes.azure.com" {
						ingress["className"] = infraIntegration.IngressClass
						config.Log.Debug("Updated ingress className to nginx")
					}

					// Update TLS hosts if present
					if tls, ok := ingress["tls"].([]interface{}); ok && len(tls) > 0 {
						if tlsConfig, ok := tls[0].(map[string]interface{}); ok {
							if tlsHosts, ok := tlsConfig["hosts"].([]interface{}); ok && len(tlsHosts) > 0 {
								tlsConfig["hosts"] = []interface{}{newHost}
								config.Log.Debug("Updated TLS hosts")
							}
						}
						// }
					}
				}
			}
		}
	}

	// Set workspace and namespace
	rawVals["teamSlug"] = workspace
	rawVals["namespace"] = namespace
	config.Log.Debug("Added workspace:", workspace, "and namespace:", namespace, "to values")

	// Log the final values for debugging
	config.Log.Debug("Final chart values:", rawVals)

	// Print the entire kubeconfig for debugging
	kubeconfigYAML, err := yaml.Marshal(rawVals)
	if err != nil {
		config.Log.Error("Failed to marshal kubeconfig for printing:", err)
	} else {
		config.Log.Debug("Complete kubeconfig:\n", string(kubeconfigYAML))
	}

	return chart, rawVals, nil
}

// Helper function to get all keys from a map
func getKeys(m map[string]interface{}) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	return keys
}
