package helm

import "testing"

func TestInstallworkspace(t *testing.T) {

	var c ReleaseConfig
	var user string
	c.WorkspaceURL = "xenon.nexa.xenon.work"
	mapd, code := InstallWorkspace(c, nil, user)
	if code != 200 {
		t.Error("test case fail -->", mapd)
	}
}
func TestInstallworkspaceWrongData(t *testing.T) {

	var c ReleaseConfig
	var user string
	c.WorkspaceURL = "xenon123@#.nexa.xenon.work"
	mapd, code := InstallWorkspace(c, nil, user)
	if code != 500 {
		t.Error("test case fail -->", mapd)
	}
}
func TestInstallworkspaceAlreadyExist(t *testing.T) {

	var c ReleaseConfig
	var user string
	c.WorkspaceURL = "xenon.nexa.xenon.work"
	mapd, code := InstallWorkspace(c, nil, user)
	if code != 500 {
		t.Error("test case fail -->", mapd)
	}
}
