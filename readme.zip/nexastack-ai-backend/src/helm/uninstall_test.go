package helm

import "testing"

func TestDeleteWorkspace(t *testing.T) {

	WorkspaceURL := "xenon.nexa.xenon.work"
	mapd, code := DeleteWorkspace(WorkspaceURL)
	if code != 200 {
		t.Error("test case fail -->", mapd)
	}
}
func TestDeleteWorkspaceWrongData(t *testing.T) {

	WorkspaceURL := "xenon@123#.nexa.xenon.work"
	mapd, code := DeleteWorkspace(WorkspaceURL)
	if code != 404 {
		t.Error("test case fail -->", mapd)
	}
}
func TestDeleteWorkspaceAlreadyDelete(t *testing.T) {

	WorkspaceURL := "xenon.nexa.xenon.work"
	mapd, code := DeleteWorkspace(WorkspaceURL)
	if code != 404 {
		t.Error("test case fail -->", mapd)
	}
}
