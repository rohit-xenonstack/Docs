package helm

//ReleaseConfig is structure for Release
type ReleaseConfig struct {
	WorkspaceURL string `json:"workspace_url" binding:"required"`
	Dry          bool   `json:"dry"`
	Context      string `json:"context"`
	Values       string `json:"values"`
}
