package accounts

import (
	"errors"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
)

// GetAccountForid is a method used to get account details on basis of id
func GetAccountForid(id int) database.Accounts {
	// connecting to db
	db := config.DB

	// intialize variable with type accounts
	var acs []database.Accounts
	// fetching data on basis of id
	db.Where("id= ?", id).Find(&acs)

	// if there is account pass the first element of array
	if len(acs) != 0 {
		return acs[0]
	}
	// if there is no account pass null values
	return database.Accounts{}
}

//==============================================================================

// GetAccountForEmail is a method used to get account details on basis of email
func GetAccountForEmail(email string) (database.Accounts, error) {
	// connecting to db
	db := config.DB

	// intialize variable with type accounts
	var acs []database.Accounts
	// fetching data on basis of email
	db.Where("email=?", email).Find(&acs)

	// if there is account pass the first element of array
	if len(acs) != 0 {
		return acs[0], nil
	}
	// if there is no account pass null values
	return database.Accounts{}, errors.New("no account found")
}

//==============================================================================

// GetAllAccounts is a method used to get all account details
func GetAllAccounts() ([]database.Accounts, error) {
	// connecting to db
	db := config.DB

	// intialize variable with type accounts
	var acs []database.Accounts
	// fetching data from db
	db.Where("role_id=? AND verify_status=?", "user", "verified").Find(&acs)

	// return all accounts
	return acs, nil
}

//==============================================================================

// DeleteAccount is a method used to delete an account
func DeleteAccount(email string) error {
	// connecting to db
	db := config.DB

	//fetch account
	acc, err := GetAccountForEmail(email)
	if err != nil {
		config.Log.Error(err)
		return err
	}
	if acc.ID != 0 && acc.RoleID != "admin" {
		// delete all tokens
		var sessions []database.ActiveSessions
		db.Where("id=?", acc.ID).Find(&sessions)

		//delete from database tables
		row := db.Where("id=?", acc.ID).Delete(&database.Accounts{})
		config.Log.Error("accounts...", row.Error)
		row = db.Where("id=?", acc.ID).Delete(&database.Tokens{})
		config.Log.Error("token...", row.Error)
		row = db.Where("email=?", acc.Email).Delete(&database.Activities{})
		config.Log.Error("activites...", row.Error)
		row = db.Where("id=?", acc.ID).Delete(&database.ActiveSessions{})
		config.Log.Error("sessiom...", row.Error)

	} else {
		return errors.New("you cannot delete admin account")
	}

	return nil
}
