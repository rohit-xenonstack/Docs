package accounts

import (
	"errors"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
)

// ChangePassword is method for updating password
func ChangePassword(id, oldPassword, newPassword string) (int, bool, string) {

	// connecting to db
	db := config.DB

	acc := database.Accounts{}
	db.Where("id=?", id).Find(&acc)

	if !methods.CheckHashForPassword(acc.Password, oldPassword) {
		return 400, false, "please pass valid current password"
	}

	if oldPassword == newPassword {
		return 400, false, "current and New password are same."
	}

	if !methods.CheckPassword(newPassword) {
		return 400, false, "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character."
	}

	// creating hash for new password
	newPassHash := methods.HashForNewPassword(newPassword)

	//updating password in db is there is user with that id passed in parameter
	dbResult := db.Exec("update accounts set password= '" + newPassHash + "' where id= '" + id + "';")
	if dbResult.Error == nil && dbResult.RowsAffected != 0 {
		return 200, true, "Password updated successfully."
	}
	config.Log.Error(dbResult.Error.Error())
	return 200, false, "Unable to change password."
}

// ======================================================================================= //

// UpdateProfile is a method to update name and contact of user
func UpdateProfile(email, name, contact string) error {

	// connecting to db
	db := config.DB

	//update name of user
	var row int64
	if name != "" {
		row = db.Model(&database.Accounts{}).Where("email=?", email).Update("name", name).RowsAffected
	}
	// update contact number of user
	if contact != "" {
		row = db.Model(&database.Accounts{}).Where("email=?", email).Update("contact_no", contact).RowsAffected
	}
	if row == 0 {
		return errors.New("no account found")
	}
	return nil
}

func UserWorkspace(email string) []database.WorkspaceMembers {

	db := config.DB

	data := []database.WorkspaceMembers{}
	db.Where("member_email=?", email).Find(&data)
	return data
}
