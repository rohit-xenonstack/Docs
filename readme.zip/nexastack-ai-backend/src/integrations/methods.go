package integrations

import (
	"encoding/json"
	"strings"
	"sync"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/azures"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"
)

// ListInfrastucture function used for list down the infrastucture integration
func ListInfrastucture(workspace, method, name string, limit, page int) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	db := config.DB
	list := []database.InfraIntegration{}

	// Prepare the query
	query := db.Model(database.InfraIntegration{}) // replace YourModel with your actual struct

	// Split the name and build conditions
	str := strings.Split(name, " ")
	if len(str) > 0 && str[0] != "" {
		query = query.Where("name ILIKE ?", "%"+str[0]+"%")
	}
	for i := 1; i < len(str); i++ {
		query = query.Or("name ILIKE ?", "%"+str[i]+"%")
	}

	// Add method (cloud_type) condition
	if method != "" {
		query = query.Where("cloud_type = ?", method)
	}

	// Count total rows
	var totalRows int64
	query.Count(&totalRows)

	// Apply pagination and fetch results
	err := query.Order("id desc").
		Limit(limit).
		Offset((page - 1) * limit).
		Find(&list).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	var rows int64
	// Apply pagination and fetch results
	err = query.Order("id desc").
		Count(&rows).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}
	// check health of each integration
	var wg sync.WaitGroup
	wg.Add(len(list))
	for i := 0; i < len(list); i++ {
		go healthCheck(&list[i], &wg)
		//convert time to unix
		list[i].AddedAt = list[i].CreatedAt.Unix()
		list[i].UpdateAt = list[i].UpdatedAt.Unix()
	}
	wg.Wait()

	mapd["error"] = false
	mapd["list"] = list
	mapd["total_count"] = rows
	mapd["page"] = page
	mapd["limit"] = limit
	mapd["search"] = name
	return mapd, 200
}

func healthCheck(data *database.InfraIntegration, wg *sync.WaitGroup) {
	defer wg.Done()
	mapd := make(map[string]database.Status)
	if data.Terraform {
		value, err := vault.ViewSecret(data.Workspace, data.ClusterName, "terraform")
		if err != nil {
			mapd["terraform"] = database.Status{
				Msg:    "Please try again",
				Health: 3,
			}
		} else {

			if data.CloudType == "azure" || data.CloudType == "on-prem" {
				valueBytes, _ := json.Marshal(value)
				err = azures.ValidateFile(valueBytes, data.ClusterName)
				if err != nil {
					mapd["terraform"] = database.Status{
						Msg:    err.Error(),
						Health: 3,
					}
				} else {
					mapd["terraform"] = database.Status{
						Msg:    "Terraform Integrated.",
						Health: 2,
					}
				}
			} else {
				mapd["terraform"] = database.Status{
					Msg:    "Wrong cloud type.",
					Health: 1,
				}
			}
		}
	} else {
		mapd["terraform"] = database.Status{
			Msg:    "Terraform Not Integrated.",
			Health: 1,
		}
	}

	data.FrameStatus = mapd
}
