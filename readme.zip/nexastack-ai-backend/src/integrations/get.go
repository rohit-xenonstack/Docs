package integrations

import (
	"encoding/json"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"
)

// GetFile function used for send the file
func GetFile(name, workspace, email string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})

	//connection to DB
	db := config.DB
	infra := database.InfraIntegration{}
	db.Debug().Where("cluster_name=? and workspace=?", name, workspace).Find(&infra)
	if infra.ID == 0 {
		config.Log.Error("error in getting integration from db", nil)
		mapd["error"] = true
		mapd["message"] = "No Integration Found"
		return mapd, 400
	}

	value, err := vault.ViewSecret(infra.Workspace, infra.ClusterName, infra.Framework)
	if err != nil {
		config.Log.Error("error in getting secret from vault", err)

		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	// if framework == "terraform" {
	// 	byteData := util.Template("./src/cloud/template/aws.tmpl", value)
	// 	mapd["file"] = []byte(byteData)
	// 	return mapd, 200
	// }

	byteData, err := json.Marshal(&value)
	if err != nil {
		config.Log.Error("error in marshalling secret", err)
		mapd["error"] = true
		mapd["message"] = "please try again"
		return mapd, 500
	}
	mapd["file"] = byteData
	return mapd, 200
}
