
INSERT INTO roles.role (created_at,updated_at,name,domain,environment) VALUES
(NOW(),NOW(),'admin','workspace',null),
(NOW(),NOW(),'user','workspace',null),
(NOW(),NOW(),'admin','project',null),
(NOW(),NOW(),'user','project',null),
(NOW(),NOW(),'admin','environment','dev'),
(NOW(),NOW(),'user','environment','dev'),
(NOW(),NOW(),'admin','environment','stage'),
(NOW(),NOW(),'user','environment','stage'),
(NOW(),NOW(),'admin','environment','prod'),
(NOW(),NOW(),'user','environment','prod');

INSERT INTO permission (created_at,updated_at,feature,"action") VALUES
(NOW(),NOW(),'all','read'),
(NOW(),NOW(),'all','all');


INSERT INTO role_permission_mapping (created_at,updated_at,permission_id,role_id) VALUES
(NOW(),NOW(),
(select id from roles.permission where "action"='all' limit 1),
(select id from roles.role where name='admin' and domain='workspace' and environment is null limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='read'  limit 1),
(select id from roles.role where name='user' and domain='workspace' and environment is null limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='all' limit 1),
(select id from roles.role where name='admin' and domain='project' and environment is null limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='read' limit 1),
(select id from roles.role where name='user' and domain='project' and environment is null limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='all' limit 1),
(select id from roles.role where name='admin' and domain='environment' and environment = 'dev' limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='read' limit 1),
(select id from roles.role where name='user' and domain='environment' and environment = 'dev' limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='all'  limit 1),
(select id from roles.role where name='admin' and domain='environment' and environment = 'stage' limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='read'  limit 1),
(select id from roles.role where name='user' and domain='environment' and environment = 'stage' limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='all'  limit 1),
(select id from roles.role where name='admin' and domain='environment' and environment = 'prod' limit 1)
),
(NOW(),NOW(),
(select id from roles.permission where "action"='read' limit 1),
(select id from roles.role where name='user' and domain='environment' and environment = 'prod' limit 1)
);


