package signup

import (
	"log"
	"os"
	"testing"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
	_ "github.com/mattn/go-sqlite3"
)

const (
	email string = "test@test.com"
	name  string = "test"
)

var (
	id int
)

func init() {

	os.Remove(os.Getenv("HOME") + "/account-testing.db")
	db, err := gorm.Open("sqlite3", os.Getenv("HOME")+"/account-testing.db")
	if err != nil {

		log.Println(err)
		log.Println("Exit")
		os.Exit(1)
	}
	config.DB = db
	database.CreateDatabaseTables()
}

func TestSignUp(t *testing.T) {

	//test case 1 -> create account only with email
	acc, err := WithEmail(email)
	if err != nil {
		t.Error("test case fail")
	}

	str, _ := Signup(acc)
	if str != "We have sent a confirmation link to your email, please check your email." {
		t.Error("test case fail")
	}

	account := database.Accounts{}
	account.Email = "testint@testcase.com"
	account.VerifyStatus = "not_verified"
	str, _ = Signup(account)
	if str != "We have sent a confirmation link to your email, please check your email." {
		t.Error("test case fail")
	}

	//test case 2 -> account already exit
	acc, err = WithEmail(email)
	if err != nil {
		t.Error("test case fail")
	}

	//test case 3 -> verify account
	str, _ = SendCodeAgain(email)
	if str != "Verification code sent." {
		t.Error("test case fail", str)
	}
	//test case 3 -> verify account but account not exist
	str, _ = SendCodeAgain("email")
	if str != "Email doesn't exists." {
		t.Error("test case fail", str)
	}
}
