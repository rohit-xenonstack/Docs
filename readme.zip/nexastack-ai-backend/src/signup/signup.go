package signup

import (
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
)

// new is a constant to remove duplicacy code
const new string = "new"

// Signup is a method for creating account if account is already not preset and send mail for verification
func Signup(newAccount database.Accounts) (string, bool) {

	// connecting to db
	db := config.DB

	//Checking for email whether already exists or not
	var oldAccount []database.Accounts
	db.Where("email = ?", newAccount.Email).Find(&oldAccount)

	// if no account is there with that email
	if len(oldAccount) == 0 {
		// initializing newSignup account
		initNewAccount(&newAccount)
		// creating new account
		db.Create(&newAccount)

		// Get the user role ID
		var role models.Role
		if err := config.DB.Where("name = ?", "user").First(&role).Error; err != nil {
			config.Log.Error("Error finding user role:", err)
			return "", false
		}

		// Create user role mapping
		userRoleMapping := models.AccountRoleMapping{
			AccountID: uint(newAccount.ID),
			RoleID:    uint(role.Id),
			ProjectId: 0,
		}

		if err := config.DB.Create(&userRoleMapping).Error; err != nil {
			config.Log.Error("Error creating user role mapping:", err)
		}

		// sending mail when account status is new
		if newAccount.AccountStatus == new {
			//send verification mail
			go mail.SendVerifyMail(newAccount)
			return "We have sent a confirmation link to your email, please check your email.", true
		}
		return "Registered successfully.", true
	}

	// when there is account with that email but status is new means not verified
	if oldAccount[0].AccountStatus == "new" {
		// delete previous account details
		db.Where("id=?", oldAccount[0].ID).Delete(&database.Accounts{})
		oldAccount[0].Name = newAccount.Name
		oldAccount[0].Password = newAccount.Password
		// creating account with new details
		db.Create(&oldAccount[0])
		//send verification mail
		go mail.SendVerifyMail(oldAccount[0])
		return "We have sent a confirmation link to your email, please check your email.", true
	}
	return "Email Already Exists.", false
}

//==============================================================================

// WithEmail is a method used to create account with email only
func WithEmail(email string) (database.Accounts, error) {
	// connecting to db
	db := config.DB

	//check account already exist
	acc := []database.Accounts{}
	db.Where("email=?", email).Find(&acc)
	if len(acc) != 0 {
		return acc[0], nil
	}

	// new account structure
	newAccount := database.Accounts{
		Email:         email,
		VerifyStatus:  "not_verified",
		AccountStatus: "new",
		CreationDate:  time.Now().Unix(),
	}

	// initialize new account
	initNewAccount(&newAccount)
	// create account in database
	db.Create(&newAccount)
	return newAccount, nil
}
