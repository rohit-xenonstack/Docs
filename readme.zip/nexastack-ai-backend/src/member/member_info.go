package member

import (
	"encoding/json"
	"strconv"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
)

// SaveMemberInfo is a method to save member information of invited member through invite link token
func SaveMemberInfo(token, password, wsID, name, contact string) (int, map[string]interface{}) {
	mapd := make(map[string]interface{})

	// connect to database
	db := config.DB

	//Checking token in database

	tok, err := verifytoken.CheckToken(token)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Invalid Join Link."
		return 404, mapd
	}
	config.Log.Debug(tok)
	//check token task
	if tok.TokenTask != "invite_link" {
		mapd["error"] = true
		mapd["message"] = "Invalid Join Link."
		return 404, mapd
	}

	//fetch account informtion on basis of id
	acc := accounts.GetAccountForid(tok.Userid)

	var member []database.WorkspaceMembers
	db.Select("role").Where("member_email= ? AND workspace_id= ?", acc.Email, wsID).Find(&member)
	if len(member) <= 0 {
		mapd["error"] = true
		mapd["message"] = "You have not been invited in this workspace"
		return 404, mapd
	}

	//update details
	db.Model(&database.Accounts{}).Where("id=?", tok.Userid).Updates(map[string]interface{}{"name": name, "contact_no": contact, "password": password, "creation_date": time.Now().Unix(), "account_status": "active", "verify_status": "verified"})
	db.Model(&database.WorkspaceMembers{}).Where("member_email=?", acc.Email).Update("joined", time.Now().Unix())
	var work database.Workspaces
	db.Select("team_name").Where("workspace_id=?", wsID).Find(&work)
	// delete used tokens
	go verifytoken.DeleteToken(token)

	if work.TeamName == "" {
		work.TeamName = wsID
	}

	acc.Name = name
	err, mapd = AssignDefaultProjectToWorkspaceMember(wsID, mapd, acc)
	if err != nil {
		return 400, mapd
	}

	//generate jwt Token
	mapd, err = jwtToken.JwtToken(acc, wsID, member[0].Role, "", 0)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return 503, mapd
	}
	mapd["name"] = name
	mapd["role_id"] = acc.RoleID
	mapd["email"] = acc.Email
	mapd["id"] = acc.ID
	mapd["workspace_id"] = wsID
	mapd["workspace_name"] = work.TeamName
	mapd["workspace_role"] = member[0].Role
	return 200, mapd
}

func AssignDefaultProjectToWorkspaceMember(wsID string, mapd map[string]interface{}, acc database.Accounts) (error, map[string]interface{}) {
	const NexastackDefaultProjectPrefix = "nexastack_"
	var project models.Project
	err := config.DB.Debug().Model(&models.Project{}).Where("name=?", NexastackDefaultProjectPrefix+wsID).Find(&project).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "No project found for this workspace"
		return err, mapd
	}

	// Assign project to account
	projectToAccountMapping := models.ProjectToAccountMapping{
		ProjectID: project.ID,
		AccountID: acc.ID,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	err = config.DB.Debug().Create(&projectToAccountMapping).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to assign project to account"
		return err, mapd
	}

	// get role by account id
	var roleMapping models.AccountRoleMapping
	err = config.DB.Debug().Model(&models.AccountRoleMapping{}).Where("account_id=?", acc.ID).Find(&roleMapping).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to get role mapping by account id"
		return err, mapd
	}

	// create default project member
	// get role by role id
	var role models.Role
	err = config.DB.Debug().Model(&models.Role{}).Where("id=?", roleMapping.RoleID).Find(&role).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to get role by role id"
		return err, mapd
	}

	err = ProjectSendInvite(models.TempProjectMembers{
		Email:       acc.Email,
		RoleId:      int(role.Id),
		Role:        role.Name,
		Name:        acc.Name,
		UserId:      acc.ID,
		ProjectId:   strconv.Itoa(project.ID),
		Workspace:   wsID,
		ProjectName: project.Name,
		Status:      "Member added",
		EnvironmentAccess: []models.TempEnvironmentPermissions{
			{
				Environment: "development",
				Permissions: []string{"read"},
			},
		},
	})
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to create default project member"
		return err, mapd
	}
	return nil, nil
}
func ProjectSendInvite(tempProjectMember models.TempProjectMembers) (err error) {
	var projectMember models.ProjectMembers

	// Copy data from temp struct to actual struct
	projectMember.ID = tempProjectMember.ID
	projectMember.Role = tempProjectMember.Role
	projectMember.RoleId = tempProjectMember.RoleId
	projectMember.Email = tempProjectMember.Email
	projectMember.Name = tempProjectMember.Name
	projectMember.Status = "Invitation Sent"
	projectMember.UserId = tempProjectMember.UserId
	projectMember.ProjectId = tempProjectMember.ProjectId
	projectMember.Workspace = tempProjectMember.Workspace
	projectMember.ProjectName = tempProjectMember.ProjectName

	// Process environment access with JSON conversion
	projectMember.EnvironmentAccess = make([]models.EnvironmentPermissions, len(tempProjectMember.EnvironmentAccess))
	for i, env := range tempProjectMember.EnvironmentAccess {
		projectMember.EnvironmentAccess[i].ID = env.ID
		projectMember.EnvironmentAccess[i].MemberID = env.MemberID
		projectMember.EnvironmentAccess[i].Environment = env.Environment

		// Marshal permissions to JSON string
		permissionsJSON, err := json.Marshal(env.Permissions)
		if err != nil {
			return err
		}
		projectMember.EnvironmentAccess[i].Permissions = append(projectMember.EnvironmentAccess[i].Permissions, string(permissionsJSON))
	}

	// Connect to database
	db := config.DB

	// Check if project exists
	var projectCount int64
	if err = db.Model(&models.Project{}).Where("id = ?", projectMember.ProjectId).Count(&projectCount).Error; err != nil {
		config.Log.Error("Failed to check project existence:", err)
		return
	}

	// Create new project member record
	err = db.Create(&projectMember).Error
	if err != nil {
		config.Log.Error("Failed to create project member:", err)
		return
	}

	return nil
}
