package member

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
)

// MemberSignup is a method to send invite link again if user is already invited by owner
func MemberSignup(email, wsID string) (int, string) {
	if !CheckMember(email, wsID) {
		return 404, "You have not been invited in this workspace."
	}

	// connecting to db
	db := config.DB
	owner := []database.WorkspaceMembers{}
	db.Where("role=? AND workspace_id=?", "owner", wsID).Find(&owner)

	//fetch account on basis of email
	acc, err := accounts.GetAccountForEmail(email)
	if err != nil {
		config.Log.Debug(err)
		return 404, err.Error()
	}

	if acc.AccountStatus == "active" {
		return 209, "You have already registered."
	}
	ownerAcc, err := accounts.GetAccountForEmail(owner[0].MemberEmail)
	if err != nil {
		config.Log.Debug(err)
		return 404, err.Error()
	}

	// send mail
	go mail.SendInviteLink(acc, wsID, ownerAcc.Email, ownerAcc.Name)
	return 200, "We have sent a link to your email, Please check your email."
}

// CheckMember is a method to check user belongs to that workspace
func CheckMember(email, wsID string) bool {
	// connecting to db
	db := config.DB

	var count int64
	db.Model(&database.WorkspaceMembers{}).Where("member_email= ? AND workspace_id= ?", email, wsID).Count(&count)
	return count != 0
}
