package member

import (
	"log"
	"testing"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
)

func TestSaveMemberInfo(t *testing.T) {

	contact := "9876543211"
	token := database.Tokens{}
	db := config.DB

	db.Where("token_task='invite_link'").Find(&token)
	log.Println(token)
	//Test case 1 -> right token pass
	code, mapd := SaveMemberInfo(token.Token, methods.HashForNewPassword(password), wsid, "name", contact)
	if mapd["message"].(string) != "Internal Server Error" {
		t.Error("test case fail", mapd, code)
	}

	//test case 2 -> wrong token pass
	code, mapd = SaveMemberInfo(token.Token, password, wsid, "name", contact)
	if code == 200 {
		t.Error("test case fail", mapd)
	}
}
