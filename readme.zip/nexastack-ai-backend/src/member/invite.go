package member

import (
	"errors"
	"log"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/signup"
	"github.com/jinzhu/gorm"
)

// output structure for invite member requests
type out struct {
	Role    string `json:"role"`
	Email   string `json:"email"`
	Message string `json:"message"`
}

type status struct {
	Add    []out `json:"add"`
	NotAdd []out `json:"not_add"`
}

type WorkSpaceMember struct {
	Email string `json:"email" binding:"required"`
	Role  string `json:"role" binding:"required"`
}

// Invite is a method to send invite mail to valid Users
func Invite(data interface{}, ownerEmail, ownerName, wsID string) (int, map[string]interface{}) {
	emails := data.([]WorkSpaceMember)

	mapd := make(map[string]interface{})

	//connect to db
	db := config.DB

	add := make([]out, 0)
	notadd := make([]out, 0)
	for i := 0; i < len(emails); i++ {
		if emails[i].Email == ownerEmail {
			notadd = append(notadd, out{
				Role:    "owner",
				Email:   ownerEmail,
				Message: "This person is already in your workspace",
			})
			continue
		}
		if emails[i].Email == "" {
			continue
		}
		acc, err := signup.WithEmail(strings.ToLower(emails[i].Email))
		if err != nil {
			config.Log.Error(err)
			continue
		}
		var count int64
		db.Model(&database.WorkspaceMembers{}).Where("workspace_id= ? AND member_email= ?", wsID, acc.Email).Count(&count)
		if count == 0 {
			if acc.VerifyStatus == "not_verified" {
				// add in workspace member
				db.Create(&database.WorkspaceMembers{
					WorkspaceID: wsID,
					MemberEmail: acc.Email,
					Role:        emails[i].Role,
				})
				//send invite mail
				go mail.SendInviteLink(acc, wsID, ownerEmail, ownerName)
			} else {
				// add in workspace member
				db.Create(&database.WorkspaceMembers{
					WorkspaceID: wsID,
					MemberEmail: acc.Email,
					Role:        emails[i].Role,
					Joined:      time.Now().Unix(),
				})
				// send login link mail
				go mail.SendLoginLink(acc, wsID, ownerEmail, ownerName)
			}
			add = append(add, out{
				Role:    emails[i].Role,
				Email:   acc.Email,
				Message: "Successfully invited",
			})

			var roles models.Role
			err := config.DB.Debug().Raw(`SELECT * FROM roles.role r WHERE r.id IN (
				select rpm.role_id from roles.role_permission_mapping rpm where rpm.permission_id in  
				(SELECT p.id from roles.permission p where p."action" in (?))
			 ) AND r.domain = 'workspace'`, GetRolePermission(emails[i].Role)).Scan(&roles).Error
			if err != nil {
				config.Log.Error(err)
				log.Println(err)
			}

			accountRoleMapping := models.AccountRoleMapping{
				AccountID: uint(acc.ID),
				RoleID:    uint(roles.Id),
				ProjectId: int(0),
			}

			if err := config.DB.Debug().Create(&accountRoleMapping).Error; err != nil {
				config.Log.Error(err)
			}
		} else {
			if acc.VerifyStatus == "not_verified" {

				add = append(add, out{
					Role:    emails[i].Role,
					Email:   acc.Email,
					Message: "Successfully invited",
				})
				//send invite mail
				go mail.SendInviteLink(acc, wsID, ownerEmail, ownerName)
			} else {

				notadd = append(notadd, out{
					Role:    emails[i].Role,
					Email:   acc.Email,
					Message: "This person is already in your workspace",
				})
			}
		}
	}

	mapd["error"] = false
	mapd["status"] = status{
		Add:    add,
		NotAdd: notadd,
	}
	return 200, mapd
}

//===========================================================================//

// MemList is a structure to send member details in member list request
type MemList struct {
	Id     int    `json:"id"`
	Name   string `json:"name"`
	Email  string `json:"email"`
	Role   string `json:"role"`
	Joined int64  `json:"joined"`
}

// List is a method to fetch all member in a workspace from database
func List(db *gorm.DB, workspace string) ([]MemList, error) {
	list := make([]MemList, 0)

	// member list from database
	wsMem := []database.WorkspaceMembers{}
	err := db.Debug().Where("workspace_id= ?", workspace).Order("joined asc").Find(&wsMem).Error
	if err != nil {
		return nil, err
	}
	config.Log.Debug("1st query..")

	for i := 0; i < len(wsMem); i++ {
		// fetch account details on basis of email
		acc, err := accounts.GetAccountForEmail(wsMem[i].MemberEmail)
		if err != nil {
			config.Log.Error(err)
			continue
		}
		// append final details
		list = append(list, MemList{
			Id:     acc.ID,
			Name:   acc.Name,
			Email:  acc.Email,
			Role:   wsMem[i].Role,
			Joined: wsMem[i].Joined,
		})
	}

	return list, nil
}

//===========================================================================//

// Check is a method to check member joined the worksapce from database
func Check(workspace, email string) error {

	db := config.DB
	// check member in database
	var count int64
	db.Model(&database.WorkspaceMembers{}).Where("member_email = ? AND workspace_id= ? AND joined <> 0", email, workspace).Count(&count)
	if count == 0 {
		return errors.New("member not invited or joined the workspace")
	}
	return nil
}

//===========================================================================//

// Delete is a method to delete member in a workspace from database
func Delete(workspace, email string) error {
	// connecting to db
	db := config.DB

	// delete member from database
	count := db.Where("member_email = ? AND workspace_id= ?", email, workspace).Delete(&database.WorkspaceMembers{}).RowsAffected
	if count == 0 {
		return errors.New("this member is not invited in the workspace")
	}

	return nil
}

func GetRolePermission(data string) (permissions []string) {
	if strings.EqualFold(data, "admin") {
		permissions = []string{"all"}
	} else if strings.EqualFold(data, "owner") {
		permissions = []string{"all"}
	} else {
		permissions = []string{"read"}
	}
	return
}
