package member

import (
	"testing"
)

func TestMemberSignUp(t *testing.T) {

	code, str := MemberSignup("testing1@testing.com", wsid)
	if str != "You have already registered." {
		t.Error("test case fail", code)
	}
}

// func TestDelete(t *testing.T)

// 	//test case -> when user email exist
// 	err := Delete(wsid, "testing@testing.com")
// 	if err.Error() != "nats: invalid connection" {
// 		t.Error("test case fail", err)
// 	}

// 	//test case -> when user email not exist
// 	err = Delete(wsid, "testing@testing.com")
// 	if err == nil {
// 		t.Error("test case fail", err)
// 	}
// }
