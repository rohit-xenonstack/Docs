package member

import (
	"log"
	"os"
	"testing"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
	_ "github.com/mattn/go-sqlite3"
)

const (
	email    string = "test@test.com"
	wsemail  string = "test1@test.com"
	name     string = "test"
	password string = "Admin#123"
	wsid     string = "test"
)

var (
	id int
)

func init() {

	os.Remove(os.Getenv("HOME") + "/account-testing.db")
	db, err := gorm.Open("sqlite3", os.Getenv("HOME")+"/account-testing.db")
	if err != nil {
		log.Println(err)
		log.Println("Exit")
		os.Exit(1)
	}
	config.DB = db
	//create table
	database.CreateDatabaseTables()
	acc := []database.Accounts{}
	//save data in account table
	acc = append(acc, database.Accounts{
		Name:          name,
		Email:         email,
		VerifyStatus:  "verified",
		AccountStatus: "active"})
	acc = append(acc, database.Accounts{
		Name:          name,
		Email:         wsemail,
		VerifyStatus:  "verified",
		AccountStatus: "active"})
	db.Create(&acc[0])
	db.Create(&acc[1])
	id = acc[1].ID

	workspace := database.Workspaces{}
	workspace.WorkspaceID = wsid
	workspace.TeamName = wsid
	workspace.TeamType = wsid
	db.Create(&workspace)

	wsMember := database.WorkspaceMembers{}
	wsMember.MemberEmail = wsemail
	wsMember.Role = "owner"
	wsMember.WorkspaceID = wsid
	db.Create(&wsMember)
}

func TestInvite(t *testing.T) {

	newmember := []WorkSpaceMember{}

	newmember = append(newmember, WorkSpaceMember{
		Email: wsemail,
		Role:  "Admin",
	})
	newmember = append(newmember, WorkSpaceMember{
		Email: "testing@testing.com",
		Role:  "Admin",
	})
	newmember = append(newmember, WorkSpaceMember{
		Email: "testing@testing.com",
		Role:  "Admin",
	})
	newmember = append(newmember, WorkSpaceMember{
		Email: "testing1@testing.com",
		Role:  "Admin",
	})
	code, _ := Invite(newmember, wsemail, "", wsid)
	if code != 200 {
		t.Error("test case fail")
	}
}

func TestList(t *testing.T) {

	//test case 1 -> When wrong wrokspace pass
	db := config.DB
	list, err := List(db, "xenon")
	if len(list) != 0 {
		t.Error("test case fail", list, err)
	}

	//test case 2 -> When right wrokspace pass

	list, err = List(db, wsid)
	if len(list) == 0 {
		t.Error("test case fail", list, err)
	}
}
func TestCheck(t *testing.T) {

	//test case -> when user note invited
	err := Check(wsemail, wsid)
	if err == nil {
		t.Error("test case fail", err)
	}

	//test case -> when user invite
	err = Check("testing@testing.com", wsid)
	if err == nil {
		t.Error("test case fail", err)
	}
}
