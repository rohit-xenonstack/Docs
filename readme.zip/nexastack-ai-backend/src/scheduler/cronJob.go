// +build !test

package scheduler

import (
	"strconv"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"github.com/robfig/cron"
)

// Start is a function to start cronjobs
func Start() {
	update()
	DeleteUsers()
	c := cron.New()
	c.AddFunc("0 20 * * *", DeleteUsers)
	c.AddFunc("0 20 * * *", update)
	c.Start()
}

func update() {
	db := config.DB
	acc := []database.Accounts{}

	db.Find(&acc)

	for i := 0; i < len(acc); i++ {
		db.Exec(`UPDATE activities SET "name" ='` + acc[i].Name + `' WHERE email='` + acc[i].Email + `';`)
	}
}
func DeleteUsers() {
	db := config.DB
	db.Exec("delete from accounts where verify_status='not_verified' AND creation_date<" + strconv.FormatInt(time.Now().Unix()-86400, 10) + ";")
	db.Exec("delete from workspace_members where member_email not in (select email from accounts);")
}
