package api

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/minioBucket"

	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

const BucketNameRequired = "Bucket name is required."

type Bucket struct {
	BucketName string `json:"bucket_name" binding:"required"`
}

// CreateMinioBucket godoc
// @Summary Create a new Minio bucket
// @Description Create a new Minio bucket with the specified name
// @Tags Storage
// @Accept json
// @Produce json
// @Param bucket body Bucket true "Bucket details"
// @Success 200 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/buckets [post]
func CreateMinioBucket(c *gin.Context) {

	var bucket Bucket
	if err := c.BindJSON(&bucket); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err)
		c.JSON(401, gin.H{"error": true, "message": BucketNameRequired})
		return
	}

	// extract jwt claims
	claims := jwt.ExtractClaims(c)
	//fetch id from claims
	email, ok := claims["email"]
	if !ok {
		c.JSON(401, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}
	config.Log.Debug(MinioEmailLog, email)

	// Call the CreateMinioBucket function
	err := minioBucket.CreateMinioBucket(bucket.BucketName)
	if err != nil {
		config.Log.Error(err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to create Minio bucket",
		})
		return
	}

	c.JSON(200, gin.H{
		"error":   false,
		"message": "Minio bucket created successfully",
	})

}

// UploadFile godoc
// @Summary Upload a file to Minio bucket
// @Description Upload a file to a specific Minio bucket
// @Tags Storage
// @Accept multipart/form-data
// @Produce json
// @Param bucket_name formData string true "Bucket Name"
// @Param email formData string true "User Email"
// @Param workspace formData string true "Workspace ID"
// @Param upload_file formData file true "File to upload"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 401 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/buckets/upload [post]
func UploadFile(c *gin.Context) {
	var fileData struct {
		BucketName string `form:"bucket_name" validate:"required"`
		Email      string `form:"email"  validate:"required"`
		Workspace  string `form:"workspace" validate:"required"`
	}
	mapd := make(map[string]interface{})
	mapd["error"] = false
	if err := c.Bind(&fileData); err != nil {
		mapd["error"] = true
		mapd["message"] = "Invalid request body"
		c.JSON(400, mapd)
		return
	}

	// Extract JWT claims
	claims := jwt.ExtractClaims(c)

	email, ok := claims["email"]
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}
	config.Log.Debug("====email====", email)

	wsid, ok := claims["workspace"].(string)
	config.Log.Debug("workspace====", wsid)
	config.Log.Debug("filedata workspace", fileData.Workspace)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}
	if wsid != fileData.Workspace {
		mapd["error"] = true
		mapd["message"] = "Please enter valid workspace."
		c.JSON(500, mapd)
		return
	}

	// connect to database
	//Check workspace present in database
	var WorkID database.Workspaces
	err := config.DefaultDb.Debug().Model(&database.Workspaces{}).Where("workspace_id = ?", wsid).First(&WorkID).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Workspace does not match"
		c.JSON(500, mapd)
		return
	}

	//check user is member of that workspace
	member := []database.WorkspaceMembers{}
	err = config.DefaultDb.Debug().Model(&database.Workspaces{}).Where("member_email= ? AND workspace_id= ?", fileData.Email, WorkID.WorkspaceID).Find(&member).Error
	if err != nil {
		//when not a member
		mapd["error"] = true
		mapd["message"] = "The user does not belong to this workspace."
		c.JSON(401, mapd)
		return
	}

	config.Log.Debug("reached 0...")

	// Get the file from the request
	file, header, err := c.Request.FormFile("upload_file")
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "No file provided"

		c.JSON(400, mapd)
		return
	}

	config.Log.Debug("reached 1...")

	// Call the main function to insert file in Minio
	err = minioBucket.InsertFileInMinio(fileData.BucketName, file, header)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to upload file"
		c.JSON(500, mapd)
		return
	}

	config.Log.Debug("reached 2...")

	mapd["error"] = false
	mapd["message"] = "File uploaded successfully"
	mapd["file"] = header.Filename

	c.JSON(200, mapd)
}

// GetMinioBucketContents godoc
// @Summary Get contents of a Minio bucket
// @Description Get a list of all objects in a specific Minio bucket
// @Tags Storage
// @Accept json
// @Produce json
// @Param bucket body Bucket true "Bucket details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/buckets/contents [get]
func GetMinioBucketContents(c *gin.Context) {

	var bucket Bucket
	if err := c.BindJSON(&bucket); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": BucketNameRequired})
		return
	}

	// extract jwt claims
	claims := jwt.ExtractClaims(c)
	//fetch id from claims
	email, ok := claims["email"]
	if !ok {
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}
	config.Log.Error(MinioEmailLog, email)

	// Call the GetMinioBucketContents function
	contents, err := minioBucket.GetMinioBucketContents(bucket.BucketName)
	if err != nil {
		config.Log.Error(err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to get Minio bucket contents",
		})
		return
	}

	c.JSON(200, gin.H{
		"error":    false,
		"message":  "Minio bucket contents retrieved successfully",
		"contents": contents,
	})

}

// GetFilesInFolder godoc
// @Summary Get files in a folder
// @Description Get a list of files in a specific folder within a Minio bucket
// @Tags Storage
// @Accept json
// @Produce json
// @Param bucket body Bucket true "Bucket details"
// @Success 200 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/buckets/folder [get]
func GetFilesInFolder(c *gin.Context) {

	bucket, folderName, shouldReturn := BindPayloadAndGetFolderName(c)
	if shouldReturn {
		return
	}

	// Call the GetFilesInFolder function
	files, err := minioBucket.GetFilesInFolder(bucket.BucketName, folderName)
	if err != nil {
		config.Log.Error(err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to get files in folder",
		})
		return
	}

	c.JSON(200, gin.H{
		"error":   false,
		"message": "Files in folder retrieved successfully",
		"files":   files,
	})

}

func BindPayloadAndGetFolderName(c *gin.Context) (Bucket, string, bool) {
	var bucket Bucket

	if err := c.BindJSON(&bucket); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": BucketNameRequired})
		return Bucket{

			// extract jwt claims
		}, "", true
	}

	claims := jwt.ExtractClaims(c)
	//fetch id from claims
	email, ok := claims["email"]
	if !ok {
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return Bucket{}, "", true
	}
	config.Log.Debug(MinioEmailLog, email)

	// Get the folder name from the URL
	folderName := c.Param("folderName")
	return bucket, folderName, false
}

// DeleteMinioObject godoc
// @Summary Delete an object from Minio bucket
// @Description Delete a specific object from a Minio bucket
// @Tags Storage
// @Accept json
// @Produce json
// @Param bucket body Bucket true "Bucket details"
// @Success 200 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/buckets/object [delete]
func DeleteMinioObject(c *gin.Context) {

	bucket, folderName, shouldReturn := BindPayloadAndGetFolderName(c)
	if shouldReturn {
		return
	}
	fileName := c.Param("fileName")

	// Call the DeleteMinioObject function
	err := minioBucket.DeleteMinioObject(bucket.BucketName, folderName, fileName)
	if err != nil {
		config.Log.Error(err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to delete object",
		})
		return
	}

	c.JSON(200, gin.H{
		"error":   false,
		"message": "Object deleted successfully",
	})

}
