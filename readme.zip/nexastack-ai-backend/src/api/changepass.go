package api

import (
	"fmt"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// ChangePasswordEp is a api handler to change password of a account
func ChangePasswordEp(c *gin.Context) {
	// handler panic and Alerts
	defer util.Panic()

	// defining type for fetching password from body of post request
	type NewPassword struct {
		OldPassword string `json:"old_password" form:"password" binding:"required"`
		NewPassword string `json:"new_password" form:"password" binding:"required"`
	}

	var newPass NewPassword
	// binding body json with above variable and checking error
	if err := c.BindJSON(&newPass); err != nil {
		c.JSON(400, gin.H{"error": true, "message": "Password is required field."})
		return
	}

	// extracting jwt claims for getting user id
	claims := jwt.ExtractClaims(c)

	// passing new password and id and in return getting status code, msg and error
	code, ok, msg := accounts.ChangePassword(fmt.Sprint(claims["id"]), newPass.OldPassword, newPass.NewPassword)

	// record activity
	activity := database.Activities{
		Email:        claims["email"].(string),
		ActivityName: "change password",
		Name:         claims["name"].(string),
		ClientIP:     c.ClientIP(),
		ClientAgent:  c.Request.Header.Get("User -Agent"),
		Timestamp:    time.Now().Unix(),
	}

	// update activity status and reason
	if code == 200 {
		activity.Status = "pass"
	} else {
		activity.Status = "fail"
		activity.Reason = msg
	}

	activities.RecordActivity(activity)

	// return response
	c.JSON(code, gin.H{"error": !ok, "message": msg})
}
