//go:build !test
// +build !test

package api

import (
	"net/http"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// TokenUpgradeRequest represents the request body for upgrading a token
type TokenUpgradeRequest struct {
	ProjectID   int    `json:"project_id"`
	Environment string `json:"environment"`
	Workspace   string `json:"workspace"`
}

// UpgradeToken godoc
// @Summary Upgrade JWT token with additional information
// @Description Upgrade the current JWT token with project, environment, and workspace information
// @Tags Authentication
// @Accept json
// @Produce json
// @Param upgrade body TokenUpgradeRequest true "Token upgrade details"
// @Success 200 {object} map[string]interface{} "Success"  Example: { "error": false, "expire": "2025-04-08T21:47:55+05:30", "token": "" }
// @Failure 400 {object} map[string]interface{} "Bad request"
// @Failure 401 {object} map[string]interface{} "Unauthorized"
// @Router /v1/upgrade_token [post]
func UpgradeToken(c *gin.Context) {
	config.Log.Info("UpgradeToken function called")
	// Handle panic and alerts
	defer util.Panic()

	// Parse request body
	var req TokenUpgradeRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error":   true,
			"message": "Invalid request body",
		})
		return
	}

	// Extract current claims from token
	claims := jwt.ExtractClaims(c)
	if claims == nil {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error":   true,
			"message": "Invalid or expired token",
		})
		return
	}

	// Create new claims map with existing claims
	newClaims := make(map[string]interface{})
	for key, value := range claims {
		newClaims[key] = value
	}

	// Add new fields if provided
	if req.ProjectID != 0 {
		newClaims["project_id"] = req.ProjectID
	}
	if req.Environment != "" {
		newClaims["environment"] = req.Environment
	}
	if req.Workspace != "" {
		newClaims["workspace"] = req.Workspace
	}

	// Generate new token with updated claims
	mapd, err := jwtToken.JwtRefreshToken(newClaims)
	if err != nil {
		config.Log.Error("Error generating new token: ", err)
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   true,
			"message": "Failed to generate new token",
		})
		return
	}

	// Return the new token
	c.JSON(http.StatusOK, mapd)
}
