//go:build !test
// +build !test

package api

import (
	"net/http"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"

	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// MemberSignup is a structure for binding data from body during member signup request
type MemberSignup struct {
	Workspace string `json:"workspace" binding:"required"`
	Email     string `json:"email" binding:"required"`
}

// MemberSignupEp is an api handler
// It is used to send invite link on mail if user is invited by the owner
func MemberSignupEp(c *gin.Context) {
	var mem MemberSignup
	if err := c.BindJSON(&mem); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err.Error())
		c.JSON(400, gin.H{"error": true, "message": "Email and Workspace are required fields."})
		return
	}

	if !methods.ValidateEmail(mem.Email) {
		// if there is some error passing bad status code
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Please enter valid email id."})
		return
	}

	// send again invite mail to user
	code, msg := member.MemberSignup(strings.ToLower(mem.Email), mem.Workspace)
	c.JSON(code, gin.H{
		"error":   code != 200,
		"message": msg,
	})
}

//========================================================================//

// TokenPassword is a structure for binding data from body during set new password request
type TokenPassword struct {
	Name      string `json:"name" binding:"required"`
	Contact   string `json:"contact" binding:"required"`
	Password  string `json:"password" binding:"required"`
	Token     string `json:"token" binding:"required"`
	Workspace string `json:"workspace" binding:"required"`
}

// MemberRegistration is an api handler
// It is used for saving member information in database
// but before saving using invite token member is verified
func MemberRegistration(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	var tp TokenPassword
	if err := c.BindJSON(&tp); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": "name, contact, password, token and workspace are required field."})
		return
	}

	// check password is valid
	if !methods.CheckPassword(tp.Password) {
		c.JSON(400, gin.H{"error": true, "message": "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character."})
		return
	}

	// update password in database
	code, mapd := member.SaveMemberInfo(tp.Token, methods.HashForNewPassword(tp.Password), tp.Workspace, strings.Title(tp.Name), tp.Contact)
	if code == 200 {
		// recording user activity of reseting password
		activities.RecordActivity(database.Activities{Email: mapd["email"].(string),
			ActivityName: "registration",
			Name:         mapd["name"].(string),
			Status:       "pass",
			ClientIP:     c.ClientIP(),
			ClientAgent:  c.Request.Header.Get("User-Agent"),
			Timestamp:    time.Now().Unix()})
	}
	c.JSON(code, mapd)
}
