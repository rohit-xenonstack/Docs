//go:build !test
// +build !test

package api

import (
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// WorkSpaceMembers is a array of structure for binding data from body during invite member request
type WorkSpaceMembers []struct {
	Email  string `json:"email" binding:"required"`
	Role   string `json:"role" binding:"required"`
	RoleId int    `json:"role_id"`
}

// InviteWorkspaceMembers is an api handler to send mail to members who are invited
func InviteWorkspaceMembers(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)

	// fetching data from request body
	var members WorkSpaceMembers
	if err := c.BindJSON(&members); err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": "Bad Request."})
		return
	}

	// save emails in string array
	wsID, ok := claims["workspace"]
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": LoginAgainMessage})
		return
	}
	ownerEmail, ok := claims["email"]
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": LoginAgainMessage})
		return
	}
	ownerName, ok := claims["name"]
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": LoginAgainMessage})
		return
	}

	// save emails in string array
	emails := make([]member.WorkSpaceMember, 0)
	mapd := make(map[string]interface{}, 0)
	for i := 0; i < len(members); i++ {
		_, ok = mapd[members[i].Email]
		if !ok {
			role := strings.ToLower(members[i].Role)
			if role != "admin" {
				role = "user"
			}
			emails = append(emails, member.WorkSpaceMember{
				Email: members[i].Email,
				Role:  role,
			})
			mapd[members[i].Email] = true
		}
	}
	// empty this map
	for k := range mapd {
		delete(mapd, k)
	}

	//send invite or login link to users
	code, mapd := member.Invite(emails, ownerEmail.(string), ownerName.(string), wsID.(string))
	activities.RecordActivity(database.Activities{Email: claims["email"].(string),
		ActivityName: "add member",
		Name:         claims["name"].(string),
		Status:       "pass",
		ClientIP:     c.ClientIP(),
		ClientAgent:  c.Request.Header.Get(ClientAgentUser),
		Timestamp:    time.Now().Unix()})
	c.JSON(code, mapd)
}

//===============================================================================

// WorkspaceMembers is api handler to list members of a workspace
func WorkspaceMembers(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)

	workspace, ok := claims["workspace"]
	if !ok {
		c.JSON(501, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}
	db := config.DB
	// fetch workspace members from database
	members, err := member.List(db, workspace.(string))
	if err != nil {
		c.JSON(501, gin.H{"error": true, "message": "Unable to read data from db"})
		return
	}
	c.JSON(200, gin.H{
		"error":       false,
		"members":     members,
		"total_count": len(members),
	})
}

//===============================================================================

// WorkspaceCheckMember is api handler to check member joined the workspace
func WorkspaceCheckMember(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	// fetch workspace id from jwt claims
	claims := jwt.ExtractClaims(c)
	workspace, ok := claims["workspace"]
	if !ok {
		c.JSON(501, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}
	// check member in workspace from database
	err := member.Check(workspace.(string), c.Query("email"))
	if err != nil {
		c.JSON(501, gin.H{"error": true,
			"message": err.Error()})
		return
	}
	c.JSON(200, gin.H{
		"error": false,
	})
}

//======================================================================================

// DeleteWorkspaceMember is an API handler for deleting member from a workspace
func DeleteWorkspaceMember(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)
	workspace, ok := claims["workspace"]
	if !ok {
		c.JSON(501, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	// check member in workspace from database
	err := member.Delete(workspace.(string), c.Query("email"))
	if err != nil {
		activities.RecordActivity(database.Activities{Email: claims["email"].(string),
			ActivityName: "delete member",
			Name:         claims["name"].(string),
			Status:       "fail",
			Reason:       err.Error(),
			ClientIP:     c.ClientIP(),
			ClientAgent:  c.Request.Header.Get(ClientAgentUser),
			Timestamp:    time.Now().Unix()})
		c.JSON(501, gin.H{"error": true, "message": err.Error()})
		return
	}
	activities.RecordActivity(database.Activities{Email: claims["email"].(string),
		ActivityName: "delete member",
		Name:         claims["name"].(string),
		Status:       "pass",
		ClientIP:     c.ClientIP(),
		ClientAgent:  c.Request.Header.Get(ClientAgentUser),
		Timestamp:    time.Now().Unix()})

	c.JSON(200, gin.H{
		"error":   false,
		"message": "Member deleted Successfully.",
	})
}

// WorkspaceList is an api hanler for the list user workspace
func WorkspaceList(c *gin.Context) {
	//handler panic and Alerts
	defer util.Panic()

	//extracting jwt claims for getting user id
	claims := jwt.ExtractClaims(c)
	// passing new password and id and in return getting status code, msg and error
	data := accounts.UserWorkspace(claims["email"].(string))
	c.JSON(200, gin.H{"error": false, "list": data})
}
