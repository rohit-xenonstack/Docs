//go:build !test
// +build !test

package api

import (
	"net/http"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/signup"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// SignupData defining structure for binding signup data

// SignupEndpoint godoc
// @Summary User signup
// @Description Create a new user account
// @Tags Authentication
// @Accept json
// @Produce json
// @Param signup body models.SignupData true "Signup details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/signup [post]
func SignupEndpoint(c *gin.Context) {

	defer util.Panic()

	// binding body data
	var signupdt models.SignupData
	if err := c.BindJSON(&signupdt); err != nil {
		// if there is some error passing bad status code
		c.JSON(400, gin.H{"error": true, "message": "email, password and name are required fields."})
		return
	}

	// // Check if password and confirm password match
	// if signupdt.Password != signupdt.ConfirmPassword {
	// 	c.JSON(400, gin.H{"error": true, "message": "Password and confirm password do not match."})
	// 	return
	// }

	//saving data in account structure
	acs := database.Accounts{}
	acs.Name = signupdt.Name
	if !methods.ValidateEmail(strings.ToLower(signupdt.Email)) {
		c.JSON(400, gin.H{"error": true, "message": "Please pass valid email address"})
		return
	}
	acs.Email = strings.ToLower(signupdt.Email)
	acs.ContactNo = signupdt.Contact
	acs.VerifyStatus = "not_verified"
	acs.CreationDate = time.Now().Unix()
	acs.CreateAt = time.Now()
	//validation check on password
	if !methods.CheckPassword(signupdt.Password) {
		c.JSON(400, gin.H{"error": true, "message": "Minimum eight characters, at least one uppercase letter, at least one lowercase letter, at least one number and at least one special character."})
		return
	}

	// save hash password insted of normal password
	acs.Password = methods.HashForNewPassword(signupdt.Password)

	// passing account details to save in db and send mail for verification
	msg, ok := signup.Signup(acs)

	// attach role to created mail
	if ok {
		err := AssignRoleToUser(signupdt)
		if err != nil {
			config.Log.Error("Error assigning role to user:", err)
			c.JSON(500, gin.H{"error": true, "message": "Failed to assign role to user."})
			return
		}
	}

	if !ok {
		c.JSON(400, gin.H{"error": !(ok), "message": msg})
		return
	}
	c.JSON(200, gin.H{"error": !(ok), "message": msg})
}

//==============================================================================

// Email defining structure for binding send code again data
type Email struct {
	Email string `json:"email" binding:"required"`
}

// SendCodeAgain godoc
// @Summary Resend verification code
// @Description Resend email verification code to user
// @Tags Authentication
// @Accept json
// @Produce json
// @Param email body Email true "User email"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/signup/resend-code [post]
func SendCodeAgain(c *gin.Context) {

	defer util.Panic()

	// binding request body data
	var email Email
	if err := c.BindJSON(&email); err != nil {
		// if there is some error passing bad status code
		c.JSON(400, gin.H{"error": true, "message": "Email is required."})
		return
	}

	if !methods.ValidateEmail(email.Email) {
		// if there is some error passing bad status code
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Please enter valid email id."})
		return
	}

	// passing passed email to sendcodeagain function and in response boolean or message
	msg, ok := signup.SendCodeAgain(strings.ToLower(email.Email))

	// checking boolean is true or false
	if !ok {
		// if false sending unable to send code again
		c.JSON(400, gin.H{"error": !(ok), "message": msg})
		return
	}

	c.JSON(200, gin.H{"error": !(ok), "message": msg})
}

//==============================================================================

// AssignRoleToUser assigns appropriate role to a new user based on their role type
func AssignRoleToUser(signupdt models.SignupData) (err error) {
	// Get the user's account by email
	var account database.Accounts
	if err = config.DB.Where("email = ?", strings.ToLower(signupdt.Email)).First(&account).Error; err != nil {
		config.Log.Error("Failed to find account:", err)
		return
	}

	// Get the appropriate role based on the role type
	var role models.Role
	query := config.DB.Where("domain = ?", "workspace")

	if signupdt.Role == "admin" {
		query = query.Where("name = ?", "admin")
	} else {
		query = query.Where("name = ?", "user")
	}

	if err = query.First(&role).Error; err != nil {
		config.Log.Error("Failed to find role:", err)
		return
	}

	// Create the role mapping
	roleMapping := models.AccountRoleMapping{
		AccountID: uint(account.ID),
		RoleID:    uint(role.Id),
		ProjectId: 0,
	}

	// Save the role mapping
	if err = config.DB.Create(&roleMapping).Error; err != nil {
		config.Log.Error("Failed to create role mapping:", err)
		return
	}

	config.Log.Info("Successfully assigned role to user:", account.Email)
	return
}
