package api

import (
	"fmt"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/compute"
	"git.xenonstack.com/nexa-platform/accounts/src/helm"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/resource"

	// "git.xenonstack.com/nexa-platform/accounts/src/compute"

	// "git.xenonstack.com/nexa-platform/accounts/src/resource"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"helm.sh/helm/v3/pkg/action"
)

func UpdateResourcesPreset(c *gin.Context) {
	var requestBody database.ComputeConfig

	if err := c.ShouldBindJSON(&requestBody); err != nil {
		c.JSON(400, gin.H{"error": "Invalid JSON input"})
		return
	}

	mapd, db, WorkID, err, _ := GetWorkId(c)
	if err != nil {
		return
	}

	//check user is member of that workspace
	member := []database.WorkspaceMembers{}
	db.Where("member_email= ? AND workspace_id= ?", requestBody.UserEmail, WorkID.WorkspaceID).Find(&member)
	if len(member) == 0 {
		//when not a member
		mapd["error"] = true
		mapd["message"] = "The user does not belong to this workspace."
		c.JSON(401, mapd)
		return
	}

	companyFQDN := WorkID.WorkspaceID

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(WorkID.WorkspaceID, ".")
	workspace := wsURLParts[0]
	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)

	// Set kube-config
	actionConfig, code, err := kubernetes.SetConfig(nameSpace)
	if err != nil {
		config.Log.Error("kubeconfig set :- ", err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(code, mapd)
		return
	}

	var bucketName = config.Conf.MinioJupyterHelm.BucketName
	var fileName = config.Conf.MinioJupyterHelm.FileName
	//Downlaod the Charts
	resource.DownlaodCharts(bucketName, fileName)

	//fetchChart from charts and modifiy values.yaml
	chart, val, err := helm.FetchChart(companyFQDN, workspace, nameSpace)
	// fmt.Printf("===chart:%v, val====:%s\n", chart, val)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = false
		mapd["message"] = err.Error()
		c.JSON(404, val)
		return
	}

	// cpu:
	//   limit:      # This is equivalent to `limits.cpu`
	//   guarantee:  # This is equivalent to `requests.cpu`

	// memory:
	//   limit:      # This is equivalent to `limits.memory`
	//   guarantee:  # This is equivalent to `requests.memory`

	// new presetvalue structure according to the multiuser jupyterhub helm

	// Get preset values for the specified ResourcesPreset
	presetValue, ok := PresetValues[requestBody.ResourcesPreset]
	fmt.Printf("====PresetValues====: %s", presetValue)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = "Invalid ResourcesPreset value"
		c.JSON(400, mapd)
		return
	}

	releaseName := strings.Replace(workspace, "_", "-", -1) + "-" + branch
	userPodNamePrefix := "jupyter-"

	// Check nodes with the specific label for available resources
	nodes, err := kubernetes.GetNodesNames(workspace)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to retrieve nodes"
		c.JSON(500, mapd)
		return
	}
	var suitableNode string
	for _, node := range nodes {
		// Check if the specified node has sufficient resources
		if !kubernetes.HasSufficientResources(node, map[string]string{
			"cpu":    fmt.Sprintf("%.2f", presetValue["cpu"]["guarantee"]),
			"memory": presetValue["memory"]["guarantee"].(string),
		}) {
			mapd["error"] = true
			mapd["message"] = "Resources not available on the specified node"
			c.JSON(500, mapd)
			return
		} else {
			suitableNode = node

		}
	}

	println("Suitable Node is ======", suitableNode)

	if suitableNode == "" {
		mapd["error"] = true
		mapd["message"] = "Resources not available on any node with the specified label"
		c.JSON(500, mapd)
		return
	}

	// Check if release exists
	getCli := action.NewGet(actionConfig)
	getCli.Version = 0 // Get the latest revision of the release
	release, err := getCli.Run(releaseName)
	if err != nil {
		config.Log.Error(err)
		// Release does not exist, install it
		iCli, _, values := InitialiseICLI(actionConfig, nameSpace, releaseName, presetValue, "NewInstall")
		_, err = iCli.Run(chart, values)
		if err != nil {
			config.Log.Error(err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			c.JSON(500, mapd)
			return
		}
	} else {
		if release != nil {
			_, uCli, values := InitialiseICLI(actionConfig, nameSpace, releaseName, presetValue, "Upgrade")
			_, err = uCli.Run(releaseName, chart, values)
			if err != nil {
				config.Log.Error(err)
				mapd["error"] = true
				mapd["message"] = err.Error()
				c.JSON(500, mapd)
				return
			}

		} else {
			iCli, _, values := InitialiseICLI(actionConfig, nameSpace, releaseName, presetValue, "NewInstall")
			_, err = iCli.Run(chart, values)
			if err != nil {
				config.Log.Error(err)
				mapd["error"] = true
				mapd["message"] = err.Error()
				c.JSON(500, mapd)
				return
			}
		}
	}

	// Check if user pod exists before restarting

	podExists, err := kubernetes.CheckPodExists(nameSpace, userPodNamePrefix)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(500, mapd)
		return
	}

	if podExists {
		// Restart user pod if it exists
		err = kubernetes.RestartPod(nameSpace, userPodNamePrefix)
		if err != nil {
			config.Log.Error(err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			c.JSON(500, mapd)
			return
		}
	}

	var existingComputeConfig database.ComputeConfig
	err = db.Model(&database.ComputeConfig{}).Where("workspace_id = ? AND user_email = ? AND node_runtime = ?", wsURLParts[0], requestBody.UserEmail, requestBody.NodeRuntime).First(&existingComputeConfig).Error
	if err != nil {
		// If no existing compute config is found, create a new one
		db.Create(&database.ComputeConfig{
			WorkspaceID:      wsURLParts[0],
			UserEmail:        requestBody.UserEmail,
			NodeRuntime:      requestBody.NodeRuntime,
			ArchitectureType: requestBody.ArchitectureType,
			AccessMode:       requestBody.AccessMode,
			ResourcesPreset:  requestBody.ResourcesPreset,
			NoteBookIngress:  Http + nameSpace + NoteBookIngressNexaStackURL,
			NodeName:         suitableNode,
			CreateAt:         time.Now(),
		})
	} else {
		// If an existing compute config is found, update it with the new values
		existingComputeConfig.NodeRuntime = requestBody.NodeRuntime
		existingComputeConfig.ArchitectureType = requestBody.ArchitectureType
		existingComputeConfig.AccessMode = requestBody.AccessMode
		existingComputeConfig.ResourcesPreset = requestBody.ResourcesPreset
		existingComputeConfig.NoteBookIngress = Http + nameSpace + NoteBookIngressNexaStackURL
		existingComputeConfig.UpdatedAt = time.Now()
		db.Model(&existingComputeConfig).Updates(map[string]interface{}{
			"NodeRuntime":      existingComputeConfig.NodeRuntime,
			"ArchitectureType": existingComputeConfig.ArchitectureType,
			"AccessMode":       existingComputeConfig.AccessMode,
			"ResourcesPreset":  existingComputeConfig.ResourcesPreset,
			"NoteBookIngress":  existingComputeConfig.NoteBookIngress,
			"NodeName":         existingComputeConfig.NodeName,
			"UpdatedAt":        existingComputeConfig.UpdatedAt,
		})
	}

	mapd["message"] = "ResourcesPreset successfully updated in values.yaml"
	mapd["ingress of jupyter"] = Http + nameSpace + NoteBookIngressNexaStackURL
	c.JSON(200, mapd)

}

func InitialiseICLI(actionConfig *action.Configuration, nameSpace string, releaseName string, presetValue map[string]map[string]interface{}, operationType string) (iCli *action.Install, uCli *action.Upgrade, values map[string]interface{}) {

	if strings.EqualFold(operationType, "NewInstall") {
		iCli = action.NewInstall(actionConfig)
		iCli.Namespace = nameSpace
		iCli.ReleaseName = releaseName
		iCli.DryRun = false
	} else if strings.EqualFold(operationType, "Upgrade") {
		uCli := action.NewUpgrade(actionConfig)
		uCli.Namespace = nameSpace
		uCli.DryRun = false
	}

	values = map[string]interface{}{
		"singleuser": map[string]interface{}{
			"cpu": map[string]interface{}{
				"guarantee": presetValue["cpu"]["guarantee"],
				"limit":     presetValue["cpu"]["limit"],
			},
			"memory": map[string]interface{}{
				"guarantee": presetValue["memory"]["guarantee"],
				"limit":     presetValue["memory"]["limit"],
			},
		},
		"ingress": map[string]interface{}{
			"hosts": []string{
				nameSpace + NexaStackSubBasePath,
			},
			"tls": []map[string]interface{}{
				{
					"secretName": releaseName + "-tls",
					"hosts": []string{
						nameSpace + NexaStackSubBasePath,
					},
				},
			},
		},
	}
	return iCli, uCli, values
}

// SonarQube: end-ignore

func DeleteCompute(c *gin.Context) {
	modelId := c.Param("computeId")
	mapd := make(map[string]interface{})
	mapd["error"] = false
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	// fmt.Println("====workspace name =====:", wsid)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(wsid, ".")
	workspace := wsURLParts[0]
	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
	releaseName := workspace + "-" + branch
	email, ok := claims["email"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	// Check if the email belongs to the same workspace
	db := config.DB
	var workspaces database.WorkspaceMembers
	if err := db.Where("workspace_id = ? AND member_email = ?", workspace, email).First(&workspaces).Error; err != nil {
		mapd["error"] = true
		mapd["message"] = "Email does not belong to the same workspace"
		c.JSON(401, mapd)
		return

	}

	// Get deployment details
	var computes database.ComputeConfig
	if err := db.Where("id = ? AND workspace_id = ? ", modelId, workspace).First(&computes).Error; err != nil {
		mapd["error"] = true
		mapd["message"] = "Compute not found"
		c.JSON(404, mapd)
		return
	}

	// Uninstall using marketplace helper
	result, code := compute.UninstallCompute(nameSpace, releaseName)
	if code != 200 {
		mapd["error"] = true
		mapd["result"] = result
		mapd["message"] = "Failed to delete the deployed model"
		c.JSON(code, result)
		return
	}

	// Delete from database
	if err := db.Delete(&computes).Error; err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to delete compute from database"
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	mapd["message"] = "Compute deleted successfully"
	c.JSON(200, mapd)
}

// Functionality to get computes list present in workspace
func GetComputeList(c *gin.Context) {
	mapd, db, WorkID, err, _ := GetWorkId(c)
	if err != nil {
		return
	}

	// Get compute list with is_deleted = false condition
	computeList := []database.ComputeConfig{}
	err = db.Where("workspace_id = ? AND is_deleted = ?", WorkID.WorkspaceID, false).Find(&computeList).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to get compute list"
		c.JSON(500, mapd)
		return
	}

	if len(computeList) == 0 {
		mapd["error"] = true
		mapd["message"] = "No compute configurations found"
		c.JSON(404, mapd)
		return
	}

	mapd["computeList"] = computeList
	c.JSON(200, mapd)
}

func GetWorkId(c *gin.Context) (map[string]interface{}, *gorm.DB, database.Workspaces, error, bool) {
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return nil, nil, database.Workspaces{}, nil, true
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false

	// connect to database
	db := config.DB
	// Check workspace present in database
	var WorkID database.Workspaces
	err := db.Model(&database.Workspaces{}).Where(WorkspaceIdWhereCondition, wsid).First(&WorkID).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = WorkspaceNotMatchMessage
		c.JSON(500, mapd)
		return nil, nil, database.Workspaces{}, nil, true
	}
	return mapd, db, WorkID, err, false
}

// Functionality to get jupyterhub API Token and username
func GetPodDetails(c *gin.Context) {

	var podDetails struct {
		Workspace string `json:"workspace" validate:"required"`
	}
	mapd := make(map[string]interface{})
	mapd["error"] = false
	if err := c.Bind(&podDetails); err != nil {
		mapd["error"] = true
		mapd["message"] = "Invalid request body"
		c.JSON(400, mapd)
		return
	}
	mapd, _, WorkID, err, _ := GetWorkId(c)
	if err != nil {
		return
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(WorkID.WorkspaceID, ".")
	workspace := wsURLParts[0]
	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)

	// releaseName := strings.Replace(workspace, "_", "-", -1) + "-" + branch
	userPodNamePrefix := "jupyter-"

	// Call the GetPodInfo function to get jupyterhub_api_token and username
	podInfo, err := kubernetes.GetPodInfo(nameSpace, userPodNamePrefix)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(500, mapd)
		return
	}

	c.JSON(200, podInfo)

}

func PodStatus(c *gin.Context) {
	var podDetails struct {
		Workspace string `json:"workspace" validate:"required"`
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false
	if err := c.Bind(&podDetails); err != nil {
		mapd["error"] = true
		mapd["message"] = "Invalid request body"
		c.JSON(400, mapd)
		return
	}
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	if wsid != podDetails.Workspace {
		mapd["error"] = true
		mapd["message"] = "Workspace not valid!"
		c.JSON(500, mapd)
		return
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(wsid, ".")
	workspace := wsURLParts[0]
	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
	// connect to database
	db := config.DB
	// Check workspace present in database
	var WorkID database.Workspaces
	err := db.Debug().Model(&database.Workspaces{}).Where(WorkspaceIdWhereCondition, wsid).First(&WorkID).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = WorkspaceNotMatchMessage
		c.JSON(500, mapd)
		return
	}
	releaseName := strings.Replace(workspace, "_", "-", -1) + "-" + branch

	podRunning, err := kubernetes.CheckPodStatus(nameSpace, releaseName)
	if err != nil {
		config.Log.Error(err)
		return
	}

	if !podRunning {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = "Pods are not running"
		c.JSON(500, mapd)
		return
	}
	mapd["error"] = false
	mapd["message"] = "Pods running successfully"
	c.JSON(200, mapd)
}
