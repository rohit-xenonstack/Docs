package api

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
)

// ListGKEClusterNames godoc
// @Summary List GKE clusters
// @Description Get list of available GKE clusters
// @Tags GKE
// @Produce json
// @Success 200 {array} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/gcp/clusters [get]
func ListGKEClusterNames(c *gin.Context) {
	vault, err := NewVaultClient()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   true,
			"message": fmt.Sprintf("Failed to initialize Vault client: %v", err),
		})
		return
	}

	secretList, err := vault.Client.Logical().List("gcp/")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":   true,
			"message": fmt.Sprintf("Failed to list clusters: %v", err),
		})
		return
	}

	var clusterNames []string
	if secretList != nil && secretList.Data != nil {
		if customers, ok := secretList.Data["keys"].([]interface{}); ok {
			for _, customer := range customers {
				customerID := customer.(string)
				clusterList, err := vault.Client.Logical().List(fmt.Sprintf("gcp/%s/", customerID))
				if err != nil {
					continue
				}
				if clusterList != nil && clusterList.Data != nil {
					if clusters, ok := clusterList.Data["keys"].([]interface{}); ok {
						for _, cluster := range clusters {
							clusterName := strings.TrimSuffix(cluster.(string), "/")
							_, err := vault.GetClusterInfo(customerID, clusterName)
							if err == nil {
								clusterNames = append(clusterNames, clusterName)
							}
						}
					}
				}
			}
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"error":         false,
		"cluster_names": clusterNames,
	})
}

// OnboardGKE godoc
// @Summary Onboard GKE cluster
// @Description Onboard a new GKE cluster
// @Tags GKE
// @Accept multipart/form-data
// @Produce json
// @Param cluster_name formData string true "Cluster name"
// @Param credentials_file formData file true "GCP credentials file"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/gcp/onboard [post]
func OnboardGKE(c *gin.Context) {
	// Extract cluster_name from form data
	clusterName := c.PostForm("cluster_name")
	if clusterName == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "cluster_name is required"})
		return
	}

	// Get the uploaded file
	file, err := c.FormFile("credentials_file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "credentials_file is required"})
		return
	}

	// Open and read the file
	f, err := file.Open()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": true, "message": "Failed to open uploaded file"})
		return
	}
	defer f.Close()

	credentials, err := ioutil.ReadAll(f)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": true, "message": "Failed to read uploaded file"})
		return
	}

	// Call the updated OnboardGKECluster function
	err = OnboardGKECluster(clusterName, credentials)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": true, "message": err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"error": false, "message": "Cluster onboarded successfully"})
}
