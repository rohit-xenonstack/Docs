package api

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"github.com/hashicorp/vault/api"
	"golang.org/x/oauth2/google"
	"google.golang.org/api/container/v1"
	"google.golang.org/api/option"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
)

type GCPCredentials struct {
	Type                string `json:"type"`
	ProjectID           string `json:"project_id"`
	PrivateKeyID        string `json:"private_key_id"`
	PrivateKey          string `json:"private_key"`
	ClientEmail         string `json:"client_email"`
	ClientID            string `json:"client_id"`
	AuthURI             string `json:"auth_uri"`
	TokenURI            string `json:"token_uri"`
	AuthProviderCertURL string `json:"auth_provider_x509_cert_url"`
	ClientCertURL       string `json:"client_x509_cert_url"`
}

type ClusterInfo struct {
	CustomerID    string `json:"customer_id"`
	ClusterName   string `json:"cluster_name"`
	ProjectID     string `json:"project_id"`
	Location      string `json:"location"`
	Endpoint      string `json:"endpoint"`
	MasterVersion string `json:"master_version"`
	NodeCount     int    `json:"node_count"`
}

type VaultClient struct {
	Client *api.Client
}

func NewVaultClient() (*VaultClient, error) {
	config := api.DefaultConfig()
	config.Address = os.Getenv("VAULT_ADDR")
	client, err := api.NewClient(config)
	if err != nil {
		return nil, err
	}
	token := os.Getenv("VAULT_TOKEN")
	client.SetToken(token)
	return &VaultClient{Client: client}, nil
}

func (v *VaultClient) StoreCredentials(customerID, clusterName string, credentials []byte) error {
	path := fmt.Sprintf("gcp/%s/%s/credentials", customerID, clusterName)
	data := map[string]interface{}{
		"credentials": string(credentials),
	}
	_, err := v.Client.Logical().Write(path, data)
	return err
}

func (v *VaultClient) GetCredentials(customerID, clusterName string) ([]byte, error) {
	path := fmt.Sprintf("gcp/%s/%s/credentials", customerID, clusterName)
	secret, err := v.Client.Logical().Read(path)
	if err != nil {
		return nil, err
	}
	if secret == nil || secret.Data == nil {
		return nil, fmt.Errorf("no credentials found at %s", path)
	}
	credStr, ok := secret.Data["credentials"].(string)
	if !ok {
		return nil, fmt.Errorf("invalid credential format")
	}
	return []byte(credStr), nil
}

func (v *VaultClient) StoreClusterInfo(info ClusterInfo) error {
	path := fmt.Sprintf("gcp/%s/%s/info", info.CustomerID, info.ClusterName)
	data := map[string]interface{}{
		"project_id":     info.ProjectID,
		"location":       info.Location,
		"endpoint":       info.Endpoint,
		"master_version": info.MasterVersion,
		"node_count":     info.NodeCount,
	}
	_, err := v.Client.Logical().Write(path, data)
	return err
}

func (v *VaultClient) GetClusterInfo(customerID, clusterName string) (*ClusterInfo, error) {
	path := fmt.Sprintf("gcp/%s/%s/info", customerID, clusterName)
	secret, err := v.Client.Logical().Read(path)
	if err != nil {
		return nil, err
	}
	if secret == nil || secret.Data == nil {
		return nil, fmt.Errorf("no cluster info found at %s", path)
	}

	info := &ClusterInfo{
		CustomerID:  customerID,
		ClusterName: clusterName,
	}
	if projectID, ok := secret.Data["project_id"].(string); ok {
		info.ProjectID = projectID
	}
	if location, ok := secret.Data["location"].(string); ok {
		info.Location = location
	}
	if endpoint, ok := secret.Data["endpoint"].(string); ok {
		info.Endpoint = endpoint
	}
	if masterVersion, ok := secret.Data["master_version"].(string); ok {
		info.MasterVersion = masterVersion
	}
	if nodeCount, ok := secret.Data["node_count"].(float64); ok {
		info.NodeCount = int(nodeCount)
	}

	return info, nil
}

func VerifyGCPCredentials(credentials []byte, projectID, location, clusterName string) error {
	ctx := context.Background()

	containerService, err := container.NewService(ctx, option.WithCredentialsJSON(credentials))
	if err != nil {
		return fmt.Errorf("invalid credentials - failed to create container service: %v", err)
	}

	clusterPath := fmt.Sprintf("projects/%s/locations/%s/clusters/%s", projectID, location, clusterName)
	clusterReq := containerService.Projects.Locations.Clusters.Get(clusterPath)
	_, err = clusterReq.Do()
	if err != nil {
		return fmt.Errorf("invalid credentials - failed to verify access to cluster %s: %v", clusterName, err)
	}

	return nil
}

func OnboardGKECluster(clusterName string, credentials []byte) error {
	vault, err := NewVaultClient()
	if err != nil {
		config.Log.Error("Failed to initialize Vault client: %v", err)
		return fmt.Errorf("failed to initialize Vault client: %v", err)
	}

	var gcpCreds GCPCredentials
	if err := json.Unmarshal(credentials, &gcpCreds); err != nil {
		config.Log.Error("Failed to parse credentials JSON: %v", err)
		return fmt.Errorf("invalid credentials JSON: %v", err)
	}

	projectID := gcpCreds.ProjectID
	if projectID == "" {
		return fmt.Errorf("project_id missing in credentials JSON")
	}
	customerID := DeriveCustomerID(gcpCreds.ClientEmail)
	if customerID == "" {
		return fmt.Errorf("could not derive customer_id from client_email")
	}

	ctx := context.Background()
	containerService, err := container.NewService(ctx, option.WithCredentialsJSON(credentials))
	if err != nil {
		config.Log.Error("Failed to create container service: %v", err)
		return fmt.Errorf("failed to create container service: %v", err)
	}

	location, err := FindClusterLocation(containerService, projectID, clusterName)
	if err != nil {
		config.Log.Error("Failed to determine cluster location: %v", err)
		return fmt.Errorf("failed to determine cluster location: %v", err)
	}

	config.Log.Error("Verifying GCP credentials for %s/%s", customerID, clusterName)
	err = VerifyGCPCredentials(credentials, projectID, location, clusterName)
	if err != nil {
		config.Log.Error("GCP credentials verification failed: %v", err)
		return fmt.Errorf("GCP credentials verification failed: %v", err)
	}
	config.Log.Error("GCP credentials verified successfully")

	clusterReq := containerService.Projects.Locations.Clusters.Get(
		fmt.Sprintf("projects/%s/locations/%s/clusters/%s", projectID, location, clusterName),
	)
	cluster, err := clusterReq.Do()
	if err != nil {
		config.Log.Error("Failed to get cluster details: %v", err)
		return fmt.Errorf("failed to get cluster details: %v", err)
	}

	err = CheckKubernetesCluster(cluster.Endpoint, credentials, cluster.MasterAuth.ClusterCaCertificate)
	if err != nil {
		config.Log.Error("Failed to verify Kubernetes cluster: %v", err)
		return fmt.Errorf("failed to verify Kubernetes cluster: %v", err)
	}

	existingCreds, err := vault.GetCredentials(customerID, clusterName)
	if err != nil {
		config.Log.Error("Error checking existing credentials in Vault: %v", err)
	}

	existingInfo, err := vault.GetClusterInfo(customerID, clusterName)
	if err != nil {
		config.Log.Error("Error checking existing cluster info in Vault: %v", err)
	}

	if existingCreds != nil && existingInfo != nil {
		config.Log.Error("Cluster %s for customer %s is already onboarded", clusterName, customerID)
		config.Log.Error("Stored Cluster Info for %s/%s: Endpoint=%s, Location=%s, MasterVersion=%s, NodeCount=%d, ProjectID=%s",
			customerID, clusterName, existingInfo.Endpoint, existingInfo.Location, existingInfo.MasterVersion, existingInfo.NodeCount, existingInfo.ProjectID)
		return nil
	}

	config.Log.Error("Proceeding with onboarding cluster %s for customer %s", clusterName, customerID)

	config.Log.Error("Attempting to store credentials for %s/%s", customerID, clusterName)
	err = vault.StoreCredentials(customerID, clusterName, credentials)
	if err != nil {
		config.Log.Error("Failed to store credentials: %v", err)
		return fmt.Errorf("failed to store credentials: %v", err)
	}

	info := ClusterInfo{
		CustomerID:    customerID,
		ClusterName:   clusterName,
		ProjectID:     projectID,
		Location:      location,
		Endpoint:      cluster.Endpoint,
		MasterVersion: cluster.CurrentMasterVersion,
		NodeCount:     GetTotalNodeCount(cluster),
	}
	config.Log.Error("Attempting to store cluster info for %s/%s", customerID, clusterName)
	err = vault.StoreClusterInfo(info)
	if err != nil {
		config.Log.Error("Failed to store cluster info: %v", err)
		return fmt.Errorf("failed to store cluster info: %v", err)
	}
	storedInfo, err := vault.GetClusterInfo(customerID, clusterName)
	if err != nil {
		config.Log.Error("Failed to retrieve cluster info from Vault: %v", err)
	} else {
		config.Log.Error("Stored Cluster Info for %s/%s: Endpoint=%s, Location=%s, MasterVersion=%s, NodeCount=%d, ProjectID=%s",
			customerID, clusterName, storedInfo.Endpoint, storedInfo.Location, storedInfo.MasterVersion, storedInfo.NodeCount, storedInfo.ProjectID)
	}

	config.Log.Debug("Successfully onboarded GKE cluster %s for customer %s", clusterName, customerID)
	return nil
}

func CheckKubernetesCluster(clusterEndpoint string, credentials []byte, caCert string) error {
	ctx := context.Background()
	token, err := GenerateGKEAuthToken(ctx, credentials)
	if err != nil {
		config.Log.Error("Failed to generate auth token: %v", err)
		return fmt.Errorf("failed to generate auth token: %v", err)
	}

	caData, err := base64.StdEncoding.DecodeString(caCert)
	if err != nil {
		config.Log.Error("Failed to decode CA certificate: %v", err)
		return fmt.Errorf("failed to decode CA certificate: %v", err)
	}

	configRest := &rest.Config{
		Host:        "https://" + clusterEndpoint,
		BearerToken: token,
		TLSClientConfig: rest.TLSClientConfig{
			Insecure: false,
			CAData:   caData,
		},
	}

	clientset, err := kubernetes.NewForConfig(configRest)
	if err != nil {
		config.Log.Error("Failed to create Kubernetes client: %v", err)
		return fmt.Errorf("invalid kubeconfig - failed to create client: %v", err)
	}

	serverVersion, err := clientset.Discovery().ServerVersion()
	if err != nil {
		config.Log.Error("Failed to get cluster version: %v", err)
		return fmt.Errorf("failed to verify cluster connectivity: %v", err)
	}
	config.Log.Debug("Connected to Kubernetes cluster version %s", serverVersion.GitVersion)

	pods, err := clientset.CoreV1().Pods("").List(ctx, metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Failed to get pods: %v", err)
		return fmt.Errorf("failed to get pods: %v", err)
	}
	config.Log.Debug("Found %d pods in the cluster", len(pods.Items))
	for _, pod := range pods.Items {
		config.Log.Error("Pod: %s, Namespace: %s, Status: %s",
			pod.Name, pod.Namespace, pod.Status.Phase)
	}

	services, err := clientset.CoreV1().Services("").List(ctx, metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Failed to get services: %v", err)
		return fmt.Errorf("failed to get services: %v", err)
	}
	config.Log.Debug("Found %d services in the cluster", len(services.Items))

	deployments, err := clientset.AppsV1().Deployments("").List(ctx, metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Failed to get deployments: %v", err)
		return fmt.Errorf("failed to get deployments: %v", err)
	}
	config.Log.Debug("Found %d deployments in the cluster", len(deployments.Items))

	return nil
}

func GenerateGKEAuthToken(ctx context.Context, credentials []byte) (string, error) {
	ts, err := google.CredentialsFromJSON(ctx, credentials, "https://www.googleapis.com/auth/cloud-platform")
	if err != nil {
		return "", fmt.Errorf("failed to create token source from credentials: %v", err)
	}

	token, err := ts.TokenSource.Token()
	if err != nil {
		return "", fmt.Errorf("failed to fetch token: %v", err)
	}

	return token.AccessToken, nil
}

func GetTotalNodeCount(cluster *container.Cluster) int {
	count := 0
	for _, np := range cluster.NodePools {
		count += int(np.InitialNodeCount)
	}
	return count
}

func DeriveCustomerID(clientEmail string) string {
	parts := strings.Split(clientEmail, "@")
	if len(parts) != 2 {
		return ""
	}
	return parts[1]
}

func FindClusterLocation(service *container.Service, projectID, clusterName string) (string, error) {
	parent := fmt.Sprintf("projects/%s/locations/-", projectID)
	resp, err := service.Projects.Locations.Clusters.List(parent).Do()
	if err != nil {
		return "", fmt.Errorf("failed to list clusters: %v", err)
	}

	for _, cluster := range resp.Clusters {
		if cluster.Name == clusterName {
			return cluster.Location, nil
		}
	}
	return "", fmt.Errorf("cluster %s not found in project %s", clusterName, projectID)
}
