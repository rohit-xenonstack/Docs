//go:build !test
// +build !test

package api

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// ViewProfile is a api handler for viewing user profile
func ViewProfile(c *gin.Context) {
	config.Log.Info("ViewProfile function called")

	//handler panic and Alerts
	defer util.Panic()

	// extracting jwt claims
	claims := jwt.ExtractClaims(c)

	// fetch profile on basis of email
	acc, err := accounts.GetAccountForEmail(claims["email"].(string))
	if err != nil {
		c.JSON(500, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"error":   false,
		"account": acc,
	})
}

// UpdateData is a structure for binding update profile data
type UpdateData struct {
	Name    string `json:"name"`
	Contact string `json:"contact"`
}

// UpdateProfile is a api handler for updating user profile
func UpdateProfile(c *gin.Context) {
	config.Log.Info("UpdateProfile function called")

	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)

	email, ok := claims["email"]
	if !ok {
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Please login again",
		})
		return
	}

	// fetching data from request body
	var data UpdateData
	if err := c.BindJSON(&data); err != nil {
		config.Log.Error(err.Error())
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass valid name and contact number",
		})
		return
	}

	// update name and contact of user
	err := accounts.UpdateProfile(email.(string), data.Name, data.Contact)
	if err != nil {
		config.Log.Error(err.Error())
		c.JSON(500, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"error":   false,
		"message": "Profile Updated Succesfully",
	})
}

// Activity is an api handler for for get user activity
func Activity(c *gin.Context) {
	config.Log.Info("Activity function called")
	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)

	email, ok := claims["email"].(string)
	if !ok {
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Please login again",
		})
		return
	}
	act, err := activities.GetLoginActivities(email)
	c.JSON(200, gin.H{
		"error": err,
		"list":  act,
	})
}

func TestGinContexts(c *gin.Context) {
	config.Log.Info("TestGinContexts function called")
	test := c.Query("hi")

	config.Log.Debug(test)

	c.JSON(200, gin.H{
		"message": "Gin Context Test Passed",
	})
}
