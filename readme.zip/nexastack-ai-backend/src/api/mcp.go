package api

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/kr/pretty"
)

// MCPRepositoriesResponse represents the response structure for GetMCPRepositories
// @Description Response containing paginated MCP repository data
type MCPRepositoriesResponse struct {
	Data  []models.MCPRepositoryResponse `json:"data"`
	Limit int                            `json:"limit"`
	Page  int                            `json:"page"`
	Total int64                          `json:"total"`
}

// FetchMCPDataStreamHandler godoc
// @Summary Stream MCP data
// @Description Stream MCP repository data using Server-Sent Events (SSE)
// @Tags MCP
// @Produce text/event-stream
// @Success 200 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/mcp/fetch-data [get]
func FetchMCPDataStreamHandler(c *gin.Context) {
	c.Writer.Header().Set("Content-Type", "text/event-stream")
	c.Writer.Header().Set("Cache-Control", "no-cache")
	c.Writer.Header().Set("Connection", "keep-alive")
	c.Writer.Header().Set("Transfer-Encoding", "chunked")

	repoChan := make(chan models.MCPRepository)
	errChan := make(chan error)
	doneChan := make(chan bool)
	clientGone := c.Request.Context().Done()

	go fetchMCPDataStream(repoChan, errChan, doneChan)

	repoCount := 0

	for {
		select {
		case repo := <-repoChan:
			repoCount++
			repoJSON, err := json.Marshal(repo)
			if err != nil {
				log.Printf("Error marshaling repository: %v", err)
				continue
			}
			c.Writer.Write([]byte(fmt.Sprintf("event: repository\ndata: %s\n\n", repoJSON)))
			c.Writer.Flush()

		case err := <-errChan:
			errMsg, _ := json.Marshal(gin.H{"error": err.Error()})
			c.Writer.Write([]byte(fmt.Sprintf("event: error\ndata: %s\n\n", errMsg)))
			c.Writer.Flush()
			return

		case <-doneChan:
			summaryMsg, _ := json.Marshal(gin.H{
				"message": "MCP data fetch completed",
				"count":   repoCount,
			})
			c.Writer.Write([]byte(fmt.Sprintf("event: complete\ndata: %s\n\n", summaryMsg)))
			c.Writer.Flush()
			return

		case <-clientGone:
			log.Println("Client connection closed")
			return
		}
	}
}

// GetMCPRepositories godoc
// @Summary Get paginated MCP repositories
// @Description Retrieves a paginated list of MCP repositories with optional search functionality
// @Tags MCP
// @Produce json
// @Param page query int false "Page number for pagination (default: 1)"
// @Param limit query int false "Number of items per page (default: 20)"
// @Param search query string false "Search term to filter repositories by name"
// @Success 200 {object} MCPRepositoriesResponse
// @Failure 500 {object} map[string]interface{} "Error response"
// @Router /v1/mcp/marketplace [get]
func GetMCPRepositories(c *gin.Context) {
	var repositories []models.MCPRepository
	var responses []models.MCPRepositoryResponse
	var total int64

	// Pagination query params
	pageStr := c.DefaultQuery("page", "1")
	limitStr := c.DefaultQuery("limit", "20")
	search := c.Query("search")
	id := c.Query("id")

	page, err := strconv.Atoi(pageStr)
	if err != nil || page < 1 {
		page = 1
	}
	limit, err := strconv.Atoi(limitStr)
	if err != nil || limit < 1 {
		limit = 10
	}
	offset := (page - 1) * limit

	var customDB *gorm.DB
	if search != "" {
		// Search by name
		customDB = config.DefaultDb.Where("name LIKE ?", "%"+search+"%")
	} else {
		customDB = config.DefaultDb
	}

	if id != "" {
		customDB = customDB.Where("id = ?", id)
	}

	// Total count
	if err := customDB.Debug().Model(&models.MCPRepository{}).Count(&total).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to count repositories"})
		return
	}

	// Query with pagination
	if err := customDB.Debug().Offset(offset).Limit(limit).Find(&repositories).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch repositories"})
		return
	}

	// Prepare response
	for _, repo := range repositories {
		var characteristics models.Characteristics
		var tools []models.ToolDescription
		var mcpConfig map[string]interface{}

		if err := json.Unmarshal([]byte(repo.Characteristics), &characteristics); err != nil {
			characteristics = models.Characteristics{}
		}
		if err := json.Unmarshal([]byte(repo.Tools), &tools); err != nil {
			tools = []models.ToolDescription{}
		}

		if err := json.Unmarshal([]byte(repo.McpConfig), &mcpConfig); err != nil {
			mcpConfig = map[string]interface{}{}
		}

		responses = append(responses, models.MCPRepositoryResponse{
			ID:              repo.ID,
			Name:            repo.Name,
			Description:     repo.Description,
			Namespace:       repo.Namespace,
			By:              repo.By,
			LastUpdated:     repo.LastUpdated,
			Characteristics: characteristics,
			Tools:           tools,
			McpConfig:       mcpConfig,
		})
	}

	c.JSON(http.StatusOK, gin.H{
		"page":  page,
		"limit": limit,
		"total": total,
		"data":  responses,
	})
}

// GetMcpRepoReadMe godoc
// @Summary Get MCP repository README
// @Description Retrieves the README for a specific MCP repository
// @Tags MCP
// @Produce text/markdown
// @Param id path string true "Repository ID"
// @Success 200 {string} string "Markdown content"
// @Failure 500 {object} map[string]interface{} "Error response"
// @Router /v1/mcp/marketplace/{id}/readme [get]
func GetMcpRepoReadMe(c *gin.Context) {
	repoID := c.Param("id")
	var repo models.MCPRepository
	if err := config.DefaultDb.First(&repo, repoID).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch repository"})
		return
	}

	var characteristics models.Characteristics
	if err := json.Unmarshal([]byte(repo.Characteristics), &characteristics); err != nil {
		characteristics = models.Characteristics{}
	}

	md, err := FetchMarkdownFromGitHub(characteristics.Repository, "README.md", "")
	if err != nil {
		fmt.Println("Error:", err)
		return
	}

	fmt.Println("Markdown Content:\n", md)

	c.Data(http.StatusOK, "text/markdown; charset=utf-8", []byte(md))
}

// GetRawGithubFileURL generates the raw GitHub file URL
func GetRawGithubFileURL(githubURL, filePath, branch string) string {
	if branch == "" {
		branch = "main"
	}

	parsedURL, err := url.Parse(githubURL)
	if err != nil {
		fmt.Println("Failed to parse GitHub URL:", err)
		return ""
	}

	parts := strings.Split(strings.Trim(parsedURL.Path, "/"), "/")
	if len(parts) < 2 {
		fmt.Println("Invalid GitHub URL")
		return ""
	}

	owner := parts[0]
	repo := strings.TrimSuffix(parts[1], ".git")

	rawURL := fmt.Sprintf("https://raw.githubusercontent.com/%s/%s/%s/%s", owner, repo, branch, filePath)
	return rawURL
}

// FetchMarkdownFromGitHub fetches and returns the markdown content from a GitHub repo
func FetchMarkdownFromGitHub(githubURL, filePath, branch string) (string, error) {
	rawURL := GetRawGithubFileURL(githubURL, filePath, branch)
	if rawURL == "" {
		return "", fmt.Errorf("could not generate raw GitHub URL")
	}

	resp, err := http.Get(rawURL)
	if err != nil {
		return "", fmt.Errorf("failed to fetch file: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("non-200 response: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response: %w", err)
	}

	return string(body), nil
}

func fetchMCPDataStream(repoChan chan models.MCPRepository, errChan chan error, doneChan chan bool) {
	url := "https://hub.docker.com/v2/repositories/mcp/"
	client := &http.Client{Timeout: 30 * time.Second}
	repoCount := 0
	log.Println("Starting MCP data fetch from Docker Hub...")
	for url != "" {
		resp, err := client.Get(url)
		if err != nil {
			errChan <- fmt.Errorf("error fetching from Docker Hub: %v", err)
			return
		}
		if resp.StatusCode != http.StatusOK {
			resp.Body.Close()
			errChan <- fmt.Errorf("non-200 from Docker Hub: %d", resp.StatusCode)
			return
		}

		var response models.DockerHubResponse
		if err := json.NewDecoder(resp.Body).Decode(&response); err != nil {
			resp.Body.Close()
			errChan <- fmt.Errorf("decode error: %v", err)
			return
		}
		resp.Body.Close()

		for _, repo := range response.Results {
			data, err := fetchRepositoryWithDescription(repo.Namespace, repo.Name)
			if err != nil {
				log.Printf("Fetch full description failed for %s/%s: %v", repo.Namespace, repo.Name, err)
				continue
			}

			toolsJSON, err := json.Marshal(data.RepositoryDetails.Tools)
			if err != nil {
				log.Printf("Marshal tools error: %v", err)
				continue
			}

			// Extract the repository characteristics
			characteristics := mapToCharacteristics(extractCharacteristics(data.FullRepo.FullDescription))
			CharacteristicJSON, err := json.Marshal(characteristics)
			if err != nil {
				log.Printf("Marshal tools error: %v", err)
				continue
			}

			newRepo := models.MCPRepository{
				Name:            repo.Name,
				Description:     repo.Description,
				Namespace:       repo.Namespace,
				HubUser:         repo.HubUser,
				LastUpdated:     repo.LastUpdated,
				Characteristics: string(CharacteristicJSON),
				Tools:           string(toolsJSON),
				McpConfig:       MapToString(data.MCPConfig),
			}

			if err := config.DefaultDb.
				Where("name = ? AND namespace = ?", newRepo.Name, newRepo.Namespace).
				Assign(newRepo).
				FirstOrCreate(&newRepo).Error; err != nil {
				log.Printf("DB upsert error: %v", err)
				continue
			}

			repoChan <- newRepo
			repoCount++
		}
		url = response.Next
	}
	doneChan <- true
}

func fetchRepositoryDetails(namespace, name string) (models.RepositoryDetails, error) {
	details := models.RepositoryDetails{Tags: []string{}}
	client := &http.Client{Timeout: 30 * time.Second}
	tagsURL := fmt.Sprintf("https://hub.docker.com/v2/repositories/%s/%s/tags", namespace, name)

	config.Log.Debug("hitting url: ", tagsURL)
	log.Printf("Fetching tags for %s/%s", namespace, name)
	for tagsURL != "" {
		resp, err := client.Get(tagsURL)
		if err != nil {
			return details, fmt.Errorf("tag fetch error: %v", err)
		}
		defer resp.Body.Close()

		if resp.StatusCode != http.StatusOK {
			return details, fmt.Errorf("tag fetch non-200: %d", resp.StatusCode)
		}

		var tagsResponse models.DockerHubTags
		if err := json.NewDecoder(resp.Body).Decode(&tagsResponse); err != nil {
			return details, fmt.Errorf("decode tag error: %v", err)
		}

		bodyBytes, err := io.ReadAll(resp.Body)
		if err != nil {
			log.Printf("Failed to read response body: %v", err)
			return details, err
		}
		config.Log.Debug("tagsResponse:", string(bodyBytes))

		// Reset the body for the decoder
		resp.Body = io.NopCloser(strings.NewReader(string(bodyBytes)))

		for _, tag := range tagsResponse.Results {
			details.Tags = append(details.Tags, tag.Name)
		}
		tagsURL = tagsResponse.Next
	}

	// Try to fetch tools from swagger.json
	swaggerURL := fmt.Sprintf("https://hub.docker.com/v2/repositories/%s/%s/swagger.json", namespace, name)
	tools, err := fetchOpenAPITools(swaggerURL)
	if err == nil {
		details.Tools = tools
	}

	return details, nil
}

func fetchOpenAPITools(url string) ([]models.ToolDescription, error) {
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return nil, fmt.Errorf("fetch swagger error: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("swagger fetch failed with status: %d", resp.StatusCode)
	}

	var swagger map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&swagger); err != nil {
		return nil, fmt.Errorf("decode swagger error: %v", err)
	}

	var tools []models.ToolDescription
	paths, ok := swagger["paths"].(map[string]interface{})
	if !ok {
		return tools, nil
	}

	for path, operations := range paths {
		ops, ok := operations.(map[string]interface{})
		if !ok {
			continue
		}

		for method, details := range ops {
			tool := models.ToolDescription{
				Tool:        fmt.Sprintf("%s %s", strings.ToUpper(method), path),
				Description: "",
				Parameters:  []models.ToolParameterInfo{},
			}

			detailMap, ok := details.(map[string]interface{})
			if ok {
				if desc, exists := detailMap["description"].(string); exists {
					tool.Description = desc
				}
				if params, exists := detailMap["parameters"].([]interface{}); exists {
					for _, p := range params {
						param, ok := p.(map[string]interface{})
						if !ok {
							continue
						}
						paramInfo := models.ToolParameterInfo{
							Name:        getString(param, "name"),
							Type:        getString(param, "type"),
							Description: getString(param, "description"),
							Optional:    !getBool(param, "required"),
						}
						tool.Parameters = append(tool.Parameters, paramInfo)
					}
				}
			}
			tools = append(tools, tool)
		}
	}

	return tools, nil
}

func getString(m map[string]interface{}, key string) string {
	if val, ok := m[key].(string); ok {
		return val
	}
	return ""
}

func getBool(m map[string]interface{}, key string) bool {
	if val, ok := m[key].(bool); ok {
		return val
	}
	return false
}

func fetchRepositoryWithDescription(namespace, name string) (models.MCPResponse, error) {
	var details models.RepositoryDetails
	details.Tags = []string{}
	details.Tools = []models.ToolDescription{}

	url := fmt.Sprintf("https://hub.docker.com/v2/namespaces/%s/repositories/%s", namespace, name)

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return models.MCPResponse{}, fmt.Errorf("error fetching full repo: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return models.MCPResponse{}, fmt.Errorf("non-200 fetching full repo: %d", resp.StatusCode)
	}

	var fullRepo models.FullRepo
	if err := json.NewDecoder(resp.Body).Decode(&fullRepo); err != nil {
		return models.MCPResponse{}, fmt.Errorf("decode full repo error: %v", err)
	}

	// Extract MCP config from description
	extractedData := extractToolsFromDescription(fullRepo.FullDescription)

	// Extract tools from description
	for _, t := range extractedData.Tools {
		details.Tools = append(details.Tools, models.ToolDescription{
			Tool:        t.Tool,
			Description: t.Description,
			Parameters:  t.Parameters,
		})

	}

	return models.MCPResponse{
		RepositoryDetails: details,
		FullRepo:          fullRepo,
		MCPConfig:         extractedData.MCPConfig,
	}, nil
}

type ExtractedData struct {
	MCPConfig map[string]interface{}
	Tools     []models.ToolDescription
}

func extractToolsFromDescription(desc string) ExtractedData {
	var tools []models.ToolDescription
	var mcpConfig map[string]interface{} = make(map[string]interface{})

	lines := strings.Split(desc, "\n")

	var currentTool models.ToolDescription
	var collectingParams bool
	var paramHeaders []string

	for i := 0; i < len(lines); i++ {
		rawLine := lines[i]
		line := strings.TrimSpace(rawLine)

		// --- MCP JSON BLOCK DETECTION ---
		if strings.HasPrefix(line, "{") && i+1 < len(lines) && strings.Contains(lines[i+1], "\"mcpServers\"") {
			jsonBlock := line
			openBraces := strings.Count(line, "{")
			closeBraces := strings.Count(line, "}")

			// Accumulate full JSON block
			for j := i + 1; j < len(lines); j++ {
				nextLine := strings.TrimSpace(lines[j])
				jsonBlock += "\n" + nextLine
				openBraces += strings.Count(nextLine, "{")
				closeBraces += strings.Count(nextLine, "}")
				if openBraces > 0 && openBraces == closeBraces {
					i = j // skip to end of JSON block
					break
				}
			}

			// Try to parse JSON
			err := json.Unmarshal([]byte(jsonBlock), &mcpConfig)
			if err != nil {
				fmt.Println("Failed to parse MCP JSON block:", err)
			}
			continue
		}

		// --- TOOL PARSING ---
		if strings.HasPrefix(line, "#### Tool:") {
			if currentTool.Tool != "" {
				tools = append(tools, currentTool)
			}

			re := regexp.MustCompile(`\*\*(.*?)\*\*`)
			matches := re.FindStringSubmatch(line)
			toolName := ""
			if len(matches) > 1 {
				toolName = matches[1]
			}

			currentTool = models.ToolDescription{
				Tool:       toolName,
				Parameters: []models.ToolParameterInfo{},
			}
			collectingParams = false
			paramHeaders = nil
			continue
		}

		if currentTool.Tool != "" && currentTool.Description == "" && line != "" && !strings.Contains(line, "|") {
			currentTool.Description = line
			continue
		}

		if strings.HasPrefix(line, "Parameters") {
			collectingParams = true
			paramHeaders = splitMarkdownRow(line)
			continue
		}

		if collectingParams && strings.Contains(line, "---") {
			continue
		}

		if collectingParams && strings.Contains(line, "|") {
			paramValues := splitMarkdownRow(line)
			if len(paramValues) < len(paramHeaders) {
				continue
			}

			param := models.ToolParameterInfo{}
			for j, header := range paramHeaders {
				key := strings.ToLower(strings.TrimSpace(header))
				val := strings.TrimSpace(paramValues[j])

				switch key {
				case "name", "parameter", "parameters":
					param.Name = val
				case "type":
					param.Type = val
					if strings.Contains(val, "*optional*") {
						param.Optional = true
					}
				case "description":
					param.Description = val
					if strings.Contains(strings.ToLower(val), "optional") {
						param.Optional = true
					}
				}
			}
			currentTool.Parameters = append(currentTool.Parameters, param)
		}
	}

	if currentTool.Tool != "" {
		tools = append(tools, currentTool)
	}
	// log.Printf("Extracted %d tools from description", tools)
	return ExtractedData{
		MCPConfig: mcpConfig,
		Tools:     tools,
	}
}

func splitMarkdownRow(row string) []string {
	row = strings.TrimSpace(row)
	if strings.HasPrefix(row, "|") {
		row = row[1:]
	}
	if strings.HasSuffix(row, "|") {
		row = row[:len(row)-1]
	}
	parts := strings.Split(row, "|")
	for i, part := range parts {
		parts[i] = strings.TrimSpace(part)
	}
	return parts
}

func extractCharacteristics(desc string) []models.Characteristic {
	var characteristics []models.Characteristic

	// Try to find the Characteristics section
	startIdx := strings.Index(desc, "## Characteristics")
	if startIdx == -1 {
		return characteristics
	}

	// Extract section until next "##"
	endIdx := strings.Index(desc[startIdx+1:], "## ")
	var section string
	if endIdx != -1 {
		section = desc[startIdx : startIdx+1+endIdx]
	} else {
		section = desc[startIdx:]
	}

	lines := strings.Split(section, "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)

		// Skip headers, separators, and empty lines
		if line == "" || strings.Contains(line, "Attribute") || strings.Contains(line, "-|-") {
			continue
		}

		// Handle both pipe and tab separated lines
		var parts []string
		if strings.Contains(line, "|") {
			parts = strings.Split(line, "|")
		} else if strings.Contains(line, "\t") {
			parts = strings.Split(line, "\t")
		}

		if len(parts) >= 2 {
			key := cleanMarkdown(parts[0])
			value := cleanMarkdown(parts[1])
			if key != "" && value != "" && key != "-" {
				characteristics = append(characteristics, models.Characteristic{
					Key:   key,
					Value: value,
				})
			}
		}
	}

	pretty.Println("characteristics: ", characteristics)

	return characteristics
}

// Cleans up markdown links, bold, images etc.
func cleanMarkdown(s string) string {
	s = strings.TrimSpace(s)

	// Remove bold `**` or `__`
	s = strings.Trim(s, "*_")

	// Remove markdown links and images: ![alt](url) or [text](url)
	re := regexp.MustCompile(`!?\[([^\]]*)\]\([^\)]*\)`)
	s = re.ReplaceAllString(s, "$1")

	return s
}

// Maps []Characteristic into a strongly typed Characteristics struct
func mapToCharacteristics(charList []models.Characteristic) models.Characteristics {
	c := models.Characteristics{}
	for _, item := range charList {
		switch strings.ToLower(item.Key) {
		case "image source":
			c.ImageSource = item.Value
		case "docker image":
			c.DockerImage = item.Value
		case "author":
			c.Author = item.Value
		case "repository":
			c.Repository = item.Value
		case "dockerfile":
			c.Dockerfile = item.Value
		case "docker image built by":
			c.DockerImageBuiltBy = item.Value
		case "docker scout health score":
			c.DockerScoutHealthScore = item.Value
		case "licence", "license":
			c.License = item.Value
		}
	}
	return c
}

func MapToString(data map[string]interface{}) string {
	bytes, err := json.MarshalIndent(data, "", "  ")
	if err != nil {
		return fmt.Sprintf("error: %v", err)
	}
	return string(bytes)
}
