package api

import (
	"log"
	"os"
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/marketplace"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	k8 "k8s.io/client-go/kubernetes"

	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"

	jwtRet "gopkg.in/dgrijalva/jwt-go.v3"
)

// GetModelList returns a list of all models from the marketplace
func GetModelList(c *gin.Context) {
	var models []database.ModelMarketplace
	mapd := make(map[string]interface{})
	mapd["error"] = false

	claims := jwt.ExtractClaims(c)
	userId, ok := claims["id"].(float64)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(400, mapd)
		return
	}

	if err := config.DB.Debug().
		Where("created_by IS NULL OR created_by = ?", userId).
		Order("ranking").
		Find(&models).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to fetch models"
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	mapd["models"] = models
	mapd["message"] = "Models fetched successfully"

	c.JSON(200, mapd)
}

func GetSuitableCluster(c *gin.Context) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	hfModelName := c.Query("name")

	claims, _, workspace, namespace, shouldReturn := CreateNameSpaceString(c)
	if shouldReturn {
		return
	}

	email, ok := claims["email"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	suitableCluster, err := marketplace.FindBestCluster(workspace, namespace, email, hfModelName)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to fetch suitable clusters"
		mapd["error_message"] = err.Error()
		c.JSON(400, mapd)
		return
	}

	// Get the full cluster details
	fullClusters, err := marketplace.GetFullClusterDetails(namespace, suitableCluster, workspace)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to fetch full cluster details"
		mapd["error_message"] = err.Error()
		c.JSON(400, mapd)
		return
	}

	for i, _ := range fullClusters {
		if os.Getenv("ONPREM_CLUSTER") == "nexastack" {
			fullClusters[i].GovernanceUrl = os.Getenv("GOVERNANCE")
			fullClusters[i].LogsUrl = os.Getenv("GRAFANA_NEXASTACK_CLUSTER")
			fullClusters[i].ObservabilityUrl = os.Getenv("GRAFANA_NEXASTACK_CLUSTER")
		} else if os.Getenv("ONPREM_CLUSTER") == "azure" {
			fullClusters[i].GovernanceUrl = os.Getenv("GOVERNANCE")
			fullClusters[i].LogsUrl = os.Getenv("GRAFANA_AZURE_CLUSTER")
			fullClusters[i].ObservabilityUrl = os.Getenv("GRAFANA_AZURE_CLUSTER")
		}
	}

	mapd["error"] = false
	mapd["suitable_clusters"] = fullClusters
	mapd["message"] = "Clusters fetched successfully"
	c.JSON(200, mapd)

}

// functionality to install/deploy the model on user cluster
func InstallModel(c *gin.Context) {
	var model database.Deployment

	mapd := make(map[string]interface{})
	mapd["error"] = false

	if err := c.ShouldBindBodyWithJSON(&model); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please enter correct cluster_name and hf_model_name"
		c.JSON(400, mapd)
		return
	}

	config.Log.Info("===model===", model)

	claims, _, workspace, _, shouldReturn := CreateNameSpaceString(c)
	if shouldReturn {
		return
	}

	// Update: not using this relase name (release name will generate from InstallModel function)
	// releaseName = strings.Replace(modelResource.DeploymentName, "_", "-", -1)

	// var releaseName string
	apiKey := strings.ToLower(methods.RandomString(16))
	if apiKey == "" {
		mapd["error"] = true
		mapd["message"] = "Failed to generate API key"
		c.JSON(500, mapd)
		return
	}
	email, ok := claims["email"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	// connect to database
	db := config.DB
	//Check workspace present in database
	var WorkID database.Workspaces
	err := config.DefaultDb.Model(&database.Workspaces{}).Where(WorkspaceIdWhereCondition, workspace).First(&WorkID).Error
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = WorkspaceNotMatchMessage
		c.JSON(500, mapd)
		return
	}

	config.Log.Info("===workid===", WorkID)

	//check user is member of that workspace
	member := []database.WorkspaceMembers{}
	config.DefaultDb.Debug().Where("member_email= ? AND workspace_id= ?", email, WorkID.WorkspaceID).Find(&member)
	if len(member) == 0 {
		//when not a member
		mapd["error"] = true
		mapd["message"] = "The user does not belong to this workspace."
		c.JSON(401, mapd)
		return
	}

	//check same model deployed or not
	deploy := []database.Deployment{}
	db.Debug().Where("user_email = ? AND workspace_id = ? AND hf_model_name = ? AND cluster_name = ?", email, workspace, model.HFModelName, model.ClusterName).Find(&deploy)
	if len(deploy) > 0 {
		// Model is already deployed
		mapd["error"] = true
		mapd["message"] = model.HFModelName + " model is already deployed."
		c.JSON(400, mapd)
		return
	}

	// config.Log.Info("===deploy===", deploy)
	// mapd, code := marketplace.InstallModel(email, nameSpace, workspace, releaseName, model.HFModelName, model.ClusterName, apiKey)
	// if code != 200 {
	// 	mapd["error"] = true
	// 	if message, ok := mapd["message"].(string); ok {
	// 		mapd["error_message"] = message
	// 	} else {
	// 		mapd["error_message"] = "Unknown error"
	// 	}
	// 	mapd["message"] = "Failed to install model on server"
	// 	// delete model-helm folder in data

	// 	config.Log.Error("Failed to install model on server: ", mapd)
	// 	if err := os.RemoveAll("data/model-helm"); err != nil {
	// 		config.Log.Error(err.Error())
	// 		mapd["error"] = true
	// 		mapd["message"] = "Failed to delete model-helm folder"
	// 		c.JSON(500, mapd)
	// 		return
	// 	}

	// 	c.JSON(code, mapd)
	// 	return
	// }

	// // delete model-helm folder in data
	// if err := os.RemoveAll("data/model-helm"); err != nil {
	// 	config.Log.Error(err.Error())
	// 	mapd["error"] = true
	// 	mapd["message"] = "Failed to delete model-helm folder"
	// 	c.JSON(500, mapd)
	// 	return
	// }

	// get model_marketplace data based on hf_model_name
	marketplace := database.ModelMarketplace{}
	err = config.DefaultDb.Debug().Where("hf_model_name = ?", model.HFModelName).Find(&marketplace).Error
	if err != nil {
		//when not a member
		c.JSON(400, &err)
		return
	}

	// get model_marketplace data based on hf_model_name
	infra := database.InfraIntegration{}
	err = db.Debug().Where("cluster_name = ?", model.ClusterName).Find(&infra).Error
	if err != nil {
		//when not a member
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(400, mapd)
		return
	}

	log.Println("===>", infra.Ingress)

	if marketplace.DeploymentName == "" {
		config.Log.Error("Deployment name is empty")
		mapd["error"] = true
		mapd["message"] = "deployment name cannot be empty"
		return
	}

	path := GetSuitableKubeConfigPath(infra, mapd)
	config.Log.Info("path: ", path)
	// Ensure the file exists
	if _, err := os.Stat(path); os.IsNotExist(err) {
		config.Log.Errorf("Kubeconfig file does not exist at path: %s", path)
		mapd["error"] = true
		mapd["message"] = "kubeconfig file not found"
		return
	}

	clientSet, err := kubernetes.NewKubeClient(path)
	if err != nil {
		config.Log.Error("Error creating Kubernetes client:", err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return
	}

	result, statusCode := kubernetes.UpscaleDeployment(clientSet, "playground", marketplace.DeploymentName)
	if statusCode != 200 {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = result["message"].(string)
		c.JSON(200, mapd)
		return
	}

	deployment1 := database.Deployment{
		WorkspaceID: workspace,
		UserEmail:   email,
		HFModelName: model.HFModelName,
		// ReleaseName: util.CheckInterface(mapd["release_name"]),
		// Ingress:     util.CheckInterface(mapd["ingress"]),
		ReleaseName:    marketplace.ReleaseName,
		Ingress:        "https://" + marketplace.DeploymentName + infra.Ingress,
		ClusterName:    model.ClusterName,
		ApiKey:         apiKey,
		DeployedAt:     time.Now(),
		DeploymentName: marketplace.DeploymentName,
		IngressSubUrl:  infra.Ingress,
		ProjectId:      model.ProjectId,
		Environment:    model.Environment,
		Workspace:      model.Workspace,
	}

	if err := db.Create(&deployment1).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to Add the deployed model in database"
		// marketplace.UninstallModel(nameSpace, releaseName, model.ClusterName, workspace, email)
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	// mapd["model_ingress"] = deployment.ReleaseName + mapd["deployment_sub_name"].(string)
	mapd["model_ingress"] = "https://" + marketplace.DeploymentName + marketplace.DeploymentSubName
	mapd["ingress"] = "https://" + marketplace.DeploymentName + infra.Ingress
	mapd["deployment_name"] = marketplace.DeploymentName
	mapd["api_key"] = apiKey
	mapd["message"] = model.HFModelName + "Model deployed successfully"
	c.JSON(200, mapd)

}

func GetSuitableKubeConfigPath(infra database.InfraIntegration, mapd map[string]interface{}) string {
	var path string
	if infra.Ingress == ".managed.neuralcompany.team" {
		path = "./templates/azure_kubeconfig.yaml"
	} else if infra.Ingress == ".lab.neuralcompany.team" {
		path = "./templates/azure_kubeconfig_old.yaml"
	} else if infra.Ingress == ".nexastack.neuralcompany.team" {
		path = "./templates/nexastack_kubeconfig.yaml"
	}
	return path
}

func CreateNameSpaceString(c *gin.Context) (jwtRet.MapClaims, string, string, string, bool) {
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)

		return nil, "", "", "", true
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(wsid, ".")
	workspace := wsURLParts[0]
	// nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
	nameSpace := strings.Replace(workspace, "_", "-", -1)

	return claims, branch, workspace, nameSpace, false
}

// functionality to get the list of deployed model on user cluster
func GetDeployedModel(c *gin.Context) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	wsid, _, shouldReturn := GetEmailAndWorkSpaceFromToken(c)
	if shouldReturn {
		return
	}

	wsURLParts := strings.Split(wsid, ".")
	workspace := wsURLParts[0]

	// Check if the email belongs to the same workspace
	db := config.DB
	// var workspaces database.WorkspaceMembers
	// if err := db.Debug().Where(GetDeployModelWhereConditions, workspace, email).First(&workspaces).Error; err != nil {
	// 	config.Log.Error(err.Error())
	// 	mapd["error"] = true
	// 	mapd["message"] = WorkSpaceEmailError
	// 	c.JSON(401, mapd)
	// 	return

	// }

	var deployment []database.Deployment
	if err := db.Debug().Where("workspace_id = ? ", workspace).Find(&deployment).Error; err != nil {
		config.Log.Error(err.Error())
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = err.Error()
		mapd["deployment"] = deployment
		c.JSON(400, mapd)
		return
	}

	for i, j := range deployment {
		var infraModel database.InfraIntegration
		if err := db.Debug().Where("cluster_name = ? and workspace = ? ", j.ClusterName, workspace).Find(&infraModel).Error; err != nil {
			config.Log.Error(err.Error())
			mapd["error"] = true
			mapd["message"] = err.Error()
			mapd["deployment"] = deployment
			c.JSON(400, mapd)
			return
		}

		deployment[i].Ingress = "https://" + j.DeploymentName + infraModel.Ingress

		if os.Getenv("ONPREM_CLUSTER") == "nexastack" {
			deployment[i].GovernanceUrl = os.Getenv("GOVERNANCE")
			deployment[i].LogsUrl = os.Getenv("GRAFANA_NEXASTACK_CLUSTER")
			deployment[i].ObservabilityUrl = os.Getenv("GRAFANA_NEXASTACK_CLUSTER")
		} else if os.Getenv("ONPREM_CLUSTER") == "azure" {
			deployment[i].GovernanceUrl = os.Getenv("GOVERNANCE")
			deployment[i].LogsUrl = os.Getenv("GRAFANA_AZURE_CLUSTER")
			deployment[i].ObservabilityUrl = os.Getenv("GRAFANA_AZURE_CLUSTER")
		}
	}

	mapd["error"] = false
	mapd["deployment"] = deployment
	mapd["message"] = "Deployed Models fetched successfully"

	c.JSON(200, mapd)
}

func GetEmailAndWorkSpaceFromToken(c *gin.Context) (string, string, bool) {
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return "", "", true
	}

	email, ok := claims["email"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return "", "", true
	}
	return wsid, email, false
}

// functionality to delete the deployment of model from user cluster
func DeleteDeployedModel(c *gin.Context) {
	modelId := c.Param("model_id")
	mapd := make(map[string]interface{})
	mapd["error"] = false

	claims, _, workspace, _, shouldReturn := CreateNameSpaceString(c)
	if shouldReturn {
		return
	}

	email, ok := claims["email"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	// Check if the email belongs to the same workspace
	db := config.DB
	var workspaces database.WorkspaceMembers
	if err := config.DefaultDb.Debug().Where(GetDeployModelWhereConditions, workspace, email).First(&workspaces).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = WorkSpaceEmailError
		c.JSON(401, mapd)
		return

	}

	// Get deployment details
	var deployment database.Deployment
	if err := db.Where("id = ? AND workspace_id = ? ", modelId, workspace).First(&deployment).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Instance not found"
		c.JSON(404, mapd)
		return
	}

	// // Uninstall using marketplace helper
	// result, code := marketplace.UninstallModel(nameSpace, deployment.ReleaseName, deployment.ClusterName, deployment.WorkspaceID, deployment.UserEmail)
	// if code != 200 {
	// 	mapd["error"] = true
	// 	mapd["result"] = result
	// 	mapd["message"] = "Failed to delete the deployed model"
	// 	c.JSON(code, result)
	// 	return
	// }deployment

	path := GetSuitableKubeConfigPath(database.InfraIntegration{
		Ingress: deployment.IngressSubUrl,
	}, mapd)
	config.Log.Info("path: ", path)
	// Ensure the file exists
	if _, err := os.Stat(path); os.IsNotExist(err) {
		config.Log.Errorf("Kubeconfig file does not exist at path: %s", path)
		mapd["error"] = true
		mapd["message"] = "kubeconfig file not found"
		return
	}

	clientSet, err := kubernetes.NewKubeClient(path)
	if err != nil {
		config.Log.Error("Error creating Kubernetes client:", err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return
	}

	result, statusCode := kubernetes.DownscaleDeployment(clientSet, deployment.DeploymentName)
	if statusCode != 200 {
		config.Log.Error(result["message"].(string))
		mapd["error"] = true
		mapd["message"] = result["message"].(string)
		c.JSON(statusCode, mapd)
		return
	}

	// Delete from database
	if err := db.Delete(&deployment).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to delete from database"
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	mapd["message"] = "Deployed model deleted successfully"
	c.JSON(200, mapd)
}

// functionality to upscale the deployed model on nexastack cluster
func UpscaleModel(c *gin.Context) {
	var deploymentDetails struct {
		DeploymentName string `json:"deployment_name" validate:"required"`
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false
	if err := c.Bind(&deploymentDetails); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please provide valid deployment name and replicas"
		c.JSON(400, mapd)
		return
	}

	wsid, email, shouldReturn := GetEmailAndWorkSpaceFromToken(c)
	if shouldReturn {
		return
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(wsid, ".")
	workspace := wsURLParts[0]
	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)

	// Check if the email belongs to the same workspace
	var workspaces database.WorkspaceMembers
	if err := config.DefaultDb.Debug().Where(GetDeployModelWhereConditions, workspace, email).First(&workspaces).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = WorkSpaceEmailError
		c.JSON(401, mapd)
		return

	}
	// Check workspace present in database
	var WorkID database.Workspaces
	err := config.DefaultDb.Model(&database.Workspaces{}).Where(WorkspaceIdWhereCondition, wsid).First(&WorkID).Error
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = WorkspaceNotMatchMessage
		c.JSON(500, mapd)
		return
	}

	// Fetch the HFModelName from the ModelMarketplace table
	var modelMarketplace database.ModelMarketplace
	err = config.DefaultDb.Debug().Model(&database.ModelMarketplace{}).Where("deployment_name = ?", deploymentDetails.DeploymentName).First(&modelMarketplace).Error
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Model not found"
		c.JSON(200, mapd) //c.JSON(404, mapd)
		return
	}

	result, statusCode := kubernetes.UpscaleDeployment(nil, nameSpace, deploymentDetails.DeploymentName)
	if statusCode != 200 {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = result["message"].(string)
		c.JSON(200, mapd)
		return
	}

	// ingressMap := map[string]string{
	// 	"Qwen/Qwen2.5-1.5B-Instruct": "https://qwen15.nexastack.neuralcompany.team/v1",
	// 	"Qwen/Qwen2.5-3B-Instruct":   "https://qwen3b.nexastack.neuralcompany.team/v1",
	// }

	// ingress, ok := ingressMap[modelMarketplace.HFModelName]
	// if !ok {
	// 	mapd["error"] = true
	// 	mapd["message"] = "No ingress exists for the given HFModelName"
	// 	c.JSON(404, mapd)
	// 	return
	// }

	mapd["error"] = false
	mapd["message"] = "Deployment upscaled successfully"
	mapd["ingress_model"] = "https://" + modelMarketplace.DeploymentName + modelMarketplace.DeploymentSubName // ".nexastack.neuralcompany.team/v1"
	mapd["deployment_name"] = deploymentDetails.DeploymentName
	mapd["hf_model_name"] = modelMarketplace.HFModelName
	c.JSON(200, mapd)

}

// functionality to downscale the model on nexastack cluster
func DownscaleModel(c *gin.Context) {
	var deploymentDetails struct {
		DeploymentName string `json:"deployment_name" validate:"required"`
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false
	if err := c.Bind(&deploymentDetails); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please provide valid deployment name"
		c.JSON(400, mapd)
		return
	}

	// Downscale deployment
	result, statusCode := kubernetes.DownscaleDeployment(&k8.Clientset{}, deploymentDetails.DeploymentName)
	if statusCode != 200 {
		config.Log.Error(result["message"].(string))
		mapd["error"] = true
		mapd["message"] = result["message"].(string)
		c.JSON(statusCode, mapd)
		return
	}

	mapd["error"] = false
	mapd["message"] = "Deployment downscaled successfully"
	c.JSON(200, mapd)

}

// functionality to upload the model details in database (used by admin)
func UploadModel(c *gin.Context) {
	var model database.ModelMarketplace
	mapd := make(map[string]interface{})
	mapd["error"] = false
	var err error
	if err = c.ShouldBindBodyWithJSON(&model); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please enter correct model details"
		c.JSON(400, mapd)
		return
	}

	model.LastUpdated = time.Now()

	exists, err := marketplace.CheckModelExists(model.HFModelName)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to check model existence"
		c.JSON(500, mapd)
		return
	}

	if !exists {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Model does not exist on Hugging Face Hub"
		c.JSON(400, mapd)
		return
	}

	// Extract model name from HF model name
	parts := strings.Split(model.HFModelName, "/")
	if len(parts) != 2 {
		config.Log.Error("Invalid HF model name")
		mapd["error"] = true
		mapd["message"] = "Invalid HF model name"
		c.JSON(400, mapd)
		return
	}
	model.ModelName = parts[1]

	// Check if model name already exists in database
	var existingModel database.ModelMarketplace
	db := config.DB
	db.Debug().Where("hf_model_name = ?", model.HFModelName).First(&existingModel)
	if existingModel.ID != 0 {
		config.Log.Error("Model already exists in database")
		mapd["error"] = true
		mapd["message"] = "Model already exists in database"
		c.JSON(400, mapd)
		return
	}
	// connect to database
	err = SetModel(config.DB, model, mapd)

	if err != nil {
		return
	}

	mapd["error"] = false
	mapd["message"] = "Model uploaded successfully"
	c.JSON(200, mapd)
}

func SetModel(db *gorm.DB, model database.ModelMarketplace, mapd map[string]interface{}) error {
	if model.MemoryLimit != "" && !strings.HasSuffix(model.MemoryLimit, "Gi") {
		model.MemoryLimit += "Gi"
	}
	if model.MemoryRequest != "" && !strings.HasSuffix(model.MemoryRequest, "Gi") {
		model.MemoryRequest += "Gi"
	}
	if err := db.Create(&model).Error; err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to create model"
		return err
	}
	return nil
}

// functionality to delete the model from database (used by admin)
func DeleteModel(c *gin.Context) {
	id, err := strconv.Atoi(c.Param("id"))

	config.Log.Error("===error===", err)
	mapd := make(map[string]interface{})
	mapd["error"] = false

	// connect to database
	db := config.DB
	var model database.ModelMarketplace

	// Then delete it
	err, mapd = DeleteModelWrapper(db, model, id, mapd)
	if err != nil {
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	mapd["message"] = "Model deleted successfully"
	c.JSON(200, mapd)
}

func DeleteModelWrapper(db *gorm.DB, model database.ModelMarketplace, id int, mapd map[string]interface{}) (error, map[string]interface{}) {
	if err := db.Debug().Delete(&model, id).Error; err != nil {
		config.Log.Error("===error===", err)
		mapd["error"] = true
		mapd["message"] = "Failed to delete model"
		return err, mapd
	}

	mapd["error"] = false
	mapd["message"] = "Model deleted successfully"
	return nil, mapd
}

// functionality to check the deployment staus of deployed model on nexastack cluster
func DeployemntStatus(c *gin.Context) {
	var deployemntDetails struct {
		NameSpace      string `json:"namespace"`
		HfModelName    string `json:"hf_model_name" validate:"required"`
		DeploymentName string `json:"deployment_name" validate:"required"`
		ModelIngress   string `json:"ingress_model"`
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false

	if err := c.ShouldBindBodyWithJSON(&deployemntDetails); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please enter correct deployment_name"
		c.JSON(400, mapd)
		return
	}

	deploymentRunning, err := kubernetes.CheckDeploymentStatus(deployemntDetails.NameSpace, deployemntDetails.DeploymentName)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to fetch the state of the deployed model"
		c.JSON(200, mapd)
		return
	}

	// get model_marketplace data based on hf_model_name
	marketplace := database.ModelMarketplace{}
	err = config.DefaultDb.Debug().Where("hf_model_name = ?", deployemntDetails.HfModelName).Find(&marketplace).Error
	if err != nil {
		//when not a member
		mapd["error"] = true
		mapd["message"] = "error while getting model marketplace data"
		mapd["error_message"] = err.Error()
		c.JSON(400, mapd)
		return
	}

	var infra database.ModelMarketplace
	err = config.DefaultDb.Where("hf_model_name = ? and deployment_name = ?", deployemntDetails.HfModelName, deployemntDetails.DeploymentName).Find(&infra).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "infra integration not found"
		mapd["error_message"] = err.Error()
		c.JSON(400, mapd)
		return
	}

	// println("====deployment===", deploymentRunning)
	if !deploymentRunning {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = "Deployment is not in running state"
		c.JSON(200, mapd)
		return
	}

	mapd["error"] = false
	mapd["model_name"] = deployemntDetails.HfModelName
	mapd["ingress_model"] = "http://" + marketplace.DeploymentName + infra.DeploymentSubName
	mapd["message"] = "Deployment running successfully"
	c.JSON(200, mapd)

}

func CheckDeployedPodStatus(c *gin.Context) {
	var deployemntDetails struct {
		DeploymentName string `json:"deployment_name" validate:"required"`
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false

	if err := c.ShouldBindBodyWithJSON(&deployemntDetails); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please enter correct deployment_name"
		c.JSON(400, mapd)
		return
	}

	// deploymentRunning, err := kubernetes.CheckPlaygroundModelPodStatus(deployemntDetails.DeploymentName)
	// if err != nil {
	// 	config.Log.Error(err.Error())
	// 	mapd["error"] = true
	// 	mapd["message"] = "Failed to fetch the state of the deployed model"
	// 	c.JSON(500, mapd)
	// 	return
	// }

	deploymentRunning := true

	println("====deployment===", deploymentRunning)
	if !deploymentRunning {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = "Failed to downscale the deployed model"
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	mapd["message"] = "Deployment status downscaled"
	c.JSON(200, mapd)

}

// func ModelPodStatus(c *gin.Context) {
// 	var podDetails struct {
// 		Workspace string `json:"workspace" validate:"required"`
// 	}

// 	mapd := make(map[string]interface{})
// 	mapd["error"] = false
// 	if err := c.Bind(&podDetails); err != nil {
// 		mapd["error"] = true
// 		mapd["message"] = "Invalid request body"
// 		c.JSON(400, mapd)
// 		return
// 	}
// 	claims := jwt.ExtractClaims(c)
// 	wsid, ok := claims["workspace"].(string)
// 	if !ok {
// 		mapd := make(map[string]interface{})
// 		mapd["error"] = true
// 		mapd["message"] = LoginAgainMessage
// 		c.JSON(500, mapd)
// 		return
// 	}

// 	if wsid != podDetails.Workspace {
// 		mapd["error"] = true
// 		mapd["message"] = "Workspace not valid!"
// 		c.JSON(500, mapd)
// 		return
// 	}

// 	branch := strings.ToLower(config.Conf.Service.Branch)
// 	if branch == "" {
// 		branch = "prod"
// 	}
// 	wsURLParts := strings.Split(wsid, ".")
// 	workspace := wsURLParts[0]
// 	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
// 	// connect to database
// 	db := config.DB
// 	// Check workspace present in database
// 	var WorkID database.Workspaces
// 	err := db.Model(&database.Workspaces{}).Where(WorkspaceIdWhereCondition, wsid).First(&WorkID).Error
// 	if err != nil {
// 		mapd["error"] = true
// 		mapd["message"] = WorkspaceNotMatchMessage
// 		c.JSON(500, mapd)
// 		return
// 	}

// 	// Fetch release names from deployments table
// 	var deployments []database.Deployment
// 	err = db.Model(&database.Deployment{}).Where(WorkspaceIdWhereCondition, wsid).Find(&deployments).Error
// 	if err != nil {
// 		mapd["error"] = true
// 		mapd["message"] = "Failed to fetch deployments"
// 		c.JSON(500, mapd)
// 		return
// 	}

// 	var releaseNames []string
// 	for _, deployment := range deployments {
// 		releaseNames = append(releaseNames, deployment.ReleaseName)
// 	}

// 	_, path, code, err := kubernetes.SetInfraConfig(nameSpace, deployments[0].ClusterName, workspace, deployments[0].UserEmail)
// 	defer os.Remove(path)
// 	if err != nil {
// 		config.Log.Error(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		c.JSON(code, mapd)
// 		return
// 	}

// 	podStatus, err := kubernetes.CheckModelPodStatus(nameSpace, releaseNames)
// 	if err != nil {
// 		mapd["error"] = true
// 		mapd["message"] = "Failed to get pod status"
// 		c.JSON(500, mapd)
// 		return
// 	}

// 	// Create a map to store pod status with model name
// 	podStatusWithModel := make(map[string]map[string]string)
// 	for pod, status := range podStatus {
// 		for _, deployment := range deployments {
// 			if strings.Contains(pod, deployment.ReleaseName) {
// 				podStatusWithModel[pod] = map[string]string{
// 					"status": status,
// 					"model":  deployment.HFModelName,
// 				}
// 			}
// 		}
// 	}

// 	mapd["error"] = false
// 	mapd["pod_status"] = podStatusWithModel
// 	mapd["message"] = "Pods status fetched successfully"
// 	c.JSON(200, mapd)
// }

func ModelPodStatus(c *gin.Context) {
	var podDetails struct {
		Workspace   string   `json:"workspace" validate:"required"`
		ReleaseName []string `json:"release_name"`
	}

	mapd := make(map[string]interface{})
	mapd["error"] = false
	if err := c.Bind(&podDetails); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Invalid request body"
		c.JSON(400, mapd)
		return
	}
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	if wsid != podDetails.Workspace {
		mapd["error"] = true
		mapd["message"] = "Workspace not valid!"
		c.JSON(500, mapd)
		return
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	// wsURLParts := strings.Split(wsid, ".")
	// workspace := wsURLParts[0]
	// nameSpace := strings.Replace(workspace, "_", "-", -1) //"nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)
	// connect to database
	db := config.DB
	// Check workspace present in database
	var WorkID database.Workspaces
	err := config.DefaultDb.Model(&database.Workspaces{}).Where(WorkspaceIdWhereCondition, wsid).First(&WorkID).Error
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = WorkspaceNotMatchMessage
		c.JSON(500, mapd)
		return
	}

	// Fetch release names from deployments table
	var deployments []database.Deployment
	err = db.Model(&database.Deployment{}).Where(WorkspaceIdWhereCondition, wsid).Find(&deployments).Error
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to fetch deployments"
		c.JSON(500, mapd)
		return
	}

	// Create a map to store pod status with model name
	podStatusWithModel := make(map[string]map[string]string)
	for _, deployment := range deployments {
		// Get the cluster name for the current deployment
		// clusterName := deployment.ClusterName
		// Get the release name for the current deployment
		releaseName := deployment.ReleaseName
		// Get the user email for the current deployment
		// userEmail := deployment.UserEmail

		// Set the infra config for the current cluster
		// _, path, code, err := kubernetes.SetInfraConfig(nameSpace, clusterName, workspace, userEmail)
		// defer os.Remove(path)
		// if err != nil {
		// 	config.Log.Error(err)
		// 	mapd["error"] = true
		// 	mapd["message"] = err.Error()
		// 	c.JSON(code, mapd)
		// 	return
		// }

		log.Println("deployment.Ingress: ", deployment.IngressSubUrl)

		path := GetSuitableKubeConfigPath(database.InfraIntegration{Ingress: deployment.IngressSubUrl}, mapd)
		config.Log.Info("path: ", path)
		// Ensure the file exists
		if _, err := os.Stat(path); os.IsNotExist(err) {
			config.Log.Errorf("Kubeconfig file does not exist at path: %s", path)
			mapd["error"] = true
			mapd["message"] = "kubeconfig file not found"
			return
		}

		clientSet, err := kubernetes.NewKubeClient(path)
		if err != nil {
			config.Log.Error("Error creating Kubernetes client:", err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			return
		}

		releases := []string{releaseName}

		if len(podDetails.ReleaseName) != 0 {
			// If a specific release name is provided, check if it matches the current deployment
			releases = podDetails.ReleaseName
		}

		podStatus, err := kubernetes.CheckModelPodStatusStaticKubeFiles(clientSet, path, "playground", releases)
		// Check the model pod status for the current cluster
		// podStatus, err := kubernetes.CheckModelPodStatus(path, "playground", releases)
		if err != nil {
			mapd["error"] = true
			mapd["message"] = "Failed to get pod status"
			c.JSON(500, mapd)
			return
		}

		// Add the pod status to the map
		for pod, status := range podStatus {
			podStatusWithModel[pod] = map[string]string{
				"status":  status,
				"model":   deployment.HFModelName,
				"cluster": deployment.ClusterName,
			}
		}

		if len(podDetails.ReleaseName) != 0 {
			// If a specific release name is provided, break the loop after checking that deployment
			break
		}
	}

	mapd["error"] = false
	mapd["pod_status"] = podStatusWithModel
	mapd["message"] = "Pods status fetched successfully"
	c.JSON(200, mapd)
}
