package api

import (
	"context"

	// "fmt"
	// "encoding/json"
	// "fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/sashabaranov/go-openai"
)

type ChatRequest struct {
	Message    string  `json:"message" validate:"required"`
	Model      string  `json:"model" validate:"required"`
	IngressUrl string  `json:"ingress_url" validate:"required"`
	Temprature float32 `json:"temperature" validate:"required"`
	TopP       float32 `json:"top_p" validate:"required"`
	Maxlength  int     `json:"max_length" validate:"required"`
}

// ChatResponse godoc
// @Summary Get chat response from AI model
// @Description Send a message to an AI model and get its response
// @Tags Chat
// @Accept json
// @Produce json
// @Param chat body ChatRequest{Message string `json:"message"`; Model string `json:"model"`; IngressUrl string `json:"ingress_url"`} true "Chat request parameters"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/chat [post]
func ChatResponse(c *gin.Context) {
	// ingressURL := "http://10.0.50.110:32155/v1"

	var chat ChatRequest
	if err := c.ShouldBindJSON(&chat); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	// Create an OpenAI client with a custom HTTP client
	client := openai.NewClientWithConfig(openai.ClientConfig{
		BaseURL:    chat.IngressUrl,
		HTTPClient: &http.Client{},
	})

	/* SONARQUBE_EXCLUDE_START (c:S1244) */

	// Define the chat completion request
	resp, err := client.CreateChatCompletion(context.TODO(), openai.ChatCompletionRequest{
		Model: chat.Model, // Adjust based on the available model
		Messages: []openai.ChatCompletionMessage{
			{Role: "user", Content: chat.Message},
		},
		Temperature: chat.Temprature,
		TopP:        chat.TopP,
		MaxTokens:   chat.Maxlength,
	})
	/* SONARQUBE_EXCLUDE_END (c:S1244) */

	if err != nil {
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	// Extract response
	if len(resp.Choices) > 0 {
		// Store the client message and LLM response in a list
		responses := []map[string]string{
			{"role": "user", "content": chat.Message},
			{"role": "assistant", "content": resp.Choices[0].Message.Content},
		}

		c.JSON(200, gin.H{"responses": responses})
	} else {
		c.JSON(500, gin.H{"error": "No response from model"})
	}
}
