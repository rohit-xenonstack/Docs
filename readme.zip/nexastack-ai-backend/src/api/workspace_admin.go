//go:build !test
// +build !test

package api

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// ListWorkspaces is an api handler for listing deployed workspaces

// ListWorkspaceMembers is an api handler for listing members of a workspace
func ListWorkspaceMembers(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()
	db := config.DB
	workspaceId := c.Param("workspace_id")
	list, err := member.List(db, workspaceId)
	if err != nil {
		config.Log.Error(err.Error())
		c.JSON(501, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"error":   false,
		"members": list,
	})
}

//=============================================================//

//============================================================//

// AccountsEmail is an api handler for listing accounts
func AccountsEmail(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	list := ListEmail()
	c.JSON(200, gin.H{
		"error": false,
		"list":  list,
	})
}
