package api

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"

	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// Health Check
// @Summary Health Check
// @Description Check the health of the AWS onboarding service
// @Tags AWS Onboarding
// @Accept json
// @Produce json
// @Success 200 {object} ApiResonse
// @Router /aws/ [GET]
func AwsOnboardingHealthCheck(c *gin.Context) {
	output, err := CallPythonAPI("/", "GET", nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, util.ErrorApiResponse(err.Error()))
		return
	}
	c.Data(http.StatusOK, ContentHeader, output)

}

// Register Role
// @Summary Register Role
// @Description Register an AWS role for onboarding
// @Tags AWS Onboarding
// @Accept json
// @Produce json
// @Param role body models.AWSAccountRoles true "AWS Role"
// @Success 200 {object} ApiResonse
// @Router /aws/role/register [POST]
func AwsOnboardingRegisterRole(c *gin.Context) {
	DB := config.DB
	var requestBody models.AWSAccountRoles
	var tempBody models.AWSAccountRoles

	if err := c.BindJSON(&requestBody); err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Invalid request body"))
		return
	}

	if requestBody.PolicyARN == "" || requestBody.RoleARN == "" {
		requestBody.PolicyARN = os.Getenv("NEXASTACK_ASSUME_POLICY_ARN")
		requestBody.RoleARN = os.Getenv("NEXASTACK_ASSUME_ROLE_ARN")
	}

	requestBody.AccountId, _ = GetAccountIDFromARN(requestBody.UserResourceARN)
	tempBody = requestBody
	result := DB.Debug().Where(WhereUserIdAndAccountId, requestBody.UserId, requestBody.AccountId).FirstOrCreate(&tempBody)
	if !result.RecordNotFound() {
		if err := DB.Debug().
			Model(&requestBody).
			Where("user_id = ? and account_id= ?", requestBody.UserId, requestBody.AccountId).
			Updates(requestBody).
			Error; err != nil {
			c.JSON(http.StatusInternalServerError, util.ErrorApiResponse("Failed to update role details"))
			return
		}
	}

	config.Log.Info("requestBody: ", requestBody)
	requestBodyBytes, err := json.Marshal(requestBody)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to marshal request body"})
		return
	}
	output, err := CallPythonAPI("/register-role", "POST", requestBodyBytes)
	if err != nil {
		c.JSON(http.StatusInternalServerError, util.ErrorApiResponse(err.Error()))
		return
	}
	c.Data(http.StatusOK, "application/json", output)
}

// List Clusters
// @Summary List Clusters
// @Description List AWS clusters for a given user
// @Tags AWS Onboarding
// @Accept json
// @Produce json
// @Param user_id query string true "User ID"
// @Success 200 {object} ApiResonse
// @Router /aws/clusters [GET]
func AwsOnboardingListClusters(c *gin.Context) {
	DB := config.DB
	var role models.AWSAccountRoles
	userId := c.Query("user_id")

	err := DB.Debug().Where(WhereUserId, userId).Last(&role).Error
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"message": "Failed to get user resource ARN: " + err.Error(), "error": true})
		return
	}

	if role.Region == "" {
		role.Region = "ap-south-1"
	}

	output, err := CallPythonAPI(fmt.Sprintf("/list-clusters?role_arn=%s&region=%s&user_id=%d&account_id=%s", role.UserResourceARN, role.Region, role.UserId, role.AccountId), "GET", nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, util.ErrorApiResponse(err.Error()))
		return
	}

	// Parse the clusters from the response
	var response map[string]interface{}
	if err := json.Unmarshal(output, &response); err != nil {
		c.JSON(http.StatusInternalServerError, util.ErrorApiResponse("Failed to parse clusters response"))
		return
	}

	response["account_id"] = role.AccountId

	c.JSON(http.StatusOK, response)
}

// Check Cluster Health
// @Summary Check Cluster Health
// @Description Check the health of a specific AWS cluster
// @Tags AWS Onboarding
// @Accept json
// @Produce json
// @Param user_id query string true "User ID"
// @Param clusters body models.ClusterRegister true "Cluster Register"
// @Success 200 {object} ApiResonse
// @Router /aws/cluster/register [POST]
func AwsOnboardingClusterHealthCheck(c *gin.Context) {

	DB := config.DB
	var role models.AWSAccountRoles
	var clusters models.ClusterRegister

	err := c.BindJSON(&clusters)
	if err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Invalid request body"))
		return
	}

	err = DB.Debug().Model(&models.AWSAccountRoles{}).Where("user_id = ?", clusters.UserId).Update("selected_cluster", clusters.ClusterName).Error
	if err != nil {
		c.JSON(http.StatusInternalServerError, util.ErrorApiResponse("Failed to update selected cluster: "+err.Error()))
		return
	}

	err = DB.Debug().Debug().Where(WhereUserIdAndAccountId, clusters.UserId, clusters.AccountId).First(&role).Error
	if err != nil {
		c.JSON(http.StatusInternalServerError, util.ErrorApiResponse("Failed to get user resource ARN: "+err.Error()))
		return
	}

	if role.Region == "" {
		role.Region = "ap-south-1"
	}

	endpoint := fmt.Sprintf("/check-cluster-health?cluster_name=%s&role_arn=%s&region=%s&user_id=%d&account_id=%s",
		clusters.ClusterName,
		role.UserResourceARN,
		role.Region,
		role.UserId,
		role.AccountId,
	)
	output, err := CallPythonAPI(endpoint, "GET", nil)
	if err != nil {
		config.Log.Error(err.Error())
	}
	c.Data(http.StatusOK, ContentHeader, output)
}

func CallPythonAPI(endpoint string, method string, requestBody []byte) ([]byte, error) {
	pythonServiceURL := os.Getenv("PYTHON_BACKEND_ENDPOINT")

	client := &http.Client{}
	var req *http.Request
	var err error

	config.Log.Info("calling API at: ", method, pythonServiceURL+endpoint)

	if requestBody != nil {
		req, err = http.NewRequest(method, pythonServiceURL+endpoint, bytes.NewBuffer(requestBody))
		if err != nil {
			return nil, err
		}
		req.Header.Set("Content-Type", "application/json")
	} else {
		req, err = http.NewRequest(method, pythonServiceURL+endpoint, nil)
		if err != nil {
			return nil, err
		}
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	config.Log.Info("resp status code: ", resp.StatusCode)

	buf := new(bytes.Buffer)
	_, err = buf.ReadFrom(resp.Body)
	if err != nil {
		return nil, err
	}

	var body map[string]interface{}
	err = json.Unmarshal(buf.Bytes(), &body)
	if err != nil {
		return nil, err
	}

	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusCreated {
		return nil, errors.New(util.CheckInterface(body["detail"]))
	}

	return buf.Bytes(), nil
}

// GetAwsAccountsByUserId
// @Summary Get AWS accounts by user ID
// @Description Get all AWS accounts associated with a user ID
// @Tags AWS Onboarding
// @Accept json
// @Produce json
// @Param user_id path string true "User ID"
// @Param limit query string false "Limit"
// @Param offset query string false "Offset"
// @Success 200 {object} ApiResonse
// @Router /aws/accounts/{user_id} [GET]
func GetAwsAccountsByUserId(c *gin.Context) {
	userId := c.Param("user_id")
	limit := c.Query("limit")
	page, _ := strconv.Atoi(c.Query("page"))

	DB := config.DB
	accountInformation := []models.AWSAccountRoles{}

	err := DB.Debug().Where("user_id = ?", userId).Limit(limit).Offset(page - 1).Find(&accountInformation).Error
	if err != nil {
		c.JSON(500, err)
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"error": false,
		"data":  accountInformation,
		"count": len(accountInformation),
	})
}

// GetAwsOnboardRoleConfiguration godoc
// @Summary Get AWS onboard role configuration
// @Description Get the configuration details for AWS role onboarding
// @Tags AWS Onboarding
// @Accept json
// @Produce json
// @Success 200 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /aws/role/configuration [get]
func GetAwsOnboardRoleConfiguration(c *gin.Context) {

	accountId := os.Getenv("NEXASTACK_ASSUME_ROLE_ARN")

	role := map[string]interface{}{
		"Version": "2012-10-17",
		"Statement": []map[string]interface{}{
			{
				"Effect": "Allow",
				"Principal": map[string]interface{}{
					"AWS": accountId,
				},
				"Action": "sts:AssumeRole",
			},
		},
	}

	c.JSON(200, gin.H{
		"error": false,
		"data":  role,
	})
}

func GetAccountIDFromARN(arn string) (string, error) {
	parts := strings.Split(arn, ":")
	if len(parts) < 5 {
		print("invalid ARN format")
	}
	return parts[4], nil
}
