//go:build !test
// +build !test

package api

import (
	"net/http"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
	"github.com/gin-gonic/gin"
)

// EmailVerifyToken defining structure for binding verification mail data
type EmailVerifyToken struct {
	VerificationCode string `json:"verification_code" binding:"required"`
	Email            string `json:"email" binding:"required"`
}

// VerifyMailEp is a api handler for verify email id by token
func VerifyMailEp(c *gin.Context) {
	config.Log.Info("VerifyMailEp function called")

	//handler panic and Alerts
	defer util.Panic()

	// binding request body data
	var tokendata EmailVerifyToken
	if c.BindJSON(&tokendata) != nil {
		// if there is some error passing bad status code
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Email and Verification Code are required field."})
		return
	}

	if !methods.ValidateEmail(tokendata.Email) {
		// if there is some error passing bad status code
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Please enter valid email id."})
		return
	}

	config.Log.Error("passed email validation")

	// passing email and token for getting verified
	account, ok := mail.VerifyMail(strings.ToLower(tokendata.Email), tokendata.VerificationCode)
	if !ok {
		// if there is some error then passing StatusUnauthorized and msg invalid token
		c.JSON(http.StatusUnauthorized, gin.H{"error": true, "message": "Invalid or expired Verification Code."})
		return
	}

	//=============================================

	// saving user-activity
	activity := database.Activities{Email: tokendata.Email,
		Name:         account.Name,
		ClientIP:     c.ClientIP(),
		ClientAgent:  c.Request.Header.Get("User-Agent"),
		Timestamp:    time.Now().Unix(),
		ActivityName: "email_verified"}

	//=============================================

	// setting jwt token and claims to be used in other protected apis
	mapd, err := jwtToken.GinJwtToken(account)
	if err != nil {
		config.Log.Error(err.Error())
		// activity
		activity.Status = "fail"
		activity.Reason = err.Error()
		activities.RecordActivity(activity)
		c.JSON(501, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}

	mapd["name"] = account.Name
	mapd["email"] = account.Email
	mapd["role_id"] = account.RoleID
	mapd["error"] = false
	mapd["id"] = account.ID

	mapd["message"] = "Email verification done"

	config.Log.Error("reached till RecordActivity")

	// activity
	activity.Status = "pass"
	activities.RecordActivity(activity)

	c.JSON(200, mapd)
}

func GetMemberInfo(tokendata EmailVerifyToken, mapd map[string]interface{}) ([]database.WorkspaceMembers, error) {
	member := []database.WorkspaceMembers{}
	err := config.DB.Debug().Where("member_email= ?", tokendata.Email).Find(&member).Error
	if len(member) == 0 || err != nil {
		//when not a member
		mapd["error"] = true
		mapd["message"] = "invalid email and password"
		return member, err
	}
	return member, nil
}

// ChangeMail is an api handler to toggle mail service
func ChangeMail(c *gin.Context) {
	config.Log.Info("ChangeMail function called")
	mail.ToggleMail(c.Param("value"))
}

// ChangeOTP is an api handler to toggle OTP
func ChangeOTP(c *gin.Context) {
	config.Log.Info("ChangeOTP function called")

	//handler panic and Alerts
	defer util.Panic()

	verifytoken.ToggleOTP(c.Param("value"))
}
