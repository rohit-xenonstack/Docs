package api

import (
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os/exec"
	"strconv"

	"git.xenonstack.com/nexa-platform/accounts/config"

	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"github.com/jinzhu/gorm"
)

// Define the WebSocket upgrader globally
var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		// Allow all origins for this example (can be more restrictive for production)
		return true
	},
}

// FineTuneModel godoc
// @Summary Fine tune model for given user and model.
// @Description Update specific field values for a user's fine-tune configuration
// @Tags Fine-tuning
// @Accept json
// @Produce json
// @Param user_id path string true "User ID"
// @Param config_id path string true "Config ID"
// @Success 200 {string} ApiResonse
// @Router /v1/finetune/{user_id}/{config_id} [POST]
func FineTuneModel(c *gin.Context) {
	userId := c.Param("user_id")
	jobId, _ := strconv.Atoi(c.Param("job_id"))

	// Upgrade the HTTP connection to a WebSocket connection
	wsConn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		config.Log.Error("WebSocket upgrade failed: "+err.Error(), err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to upgrade to WebSocket"})
		return
	}

	// Send a message that the connection was established successfully
	err = wsConn.WriteMessage(websocket.TextMessage, []byte("WebSocket connection established"))
	if err != nil {
		config.Log.Error("Failed to send message:", err)
		return
	}

	// Now, start the background task (training the model) asynchronously
	StartTraining(userId, wsConn, jobId)
}

func UpdateJob(userId string, DB *gorm.DB, modelStatus models.Status, jobId int) (int, error) {
	existingJob := models.Jobs{}
	existingConfig := models.FineTuneModelConfigurations{}

	err := DB.Where("created_by = ?", userId).Find(&existingConfig).Error
	if err != nil {
		return 0, err
	}

	job := models.Jobs{
		Model:     existingConfig.ModelName,
		Dataset:   existingConfig.Dataset,
		AccountId: existingConfig.CreatedBy,
		Status:    modelStatus,
	}

	err = DB.Where("id = ?", jobId).First(&existingJob).Error
	if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
		err = DB.Create(&job).Error
	} else {
		err = DB.Model(&existingJob).Updates(job).Error
	}
	if err != nil {
		util.ErrorApiResponse("Failed to create job: " + err.Error())
		return job.ID, err
	}
	return job.ID, nil
}

func StartTraining(userId string, wsConn *websocket.Conn, jobId int) {
	// Send an initial message to notify that the training has started
	DB := config.DB

	SendMessage(wsConn, "{\"process\":\"started\"}")
	defer wsConn.Close()

	cmd, stdout, stderr, err := PrepareCommand("python3", userId, jobId)
	if err != nil {
		log.Printf("Failed to prepare command: %s\n", err)
		SendMessage(wsConn, "Failed to prepare Python script execution")
		return
	}

	// Start the command
	if err := cmd.Start(); err != nil {
		log.Printf("Failed to start Python script: %s\n", err)
		SendMessage(wsConn, "Failed to start Python script")
		return
	}

	// Handle real-time output from the command
	HandleRealTimeOutput(stdout, wsConn, "RES")
	HandleRealTimeOutput(stderr, wsConn, "ERROR")

	// Wait for the command to finish
	if err := cmd.Wait(); err != nil {
		log.Printf("Error during training: %s\n", err)
		SendMessage(wsConn, "Error during training")

		// Update Job status
		_, err = UpdateJob(userId, DB, models.StatusInactive, jobId)
		if err != nil {
			return
		}
		return
	}

	// Update Job status
	_, err = UpdateJob(userId, DB, models.StatusInactive, jobId)
	if err != nil {
		return
	}
	// Final success message
	SendMessage(wsConn, "{\"process\":\"ended\"}")
}

// prepareCommand initializes the Python command and retrieves stdout and stderr pipes
func PrepareCommand(commandName, userId string, jobId int) (*exec.Cmd, io.ReadCloser, io.ReadCloser, error) {
	// Check if the command path is empty or invalid
	if commandName == "" {
		return nil, nil, nil, fmt.Errorf("invalid command path: '%s'", commandName)
	}

	cmd := exec.Command(commandName, "./src/python/main.py", userId, strconv.Itoa(jobId), "fine_tune")
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to get stdout pipe: %w", err)
	}

	stderr, err := cmd.StderrPipe()
	if err != nil {
		return nil, nil, nil, fmt.Errorf("failed to get stderr pipe: %w", err)
	}

	return cmd, stdout, stderr, nil
}

// handleRealTimeOutput reads from a reader (stdout or stderr) and sends the output via WebSocket
func HandleRealTimeOutput(reader io.Reader, wsConn *websocket.Conn, prefix string) {
	go func() {
		buf := make([]byte, 1024)
		for {
			n, err := reader.Read(buf)
			if err != nil {
				break
			}
			// Send the output with the appropriate prefix
			message := string(buf[:n])
			SendMessage(wsConn, message)
		}
	}()
}

// sendMessage sends a message to the WebSocket connection
func SendMessage(wsConn *websocket.Conn, message string) {
	if err := wsConn.WriteMessage(websocket.TextMessage, []byte(message)); err != nil {
		config.Log.Error("Error sending message: "+err.Error(), err)
	}
}
