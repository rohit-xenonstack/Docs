//go:build !test
// +build !test

package api

import (
	"net/http"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
	"git.xenonstack.com/nexa-platform/accounts/src/util"

	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// CheckToken godoc
// @Summary Check if token is valid
// @Description Verify if the current JWT token is valid
// @Tags Authentication
// @Produce json
// @Success 200 {object} map[string]interface{}
// @Router /v1/check_token [get]
func CheckToken(c *gin.Context) {

	c.JSON(200, gin.H{})
}

// RefreshToken godoc
// @Summary Refresh JWT token
// @Description Generate a new JWT token and invalidate the old one
// @Tags Authentication
// @Produce json
// @Success 200 {object} map[string]interface{}
// @Failure 501 {object} map[string]interface{}
// @Router /v1/refresh_token [get]
func RefreshToken(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)

	// fetch account on basis of id
	id := methods.ConvertID(claims["id"])
	acc := accounts.GetAccountForid(id)
	// generating new token
	mapd, err := jwtToken.JwtRefreshToken(claims)
	if err != nil {
		config.Log.Error(err)
		c.JSON(501, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}
	mapd["name"] = acc.Name
	mapd["email"] = acc.Email
	if acc.RoleID == "user" {
		mapd["workspace_role"] = claims["role"].(string)
	}
	mapd["sys_role"] = acc.RoleID

	// if any error in genrating new token
	if mapd["token"] == "" {
		c.JSON(501, gin.H{
			"error":   true,
			"message": "Error in generating new token",
		})
		return
	}
	if config.Conf.Service.IsLogoutOthers != "true" {
		// when succesfully generated new token
		// delete old token from redis
		// fetch token from header
		token := c.Request.Header.Get("Authorization")
		// trim bearer from token
		token = strings.TrimPrefix(token, "Bearer ")
		// call delete token go function
		err := redisdb.DeleteToken(token)
		if err != nil {
			c.JSON(501, gin.H{
				"error":   err,
				"message": "Error in deleting old token",
			})
			return
		}
	}
	c.JSON(200, mapd)
}

func CheckTokenValidity(c *gin.Context) {
	// fetch token from header
	token := c.Request.Header.Get("Authorization")
	// trim bearer from token
	token = strings.TrimPrefix(token, "Bearer ")

	// check token exists in Redis
	err := redisdb.CheckToken(token)
	if err != nil {
		// Allow request to pass if Redis is down
		if strings.Contains(err.Error(), "connection refused") ||
			strings.Contains(err.Error(), "i/o timeout") ||
			strings.Contains(err.Error(), "EOF") ||
			strings.Contains(err.Error(), "dial tcp") {

			config.Log.Warnf("Redis down while checking token, allowing request: %v", err)
			c.Next()
			return
		}

		// Otherwise, token is likely invalid or expired
		c.Abort()
		c.JSON(http.StatusUnauthorized, gin.H{"error": true, "message": "Expired auth token"})
		return
	}

	c.Next()
}

// CheckAdmin is a middleware for checking user is admin or not
func CheckAdmin(c *gin.Context) {
	claims := jwt.ExtractClaims(c)
	// checking sys role
	if claims["sys_role"].(string) != "admin" {
		c.Abort()
		c.JSON(403, gin.H{
			"error":   true,
			"message": NotAuthorizedMessage,
		})
		return
	}
	c.Next()
}

// CheckUser is a middleware for checking user is user or not
func CheckUser(c *gin.Context) {

	claims := jwt.ExtractClaims(c)
	// checking sys role
	if claims["sys_role"].(string) != "user" {
		c.Abort()
		c.JSON(403, gin.H{
			"error":   true,
			"message": NotAuthorizedMessage,
		})
		return
	}
	c.Next()
}

// CheckOwner is a middleware for checking workspace user is owner or not
func CheckOwner(c *gin.Context) {

	claims := jwt.ExtractClaims(c)

	// check user is owner of workpsace or user
	role, ok := claims["role"].(string)
	if !ok {
		c.Abort()
		c.JSON(403, gin.H{
			"error":   true,
			"message": NotAuthorizedMessage,
		})
		return
	}
	if role != "owner" {
		if role != "admin" {
			c.Abort()
			c.JSON(403, gin.H{
				"error":   true,
				"message": NotAuthorizedMessage,
			})
			return
		}
	}
	c.Next()
}

// RBAC is a middleware for checking if a user has permission to access a module and perform an action
func RBAC(module string, action string) gin.HandlerFunc {

	//[Deprecated RBAC check till confirmation]
	// config.Log.Debug("RBAC check deprecated - skipping permission validation")
	// return func(c *gin.Context) {
	// 	c.Next()
	// }
	//[Deprecated RBAC check till confirmation]

	return func(c *gin.Context) {
		claims := jwt.ExtractClaims(c)

		// Check if claims exist and contain required fields
		id, ok := claims["id"]
		if !ok || id == nil {
			c.Abort()
			c.JSON(401, gin.H{
				"error":   true,
				"message": "Invalid or missing user ID in token",
			})
			return
		}

		project_id, ok := claims["project_id"].(float64)
		if !ok || id == nil {
			c.Abort()
			c.JSON(401, gin.H{
				"error":   true,
				"message": "Invalid or missing project ID in token",
			})
		}

		// Convert id to int
		var userID int
		switch v := id.(type) {
		case float64:
			userID = int(v)
		case int:
			userID = v
		default:
			c.Abort()
			c.JSON(401, gin.H{
				"error":   true,
				"message": "Invalid user ID type in token",
			})
			return
		}

		// Get user's roles and permissions in a single query
		var permissions []models.Permission
		err := config.DefaultDb.Debug().Table("roles.permission").Select("roles.permission.action,account_role_mapping.project_id").
			Joins("JOIN roles.role_permission_mapping ON roles.permission.id = roles.role_permission_mapping.permission_id").
			Joins("JOIN roles.role ON roles.role_permission_mapping.role_id = roles.role.id").
			Joins("JOIN roles.account_role_mapping ON roles.role.id = roles.account_role_mapping.role_id").
			Where("roles.account_role_mapping.account_id = ?", userID).
			Find(&permissions).Error

		if err != nil {
			c.Abort()
			c.JSON(403, gin.H{
				"error":   true,
				"message": "Failed to check permissions",
			})
			return
		}

		hasPermission := false
		for _, perm := range permissions {
			config.Log.Debug("perm.ProjectId == int(project_id)", perm.ProjectId == int(project_id), perm.ProjectId, int(project_id))

			if perm.Action == action || perm.Action == "all" { // && (perm.ProjectId == int(project_id)) {
				hasPermission = true
				break
			}
		}

		config.Log.Debug("User has permission:", hasPermission)

		// If no specific permission found, check if user has admin or owner role
		if !hasPermission {
			sysRole, _ := claims["sys_role"].(string)
			workspaceRole, _ := claims["role"].(string)

			// Allow access if user is admin or owner
			if sysRole == "admin" || workspaceRole == "owner" {
				hasPermission = true
			}
		}

		if !hasPermission {
			c.Abort()
			c.JSON(403, gin.H{
				"error":   true,
				"message": "You don't have permission to perform this action",
			})
			return
		}

		c.Next()
	}
}
