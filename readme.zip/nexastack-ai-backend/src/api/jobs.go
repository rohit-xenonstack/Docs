package api

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"github.com/gin-gonic/gin"
)

func GetJobs(c *gin.Context) {
	accountId := c.Param("account_id")

	jobs, err := GetJobList(accountId)
	if err != nil {
		config.Log.Error(err.Error())
		c.JSON(500, gin.H{"error": err.Error()})
		return
	}

	c.JSON(200, gin.H{"error": false, "jobs": jobs})
}

func GetJobList(accountId string) (jobs []models.Jobs, err error) {
	// fetch jobs from db
	DB := config.DB

	err = DB.Where("account_id = ?", accountId).Find(&jobs).Error
	if err != nil {
		config.Log.Error(err.Error())
		return nil, err
	}

	return
}
