package api

import (
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	member1 "git.xenonstack.com/nexa-platform/accounts/src/member"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"git.xenonstack.com/nexa-platform/accounts/src/workspace"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// CreateWorkSpaceEp godoc
// @Summary Create a new workspace
// @Description Create a new workspace with the specified details
// @Tags Workspace
// @Accept json
// @Produce json
// @Param workspace body database.Workspaces true "Workspace details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/workspaces [post]
func CreateWorkSpaceEp(c *gin.Context) {
	// handler panic and Alerts
	defer util.Panic()
	// extract jwt claims
	claims := jwt.ExtractClaims(c)
	// bind body request data
	var data database.Workspaces
	if err := c.BindJSON(&data); err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": "WorkSpace URL is required."})
		return
	}
	// fetch id from claims
	email, ok := claims["email"]
	if !ok {
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Please login again",
		})
		return
	}

	// fetch id from claims
	userId, _ := claims["id"].(float64)

	config.Log.Debug("userId : ", int(userId))

	// create workspace
	code, mapd := workspace.CreateWorkspace(c, email.(string), c.GetHeader("Authorization"), data)
	if code != 200 {
		c.JSON(code, mapd)
		config.Log.Error(mapd)
		return
	}

	response := mapd
	recordActivity(claims, "create workspace", code, mapd, c)
	workspaceId := util.CheckInterface(mapd["workspace_id"].(string))

	mapd, resCode := ProjectPost(models.Project{
		Name:           NexastackDefaultProjectPrefix + strings.TrimSuffix(data.WorkspaceID, ".nexastack.neuralcompany.work"),
		WorkspaceID:    strings.TrimSuffix(data.WorkspaceID, ".nexastack.neuralcompany.work"),
		CreatedAt:      time.Now(),
		OrganizationId: int(userId),
		Description:    "A foundational project to facilitate seamless AI model deployment and inference within your workspace environment.",
	}, "", "", c.ClientIP())
	if resCode != 200 {
		mapd["error"] = true
		mapd["message"] = "Failed to create default project"
		config.Log.Error(mapd)
		return
	}

	loginac, err := accounts.GetAccountForEmail(email.(string))
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to get account"
		config.Log.Error(mapd)
		return
	}

	// fetch id from claims
	projectId, ok := mapd["id"]
	if !ok {
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Please login again",
		})
		return
	}
	err = member1.ProjectSendInvite(models.TempProjectMembers{
		Email:       loginac.Email,
		RoleId:      1,
		Role:        "owner",
		Name:        loginac.Name,
		ProjectId:   strconv.Itoa(projectId.(int)),
		Workspace:   workspaceId,
		ProjectName: util.CheckInterface(mapd["name"].(string)),
		Status:      "Member added",
		UserId:      int(userId),
		EnvironmentAccess: []models.TempEnvironmentPermissions{
			{
				Environment: "development",
				Permissions: []string{"all"},
			},
			{
				Environment: "stage",
				Permissions: []string{"all"},
			},
			{
				Environment: "prod",
				Permissions: []string{"all"},
			},
		},
	})
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to create default project member"
		config.Log.Error(mapd)
		return
	}

	c.JSON(code, response)
}

// WorkspaceAvailability godoc
// @Summary Check workspace availability
// @Description Check if a workspace URL is available
// @Tags Workspace
// @Accept json
// @Produce json
// @Param workspace body database.Workspaces true "Workspace URL to check"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/workspaces/availability [post]
func WorkspaceAvailability(c *gin.Context) {
	// handler panic and Alerts
	defer util.Panic()
	// bind body request data
	var data database.Workspaces
	if err := c.BindJSON(&data); err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": "workspace_url is required."})
		return
	}
	code, message := workspace.CheckWorkspaceAvailability(data)
	c.JSON(code, gin.H{
		"error":   code != 200,
		"message": message,
	})
}

// WorkSpaceLoginEp godoc
// @Summary Login to a workspace
// @Description Verify workspace existence and login
// @Tags Workspace
// @Accept json
// @Produce json
// @Param workspace body database.Workspaces true "Workspace details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/workspace_login [post]
func WorkSpaceLoginEp(c *gin.Context) {
	// handler panic and Alerts
	defer util.Panic()
	// bind body request data
	var data database.Workspaces
	if err := c.BindJSON(&data); err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": "WorkSpace URL is required."})
		return
	}
	code, mapd := workspace.Login(data.WorkspaceID)
	c.JSON(code, mapd)
}

// recordActivity records the activity of the user
func recordActivity(claims map[string]interface{}, activityName string, code int, mapd map[string]interface{}, c *gin.Context) {
	activity := database.Activities{
		Email:        claims["email"].(string),
		ActivityName: activityName,
		Name:         claims["name"].(string),
		ClientIP:     c.ClientIP(),
		ClientAgent:  c.Request.Header.Get("User  -Agent"),
		Timestamp:    time.Now().Unix(),
	}
	if code == 200 {
		activity.Status = "pass"
	} else {
		activity.Status = "fail"
		activity.Reason = mapd["message"].(string)
	}
	activities.RecordActivity(activity)
}

// ListEmail godoc
// @Summary List all user emails
// @Description Get a list of all user email addresses in the system
// @Tags Workspace
// @Produce json
// @Success 200 {array} database.Accounts
// @Router /v1/workspaces/emails [get]
func ListEmail() []database.Accounts {
	db := config.DB
	var acc []database.Accounts
	db.Find(&acc)
	return acc
}
