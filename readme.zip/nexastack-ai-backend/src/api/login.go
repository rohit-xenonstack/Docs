//go:build !test
// +build !test

package api

import (
	"net/http"
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/login"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"git.xenonstack.com/nexa-platform/accounts/src/workspace"
	"github.com/gin-gonic/gin"
)

type Login struct {
	Password    string `json:"password" binding:"required"`
	Email       string `json:"email" binding:"required"`
	Workspace   string `json:"workspace" binding:"required"`
	ProjectId   int    `json:"project_id"`
	Environment string `json:"environment"`
}

// LoginEndpoint godoc
// @Summary User login
// @Description Authenticate user and generate JWT token
// @Tags Authentication
// @Accept json
// @Produce json
// @Param login body Login true "Login payload"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/login [post]
func LoginEndpoint(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	//bind body request data
	// var data database.Workspaces

	var data Login
	if err := c.BindJSON(&data); err != nil {
		config.Log.Error("Please pass password and email")
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass password and email",
		})
		return
	}

	config.Log.Info("1..")
	//check the workspace exists or not
	code1, mapd1 := workspace.Login(data.Workspace)

	if code1 != http.StatusOK {
		c.JSON(code1, mapd1)
		return
	}

	if !methods.ValidateEmail(data.Email) {
		// if there is some error passing bad status code
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Please enter valid email id."})
		return
	}
	config.Log.Info("1..")

	//=============================================
	// recording user activity
	activity := database.Activities{Email: data.Email,
		ClientIP:    c.ClientIP(),
		CreatedAt:   time.Now(),
		ClientAgent: c.Request.Header.Get("User-Agent"),
		Timestamp:   time.Now().Unix()}
	//=============================================

	var projects models.Project
	if data.ProjectId == 0 {
		err := config.DB.Debug().Where("name = ?", NexastackDefaultProjectPrefix+data.Workspace).Find(&projects).Error
		if err != nil {
			config.Log.Error(err.Error())
			c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": err.Error()})
			return
		}
		data.ProjectId = int(projects.ID)
	}

	code, mapd := login.NormalLogin(strings.ToLower(data.Email), data.Password, data.Workspace, data.Environment, data.ProjectId)
	if code == 200 {

		config.Log.Info("after 200...")

		// Get user roles and permissions
		userID := strconv.Itoa(mapd["id"].(int))
		roles, err := GetUserRolesAndPermissions(userID)
		if err == nil {
			mapd["roles"] = roles
		} else {
			config.Log.Error("Error while fetching roles and permissions: ", err)
		}

		// recording user activity of login
		activity.ActivityName = "login"
		activity.Name = mapd["name"].(string)
		activity.Status = "pass"
		activity.CreatedAt = time.Now()
		activities.RecordActivity(activity)
	} else {
		// recording user activity of failed login
		activity.ActivityName = "login"
		activity.Status = "fail"
		activity.Reason = mapd["message"].(string)
		activity.CreatedAt = time.Now()
		activities.RecordActivity(activity)
	}
	c.JSON(code, mapd)
}
