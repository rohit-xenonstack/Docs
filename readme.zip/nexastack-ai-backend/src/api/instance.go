package api

import (
	"fmt"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"

	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// fucntion to get instances present in workspace
// fucntion to get instances present in workspace
func GetNodes(c *gin.Context) {
	config.Log.Info("GetNodes function called")
	claims := jwt.ExtractClaims(c)
	mapd := make(map[string]interface{})
	mapd["error"] = false
	wsid, ok := claims["workspace"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = LoginAgainMessage
		c.JSON(500, mapd)
		return
	}

	email, ok := claims["email"].(string)
	if !ok {
		mapd := make(map[string]interface{})
		mapd["error"] = true
		mapd["message"] = "Please login again"
		c.JSON(500, mapd)
		return
	}

	clusterName := c.Query("name")
	if clusterName == "" {
		mapd["error"] = true
		mapd["message"] = "cluster name is required"
		c.JSON(400, mapd)
		return
	}

	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	wsURLParts := strings.Split(wsid, ".")
	workspace := wsURLParts[0]
	nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)

	nodes, err := kubernetes.GetNodes(nameSpace, clusterName, workspace, email)
	if err != nil {
		config.Log.Error(fmt.Sprintf("Error fetching nodes: %v", err))
		c.JSON(500, gin.H{"error": true, "message": err.Error()})
		return
	}

	// Initialize response map

	for _, node := range nodes {
		var instance database.Instance

		nodeName, ok := node["Name"].(string)
		if !ok {
			config.Log.Error("Error: Node name is missing or incorrect type")
			continue
		}

		cpu, ok := node["CPU"].(map[string]interface{})
		if !ok {
			config.Log.Error(fmt.Sprintf("Error: CPU data is missing or incorrect type for node %s", nodeName))
			continue
		}

		capacity, _ := cpu["Capacity"].(string) // Use safe assertion
		allocatable, _ := cpu["Allocatable"].(string)
		operatingSystem, _ := cpu["operatingSystem"].(string)

		// Check if instance exists
		db := config.DB
		result := db.Debug().Where("workspace_id = ? AND node_name = ? AND cluster_name=?", wsid, nodeName, clusterName).First(&instance)

		if result.RowsAffected == 0 {
			// Insert new node
			newInstance := database.Instance{
				UserEmail:       email,
				WorkspaceID:     wsid,
				NodeName:        nodeName,
				Capacity:        capacity,
				Allocatable:     allocatable,
				OperatingSystem: operatingSystem,
				ClusterName:     clusterName,
				IsDeleted:       false,
			}
			db.Create(&newInstance)
			config.Log.Debug(fmt.Sprintf("Inserted new node: %s", nodeName))
		} else {
			// Update only if there are changes
			updated := false
			if instance.Capacity != capacity || instance.Allocatable != allocatable || instance.OperatingSystem != operatingSystem {
				instance.Capacity = capacity
				instance.Allocatable = allocatable
				instance.OperatingSystem = operatingSystem
				db.Save(&instance)
				updated = true
			}
			config.Log.Debug(fmt.Sprintf("Instance for Node: %s updated: %v", nodeName, updated))
		}
	}

	// Prepare response
	mapd["nodes"] = nodes
	mapd["email"] = email
	mapd["namespace"] = nameSpace

	c.JSON(200, mapd)

}

// func GetNodesDatabase(c *gin.Context) {
// 	claims := jwt.ExtractClaims(c)
// 	wsid, ok := claims["workspace"].(string)
// 	if !ok {
// 		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
// 		return
// 	}
// 	workspace := GetWorkspaceID(wsid)
// 	// nameSpace := "nexa-" + branch + "-" + strings.Replace(workspace, "_", "-", -1)

// 	db := config.DB
// 	var instances []database.Instance
// 	if err := db.Where("workspace_id = ? AND is_deleted = ?", workspace, false).Find(&instances).Error; err != nil {
// 		mapd := make(map[string]interface{})
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		c.JSON(500, mapd)
// 		return
// 	}

// 	// var nodes []string
// 	// for _, instance := range instances {
// 	// 	nodes = append(nodes, instance.NodeName)
// 	// }

// 	mapd := make(map[string]interface{})
// 	mapd["nodes_details"] = instances

// 	c.JSON(200, mapd)
// }

// checkEmailBelongsToWorkspace checks if an email belongs to the same workspace
func CheckEmailBelongsToWorkspace(workspaceID string, email string) error {
	var workspace database.WorkspaceMembers
	if err := config.DB.Where("workspace_id = ? AND member_email = ?", workspaceID, email).First(&workspace).Error; err != nil {
		return fmt.Errorf("Email does not belong to the same workspace")
	}
	return nil
}

// getNameSpace returns the namespace for a given workspace ID
func GetNameSpace(workspaceID string) string {
	branch := strings.ToLower(config.Conf.Service.Branch)
	if branch == "" {
		branch = "prod"
	}
	return "nexa-" + branch + "-" + strings.Replace(workspaceID, "_", "-", -1)
}

// getWorkspaceID returns the workspace ID from the workspace URL
func GetWorkspaceID(wsid string) string {
	wsURLParts := strings.Split(wsid, ".")
	return wsURLParts[0]
}
