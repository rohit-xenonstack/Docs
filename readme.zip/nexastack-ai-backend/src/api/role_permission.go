package api

import (
	"fmt"
	"net/http"
	"os"
	"strconv"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// CreateRole godoc
// @Summary Create a new role
// @Description Create a new role with the specified name
// @Tags RBAC
// @Accept json
// @Produce json
// @Param role body models.Role true "Role object to create"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/roles [post]
func CreateRole(c *gin.Context) {
	var role models.Role
	if err := c.BindJSON(&role); err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	if err := config.DB.Create(&role).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	util.SuccessApiResponse("Role created successfully")

	c.JSON(http.StatusOK, gin.H{
		"id":      role.Id,
		"name":    role.Name,
		"message": "Role created successfully",
		"error":   false,
	})
}

// CreatePermission godoc
// @Summary Create multiple permissions
// @Description Create multiple permissions at once
// @Tags RBAC
// @Accept json
// @Produce json
// @Param permissions body []models.Permission true "Array of permission objects to create"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/permissions [post]
func CreatePermission(c *gin.Context) {
	var permissions []models.Permission
	var recordCount int

	if err := c.BindJSON(&permissions); err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	// Validate each permission
	for _, permission := range permissions {
		if permission.Feature == "" || permission.Action == "" {
			c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Feature and action are required for all permissions"))
			return
		}

		// Check if permission already exists
		err := config.DB.Debug().Model(&models.Permission{}).
			Where("feature = ? AND action = ?", permission.Feature, permission.Action).
			Count(&recordCount).Error
		if err != nil {
			c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
			return
		}

		if recordCount != 0 {
			c.JSON(http.StatusBadRequest, util.ErrorApiResponse(fmt.Sprintf("Permission already exists for feature: %s, action: %s", permission.Feature, permission.Action)))
			return
		}
	}

	// Create all permissions in a single transaction
	tx := config.DB.Begin()
	if tx.Error != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(tx.Error.Error()))
		return
	}

	for _, permission := range permissions {
		if err := tx.Debug().Create(&permission).Error; err != nil {
			tx.Rollback()
			c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Failed to create permissions"))
			return
		}
	}

	if err := tx.Commit().Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Failed to commit permissions"))
		return
	}

	// Format response
	formattedPermissions := make([]map[string]string, len(permissions))
	for i, p := range permissions {
		formattedPermissions[i] = map[string]string{
			"feature": p.Feature,
			"action":  p.Action,
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"permissions": formattedPermissions,
		"message":     "Permissions created successfully",
		"error":       false,
	})
}

// AddPermissionToRole godoc
// @Summary Add permissions to a role
// @Description Add one or more permissions to an existing role
// @Tags RBAC
// @Accept json
// @Produce json
// @Param role_id path int true "Role ID"
// @Param permission_ids body []int true "Array of permission IDs to add"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 404 {object} map[string]interface{}
// @Router /v1/roles/{role_id}/permissions [post]
func AddPermissionToRole(c *gin.Context) {
	roleID, err := strconv.Atoi(c.Param("role_id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Invalid role ID"))
		return
	}

	var permissionIDs []int
	if err := c.BindJSON(&permissionIDs); err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	// Check if role exists
	var role models.Role
	if err := config.DB.First(&role, roleID).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Role not found"))
		return
	}

	// Check if all permissions exist
	var permissions []models.Permission
	if err := config.DB.Where("id IN (?)", permissionIDs).Find(&permissions).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Error checking permissions: "+err.Error()))
		return
	}

	if len(permissions) != len(permissionIDs) {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("One or more permissions not found"))
		return
	}

	// Check for existing mappings
	var existingMappings []models.RolePermissionMapping
	if err := config.DB.Where("role_id = ? AND permission_id IN (?)", roleID, permissionIDs).
		Find(&existingMappings).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Error checking existing mappings"))
		return
	}

	if len(existingMappings) > 0 {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("One or more permissions are already assigned to this role"))
		return
	}

	// Create new role-permission mappings in a single transaction
	tx := config.DB.Begin()
	if tx.Error != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(tx.Error.Error()))
		return
	}

	for _, permissionID := range permissionIDs {
		var rolePermission models.RolePermissionMapping
		rolePermission.RoleID = uint(roleID)
		rolePermission.PermissionId = uint(permissionID)

		if err := tx.Create(&rolePermission).Error; err != nil {
			tx.Rollback()
			c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Failed to assign permissions"))
			return
		}
	}

	if err := tx.Commit().Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Failed to commit permissions"))
		return
	}

	// Format response
	formattedPermissions := make([]map[string]string, len(permissions))
	for i, p := range permissions {
		formattedPermissions[i] = map[string]string{
			"feature": p.Feature,
			"action":  p.Action,
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"message":     "Permissions added to role successfully",
		"error":       false,
		"role_id":     roleID,
		"permissions": formattedPermissions,
	})
}

// AddRoleToUser godoc
// @Summary Assign role to user
// @Description Assign a specific role to a user
// @Tags RBAC
// @Produce json
// @Param user_id path string true "User ID"
// @Param role_id path string true "Role ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/users/{user_id}/roles/{role_id} [post]
func AddRoleToUser(c *gin.Context) {
	userID, err := strconv.Atoi(c.Param("user_id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Invalid user ID"))
		return
	}

	roleID, err := strconv.Atoi(c.Param("role_id"))
	if err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Invalid role ID"))
		return
	}

	var user models.User
	if err := config.DB.First(&user, userID).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("User not found"))
		return
	}

	var role models.Role
	if err := config.DB.First(&role, roleID).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse("Role not found"))
		return
	}

	var RolePermissionMapping models.RolePermissionMapping
	RolePermissionMapping.PermissionId = uint(userID)
	RolePermissionMapping.RoleID = uint(roleID)

	if err := config.DB.Create(&RolePermissionMapping).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	c.JSON(http.StatusOK, util.SuccessApiResponse("Role added to user successfully"))
}

// ListRoles godoc
// @Summary List all roles with their permissions
// @Description Get a list of all roles and their associated permissions
// @Tags RBAC
// @Produce json
// @Param domain query string false "Filter roles by domain"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/roles [get]
func ListRoles(c *gin.Context) {
	var roles []models.Role
	var rolePermissions []models.RolePermissionMapping
	var permissions []models.Permission

	// Get domain filter from query parameter
	domain := c.Query("domain")

	// Get all roles with optional domain filter
	query := config.DB.Debug()
	if domain != "" {
		query = query.Where("domain = ?", domain)
	}

	query = query.Where("(environment = ? or environment is null)", GetEnvString())
	if err := query.Find(&roles).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	// Get all role-permission mappings
	if err := config.DB.Debug().Find(&rolePermissions).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	// Get all permissions
	if err := config.DB.Debug().Find(&permissions).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	// Create a map of permission ID to permission details
	permissionMap := make(map[uint]models.Permission)
	for _, p := range permissions {
		permissionMap[p.ID] = p
	}

	// Create a map of role ID to permissions
	rolePermissionMap := make(map[uint][]map[string]string)
	for _, rp := range rolePermissions {
		if p, exists := permissionMap[rp.PermissionId]; exists {
			rolePermissionMap[rp.RoleID] = append(rolePermissionMap[rp.RoleID], map[string]string{
				"feature": p.Feature,
				"action":  p.Action,
			})
		}
	}

	// Prepare response with roles and their permissions
	response := make([]map[string]interface{}, len(roles))
	for i, role := range roles {
		response[i] = map[string]interface{}{
			"id":          role.Id,
			"name":        role.Name,
			"domain":      role.Domain,
			"environment": role.Environment,
			"permissions": rolePermissionMap[uint(role.Id)],
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"roles": response,
		"error": false,
	})
}

func GetEnvString() (res string) {
	switch os.Getenv("ENVIRONMENT") {
	case "stage":
		res = "stage"
	case "prod":
		res = "prod"
	default:
		res = "developement"
	}
	return
}

// ListPermissions godoc
// @Summary List all permissions
// @Description Get a list of all available permissions
// @Tags RBAC
// @Produce json
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/permissions [get]
func ListPermissions(c *gin.Context) {
	var permissions []models.Permission

	if err := config.DB.Find(&permissions).Error; err != nil {
		c.JSON(http.StatusBadRequest, util.ErrorApiResponse(err.Error()))
		return
	}

	// Format permissions as requested
	formattedPermissions := make([]map[string]string, len(permissions))
	for i, p := range permissions {
		formattedPermissions[i] = map[string]string{
			"feature": p.Feature,
			"action":  p.Action,
		}
	}

	c.JSON(http.StatusOK, gin.H{
		"permissions": formattedPermissions,
		"error":       false,
	})
}

// GetUserRolesAndPermissions fetches all roles and permissions for a user
func GetUserRolesAndPermissions(userID string) ([]models.RolePermissionResponse, error) {
	var roleResponses []models.RolePermissionResponse

	config.Log.Info("in function...")

	// Get all roles and their permissions in a single query
	var userRoles []struct {
		RoleID    uint   `gorm:"column:role_id"`
		RoleName  string `gorm:"column:role_name"`
		Feature   string `gorm:"column:feature"`
		Action    string `gorm:"column:action"`
		ProjectId int    `gorm:"column:project_id"`
	}

	err := config.DB.Debug().Table("roles.role").
		Select("roles.role.id as role_id, roles.role.name as role_name, roles.permission.feature as feature, roles.permission.action as action").
		Joins("JOIN roles.account_role_mapping ON roles.role.id = roles.account_role_mapping.role_id").
		Joins("JOIN roles.role_permission_mapping ON roles.role.id = roles.role_permission_mapping.role_id").
		Joins("JOIN roles.permission ON roles.role_permission_mapping.permission_id = roles.permission.id").
		Where("roles.account_role_mapping.account_id = ?", userID).
		Scan(&userRoles).Error

	if err != nil {
		return nil, err
	}

	// Group permissions by role and feature
	rolePermissions := make(map[uint]map[string][]string)
	roleNames := make(map[uint]string)

	for _, ur := range userRoles {
		if _, exists := rolePermissions[ur.RoleID]; !exists {
			rolePermissions[ur.RoleID] = make(map[string][]string)
			roleNames[ur.RoleID] = ur.RoleName
			// rolePermissions[uint(ur.ProjectId)] = str(ur.ProjectId)
		}

		// Add action to the feature group
		rolePermissions[ur.RoleID][ur.Feature] = append(rolePermissions[ur.RoleID][ur.Feature], ur.Action)
	}

	// Convert to RolePermissionResponse
	for roleID, permissions := range rolePermissions {
		var permissionGroups []string
		for _, actions := range permissions {
			permissionGroups = actions
		}

		roleResponses = append(roleResponses, models.RolePermissionResponse{
			Id:          int(roleID),
			RoleName:    roleNames[roleID],
			Permissions: permissionGroups,
			// ProjectId:   roleNames[ProjectId],
		})
	}

	config.Log.Info("Role Checked: ", roleResponses)
	return roleResponses, nil
}
