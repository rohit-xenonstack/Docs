package api

import (
	"strconv"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/integrations"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

// ListInfrastucture is an endpoint for listing all integrations
func ListInfrastucture(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	//extracting jwt claims for getting user id
	claims := jwt.ExtractClaims(c)
	// fetch and check workspace
	workspace, ok := claims["workspace"].(string)
	if !ok {
		config.Log.Error("workspace not found")
		c.JSON(500, gin.H{
			"error":   true,
			"message": "please login again",
		})
		return
	}

	pid := c.Query("page")
	if pid == "" {
		pid = "1"
	}
	page, err := strconv.Atoi(pid)
	if err != nil {
		config.Log.Error("wrong page found")
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass valid page number",
		})
		return
	}
	lim := c.Query("limit")
	if lim == "" {
		lim = "10"
	}
	limit, err := strconv.Atoi(lim)
	if err != nil {
		config.Log.Error("wrong limit found")
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass valid limit number",
		})
		return
	}
	mapd, code := integrations.ListInfrastucture(workspace, c.Query("type"), c.Query("search"), limit, page)
	c.JSON(code, mapd)
}
