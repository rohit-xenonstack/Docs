package api

const LoginAgainMessage = "Please login again"
const ClientAgentUser = "User-Agent"
const NotAuthorizedMessage = "You are not authorized"
const MinioEmailLog = "===email==="
const WorkspaceNotMatchMessage = "Workspace does not match"
const GetDeployModelWhereConditions = "workspace_id = ? AND member_email = ?"
const WorkSpaceEmailError = "Email does not belong to the same workspace"
const WorkspaceIdWhereCondition = "workspace_id = ?"
const InvalidData = "Invalid data"
const NexaStackSubBasePath = ".nexastack.neuralcompany.team"
const Http = "https://"
const NoteBookIngressNexaStackURL = ".nexastack.neuralcompany.team/"
const ContentHeader = "application/json; charset=utf-8"
const NexastackDefaultProjectPrefix = "nexastack_"

var ProjectMemberActivityWhereClause = []string{`Project member invited`, `Member added`}

var PresetValues = map[string]map[string]map[string]interface{}{
	"nano": {
		"cpu": {
			"limit":     0.15, // 150m -> 0.15
			"guarantee": 0.1,  // 100m -> 0.1
		},
		"memory": {
			"limit":     "0.1875G", // 192Mi -> 0.1875G
			"guarantee": "0.125G",  // 128Mi -> 0.125G
		},
	},
	"micro": {
		"cpu": {
			"limit":     0.375,
			"guarantee": 0.25,
		},
		"memory": {
			"limit":     "0.375G", // 384Mi -> 0.375G
			"guarantee": "0.25G",  // 256Mi -> 0.25G
		},
	},
	"small": {
		"cpu": {
			"limit":     0.75,
			"guarantee": 0.5,
		},
		"memory": {
			"limit":     "0.75G", // 768Mi -> 0.75G
			"guarantee": "0.5G",  // 512Mi -> 0.5G
		},
	},
	"medium": {
		"cpu": {
			"limit":     1.5,
			"guarantee": 1.0,
		},
		"memory": {
			"limit":     "1.5G", // 1536Mi -> 1.5G
			"guarantee": "1.0G", // 1024Mi -> 1G
		},
	},
	"large": {
		"cpu": {
			"limit":     1.5,
			"guarantee": 1.0,
		},
		"memory": {
			"limit":     "3.0G", // 3072Mi -> 3G
			"guarantee": "2.0G", // 2048Mi -> 2G
		},
	},
	"xlarge": {
		"cpu": {
			"limit":     3.0,
			"guarantee": 1.0,
		},
		"memory": {
			"limit":     "6.0G", // 6144Mi -> 6G
			"guarantee": "3.0G", // 3072Mi -> 3G
		},
	},
	"2xlarge": {
		"cpu": {
			"limit":     6.0,
			"guarantee": 3.0,
		},
		"memory": {
			"limit":     "12.0G", // 12288Mi -> 12G
			"guarantee": "3.0G",  // 3072Mi -> 3G
		},
	},
}

const WhereUserId = "user_id = ?"
const WhereUserIdAndAccountId = "user_id = ? and account_id = ?"
const WorkSpaceNotFoundErrorMessage = "workspace not found"
const EmailNotFoundMessage = "email not found"
