package api

import (
	"os"
	"os/exec"
	"strings"

	// "git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/azures"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"

	// "git.xenonstack.com/nexa-platform/accounts/src/resource"

	// "git.xenonstack.com/nexa-platform/accounts/src/resource"
	"git.xenonstack.com/nexa-platform/accounts/src/vmonboarding"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
)

type VmName struct {
	NodeName string `json:"node_name" validate:"required"`
	UserName string `json:"user_name" validate:"required"`
}

// SaveVmPrivateKey godoc
// @Summary Save VM private key
// @Description Generate and save private key for a virtual machine
// @Tags VM
// @Accept json
// @Produce json
// @Param name path string true "Cluster name"
// @Param vm body VmName true "VM details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/vm/{name}/key [post]
func SaveVmPrivateKey(c *gin.Context) {
	config.Log.Info("SaveVmPrivateKey function called")

	mapd := make(map[string]interface{})
	mapd["error"] = false
	var vmName VmName
	if err := c.ShouldBindJSON(&vmName); err != nil {
		mapd["error"] = true
		mapd["message"] = "Please pass VM name."
		c.JSON(400, mapd)
		return
	}
	clusterName := c.Param("name")
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}

	workspaceID := GetWorkspaceID(wsid)

	db := config.DB

	vm := []database.VmDetailes{}
	db.Where("name = ? AND workspace = ? AND cluster_name = ?", vmName.NodeName, workspaceID, clusterName).First(&vm)

	if len(vm) != 0 {
		mapd["error"] = true
		mapd["message"] = "Vm name already exists in this cluster"
		c.JSON(500, mapd)
		return
	}

	response, err := vmonboarding.RunGenerateKeyCommand(vmName.NodeName, workspaceID, clusterName, vmName.UserName)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(500, mapd)
		return
	}
	// token := response
	config.Log.Error("====token string====", response)
	publicKey := response["public_key"].(string)
	// encodedPublicKey := base64.StdEncoding.EncodeToString(publicKey)
	mapd["error"] = false
	mapd["public_key"] = publicKey
	mapd["message"] = "Public Key generated successfully"
	c.JSON(200, mapd)

}

// VmOnboarding godoc
// @Summary Onboard a virtual machine
// @Description Onboard a new virtual machine to the system
// @Tags VM
// @Accept json
// @Produce json
// @Param vm body database.VmDetailes true "VM details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/vm/onboarding [post]
func VmOnboarding(c *gin.Context) {
	config.Log.Info("VmOnboarding function called")
	mapd := make(map[string]interface{})
	mapd["error"] = false
	var vm database.VmDetailes

	if err := c.ShouldBindJSON(&vm); err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Please pass required detailes"
		c.JSON(400, mapd)
		return
	}

	println("====port====", vm.SSHPort)
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	email, ok := claims["email"].(string)
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	workspaceID := GetWorkspaceID(wsid)
	nameSpace := GetNameSpace(workspaceID)

	println("==vm_ip==", vm.VmIP)
	//get kube config from vault
	// Set kube-config
	_, path, code, err := kubernetes.SetInfraConfig(nameSpace, vm.ClusterName, workspaceID, email)
	defer os.Remove(path)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(code, mapd)
		return
	}

	response, err := vmonboarding.RunGenerateTokenCommand(path, nameSpace, vm.ClusterName, workspaceID, email)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = err.Error()
		c.JSON(500, mapd)
		return
	}
	token := response["token"].(string)
	config.Log.Error("====token string====", token)

	tokenParts := strings.Split(token, "kubeadm join")
	if len(tokenParts) < 2 {
		config.Log.Error("Invalid token format")
		mapd["error"] = true
		mapd["message"] = "Invalid token format"
		c.JSON(500, mapd)
		return
	}

	ipPort := strings.TrimSpace(tokenParts[1])
	ipPortParts := strings.Split(ipPort, ":")
	if len(ipPortParts) < 2 {
		config.Log.Error("Invalid token format")
		mapd["error"] = true
		mapd["message"] = "Invalid token format"
		c.JSON(500, mapd)
		return
	}

	ip := ipPortParts[0]

	tokenParts = strings.Split(token, "--token")
	if len(tokenParts) < 2 {
		config.Log.Error("Invalid token format")
		mapd["error"] = true
		mapd["message"] = "Invalid token format"
		c.JSON(500, mapd)
		return
	}

	kubeToken := strings.TrimSpace(strings.Split(tokenParts[1], "--")[0])

	discoveryToken := strings.TrimSpace(strings.Split(token, "--discovery-token-ca-cert-hash")[1])

	config.Log.Error("IP:", ip)
	config.Log.Error("Token:", kubeToken)
	config.Log.Error("Discovery Token:", discoveryToken)

	// // Save details in database

	db := config.DB
	db.Where("name = ? AND workspace = ? AND user_name = ?", vm.Name, workspaceID, vm.UserName).First(&vm)

	if vm.ID != 0 {
		mapd["error"] = true
		mapd["message"] = "Vm name already exists in this cluster"
		c.JSON(500, mapd)
		return
	} else {
		// Create new record
		newVm := database.VmDetailes{
			Name:           vm.Name,
			UserName:       vm.UserName,
			ClusterName:    vm.ClusterName,
			Workspace:      workspaceID,
			NodeType:       vm.NodeType,
			SSHPort:        vm.SSHPort,
			CreatedBy:      email,
			ClusterIP:      ip,
			VmIP:           vm.VmIP,
			Token:          kubeToken,
			DiscoveryToken: discoveryToken,
		}
		err = db.Debug().Create(&newVm).Error
		if err != nil {
			config.Log.Error(err.Error())
			mapd["error"] = true
			mapd["message"] = "Failed to create new record"
			c.JSON(500, mapd)
			return
		}
	}

	//Downlaod the ansible folder
	// var bucketName = "ansible"
	// var fileName = "ansible.zip"
	// resource.DownloadAnsibleFolder(bucketName, fileName)

	ansiblePath, err, shouldReturn := Ansible(vm, err, token, workspaceID, mapd, c)
	if shouldReturn {
		return
	}

	// if err := os.MkdirAll("", 0777); err != nil {
	// 	log.Print(err)
	// 	mapd["error"] = true
	// 	mapd["message"] = err.Error()
	// 	return mapd, 500
	// }

	// Run the Ansible command
	// cmd := exec.Command("ansible-playbook", "-i", "/home/xs453-ansgoy/Downloads/ansible-playbook-workernode/inventory", "/home/xs453-ansgoy/Downloads/ansible-playbook-workernode/main.yml")
	// output, err := cmd.CombinedOutput()
	// if err != nil {
	// 	log.Println(err)
	// 	log.Println(string(output))
	// 	mapd["error"] = true
	// 	mapd["message"] = "Failed to run Ansible command"
	// 	c.JSON(500, mapd)
	// 	return
	// }

	mapd, code = azures.GetPrivateKey(workspaceID, vm.ClusterName, vm.Name, vm.UserName)
	if code != 200 {
		config.Log.Error(err.Error())
		// Remove the VM details from the database
		vm.Workspace = workspaceID
		RemoveVmDetails(&vm)
		mapd["error"] = true
		mapd["message"] = "Failed to Fetch private key"
		c.JSON(code, mapd)
		return
	}

	// Run the Ansible command
	cmd := exec.Command("ansible-playbook", "-i", "ansible/inventory", ansiblePath, "--private-key", mapd["private_key_path"].(string))
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		config.Log.Error(err.Error())
		// Remove the VM details from the database
		vm.Workspace = workspaceID
		RemoveVmDetails(&vm)
		mapd["error"] = true
		mapd["message"] = "Failed to run Ansible command"
		c.JSON(500, mapd)
		return
	}

	err = cmd.Start()
	if err != nil {
		config.Log.Error(err.Error())
		// Remove the VM details from the database
		vm.Workspace = workspaceID
		RemoveVmDetails(&vm)
		mapd["message"] = "Failed to run Ansible command"
		c.JSON(500, mapd)
		return
	}

	// Read the output of the command and send it to the client
	buf := make([]byte, 1024)
	var output []byte
	for {
		n, err := stdout.Read(buf)
		if err != nil {
			break
		}
		output = append(output, buf[:n]...)
	}

	err = cmd.Wait()
	if err != nil {
		config.Log.Error(err.Error())
		vm.Workspace = workspaceID
		RemoveVmDetails(&vm)
		mapd["error"] = true
		mapd["message"] = "Failed to run Ansible command"
		c.JSON(500, mapd)
		return
	}

	// Write the response body
	c.Writer.Write(output)
	c.Writer.Flush()

	mapd["error"] = false
	mapd["message"] = vm.Name + " node added successfully."
	c.JSON(200, mapd)

}

func Ansible(vm database.VmDetailes, err error, token string, workspaceID string, mapd map[string]interface{}, c *gin.Context) (string, error, bool) {
	config.Log.Info("Ansible function called")
	changingValues := map[string]interface{}{
		"node_name": vm.Name,
	}
	var ansiblePath string
	println("====node_type====", vm.NodeType)
	if vm.NodeType == "worker" {
		ansiblePath = "ansible/main.yml"
	} else {
		ansiblePath = "ansible/master.yml"
	}

	err = methods.UpdateYamlFile(ansiblePath, changingValues, token)
	if err != nil {
		config.Log.Error(err.Error())
		vm.Workspace = workspaceID
		RemoveVmDetails(&vm)
		mapd["error"] = true
		mapd["message"] = "Failed to update the yaml file"
		c.JSON(500, mapd)
		return "", nil, true
	}

	println("===ssh_port==", vm.SSHPort)
	err = methods.CreateInventoryFile(vm.VmIP, vm.UserName, vm.SSHPort)
	if err != nil {
		config.Log.Error(err.Error())
		// Remove the VM details from the database
		vm.Workspace = workspaceID
		RemoveVmDetails(&vm)
		mapd["error"] = true
		mapd["message"] = "Failed to create inventory file"
		c.JSON(500, mapd)
		return "", nil, true
	}
	return ansiblePath, err, false
}

type ClusterRequest struct {
	ClusterName string `json:"cluster_name"`
}

// DeleteVmNode godoc
// @Summary Delete a virtual machine
// @Description Remove a virtual machine from the system
// @Tags VM
// @Produce json
// @Param name path string true "VM name"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/vm/{name} [delete]
func DeleteVmNode(c *gin.Context) {
	config.Log.Info("DeleteVmNode function called")
	vmName := c.Param("name")
	var clusterName ClusterRequest
	mapd := make(map[string]interface{})
	mapd["error"] = false

	if err := c.ShouldBindJSON(&clusterName); err != nil {
		mapd["error"] = true
		mapd["message"] = "Please pass valid cluster name."
		c.JSON(400, mapd)
		return
	}
	claims := jwt.ExtractClaims(c)
	wsid, ok := claims["workspace"].(string)
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	email, ok := claims["email"].(string)
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	workspaceID := GetWorkspaceID(wsid)
	nameSpace := GetNameSpace(workspaceID)
	db := config.DB

	nodeInfo, err := vmonboarding.DeleteVmNode(vmName, clusterName.ClusterName, workspaceID, nameSpace, email)
	if err != nil {
		config.Log.Error(err.Error())
		mapd["error"] = true
		mapd["message"] = "Failed to Delete Cluster"
		c.JSON(500, mapd)
		return
	}

	println("==vn node==", nodeInfo["message"].(string))

	var vm database.VmDetailes
	if err := db.Debug().Where("name = ? AND workspace = ? AND cluster_name = ?", vmName, workspaceID, clusterName.ClusterName).First(&vm).Error; err != nil {
		mapd["error"] = true
		mapd["message"] = "VM Node not found"
		c.JSON(404, mapd)
		return
	}

	if err := db.Debug().Delete(&vm).Error; err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to delete node from " + clusterName.ClusterName
		c.JSON(500, mapd)
		return
	}

	mapd["error"] = false
	mapd["message"] = vmName + " node deleted successfully from " + clusterName.ClusterName
	c.JSON(200, mapd)
}

// helper function to remove the VM Details

func RemoveVmDetails(vm *database.VmDetailes) {
	config.Log.Info("RemoveVmDetails function called")
	db := config.DB
	db.Debug().Where("name = ? AND workspace = ? AND user_name = ? AND cluster_name = ?", vm.Name, vm.Workspace, vm.UserName, vm.ClusterName).Delete(&database.VmDetailes{})
}
