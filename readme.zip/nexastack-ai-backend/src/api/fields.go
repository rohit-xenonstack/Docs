package api

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"

	models "git.xenonstack.com/nexa-platform/accounts/models"

	utils "git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/lib/pq"
)

type ApiResonse struct {
	Error   bool   `json:"error"`
	Message string `json:"message"`
}

// FineTuneFieldMetadata defines the metadata for each fine-tune field
type FineTuneFieldMetadata struct {
	Id          int       `gorm:"primaryKey" json:"id"`                        // Primary Key
	Name        string    `gorm:"type:varchar(255);not null" json:"name"`      // Name of the field
	Section     string    `gorm:"type:varchar(255)" json:"section"`            // Section in which value falls
	InputType   string    `gorm:"type:varchar(255)" json:"input_type"`         // Input type of the fields
	FieldType   string    `gorm:"type:varchar(255)" json:"field_type"`         // Field type (e.g., string, int)
	Description string    `gorm:"type:text" json:"description,omitempty"`      // Description of the field
	CreatedAt   time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"` // Creation timestamp
	UpdatedAt   time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"` // Last update timestamp
	CreatedBy   int       `gorm:"type:int" json:"created_by"`                  // Creator of the field
}

// FineTuneModelConfigurations defines the configuration for the model
type FineTuneModelConfigurations struct {
	Id                  int           `gorm:"primaryKey;autoIncrement" json:"id"`              // Primary Key
	ModelName           string        `gorm:"type:varchar(255);not null" json:"model_name"`    // Model name
	ModelPath           string        `gorm:"type:varchar(255)" json:"model_path"`             // Path to the model
	FieldConfigurations pq.Int32Array `gorm:"type:int[];not null" json:"field_configurations"` // Array of field IDs (can be JSON or string)
	CreatedAt           time.Time     `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`     // Creation timestamp
	UpdatedAt           time.Time     `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`     // Last update timestamp
	CreatedBy           int           `gorm:"type:int" json:"created_by"`
}

// FineTuneModelConfigurations defines the configuration for the model
type TempFineTuneModelConfigurations struct {
	Id                  int                   `gorm:"primaryKey;autoIncrement" json:"id"`              // Primary Key
	ModelName           string                `gorm:"type:varchar(255);not null" json:"model_name"`    // Model name
	ModelPath           string                `gorm:"type:varchar(255)" json:"model_path"`             // Path to the model
	FieldConfigurations []FineTuneFieldValues `gorm:"type:int[];not null" json:"field_configurations"` // Array of field IDs (can be JSON or string)
	CreatedAt           time.Time             `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`     // Creation timestamp
	UpdatedAt           time.Time             `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`     // Last update timestamp
	CreatedBy           int                   `gorm:"type:int" json:"created_by"`
}

type FineTuneFieldValues struct {
	Id            int       `gorm:"primaryKey;autoIncrement" json:"id"`
	FieldId       int       `gorm:"type:int;not null;uniqueIndex:idx_field_model_config" json:"field_id"`        // Apply uniqueIndex on this field
	ModelConfigId int       `gorm:"type:int;not null;uniqueIndex:idx_field_model_config" json:"model_config_id"` // Apply uniqueIndex on this field
	Value         string    `gorm:"type:jsonb;not null" json:"value"`
	CreatedAt     time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"created_at"`
	UpdatedAt     time.Time `gorm:"default:CURRENT_TIMESTAMP" json:"updated_at"`
	CreatedBy     int       `gorm:"type:int" json:"created_by"`
}

type Value struct {
	IsActive string `json:"is_active"`
	Value    string `json:"value"`
}

type FieldConfiguration struct {
	CreatedAt time.Time `json:"created_at"`
	CreatedBy int       `json:"created_by"`
	ID        int       `json:"id"`
	InputType string    `json:"input_type"`
	Name      string    `json:"name"`
	Section   string    `json:"section"`
	UpdatedAt time.Time `json:"updated_at"`
	Value     []Value   `json:"value"`
}

type ModelConfig struct {
	FieldConfigurations []FieldConfiguration `json:"field_configurations"`
	ID                  int                  `json:"id"`
	ModelName           string               `json:"model_name"`
	ModelPath           string               `json:"model_path"`
}

type FieldsJsonData struct {
	Data string "json:\"data\""
}

// CreateFields godoc
// @Summary Create new field metadata
// @Description Create a new field metadata entry
// @Tags Configuration
// @Accept json
// @Produce json
// @Param field body FineTuneFieldMetadata true "Field metadata"
// @Success 200 {object} ApiResonse
// @Router /v1/config/fields [POST]
func CreateFields(c *gin.Context) {
	var fields models.FineTuneFieldMetadata
	DB := config.DB

	// Bind JSON body to the field instance
	if err := c.ShouldBindJSON(&fields); err != nil {
		// Handle the case when JSON body cannot be parsed properly
		c.JSON(400, utils.ErrorApiResponse(InvalidData))
		return
	}

	// Attempt to create the new field in the database
	err := CreateNewFieldInDB(DB, fields)
	if err != nil {
		c.JSON(500, utils.ErrorApiResponse("Error while creating new field metadata."))
		return
	}

	c.JSON(200, utils.SuccessApiResponse(fmt.Sprintf("Field %s created successfully", fields.Name)))
}

// GetFieldsByUserId godoc
// @Summary Get fields by user ID
// @Description Retrieve field values for a specific user
// @Tags Configuration
// @Produce json
// @Param id path string true "User ID"
// @Success 200 {array} FineTuneFieldValues
// @Router /v1/config/fields/{id} [GET]
func GetFieldsByUserId(c *gin.Context) {
	userId := c.Param("id")
	var fields []models.FineTuneFieldValues
	DB := config.DB

	err := GetFieldData(DB, userId, fields)
	if err != nil {
		c.JSON(404, utils.ErrorApiResponse("No field metadata found for given user "+userId))
		return
	}

	c.JSON(200, fields)
}

// CreateFieldConfiguration godoc
// @Summary Create field configuration for fine-tuning
// @Description Create a new field configuration for fine-tuning
// @Tags Fine-tuning
// @Accept json
// @Produce json
// @Param configuration body TempFineTuneModelConfigurations true "Field configuration"
// @Success 200 {object} ApiResonse
// @Router /v1/finetune/fields [POST]
func CreateFieldConfiguration(c *gin.Context) {
	var fieldValues models.TempFineTuneModelConfigurations
	var jobId int
	DB := config.DB

	// Bind JSON body to the struct
	err := c.BindJSON(&fieldValues)
	if err != nil {
		config.Log.Error(fmt.Sprintf("==> %v", fieldValues))

		c.JSON(400, utils.ErrorApiResponse(InvalidData))
		return
	}

	// Upsert field configurations using OnConflict
	res, err := CreateFieldConfigurationInDB(DB, fieldValues)
	if err != nil {
		c.JSON(500, utils.ErrorApiResponse(res+err.Error()))
		return
	}

	if strings.EqualFold(c.Query("is_create_job"), "true") {
		userId := strconv.Itoa(fieldValues.CreatedBy)
		jobId, err = UpdateJob(userId, DB, models.StatusRunning, 0)
		if err != nil {
			return
		}
	}

	// Respond with success
	c.JSON(200, gin.H{
		"error":   false,
		"message": "Field configuration created successfully",
		"jobId":   jobId,
	})
}

const GetFieldConfigurationsByModelConfigId = `
select json_build_object(
    'id', id,
    'model_name', model_name,
	'dataset', dataset,
    'model_path', model_path,
    'field_configurations', (
        SELECT jsonb_agg(je)
		FROM (
            select json_build_object(
				'id', fc.id,
                'name', fm.name,
				'value', fc.value,
				'section', fm.section,
				'field_id', fc.field_id,
				'model_config_id', fine_tune_model_configurations.id,
				'input_type', fm.input_type,
                'created_at', fc.created_at,
                'updated_at', fc.updated_at,
                'created_by', fc.created_by
            ) as je
            from fine_tune_field_values fc
			left join fine_tune_field_metadata fm on fc.field_id = fm.id
            where fc.field_id = 
			ANY(fine_tune_model_configurations.field_configurations)
        ) as je
    )
) as data
from fine_tune_model_configurations
where created_by = ?
`

// UpdateIndividualFieldValuesByUser godoc
// @Summary Update individual field values for a user
// @Description Update specific field values for a user's fine-tune configuration
// @Tags Fine-tuning
// @Accept json
// @Produce json
// @Param updates body FineTuneFieldValues true "Field value updates"
// @Success 200 {object} ApiResonse
// @Router /v1/finetune/field [PATCH]
func UpdateIndividualFieldValuesByUser(c *gin.Context) {
	var fieldValues models.FineTuneFieldValues
	DB := config.DB

	// Bind JSON body to the struct
	err := c.BindJSON(&fieldValues)
	if err != nil {
		c.JSON(400, utils.ErrorApiResponse(InvalidData))
		return
	}

	// Update fieldValues
	err = HandlerUpdateIndividualFieldValuesByUser(DB, fieldValues)
	if err != nil {
		c.JSON(400, utils.ErrorApiResponse("Error while updating field value "+err.Error()))
		return
	}

	c.JSON(200, utils.SuccessApiResponse("Field value updated successfully"))
}

// GetFinetuneConfigByID godoc
// @Summary Get fine-tune configuration by ID
// @Description Retrieve fine-tune configuration for a specific user and config ID
// @Tags Fine-tuning
// @Produce json
// @Param user_id path string true "User ID"
// @Param config_id path string true "Config ID"
// @Success 200 {object} ModelConfig
// @Router /v1/finetune/fields/{user_id}/{config_id} [GET]
func GetFinetuneConfigByID(c *gin.Context) {
	userId := c.Param("user_id")

	var (
		temp map[string]interface{}
	)

	fields, err := GetFinetuneConfigByIDFromDB(userId)
	if err != nil {
		c.JSON(404, utils.ErrorApiResponse("error while getting field configurations "+err.Error()))
		return
	}
	json.Unmarshal([]byte(fields.Data), &temp)
	c.JSON(200, &temp)
}

func mapStructKeys(fieldValues models.TempFineTuneModelConfigurations, configurationIds pq.Int32Array) *models.FineTuneModelConfigurations {
	return &models.FineTuneModelConfigurations{
		ModelName:           fieldValues.ModelName,
		ModelPath:           fieldValues.ModelPath,
		FieldConfigurations: configurationIds,
		CreatedAt:           fieldValues.CreatedAt,
		CreatedBy:           fieldValues.CreatedBy,
		UpdatedAt:           time.Now(),
		Dataset:             fieldValues.Dataset,
		Id:                  fieldValues.Id,
	}
}

// GetAllFields godoc
// @Summary Get all field metadata
// @Description Retrieve all field metadata entries
// @Tags Configuration
// @Produce json
// @Success 200 {array} FineTuneFieldMetadata
// @Router /v1/config/fields [GET]
func GetAllFields(c *gin.Context) {
	DB := config.DB

	fields, err := GetAllFieldsFromDB(DB)
	if err != nil {
		c.JSON(404, utils.ErrorApiResponse(err.Error()))
		return
	}

	c.JSON(200, fields)
}

// RemoveField godoc
// @Summary Remove field metadata
// @Description Remove a field metadata entry by ID
// @Tags Configuration
// @Produce json
// @Param id path string true "Field ID"
// @Success 200 {object} ApiResonse
// @Router /v1/config/field/{id} [DELETE]
func RemoveField(c *gin.Context) {
	id := c.Param("id")
	var fields models.FineTuneFieldMetadata
	DB := config.DB

	err := RemoveFieldsFromDB(DB, id, fields)
	if err != nil {
		c.JSON(500, utils.ErrorApiResponse("Error while deleting field metadata."))
		return
	}

	c.JSON(200, utils.SuccessApiResponse("Field metadata deleted successfully."))
}

// UpdateField godoc
// @Summary Update existing field metadata
// @Description Update an existing field metadata entry by ID
// @Tags Configuration
// @Accept json
// @Produce json
// @Param id path string true "Field ID"
// @Param field body FineTuneFieldMetadata true "Updated field metadata"
// @Success 200 {object} ApiResonse
// @Router /v1/config/fields/{id} [PUT]
func UpdateField(c *gin.Context) {
	id := c.Param("id")
	var fields models.FineTuneFieldMetadata
	DB := config.DB

	if err := c.ShouldBindJSON(&fields); err != nil {
		c.JSON(400, gin.H{"error": err.Error()})
		return
	}

	res, err := UpdateFieldsInDB(DB, id, fields)
	if err != nil {
		c.JSON(404, utils.ErrorApiResponse(res))
		return
	}

	c.JSON(200, utils.SuccessApiResponse(fmt.Sprintf("Field metadata updated successfully for %s", fields.Name)))
}

// GenerateUpsertQuery generates the final upsert query for multiple rows
func GenerateUpsertQuery(fieldValues []models.FineTuneFieldValues) string {
	// Prepare the SQL query with placeholders
	query := `
		INSERT INTO fine_tune_field_values (field_id, model_config_id, value, created_by)
		VALUES %s
		ON CONFLICT (field_id, model_config_id)
		DO UPDATE SET 
			value = EXCLUDED.value,
			created_by = EXCLUDED.created_by,
			updated_at = CURRENT_TIMESTAMP
		RETURNING id;
	`

	// Initialize the placeholders and actual values
	var placeholders []string

	// Loop through each fieldValue and add placeholders
	for _, fieldValue := range fieldValues {
		placeholders = append(placeholders, fmt.Sprintf(`(%d, %d, '%s', %d)`, fieldValue.FieldId, fieldValue.ModelConfigId, fieldValue.Value, fieldValue.CreatedBy))
	}

	// Final query with placeholders
	finalQuery := fmt.Sprintf(query, strings.Join(placeholders, ","))

	config.Log.Error(finalQuery)

	return finalQuery
}

// ===========================[[ FINETUNE FIELDS HELPER FUNCTIONS ]]===================================

func GetFieldData(DB *gorm.DB, userId string, fields []models.FineTuneFieldValues) error {
	if err := DB.Debug().Where("created_by =?", userId).Find(&fields).Error; err != nil {
		return err
	}
	return nil
}

func CreateNewFieldInDB(DB *gorm.DB, fields models.FineTuneFieldMetadata) error {
	if err := DB.Debug().Create(&fields).Error; err != nil {
		// If there is an error in creating the field, return an error response
		return err
	}
	return nil
}

func GetAllFieldsFromDB(DB *gorm.DB) ([]models.FineTuneFieldMetadata, error) {
	var fields []models.FineTuneFieldMetadata
	if err := DB.Debug().Find(&fields).Error; err != nil {
		return fields, err
	}
	return fields, nil

}

func RemoveFieldsFromDB(DB *gorm.DB, id string, fields models.FineTuneFieldMetadata) error {
	if err := DB.Debug().Where("id =?", id).Delete(&fields).Error; err != nil {
		return err
	}
	return nil
}

func UpdateFieldsInDB(DB *gorm.DB, id string, fields models.FineTuneFieldMetadata) (string, error) {
	if err := DB.Debug().Where("id =?", id).First(&fields).Error; err != nil {
		return "Field metadata not found.", err
	}

	if err := DB.Debug().Save(&fields).Error; err != nil {
		return "Error while updating field metadata.", err
	}
	return "", nil
}

// ===========================[[ FINETUNE HELPER FUNCTIONS ]]======================================
func CreateFieldConfigurationInDB(DB *gorm.DB, fieldValues models.TempFineTuneModelConfigurations) (string, error) {
	err := DB.Debug().Exec(GenerateUpsertQuery(fieldValues.FieldConfigurations)).Error
	if err != nil {
		return "Error while creating new field values", err
	}

	var Ids pq.Int32Array
	for _, elements := range fieldValues.FieldConfigurations {
		Ids = append(Ids, int32(elements.FieldId))
	}

	query := mapStructKeys(fieldValues, Ids)
	// // Insert the new field configurations into the database
	err = DB.Debug().Save(&query).Error
	if err != nil {
		return "", err
	}
	return "", nil
}

func HandlerUpdateIndividualFieldValuesByUser(DB *gorm.DB, fieldValues models.FineTuneFieldValues) error {
	err := DB.Debug().Model(&models.FineTuneFieldValues{}).Where("id =?", fieldValues.Id).Updates(fieldValues).Error
	if err != nil {
		return err
	}
	return nil
}

func GetFinetuneConfigByIDFromDB(userId string) (FieldsJsonData, error) {
	var fields FieldsJsonData
	DB := config.DB
	err := DB.Debug().Raw(GetFieldConfigurationsByModelConfigId, userId).Scan(&fields).Error
	if err != nil {
		return fields, err
	}
	return fields, nil
}
