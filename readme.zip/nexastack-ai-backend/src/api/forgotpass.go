//go:build !test
// +build !test

package api

import (
	"net/http"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	forgetpass "git.xenonstack.com/nexa-platform/accounts/src/forgotpass"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// ForgotPassData is a  structure for binding data in body during forget or reset password request
type ForgotPassData struct {
	// state defines the state of request is it forgot or reset
	State string `json:"state" binding:"required"`
	// email of user
	Email string `json:"email"`
	// token recieved in email for resetting password
	Token string `json:"token"`
	// new password
	Password string `json:"password"`
	// WorkSpace
	Workspace string `json:"workspace"`
}

// ForgotPassEp godoc
// @Summary Handle password recovery
// @Description Handle password recovery process including forgot password and reset password
// @Tags Authentication
// @Accept json
// @Produce json
// @Param forgotpass body ForgotPassData true "Password recovery details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/forgot-password [post]
func ForgotPassEp(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	var fpdt ForgotPassData
	if err := c.BindJSON(&fpdt); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err.Error(), err)
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "State field is missing."})
		return
	}

	// when state is forget email is passed
	if fpdt.State == "forgot" {

		if !methods.ValidateEmail(fpdt.Email) {
			// if there is some error passing bad status code
			c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Please enter valid email id."})
			return
		}

		msg, ok := forgetpass.ForgotPassChallenge(strings.ToLower(fpdt.Email), fpdt.Workspace)
		if ok {
			// recording user activity of reseting password
			activities.RecordActivity(database.Activities{Email: fpdt.Email,
				ActivityName: "forgot_password",
				ClientIP:     c.ClientIP(),
				Status:       "pass",
				ClientAgent:  c.Request.Header.Get("User-Agent"),
				Timestamp:    time.Now().Unix()})
		}
		// return status code and msg and error if any
		c.JSON(http.StatusOK, gin.H{"error": !(ok), "message": msg})
		return
	}
	// when state is reset token and new password is passed
	if fpdt.State == "reset" {
		email, msg, ok := forgetpass.ResetForgottenPass(fpdt.Token, fpdt.Password, fpdt.Workspace)
		if ok {
			// recording user activity of reseting password
			activities.RecordActivity(database.Activities{Email: email,
				ActivityName: "reset_password",
				ClientIP:     c.ClientIP(),
				Status:       "pass",
				ClientAgent:  c.Request.Header.Get("User-Agent"),
				Timestamp:    time.Now().Unix()})
		}
		// return status code and msg and error if any
		c.JSON(http.StatusOK, gin.H{"error": !(ok), "message": msg})
		return
	}
	c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "State field value should be forgot or reset only."})
}
