//go:build !test
// +build !test

package api

import (
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// Logout is a  api handler for logging out user means delete token or session detail from redis
func Logout(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	token := c.Request.Header.Get("Authorization")
	// trim bearer from token
	token = strings.TrimPrefix(token, "Bearer ")
	// call delete token go function
	// delete token from db means delete session from db
	err := redisdb.DeleteToken(token)
	if err != nil {
		config.Log.Error(err.Error())
		c.JSON(501, gin.H{
			"error":   err,
			"message": "Error in deleting token",
		})
	} else {
		go jwtToken.DeleteTokenFromDb(token)
		c.JSON(200, gin.H{
			"error":   false,
			"message": "Successfully logout",
		})
	}
}
