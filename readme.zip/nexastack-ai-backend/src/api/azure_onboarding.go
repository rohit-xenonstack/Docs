package api

import (
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/azures"
	"git.xenonstack.com/nexa-platform/accounts/src/integrations"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"

	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/kr/pretty"
)

// SaveKube is an API handler for saving/integrating kube config (file upload)
// func SaveKubeFile(c *gin.Context) {
// 	// Handler panic and Alerts
// 	defer util.Panic()

// 	//extracting jwt claims for getting user id
// 	claims := jwt.ExtractClaims(c)
// 	// fetch and check workspace
// 	workspace, ok := claims["workspace"].(string)
// 	if !ok {
// 		config.Log.Error(WorkSpaceNotFoundErrorMessage)
// 		c.JSON(500, gin.H{
// 			"error":   true,
// 			"message": LoginAgainMessage,
// 		})
// 		return
// 	}

// 	name, ok := claims["name"].(string)
// 	if !ok {
// 		config.Log.Error("name not found")
// 		c.JSON(500, gin.H{
// 			"error":   true,
// 			"message": LoginAgainMessage,
// 		})
// 		return
// 	}
// 	email, ok := claims["email"].(string)
// 	if !ok {
// 		config.Log.Error(EmailNotFoundMessage)
// 		c.JSON(500, gin.H{
// 			"error":   true,
// 			"message": LoginAgainMessage,
// 		})
// 		return
// 	}
// 	var kubeConfig azures.KubeConfig
// 	err := c.Bind(&kubeConfig)
// 	if err != nil {
// 		config.Log.Error("error binding kubeconfig:", err)
// 		c.JSON(400, gin.H{
// 			"error":   true,
// 			"message": "Invalid kubeconfig data.",
// 		})
// 		return
// 	}

// 	// Check if file is present
// 	if kubeConfig.File == nil {
// 		config.Log.Error("file not found in request")
// 		c.JSON(400, gin.H{
// 			"error":   true,
// 			"message": "Please upload the kubeconfig file.",
// 		})
// 		return
// 	}

// 	// Check file size (<1MB)
// 	if kubeConfig.File.Size > (1 * 1024 * 1024) {
// 		config.Log.Error("File size exceeds limit:", kubeConfig.File.Size)
// 		c.JSON(400, gin.H{
// 			"error":   true,
// 			"message": "File size exceeds 1MB limit.",
// 		})
// 		return
// 	}

// 	// Open the uploaded file
// 	file, err := kubeConfig.File.Open()
// 	if err != nil {
// 		config.Log.Error("Failed to open uploaded file:", err)
// 		c.JSON(500, gin.H{
// 			"error":   true,
// 			"message": "Failed to read uploaded file.",
// 		})
// 		return
// 	}
// 	defer file.Close()

// 	// Read file content
// 	fileBytes, err := io.ReadAll(file)
// 	if err != nil {
// 		config.Log.Error("Error reading file content:", err)
// 		c.JSON(500, gin.H{
// 			"error":   true,
// 			"message": "Error reading file content.",
// 		})
// 		return
// 	}

// 	// Optional additional check (if needed):
// 	err = methods.CheckFileSize(int(len(fileBytes)))
// 	if err != nil {
// 		config.Log.Error(err)
// 		c.JSON(400, gin.H{
// 			"error":   true,
// 			"message": err.Error(),
// 		})
// 		return
// 	}
// 	kubeConfig.Workspace = workspace
// 	kubeConfig.UserEmail = email
// 	kubeConfig.UserName = name
// 	config.Log.Error(kubeConfig.File)
// 	// Proceed with kubeconfig validation and saving
// 	mapd, code := kubeConfig.ValidateKubeFileandSave(fileBytes, c.ClientIP())
// 	c.JSON(code, mapd)
// }

// SaveKube godoc
// @Summary Save Kubernetes configuration
// @Description Save Kubernetes configuration for Azure integration
// @Tags Azure
// @Accept json
// @Produce json
// @Param config body azures.KubeConfig true "Kubernetes configuration"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/azure/kubeconfig [post]
func SaveKube(c *gin.Context) {

	// Handler panic and Alerts
	defer util.Panic()

	//extracting jwt claims for getting user id
	claims := jwt.ExtractClaims(c)
	// fetch and check workspace
	workspace, ok := claims["workspace"].(string)
	if !ok {
		config.Log.Error(WorkSpaceNotFoundErrorMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	name, ok := claims["name"].(string)
	if !ok {
		config.Log.Error("name not found")
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}
	email, ok := claims["email"].(string)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	project_id, ok := claims["project_id"].(float64)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	environment, ok := claims["environment"].(string)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	var Config azures.KubeConfig
	err := c.Bind(&Config)
	if err != nil {
		config.Log.Error("error binding kubeconfig:", err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Invalid kubeconfig data.",
		})
		return
	}

	if Config.File == "" {
		config.Log.Error("please pass the file")
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass the file",
		})
		return
	}
	//check file size (file size must be less then 1MB)
	err = methods.CheckFileSize(int(len([]byte(Config.File))))
	if err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}

	Config.Workspace = workspace
	Config.UserEmail = email
	Config.UserName = name
	Config.ProjectId = int(project_id)
	Config.Environment = environment
	mapd, code := Config.ValidateKubeFileandSave([]byte(Config.File), c.ClientIP(), workspace)
	c.JSON(code, mapd)
}

// SaveKubeFile godoc
// @Summary Save Kubernetes configuration file
// @Description Save Kubernetes configuration file for Azure integration
// @Tags Azure
// @Accept multipart/form-data
// @Produce json
// @Param file formData file true "Kubernetes configuration file"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/azure/kubeconfig/file [post]
func SaveKubeFile(c *gin.Context) {

	// Handler panic and Alerts
	defer util.Panic()

	//extracting jwt claims for getting user id
	workspace, projectId, environment, name, email, shouldReturn := GetTokenClaims(c)
	if shouldReturn {
		return
	}

	config1, data, err := FileForm(c)
	if err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}

	pretty.Println(config1)
	config1.Workspace = workspace
	config1.UserName = name
	config1.UserEmail = email
	config1.ProjectId = projectId
	config1.Environment = environment
	config.Log.Error(config1.File)
	mapd, code := config1.ValidateKubeFileandSave(data, c.ClientIP(), workspace)
	c.JSON(code, mapd)
}

func FileForm(c *gin.Context) (azures.KubeConfig, []byte, error) {
	var data database.InfraIntegration
	var config1 azures.KubeConfig
	file, fh, err := c.Request.FormFile("file")
	if err != nil {
		config.Log.Error(err)
		return config1, nil, errors.New("please pass all required fields")
	}
	err = c.MustBindWith(&data, binding.Form)
	if err != nil {
		config.Log.Error(err)
		return config1, nil, errors.New("please pass all required fields")
	}
	config1.CloudType = data.CloudType
	config1.Framework = data.Framework
	config1.ClusterName = data.ClusterName
	config1.ClusterName = data.ClusterName
	config1.Ingress = data.Ingress
	config1.IngressClass = data.IngressClass

	// Check if file is present
	if file == nil {
		config.Log.Error("file not found in request")
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please upload the kubeconfig file.",
		})
		return config1, nil, err
	}

	// Check file size (<1MB)
	if fh.Size > (1 * 1024 * 1024) {
		config.Log.Error("File size exceeds limit:", fh.Size)
		c.JSON(400, gin.H{
			"error":   true,
			"message": "File size exceeds 1MB limit.",
		})
		return config1, nil, err
	}

	// Open the uploaded file
	file, err = fh.Open()
	if err != nil {
		config.Log.Error("Failed to open uploaded file:", err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to read uploaded file.",
		})
		return config1, nil, err
	}
	defer file.Close()

	// Read file content
	fileBytes, err := io.ReadAll(file)
	if err != nil {
		config.Log.Error("Error reading file content:", err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Error reading file content.",
		})
		return config1, nil, err
	}

	// Optional additional check (if needed):
	err = methods.CheckFileSize(int(len(fileBytes)))
	if err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return config1, nil, err
	}

	return config1, fileBytes, nil
}

// GetKubeFile godoc
// @Summary Get Kubernetes configuration file
// @Description Retrieve Kubernetes configuration file for Azure integration
// @Tags Azure
// @Produce json
// @Param name path string true "Configuration name"
// @Success 200 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/azure/kubeconfig/{name} [get]
func GetKubeFile(c *gin.Context) {
	//handler panic and Alerts
	defer util.Panic()

	//extracting jwt claims for getting user id
	claims := jwt.ExtractClaims(c)
	// fetch and check workspace
	workspace, ok := claims["workspace"].(string)
	if !ok {
		config.Log.Error(WorkSpaceNotFoundErrorMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}
	email, ok := claims["email"].(string)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	mapd, code := integrations.GetFile(c.Param("name"), workspace, email)
	c.JSON(code, mapd)

}

// DeleteInfrastucture godoc
// @Summary Delete infrastructure integration
// @Description Delete Azure infrastructure integration
// @Tags Azure
// @Produce json
// @Param id path string true "Integration ID"
// @Success 200 {object} map[string]interface{}
// @Failure 500 {object} map[string]interface{}
// @Router /v1/azure/infrastructure/{id} [delete]
func DeleteInfrastucture(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	//extracting jwt claims for getting user id
	workspace, _, _, name, email, shouldReturn := GetTokenClaims(c)
	if shouldReturn {
		return
	}

	id := c.Param("id")

	mapd, code := azures.DeleteInfraIntegration(id, workspace, name, email, c.ClientIP())
	c.JSON(code, mapd)
}

// MangagedByNexaStack godoc
// @Summary Update infrastructure integration
// @Description Update Azure infrastructure integration
// @Tags Azure
// @Accept json
// @Produce json
// @Param data body database.InfraIntegration true "Infrastructure Integration Data"
//
//	@Success 200 {object} map[string]interface{}
//
// @Failure 400 {object} map[string]interface{}
// @Router /v1/azure/onboarding [post]
func MangagedByNexaStack(c *gin.Context) {
	var data database.InfraIntegration

	err := c.BindJSON(&data)
	if err != nil {
		config.Log.Error(err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass all required fields",
		})
	}

	claims := jwt.ExtractClaims(c)
	// fetch and check workspace
	userEmail, ok := claims["email"].(string)
	if !ok {
		config.Log.Error(WorkSpaceNotFoundErrorMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	userName, ok := claims["name"].(string)
	if !ok {
		config.Log.Error(WorkSpaceNotFoundErrorMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	userWorkspace, ok := claims["workspace"].(string)
	if !ok {
		config.Log.Error(WorkSpaceNotFoundErrorMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return
	}

	data.UserEmail = userEmail
	data.UserName = userName
	data.Framework = "terraform"
	data.CloudType = "nexastack-managed"
	data.Workspace = userWorkspace

	kubeConfig, err := GetKubeConfigMapFromEnv()
	if err != nil {
		c.JSON(500, gin.H{"error": "Failed to create kubeconfig", "details": err.Error()})
		return
	}

	// Print the value for confirmation
	log.Printf("Parsed value: %+v\n", kubeConfig)
	err = vault.AddSecret(userWorkspace, data.ClusterName, data.Framework, kubeConfig)
	if err != nil {
		c.JSON(400, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}

	err = config.DB.Debug().Create(&data).Error
	if err != nil {
		if strings.Contains(err.Error(), "duplicate key value violates unique constraint") {
			c.JSON(http.StatusConflict, gin.H{
				"error":   true,
				"message": "this cluster name is already in use",
			})
			return
		}

		config.Log.Error(err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}

	c.JSON(200, gin.H{
		"error":   false,
		"message": "successfully added infrastucture integration",
	})
}

func GetTokenClaims(c *gin.Context) (string, int, string, string, string, bool) {
	claims := jwt.ExtractClaims(c)
	// fetch and check workspace
	workspace, ok := claims["workspace"].(string)
	if !ok {
		config.Log.Error(WorkSpaceNotFoundErrorMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return "", 0, "", "", "", true
	}

	name, ok := claims["name"].(string)
	if !ok {
		config.Log.Error("name not found")
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return "", 0, "", "", "", true
	}
	email, ok := claims["email"].(string)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return "", 0, "", "", "", true
	}

	projectId, ok := claims["project_id"].(float64)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return "", 0, "", "", "", true
	}

	environment, ok := claims["environment"].(string)
	if !ok {
		config.Log.Error(EmailNotFoundMessage)
		c.JSON(500, gin.H{
			"error":   true,
			"message": LoginAgainMessage,
		})
		return "", 0, "", "", "", true
	}
	return workspace, int(projectId), environment, name, email, false
}

func GetKubeConfigMapFromEnv() (map[string]interface{}, error) {
	caData := os.Getenv("CERTIFICATE_AUTHORITY_DATA")
	clientCertData := os.Getenv("WORKSPACE_KUBE_CLIENT_CERT_DATA")
	clientKeyData := os.Getenv("WORKSPACE_KUBE_CLIENT_KEY")
	host := os.Getenv("KUBERNETES_SERVICE_HOST")
	port := os.Getenv("KUBERNETES_SERVICE_PORT")

	if host == "" || port == "" {
		return nil, fmt.Errorf("KUBERNETES_SERVICE_HOST or KUBERNETES_SERVICE_PORT is not set")
	}

	clusterName := "workspace-cluster"
	contextName := "workspace-context"
	userName := "workspace-user"

	// Decode base64 if applicable
	decode := func(data string) string {
		decoded, err := base64.StdEncoding.DecodeString(data)
		if err != nil {
			return data // return raw if not base64
		}
		return string(decoded)
	}

	kubeconfig := map[string]interface{}{
		"apiVersion": "v1",
		"kind":       "Config",
		"clusters": []map[string]interface{}{
			{
				"name": clusterName,
				"cluster": map[string]interface{}{
					"server":                     fmt.Sprintf("%s:%s", host, port),
					"certificate-authority-data": base64.StdEncoding.EncodeToString([]byte(decode(caData))),
				},
			},
		},
		"contexts": []map[string]interface{}{
			{
				"name": contextName,
				"context": map[string]interface{}{
					"cluster": clusterName,
					"user":    userName,
				},
			},
		},
		"current-context": contextName,
		"users": []map[string]interface{}{
			{
				"name": userName,
				"user": map[string]interface{}{
					"client-certificate-data": base64.StdEncoding.EncodeToString([]byte(decode(clientCertData))),
					"client-key-data":         base64.StdEncoding.EncodeToString([]byte(decode(clientKeyData))),
				},
			},
		},
	}

	return kubeconfig, nil
}
