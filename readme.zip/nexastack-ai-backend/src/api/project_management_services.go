package api

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"

	models "git.xenonstack.com/nexa-platform/accounts/models"
)

type Member models.Member
type Project models.Project

// output structure for invite member requests
type out struct {
	Role    string `json:"role"`
	Name    string `json:"name"`
	Message string `json:"message"`
}

type status struct {
	Add    []out `json:"add"`
	NotAdd []out `json:"not_add"`
}

const (
	// NoProjectFound is a constant string that contains no project found string
	NoProjectFound string = "No Project Found"
)

// Post function for posting data
func ProjectPost(project models.Project, email, name, ip string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	// project.Slug = slug.Make(project.Name)

	//check project name
	// err := CheckProject(project.Slug)
	// if err != nil {
	// 	mapd["error"] = true
	// 	mapd["message"] = err.Error()
	// 	return mapd, 400
	// }

	//connection to db
	db := config.DB
	var existingProject models.Project
	err := db.Where(models.Project{Name: project.Name}).First(&existingProject).Error
	if err != nil && err.Error() != "record not found" {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	if existingProject.ID != 0 {
		// Update existing project
		existingProject.Description = project.Description
		existingProject.WorkspaceID = project.WorkspaceID
		err = db.Save(&existingProject).Error
	} else {
		// Create new project
		err = db.Create(&project).Error

		// Assign project to account
		projectToAccountMapping := models.ProjectToAccountMapping{
			ProjectID: project.ID,
			AccountID: project.OrganizationId, //project.OrganisationId,
			CreatedAt: time.Now(),
			UpdatedAt: time.Now(),
		}

		err = db.Debug().Create(&projectToAccountMapping).Error
		if err != nil {
			mapd["error"] = true
			mapd["message"] = "Failed to assign project to account"
			return mapd, 400
		}
	}

	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 400
	}

	mapd["id"] = project.ID
	mapd["message"] = "Project successfully created"
	// mapd["id"] = project.Slug
	mapd["name"] = project.Name

	return mapd, 200
}

// Projectslist struct use to store the project list with role
type Projectslist struct {
	Slug      string    `json:"id"`
	Name      string    `json:"name" gorm:"unique"`
	UserRole  string    `json:"role"`
	CreatedAt time.Time `json:"created_at"`
}

// Get function to display project information using project id
func GetProjectData(id string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})
	mapd["error"] = false
	result := models.Project{}
	//connection to db
	db := config.DB

	db.Debug().Where("id=?", id).Find(&result)
	if result.ID == 0 {
		mapd["error"] = true
		mapd["message"] = NoProjectFound
		return mapd, 400
	}

	mapd["project"] = result
	config.Log.Error(mapd)
	return mapd, 200
}

func GetProjectDataByUserId(userId, workspace string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})
	mapd["error"] = false
	result := []models.Project{}
	var query string
	db := config.DB

	if userId != "" && workspace != "" {
		query = fmt.Sprintf(`id in (select project_id::int from 
	project_management.project_to_account_mapping ptam
	where ptam.account_id = %s) and workspace_id = '%s'`, userId, workspace)
	} else if userId != "" {
		query = fmt.Sprintf(`id in (select project_id::int from 
		project_management.project_to_account_mapping ptam
		where ptam.account_id = %s)`, userId)
	} else if workspace != "" {
		query = fmt.Sprintf(`workspace_id = '%s'`, workspace)
	}

	err := db.Debug().Where(query).Find(&result).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = NoProjectFound
		return mapd, 400
	}

	mapd["project"] = result
	mapd["environment"] = os.Getenv("ENVIRONMENT")
	config.Log.Info(mapd)
	return mapd, 200
}

// Update method for updating Projects Data
func Update(Project models.Project, email, role string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	//connection to db
	db := config.DB

	//check role and admin access on project
	if role != "owner" {
		mem := Member{}
		db.Where("email=? and user_role=?", email, "admin").Find(&mem)
		if mem.ID == 0 {
			mapd["error"] = true
			mapd["message"] = "You do not have permission to delete project"
			return mapd, 400
		}
	}

	// result.Name = project.Name

	// update projects data

	// err := db.Where("id=?", result.ID).Save(&result).Error
	// if err != nil {
	// 	mapd["error"] = true
	// 	mapd["message"] = err.Error()
	// 	return mapd, 500
	// }

	mapd["message"] = "Project updated successfully."
	return mapd, 200
}

// Delete method deletes the selected project data
func Delete(Project models.Project, id, email, role, ip string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})
	mapd["error"] = false
	var name string
	//connection to db
	db := config.DB

	//check role and admin access on project
	if role != "owner" && role != "platform_owner" {
		mem := Member{}
		db.Where("email=? and user_role=?", email, "admin").Find(&mem)
		if mem.ID == 0 {
			config.Log.Error(mem)
			mapd["error"] = true
			mapd["message"] = "You do not have permission to delete project"
			return mapd, 400
		}
		email = mem.Email
		name = mem.UserName
	}

	if role == "owner" {
		mem := models.Member{}
		db.Where("user_role=?", "owner").Find(&mem)
		email = mem.Email
		name = mem.UserName
	}

	//Delete is a payload struct for details required to delete data related
	//to this project in other services
	type Delete struct {
		ID        string `json:"id"`
		UserName  string `json:"user_name"`
		Email     string `json:"user_email"`
		PID       string `json:"pid"`
		Workspace string `json:"workspace"`
		SystemIP  string `json:"system_ip"`
	}

	if role == "platform_owner" {
		email = "platform_owner@gmail.com"
		name = "platform_owner"
		id = "1"
	}

	delete := Delete{
		// PID:       project.Slug,
		Workspace: config.Conf.Service.Workspaces,
		Email:     email,
		UserName:  name,
		ID:        id,
		SystemIP:  ip,
	}

	byteData, _ := json.Marshal(&delete)
	config.Log.Debug(string(byteData))

	mapd["message"] = "Project deleted successfully"
	return mapd, 200
}

// DeleteAllProjects : It is used to delete all the projects of API
func DeleteAllProjects(ip string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	projects := []models.Project{}
	db := config.DB
	db.Find(&projects)
	for i := 0; i < len(projects); i++ {
		mapd, code := Delete(projects[i], "", "", "platform_owner", ip)
		if code != 200 {
			return mapd, code
		}
	}
	mapd["error"] = false
	mapd["message"] = "Deleted All Projects"
	return mapd, 200
}

func CheckProject(name string) error {

	str := strings.Split(config.Conf.Service.Projects, ",")
	for i := 0; i < len(str); i++ {
		if str[i] == name {
			return errors.New(name + " is not available to use")
		}
	}
	return nil
}
