//go:build !test
// +build !test

package api

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/health"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// Healthz godoc
// @Summary Health check endpoint
// @Description Check if the service is healthy and all dependencies are working
// @Tags Health
// @Produce json
// @Success 200 {object} map[string]interface{}
// @Failure 503 {object} map[string]interface{}
// @Router /healthz [get]
func Healthz(c *gin.Context) {
	config.Log.Info("Health check requested")

	//handler panic and Alerts
	defer util.Panic()

	// call health service check function
	err := health.ServiceHealth()
	if err != nil {
		// if any error is there
		config.Log.Error(err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}

	// if no error is there
	c.JSON(200, gin.H{
		"error":       false,
		"message":     "All is okay",
		"build":       config.Conf.Service.Build,
		"environment": config.Conf.Service.Environment,
	})
}
