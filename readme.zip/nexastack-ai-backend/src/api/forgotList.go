//go:build !test
// +build !test

package api

import (
	"net/http"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"git.xenonstack.com/nexa-platform/accounts/src/workspace"
	"github.com/gin-gonic/gin"
)

// ForgotWorkspaceEp is an api handler for forgot workspace
// this will send a mail for recover workspace link
func ForgotWorkspaceEp(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	// Forgot is a  structure for binding data in body during forget workspace request
	type Forgot struct {
		Email string `json:"email" binding:"required"`
	}

	//bind email from body
	var email Forgot
	if err := c.BindJSON(&email); err != nil {
		config.Log.Error(err.Error(), err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please enter Email Address.",
		})
	}

	if !methods.ValidateEmail(email.Email) {
		// if there is some error passing bad status code
		c.JSON(http.StatusBadRequest, gin.H{"error": true, "message": "Please enter valid email id."})
		return
	}

	//send token in mail to recover workspaces
	err := workspace.Forgot(strings.ToLower(email.Email))
	if err != nil {
		c.JSON(500, gin.H{
			"error":   true,
			"message": err.Error(),
		})
		return
	}
	c.JSON(200, gin.H{
		"error":   false,
		"message": "We have emailed a special link to recover your workspaces. Please check your email.",
	})
}

//=====================================================================================//

type TokenMeta struct {
	Token string `json:"token" binding:"required"`
}

// GetWorkspaceList godoc
// @Summary Get workspace list for recovery
// @Description Get list of workspaces associated with a recovery token
// @Tags Workspace
// @Accept json
// @Produce json
// @Param token body TokenMeta true "Recovery token"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/workspaces/recover [post]
func GetWorkspaceList(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	var tm TokenMeta
	if err := c.BindJSON(&tm); err != nil {
		config.Log.Error(err.Error(), err)
		c.JSON(400, gin.H{"error": true, "message": "Token is required."})
		return
	}
	code, mapd := workspace.RecoverWorkspace(tm.Token)
	c.JSON(code, mapd)
}
