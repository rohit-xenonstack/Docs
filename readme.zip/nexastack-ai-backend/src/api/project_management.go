package api

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	models "git.xenonstack.com/nexa-platform/accounts/models"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/activities"
	"git.xenonstack.com/nexa-platform/accounts/src/login"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/kr/pretty"
)

// CreateProject godoc
// @Summary Create a new project
// @Description Create a new project with the specified details
// @Tags Project
// @Accept json
// @Produce json
// @Param project body models.Project true "Project details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects [post]
func CreateProject(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	var project models.Project
	if err := c.BindJSON(&project); err != nil {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass name of the project",
		})
		return
	}
	// extracting jwt claims
	claims := jwt.ExtractClaims(c)

	project.OrganizationId = methods.ConvertID(claims["id"])
	workspace, ok := claims["workspace"].(string)
	if !ok {
		config.Log.Error("email not set")
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	project.WorkspaceID = workspace
	mapd, code := ProjectPost(project, "", "", c.ClientIP())
	c.JSON(code, mapd)
}

// ShowProjectData godoc
// @Summary Get project details
// @Description Get details of a specific project
// @Tags Project
// @Produce json
// @Param id path string true "Project ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/{id} [get]
func ShowProjectData(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()
	id := c.Param("id")

	mapd, code := GetProjectData(id)
	c.JSON(code, mapd)
}

// ProjectsByUserOrWorkspace godoc
// @Summary Get projects by user or workspace
// @Description Get all projects for a specific user or workspace
// @Tags Project
// @Produce json
// @Param user_id query string false "User ID"
// @Param workspace query string false "Workspace ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/user/projects [get]
func ProjectsByUserOrWorkspace(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()
	userId := c.Query("user_id")
	claims := jwt.ExtractClaims(c)

	workspaceStr, ok := claims["workspace"].(string)
	if !ok {
		c.JSON(500, gin.H{"error": true, "message": LoginAgainMessage})
		return
	}

	if userId != "" {
		// save emails in string array
		claims := jwt.ExtractClaims(c)
		userIdStr, ok := claims["id"].(float64)
		if !ok {
			c.JSON(500, gin.H{"error": true, "message": LoginAgainMessage})
			return
		}
		userId = strconv.FormatFloat(userIdStr, 'f', -1, 64)
	}

	mapd, code := GetProjectDataByUserId(userId, workspaceStr)
	c.JSON(code, mapd)
}

// UpdateProject godoc
// @Summary Update project details
// @Description Update details of a specific project
// @Tags Project
// @Accept json
// @Produce json
// @Param id path string true "Project ID"
// @Param project body models.Project true "Updated project details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/{id} [put]
func UpdateProject(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	var project models.Project
	if err := c.BindJSON(&project); err != nil {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Please pass name of the project",
		})
		return
	}
	// project.Slug = c.Param("id")

	//Pre-define project
	// if project.Slug == database.Slug {
	// 	c.JSON(403, gin.H{
	// 		"error":   true,
	// 		"message": "You do not have permission for this project",
	// 	})
	// 	return
	// }
	// extracting jwt claims
	claims := jwt.ExtractClaims(c)
	email, ok := claims["email"].(string)
	if !ok {
		config.Log.Error("email not set")
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	role, ok := claims["role"].(string)
	if !ok {
		config.Log.Error("role not set")
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	name, ok := claims["name"].(string)
	if !ok {
		config.Log.Error("workspace not set")
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}

	config.Log.Debug("name is :", name)

	mapd, code := Update(project, email, role)
	if code != 200 {
		//save activity
		c.JSON(code, mapd)
		return
	}
	//save activity
	c.JSON(code, mapd)
}

// DeleteProject godoc
// @Summary Delete a project
// @Description Delete a specific project
// @Tags Project
// @Produce json
// @Param id path string true "Project ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/{id} [delete]
func DeleteProject(c *gin.Context) {

	//handler panic and Alerts
	defer util.Panic()

	claims := jwt.ExtractClaims(c)

	addedBy, ok := claims["id"]
	if !ok {
		config.Log.Error("id not found")
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Please login again",
		})
		return
	}

	email, ok := claims["email"].(string)
	if !ok {
		config.Log.Error("email not set")
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	role, ok := claims["role"].(string)
	if !ok {
		config.Log.Error("workspace not set")
		c.JSON(500, gin.H{"error": true, "message": "Please login again"})
		return
	}
	var project models.Project
	// project.Slug = c.Param("id")

	//Pre-define project
	// if project.Slug == database.Slug {
	// 	c.JSON(403, gin.H{
	// 		"error":   true,
	// 		"message": "You do not have permission for this project",
	// 	})
	// 	return
	// }

	mapd, code := Delete(project, fmt.Sprint(addedBy), email, role, c.ClientIP())
	c.JSON(code, mapd)
}

// ProjectSendInvite godoc
// @Summary Send invite to project member
// @Description Send invite to project member
// @Tags Project
// @Accept json
// @Produce json
// @Param project_member body models.ProjectMembers true "Project member details"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/invite [post]
func ProjectSendInvite(c *gin.Context) {
	var projectMember models.ProjectMembers
	claims := jwt.ExtractClaims(c)

	// Log the raw request body for debugging
	body, _ := c.GetRawData()
	config.Log.Debug("Raw request body:", string(body))

	// Reset the request body for binding to our temporary struct
	c.Request.Body = io.NopCloser(bytes.NewBuffer(body))

	// Bind to temporary struct that can handle array permissions
	var tempProjectMember models.TempProjectMembers
	if err := c.BindJSON(&tempProjectMember); err != nil {
		config.Log.Error("JSON binding error:", err)
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Invalid request data: " + err.Error(),
		})
		return
	}

	// Copy data from temp struct to actual struct
	projectMember.ID = tempProjectMember.ID
	projectMember.Role = tempProjectMember.Role
	projectMember.RoleId = tempProjectMember.RoleId
	projectMember.Email = tempProjectMember.Email
	projectMember.Name = tempProjectMember.Name
	projectMember.Status = "Invitation Sent"
	projectMember.ProjectId = tempProjectMember.ProjectId
	projectMember.Workspace = tempProjectMember.Workspace
	projectMember.ProjectName = tempProjectMember.ProjectName

	// Set workspace from claims if available
	workspace, hasWorkSpace := claims["workspace"]
	if hasWorkSpace {
		config.Log.Debug("Workspace available in token")
		projectMember.Workspace = workspace.(string)
	}

	if UserIsNotAlsoMemeberOfWorkspace(projectMember.Email, projectMember.Workspace) {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "User is not a member of the workspace",
		})
		return
	}

	if UserIsAlreadyMemberOfProject(projectMember.Email, projectMember.ProjectId) {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "User is already a member of the project",
		})
		return
	}

	// Process environment access with JSON conversion
	projectMember.EnvironmentAccess = make([]models.EnvironmentPermissions, len(tempProjectMember.EnvironmentAccess))
	for i, env := range tempProjectMember.EnvironmentAccess {
		projectMember.EnvironmentAccess[i].ID = env.ID
		projectMember.EnvironmentAccess[i].MemberID = env.MemberID
		projectMember.EnvironmentAccess[i].Environment = env.Environment

		// Marshal permissions to JSON string
		permissionsJSON, err := json.Marshal(env.Permissions)
		if err != nil {
			config.Log.Error("Failed to marshal permissions:", err)
			c.JSON(400, gin.H{
				"error":   true,
				"message": "Invalid permissions format",
			})
			return
		}
		projectMember.EnvironmentAccess[i].Permissions = append(projectMember.EnvironmentAccess[i].Permissions, string(permissionsJSON))
	}

	// Validate required fields
	if projectMember.Email == "" {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Email is required",
		})
		return
	}

	// Connect to database
	db := config.DB

	// Check if project exists
	var projectCount int64
	if err := db.Model(&models.Project{}).Where("id = ?", projectMember.ProjectId).Count(&projectCount).Error; err != nil {
		config.Log.Error("Failed to check project existence:", err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to verify project existence: " + err.Error(),
		})
		return
	}

	if projectCount == 0 {
		c.JSON(404, gin.H{
			"error":   true,
			"message": "Project not found",
		})
		return
	}

	var userId int
	var err error
	userId, err = SendInviteEmail(c, tempProjectMember)
	if err != nil {
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to create project member: " + err.Error(),
		})
		return
	}

	projectMember.UserId = userId
	// Create new project member record
	err = db.Create(&projectMember).Error
	if err != nil {
		config.Log.Error("Failed to create project member:", err)
		c.JSON(500, gin.H{
			"error":   true,
			"message": "Failed to create project member: " + err.Error(),
		})
		return
	}

	// Return success response
	c.JSON(200, gin.H{
		"error":   false,
		"message": "Project member invited successfully",
		"data":    projectMember,
	})
}

func UserIsNotAlsoMemeberOfWorkspace(email, workspace string) bool {
	var accCount int
	err := config.DB.Model(&database.WorkspaceMembers{}).Where(`workspace_id=? and member_email=?`, workspace, email).Count(&accCount).Error
	if err != nil {
		config.Log.Error(err.Error())
		return true
	}

	if accCount == 0 {
		config.Log.Error("User is not a member of the workspace")
		return true
	} else {
		config.Log.Debug("User is a member of the workspace")
		return false
	}
}

func UserIsAlreadyMemberOfProject(email, projectId string) bool {
	var accCount int
	err := config.DB.Debug().Model(&models.ProjectMembers{}).Where(`project_id=? and email=?`, projectId, email).Count(&accCount).Error
	if err != nil {
		config.Log.Error(err.Error())
		return true
	}

	if accCount == 0 {
		config.Log.Error("User is not a member of the project")
		return false
	} else {
		config.Log.Debug("User is a member of the project")
		return true
	}
}

func SendInviteEmail(c *gin.Context, data models.TempProjectMembers) (int, error) {

	pretty.Println(c.Get("JWT_PAYLOAD"))
	config.Log.Info("in sendinvite email...")
	claims := jwt.ExtractClaims(c)

	ownerEmail, ok := claims["email"].(string)
	if !ok {
		return 0, errors.New("email not found in token")
	}
	ownerName, ok := claims["name"].(string)
	if !ok {
		return 0, errors.New("name not found in token")
	}

	workspace, ok := claims["workspace"].(string)
	if !ok {
		return 0, errors.New("name not found in token")
	}

	var acc database.Accounts
	err := config.DB.Where(`email=?`, data.Email).Find(&acc).Error
	if err != nil {
		config.Log.Error(err.Error())
		return 0, err
	}

	// wsId = " + workspacename + "&project="+projectname
	projectIdInt, _ := strconv.Atoi(data.ProjectId)

	//send invite or login link to users
	go mail.SendProjectInviteLink(acc, workspace, data.ProjectName, ownerEmail, ownerName, data.ProjectId)
	activities.RecordActivity(database.Activities{Email: claims["email"].(string),
		ActivityName: "Project member invited",
		Name:         claims["name"].(string),
		Status:       "pass",
		ClientIP:     c.ClientIP(),
		ProjectId:    projectIdInt,
		ClientAgent:  c.Request.Header.Get(ClientAgentUser),
		Timestamp:    time.Now().Unix()})
	return acc.ID, nil
}

// GetProjectMembers godoc
// @Summary Get project members
// @Description Get all members of a specific project
// @Tags Project
// @Produce json
// @Param project_id query string true "Project ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/members [get]
// GetProjectMembers godoc
// @Summary Get project members
// @Description Get all members of a specific project
// @Tags Project
// @Produce json
// @Param project_id query string true "Project ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/members [get]
func GetProjectMembers(c *gin.Context) {
	// Get project ID from URL parameter
	projectID := c.Param("id")
	if projectID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Project ID is required"})
		return
	}

	// Query database for all project members with the given project ID
	var members []models.ProjectMembers
	if err := config.DB.
		Debug().
		Table("project_management.project_members pm").
		Select(`pm.id,pm.role, pm.email, pm.role_id, pm.status, pm.user_id, pm.project_id, pm.workspace,
				pm.project_name, accounts.name`).
		Joins("left join accounts on accounts.id = pm.user_id").
		Where("pm.project_id = ?", projectID).
		Scan(&members).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve project members: " + err.Error()})
		return
	}

	// If no members found, return empty array rather than null
	if len(members) == 0 {
		c.JSON(http.StatusOK, []models.ProjectMembers{})
		return
	}

	// Load environment permissions for each member
	for i := range members {
		if err := config.DB.Debug().Where("member_id = ?", members[i].ID).Find(&members[i].EnvironmentAccess).Error; err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve environment permissions: " + err.Error()})
			return
		}
	}

	c.JSON(http.StatusOK, members)
}

// GetProjectMemberByID godoc
// @Summary Get project member details
// @Description Get details of a specific project member by ID
// @Tags Project
// @Produce json
// @Param member_id path string true "Member ID"
// @Success 200 {object} map[string]interface{}
// @Failure 400 {object} map[string]interface{}
// @Router /v1/projects/members/{member_id} [get]
func GetProjectMemberByID(c *gin.Context) {
	// Get member ID from URL parameter
	memberID := c.Param("id")
	if memberID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Member ID is required"})
		return
	}

	// Query database for the project member
	var member models.ProjectMembers
	if err := config.DB.First(&member, memberID).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			c.JSON(http.StatusNotFound, gin.H{"error": "Project member not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve project member: " + err.Error()})
		return
	}

	// Load environment permissions for the member
	if err := config.DB.Where("member_id = ?", member.ID).Find(&member.EnvironmentAccess).Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve environment permissions: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, member)
}

func VarifyProjectMember(c *gin.Context) {
	mapd := make(map[string]interface{})

	//handler panic and Alerts
	// defer util.Panic()

	var tp models.ProjectMemberRegistration
	if err := c.BindJSON(&tp); err != nil {
		// if there is some error passing bad status code
		config.Log.Error(err)
		c.JSON(400, gin.H{"error": true, "message": "name, contact, password, token and workspace are required field."})
		return
	}

	tp.Environment = os.Getenv("ENVIRONMENT")
	tok, err := verifytoken.CheckToken(tp.Token)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = "Invalid Join Link."
		c.JSON(400, &mapd)
		return
	}
	config.Log.Debug(tok)
	acc := accounts.GetAccountForid(tok.Userid)

	activity := database.Activities{Email: tp.Email,
		ClientIP:    c.ClientIP(),
		CreatedAt:   time.Now(),
		ClientAgent: c.Request.Header.Get("User-Agent"),
		Timestamp:   time.Now().Unix()}

	code, mapd := login.NormalLogin(strings.ToLower(acc.Email), tp.Password, tp.Workspace, tp.Environment, tp.ProjectId)
	if code == 200 {
		activity.ActivityName = "Member added"
		activity.Name = mapd["name"].(string)
		activity.Status = "pass"
		activity.CreatedAt = time.Now()
		activity.ProjectId = tp.ProjectId
		activities.RecordActivity(activity)

	} else {
		// recording user activity of failed login
		activity.ActivityName = "Member added"
		activity.Status = "fail"
		activity.Reason = mapd["message"].(string)
		activity.CreatedAt = time.Now()
		activity.ProjectId = tp.ProjectId
		activities.RecordActivity(activity)
	}

	// Assign project to account
	projectToAccountMapping := models.ProjectToAccountMapping{
		ProjectID: tp.ProjectId,
		AccountID: tok.Userid, //project.OrganisationId,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	err = config.DB.Create(&projectToAccountMapping).Error
	if err != nil {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Failed to assign project to account",
		})
		return
	}

	// Update project member status
	var projectMembers models.ProjectMembers
	err = config.DB.Debug().Where(`user_id=? and project_id=?`, acc.ID, tp.ProjectId).Find(&projectMembers).Error
	if err != nil {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Failed to update project member status",
		})
		return
	}
	// pretty.Println("projectMembers: ", projectMembers)
	// projectMembers.Status = "Joined"
	// err = config.DB.Debug().Model(models.ProjectMembers{}).Where(`user_id=? and project_id=?`, acc.ID, tp.ProjectId).Update(projectMembers).Error
	// if err != nil {
	// 	c.JSON(400, gin.H{
	// 		"error":   true,
	// 		"message": "Failed to update project member status",
	// 	})
	// 	return
	// }

	// assign project role to invited account
	var projectPermissions []models.EnvironmentPermissions
	err = config.DB.Debug().Model(models.EnvironmentPermissions{}).Where(`member_id=?`, projectMembers.ID).Find(&projectPermissions).Error
	if err != nil {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Failed to assign project role to invited account",
		})
		return
	}

	var permissions []string
	for _, projectPermission := range projectPermissions {
		for _, permission := range projectPermission.Permissions {
			var result []string
			err := json.Unmarshal([]byte(permission), &result)
			if err != nil {
				fmt.Println("Error decoding JSON:", err)
				return
			}
			permissions = append(permissions, result...)
		}
	}

	var roles []models.Role
	err = config.DB.Debug().Raw(`SELECT * FROM roles.role r WHERE r.id IN (
    	select rpm.role_id from roles.role_permission_mapping rpm where rpm.permission_id in  
    	(SELECT p.id from roles.permission p where p."action" in (?))
	 ) AND r.domain = 'environment' and environment = ?`, permissions, GetEnvString()).Scan(&roles).Error
	if err != nil || len(roles) == 0 {
		c.JSON(400, gin.H{
			"error":   true,
			"message": "Failed to get roles for project members",
		})
		return
	}

	for _, role := range roles {
		accountRoleMapping := models.AccountRoleMapping{
			AccountID: uint(acc.ID),
			RoleID:    uint(role.Id),
			ProjectId: tp.ProjectId,
		}

		if err := config.DB.Debug().Create(&accountRoleMapping).Error; err != nil {
			config.Log.Error(err)
		}
	}

	go verifytoken.DeleteToken(tp.Token)
	c.JSON(200, &mapd)
}

func GetProjectActivities(c *gin.Context) {
	var acitvities []database.Activities
	projectId := c.Param("id")
	err := config.DB.Debug().
		Where(`project_id=? and activity_name in (?)`, projectId, ProjectMemberActivityWhereClause).
		Order(`created_at DESC`).
		Find(&acitvities).Error
	if err != nil {
		config.Log.Error("error while getting acitvities " + err.Error())
		c.JSON(500, util.ErrorApiResponse("error while getting acitvities "+err.Error()))
		return
	}

	c.JSON(200, gin.H{
		"error": false,
		"data":  &acitvities,
	})
}
