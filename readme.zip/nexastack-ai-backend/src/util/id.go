package util

import (
	"errors"

	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
)

// CheckInfraName function used for check the infrastucture name
func CheckInfraName(name string) error {

	str := strings.Split(config.Conf.Service.Infrastucture, ",")
	for i := 0; i < len(str); i++ {
		if str[i] == name {
			return errors.New(name + " is not available to use")
		}
	}
	return nil
}
