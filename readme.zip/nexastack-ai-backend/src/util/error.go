package util

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	models "git.xenonstack.com/nexa-platform/accounts/models"
)

func ErrorApiResponse(errorMsg string) *models.ApiResonse {
	config.Log.Info(errorMsg)
	return &models.ApiResonse{
		Error:   true,
		Message: errorMsg,
	}
}

func SuccessApiResponse(successMsg string) *models.ApiResonse {
	return &models.ApiResonse{
		Error:   false,
		Message: successMsg,
	}
}

func CheckInterface(data interface{}) string {
	if value, ok := data.(string); !ok {
		config.Log.Error("invalid value in interface: ", value)
	} else {
		return value
	}

	return ""
}
