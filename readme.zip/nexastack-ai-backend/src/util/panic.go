//go:build !test
// +build !test

package util

import (
	"runtime/debug"
	"strconv"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"gopkg.in/gomail.v2"
)

// Panic function used when the panic is iccur then it send the alert
func Panic() {
	if recover() != nil {
		panic := string(debug.Stack())
		config.Log.Error(panic)
		mails := []string{"Ansh.Goyal@xenonstack.com"}

		for i := 0; i < len(mails); i++ {
			go send(mails[i], "Regarding Panic Occurrence in Accounts Service", panic)
		}

	}
}

func send(to, sub, template string) {
	//update Configuration
	config.SetConfig()
	// creating new message with default settings
	m := gomail.NewMessage()

	// setting mail headers from, to and subject
	m.SetHeader("From", config.Conf.Mail.From)
	m.SetHeader("To", to)
	m.SetHeader("Subject", sub)

	// set body of mail
	m.SetBody("text/html", template)

	// port of smtp mail
	port, _ := strconv.Atoi(config.Conf.Mail.Port)
	//use port 465 for TLS, other than 465 it will send without TLS.
	// connect to smtp server using mail admin username and password
	d := gomail.NewPlainDialer(config.Conf.Mail.Host, port, config.Conf.Mail.User, config.Conf.Mail.Pass)

	if port == 465 {
		d.SSL = true
	}

	// send above mail message
	err := d.DialAndSend(m)
	config.Log.Debug(err)

}
