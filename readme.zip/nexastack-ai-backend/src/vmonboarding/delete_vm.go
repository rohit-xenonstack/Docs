package vmonboarding

import (
	"context"
	"os"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/azures"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

func DeleteVmNode(vmName string, clusterName string, workspace string, namespace, email string) (map[string]interface{}, error) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	_, path, _, err := kubernetes.SetInfraConfig(namespace, clusterName, workspace, email)
	defer os.Remove(path)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()

		return mapd, err
	}
	nodeName := vmName

	clientset, err := azures.CreateClinetSet(path)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()

		return mapd, err
	}
	err = clientset.CoreV1().Nodes().Delete(context.TODO(), nodeName, metav1.DeleteOptions{})
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()

		return mapd, err
	}

	mapd["error"] = false
	mapd["message"] = vmName + " Deleted from cluster."

	return mapd, nil
}
