package vmonboarding

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/vault"
)

func RunGenerateKeyCommand(nodeName, workspace, clusterName, userName string) (map[string]interface{}, error) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	// Define the folder path
	folderPath := "data/key/"
	defer os.Remove(folderPath + "/" + nodeName)
	defer os.Remove(folderPath + "/" + nodeName + ".pub")
	// Create the folder if it doesn't exist
	if _, err := os.Stat(folderPath); os.IsNotExist(err) {
		os.Mkdir(folderPath, 0755)
	}

	// yes | ssh-keygen -t ed25519 -f workspace -N ""

	cmd := exec.Command("ssh-keygen", "-t", "ed25519", "-f", filepath.Join(folderPath, nodeName), "-N", "")
	cmd.Stdin = strings.NewReader("yes\n")

	output, err := cmd.CombinedOutput()
	if err != nil {
		config.Log.Error("Error running command:")
		config.Log.Error(string(output))
		config.Log.Error("====err===", cmd)
		// handle error
		mapd["message"] = "Failed to generate public and private key"
		mapd["error"] = true
		return mapd, err
	}

	// Print the output of the first command
	config.Log.Debug("Command 1 Output:")
	config.Log.Debug(string(output))

	// Read the public and private keys
	publicKey, err := os.ReadFile(filepath.Join(folderPath, nodeName+".pub"))
	if err != nil {
		config.Log.Error("Error reading public key:")
		config.Log.Error(err)
		// handle error
		mapd["message"] = "Failed to read public key"
		mapd["error"] = true
		return mapd, err
	}

	privateKey, err := os.ReadFile(filepath.Join(folderPath, nodeName))
	if err != nil {
		config.Log.Error("Error reading private key:")
		config.Log.Error(err)
		// handle error
		mapd["message"] = "Failed to read private key"
		mapd["error"] = true
		return mapd, err
	}

	keyMap := map[string]interface{}{
		"public_key":  publicKey,
		"private_key": privateKey,
	}

	err = vault.AddSecretKey(workspace, clusterName, nodeName, userName, keyMap)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, err
	}

	mapd["public_key"] = string(publicKey)
	mapd["error"] = false

	return mapd, nil
}

func RunGenerateTokenCommand(path, namespace, clusterName, workspace, email string) (map[string]interface{}, error) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	println("====konfigpath===", path)
	// Run the first command with dynamic parameters

	cmd1 := exec.Command("kubeadm", "token", "create", "--print-join-command", "--kubeconfig", path)
	output1, err1 := cmd1.CombinedOutput()
	config.Log.Debug("cmd1", cmd1)
	if err1 != nil {
		config.Log.Error("Error running command 1:")
		config.Log.Error(string(output1))
		config.Log.Error("====err===", cmd1)
		mapd["message"] = "Failed to generate token"
		mapd["error"] = true
		return mapd, err1
	}

	// Print the output of the first command
	config.Log.Debug("Command 1 Output:")
	config.Log.Debug(string(output1))

	mapd["token"] = string(output1)
	mapd["error"] = false

	return mapd, nil

}
