package redisdb

import (
	"fmt"
	"strconv"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"github.com/go-redis/redis"
)

// client is a redis common client
var client *redis.Client

// Initialise is a method to initialise a redis client
func Initialise() error {
	//again reset the config if any changes in toml file or environment variables
	config.SetConfig()

	// convert redis db string to int
	db, _ := strconv.Atoi(config.Conf.Redis.Database)
	// redis db client creations
	client = redis.NewClient(&redis.Options{
		Addr:     fmt.Sprintf("%s:%s", config.Conf.Redis.Host, config.Conf.Redis.Port),
		Password: config.Conf.Redis.Pass,
		DB:       db,
	})

	// check connection with server
	pong, err := client.Ping().Result()
	if err != nil {
		config.Log.Error(err)
		return err
	}
	config.Log.Debug(pong)
	return nil
}

// CheckToken is a method to check token exists in redis database
func CheckToken(token string) error {
	// initialise redis client
	err := Initialise()
	if err != nil {
		return err
	}
	// check token
	_, err = client.Get(token).Result()
	if err != nil {
		// when token not exist
		config.Log.Error(err)
		return err
	}
	// config.Log.Error(val)
	return nil
}

// SaveToken is a method saving token in redis
func SaveToken(key string, value int, expire time.Duration) error {
	// initialise redis client
	err := Initialise()
	if err != nil {
		return err
	}
	// save token with expiry
	err = client.Set(key, value, expire).Err()
	if err != nil {
		config.Log.Error(err)
		return err
	}
	return nil
}

// DeleteToken is a method for deleting token from redis
func DeleteToken(key string) error {
	// initialise redis client
	err := Initialise()
	if err != nil {
		return err
	}
	// delete token from redis
	val, err := client.Del(key).Result()
	if err != nil {
		// if any error
		config.Log.Error(err)
		return err
	}
	config.Log.Debug(val)
	return nil
}
