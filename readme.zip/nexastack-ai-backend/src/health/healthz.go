//go:build !test
// +build !test

package health

import (
	"errors"
	"os"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
)

// ServiceHealth is a method to check service each components health
func ServiceHealth() error {

	// connecting to db
	db := config.DB
	var ok string
	err := db.DB().QueryRow("SELECT 1").Scan(&ok)
	if err != nil {
		return errors.New("postgres db is not working")
	}

	// check redis database
	err = redisdb.Initialise()
	if err != nil {
		config.Log.Error("please check the redis database credentials")
		os.Exit(1)
	}

	// return nil error when all is ok
	return nil
}
