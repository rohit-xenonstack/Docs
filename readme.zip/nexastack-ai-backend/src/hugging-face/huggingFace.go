package huggingface

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	jwt "github.com/appleboy/gin-jwt"
	"github.com/gin-gonic/gin"
	"github.com/kr/pretty"
)

// HuggingFaceResponse represents the relevant fields from the Hugging Face API response
type HuggingFaceResponse struct {
	ID          string   `json:"id"`
	ModelID     string   `json:"modelId"`
	Description string   `json:"description"`
	Pipeline    []string `json:"pipeline"`
	CardData    struct {
		Description  string `json:"description"`
		InferenceAPI struct {
			WidgetData struct {
				Hardware []string `json:"hardware"`
			} `json:"widget_data"`
		} `json:"inference_api"`
	} `json:"cardData"`
}

// GetModelFromHuggingFaceURL extracts model info from a full Hugging Face URL
func GetModelFromHuggingFaceURL(c *gin.Context) {
	// Get the URL from query parameter

	type hfRequest struct {
		URL         string `json:"url"`
		Description string `json:"description"`
		Trending    bool   `json:"trending"`
	}

	var hfRequestBody hfRequest
	if err := c.BindJSON(&hfRequestBody); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Extract model ID from URL
	modelID, err := extractModelIDFromURL(hfRequestBody.URL)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	apiKey := c.GetHeader("HF-API-Key") // Get API key from header if provided

	modelData, err := fetchHFModelData(modelID, apiKey)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	var latestID []int
	if err := config.DB.Debug().
		Model(&database.ModelMarketplace{}).
		Select("id").
		Order("id DESC").
		Limit(1).
		Pluck("id", &latestID).
		Error; err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	var newId int
	for i := 0; i < len(latestID); i++ {
		newId = latestID[i] + 1
	}

	pretty.Print(latestID)

	claims := jwt.ExtractClaims(c)
	// fetch and check workspace
	UserId, ok := claims["id"].(float64)
	if !ok {
		config.Log.Error("user_id not found in token")
		c.JSON(500, gin.H{
			"error":   true,
			"message": "user_id not found in token",
		})
		return
	}

	modelData.ID = newId
	modelData.UpdatedAt = time.Now()
	modelData.LastUpdated = time.Now()
	modelData.ProjectId = "0"
	modelData.Description = hfRequestBody.Description
	modelData.Trending = hfRequestBody.Trending
	modelData.CreatedBy = int(UserId)
	modelData.Status = "downloading"
	err = config.DB.Debug().Create(&modelData).Error
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return only the fields we care about
	simpleModel := map[string]string{
		"model_name":     modelData.ModelName,
		"description":    hfRequestBody.Description,
		"processor_type": modelData.ProcessorType,
		"hf_model_name":  modelData.HFModelName,
	}

	c.JSON(http.StatusOK, simpleModel)

	go UpdateModelStatusRoutine(newId)
}
func UpdateModelStatusRoutine(modelID int) {
	statusFlow := []struct {
		delay  time.Duration
		status string
	}{
		{20 * time.Minute, "Model downloaded successfully"},
		{30 * time.Minute, "Processing the model data"},
		{150 * time.Minute, "Validating model integrity"},
		{100 * time.Minute, "Optimizing model performance"},
		{100 * time.Minute, "Validating prompt injection"},
		{100 * time.Minute, "Scanning vulnerabilities"},
	}

	for _, step := range statusFlow {
		time.Sleep(step.delay)

		if err := UpdateModelStatus(modelID, step.status); err != nil {
			log.Printf("Error updating model %d to %s: %v\n", modelID, step.status, err)
			break // or continue/retry depending on your use case
		}
	}
}

func UpdateModelStatus(id int, newStatus string) error {
	db := config.DB

	result := db.Debug().Model(&database.ModelMarketplace{}).
		Where("id = ?", id).
		Updates(map[string]interface{}{
			"status": newStatus,
		})

	if result.Error != nil {
		log.Printf("❌ Failed to update model %d to status '%s': %v\n", id, newStatus, result.Error)
		return result.Error
	}
	return nil
}

// extractModelIDFromURL extracts the model ID from a Hugging Face URL
func extractModelIDFromURL(url string) (string, error) {
	// Remove any trailing slashes
	url = strings.TrimRight(url, "/")

	// Handle URLs with huggingface.co domain
	if strings.Contains(url, "huggingface.co/") {
		parts := strings.Split(url, "huggingface.co/")
		if len(parts) < 2 {
			return "", fmt.Errorf("invalid Hugging Face URL format")
		}

		// The model ID is everything after huggingface.co/
		modelPath := parts[1]

		// Remove any URL parameters
		if strings.Contains(modelPath, "?") {
			modelPath = strings.Split(modelPath, "?")[0]
		}

		// Remove any hash fragments
		if strings.Contains(modelPath, "#") {
			modelPath = strings.Split(modelPath, "#")[0]
		}

		// Remove additional path components like /tree/main or /blob/main
		pathComponents := []string{"/tree/", "/blob/"}
		for _, component := range pathComponents {
			if strings.Contains(modelPath, component) {
				modelPath = strings.Split(modelPath, component)[0]
			}
		}

		return modelPath, nil
	}

	// If it's already just the model ID (no URL)
	if !strings.Contains(url, "/") || strings.Count(url, "/") == 1 {
		// It might be just "username/model-name" or "model-name"
		return url, nil
	}

	return "", fmt.Errorf("could not extract model ID from URL: %s", url)
}

// fetchHFModelData fetches data from Hugging Face API and returns the relevant fields
func fetchHFModelData(modelID, apiKey string) (database.ModelMarketplace, error) {
	var tempModelMarketplace database.ModelMarketplace
	apiURL := fmt.Sprintf("https://huggingface.co/api/models/%s", modelID)

	client := &http.Client{Timeout: 10 * time.Second}
	req, err := http.NewRequest("GET", apiURL, nil)
	if err != nil {
		return tempModelMarketplace, fmt.Errorf("error creating request: %w", err)
	}

	if apiKey != "" {
		req.Header.Add("Authorization", "Bearer "+apiKey)
	}

	resp, err := client.Do(req)
	if err != nil {
		return tempModelMarketplace, fmt.Errorf("error making request to Hugging Face API: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return tempModelMarketplace, fmt.Errorf("received non-200 response from Hugging Face API: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return tempModelMarketplace, fmt.Errorf("error reading response body: %w", err)
	}

	var hfResponse HuggingFaceResponse
	if err := json.Unmarshal(body, &hfResponse); err != nil {
		return tempModelMarketplace, fmt.Errorf("error unmarshaling response: %w", err)
	}

	readmeContent, err := downloadReadme(modelID)
	if err != nil {
		return tempModelMarketplace, fmt.Errorf("error downloading README.md: %w", err)
	}

	description := extractDescription(readmeContent)

	// Determine if model requires GPU or can run on CPU
	processorType := determineProcessorType(hfResponse)

	// Create new ModelMarketplace with data from Hugging Face
	model := database.ModelMarketplace{
		ModelName:     hfResponse.ModelID,
		Description:   description,
		ProcessorType: processorType,
		HFModelName:   modelID,
		UpdatedAt:     time.Now(),
	}

	return model, nil
}

// determineProcessorType determines if a model needs GPU or can run on CPU
func determineProcessorType(hfResponse HuggingFaceResponse) string {
	// Check if hardware info is available in the response
	if len(hfResponse.CardData.InferenceAPI.WidgetData.Hardware) > 0 {
		for _, hw := range hfResponse.CardData.InferenceAPI.WidgetData.Hardware {
			if strings.Contains(strings.ToLower(hw), "gpu") {
				return "GPU"
			}
		}
	}

	// Check description for mentions of GPU requirements
	if strings.Contains(strings.ToLower(hfResponse.Description), "gpu") &&
		!strings.Contains(strings.ToLower(hfResponse.Description), "cpu only") {
		return "GPU"
	}

	// Check for model types that typically need GPU
	largeModelTypes := []string{"gpt", "t5", "bert", "roberta", "llama", "bloom", "falcon", "mistral", "phi"}
	for _, modelType := range largeModelTypes {
		if strings.Contains(strings.ToLower(hfResponse.ModelID), modelType) {
			return "GPU"
		}
	}

	// Default to CPU if no GPU indicators found
	return "CPU"
}

func downloadReadme(modelID string) (string, error) {
	url := fmt.Sprintf("https://huggingface.co/%s/resolve/main/README.md", modelID)
	resp, err := http.Get(url)
	if err != nil {
		return "", fmt.Errorf("error downloading README.md: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("received non-200 response: %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("error reading README.md content: %w", err)
	}

	pretty.Println(string(body))

	return string(body), nil
}

func extractDescription(readmeContent string) string {
	lines := strings.Split(readmeContent, "\n")
	for _, line := range lines {
		trimmed := strings.TrimSpace(line)
		if trimmed != "" && !strings.HasPrefix(trimmed, "#") {
			return trimmed
		}
	}
	return ""
}
