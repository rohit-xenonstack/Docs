package vault

import (
	"errors"

	"git.xenonstack.com/nexa-platform/accounts/config"
)

func AddSecret(workspace, cloud, framework string, value map[string]interface{}) error {
	client, err := newClient()
	if err != nil {
		config.Log.Error(err)
		return err
	}

	// data structure
	data := make(map[string]interface{})
	data["data"] = value
	// send request with setting path
	_, err = client.Logical().Write("secret/data/"+workspace+"/"+cloud+"/"+framework, data)
	return err
}

func AddSecretKey(workspace, clusterName, nodeName, userName string, value map[string]interface{}) error {
	client, err := newClient()
	if err != nil {
		config.Log.Error(err)
		return err
	}

	// data structure
	data := make(map[string]interface{})
	data["data"] = value
	// send request with setting path
	_, err = client.Logical().Write("secret/data/"+workspace+"/"+clusterName+"/"+nodeName+"/"+userName, data)
	return err
}

func ViewSecret(workspace, cloud, framework string) (map[string]interface{}, error) {
	client, err := newClient()
	if err != nil {
		return nil, err
	}
	// send request with setting path
	resp, err := client.Logical().Read("secret/data/" + workspace + "/" + cloud + "/" + framework)
	if err != nil {
		config.Log.Error("vault read", err)
		return nil, err
	}
	if resp == nil {
		config.Log.Debug("vault read resp...")
		return nil, errors.New("please try again later")
	}
	data, ok := resp.Data["data"]
	if !ok {
		config.Log.Debug("vault read...", resp.Data)
		return nil, errors.New("please try again later")
	}
	return data.(map[string]interface{}), nil
}

func ViewSecretKey(workspace, clusterName, nodeName, userName string) (map[string]interface{}, error) {
	client, err := newClient()
	if err != nil {
		return nil, err
	}
	// send request with setting path
	resp, err := client.Logical().Read("secret/data/" + workspace + "/" + clusterName + "/" + nodeName + "/" + userName)
	if err != nil {
		config.Log.Error("vault read", err)
		return nil, err
	}
	if resp == nil {
		config.Log.Debug("vault read resp...")
		return nil, errors.New("please try again later")
	}
	data, ok := resp.Data["data"]
	if !ok {
		config.Log.Debug("vault read...", resp.Data)
		return nil, errors.New("please try again later")
	}
	return data.(map[string]interface{}), nil
}

// DeleteSecret function used for delete the vault secrets
func DeleteSecret(workspace, cloud, framework string) error {
	client, err := newClient()
	if err != nil {
		return err
	}
	// send request with setting path
	_, err = client.Logical().Delete("secret/metadata/" + workspace + "/" + cloud + "/" + framework)
	return err
}
