package vault

import (
	"net/http"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"github.com/hashicorp/vault/api"
)

func newClient() (*api.Client, error) {
	conf := api.DefaultConfig()
	conf.HttpClient = http.DefaultClient
	conf.Address = config.Conf.Vault.Address
	client, err := api.NewClient(conf)
	if err != nil {
		config.Log.Error("vault client......", err)
		return client, err
	}
	client.SetClientTimeout(10 * time.Second)
	client.SetToken(config.Conf.Vault.Token)
	return client, nil
}

// func newClient() (*api.Client, error) {
// 	conf := api.DefaultConfig()
// 	conf.HttpClient = http.DefaultClient
// 	conf.Address = config.Conf.Vault.Address
// 	client, err := api.NewClient(conf)
// 	if err != nil {
// 		log.Println("vault client......", err)
// 		return client, err
// 	}

// 	// Unseal the Vault
// 	unsealTokens := []string{
// 		"pYpKVfcvAti4GgYbl1o9WeF4pPIYzPrxFz/DijvQ+Wsn",
// 		"RkCwk3eIfJkYO8NsEaT+O/3yr89v0oVbbYHT/rWon81y",
// 		"X1j2tdNoGCVt2GM2Ab8byeu+OQAZAYfkO//Hih47oGws",
// 		"rudV2ftbOcODFzSMsnRQpkb1dBgG+iW+W1gjBKQNe5s5",
// 		"ayd0ajJwgblcn6rOO5LUla8dY3NImIJj9J9ycuMpKqAh,",
// 	}
// 	for _, token := range unsealTokens {
// 		resp, err := client.Sys().Unseal(token)
// 		if err != nil {
// 			log.Println(err)
// 			continue
// 		}
// 		log.Printf("Unseal token applied: %v\n", resp)
// 		if !resp.Sealed {
// 			log.Println("Vault unsealed")
// 			break
// 		}
// 	}

// 	// Set the client timeout and token
// 	client.SetClientTimeout(10 * time.Second)
// 	client.SetToken(config.Conf.Vault.Token)
// 	return client, nil
// }
