//go:build !test
// +build !test

package routes

import (
	"net/http"
	"os"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/api"
	"git.xenonstack.com/nexa-platform/accounts/src/ginjwt"
	huggingface "git.xenonstack.com/nexa-platform/accounts/src/hugging-face"
	"git.xenonstack.com/nexa-platform/accounts/src/marketplace"
	"git.xenonstack.com/nexa-platform/accounts/src/middleware"
	"git.xenonstack.com/nexa-platform/accounts/src/util"
	"github.com/gin-gonic/gin"
)

// V1Routes is a method in which all the service endpoints are defined
func V1Routes(router *gin.Engine) {

	//Healthz Check
	router.GET("/healthz", api.Healthz)

	// Serve swagger.json as static file
	router.StaticFile("/swagger.json", "./docs/swagger.json")

	// Serve Redoc
	router.GET("/redoc", util.Redoc)
	// developer help endpoint
	if config.Conf.Service.Environment != "production" {
		// endpoint to read variables
		router.GET("/end", CheckToken, ReadEnv)
		router.GET("/logs", CheckToken, ReadLogs)
		// github  webhook for deleting workspace
	}

	// intialize v1 group
	v1 := router.Group("/v1")

	// Unmodified database instance
	// v1.Use(middleware.InjectDefaultDB())

	// signup routes
	// account creation endpoint
	v1.POST("/signup", middleware.InjectDefaultDB(), api.SignupEndpoint)
	// verify mail id on basis of token
	v1.POST("/verifymail", middleware.InjectDefaultDB(), api.VerifyMailEp)
	// if verify code get expired used to send code again at mail id
	v1.POST("/send_code_again", middleware.InjectDefaultDB(), api.SendCodeAgain)
	// login in workspace
	v1.POST("/workspace_login", middleware.InjectDefaultDB(), middleware.InjectDefaultDB(), api.WorkSpaceLoginEp)
	// forgot worksapce
	v1.POST("/forgot_workspace", middleware.InjectDefaultDB(), middleware.InjectDefaultDB(), api.ForgotWorkspaceEp)
	// get workspace list of a user
	v1.POST("/get_workspace_list", middleware.InjectDefaultDB(), middleware.InjectDefaultDB(), api.GetWorkspaceList)
	// signup member in a workspace
	v1.POST("/membersignup", middleware.InjectDefaultDB(), api.MemberSignupEp)
	// this function sets new password according to invited link or token
	v1.POST("/memberregistration", middleware.InjectDefaultDB(), api.MemberRegistration)

	// login with workspace
	v1.POST("/login", middleware.InjectDefaultDB(), api.LoginEndpoint)

	v1.GET("/download/:filename", middleware.InjectDefaultDB(), marketplace.DownloadYAML)

	// forgot password routes
	// used to get link when user forgot password and also for reset password
	v1.POST("/forgotpass", middleware.InjectDefaultDB(), api.ForgotPassEp)

	// downscale the deployed model
	v1.POST("/downscale_model", middleware.InjectDefaultDB(), api.DownscaleModel)

	v1.POST("/projects/member/register", middleware.InjectDefaultDB(), api.VarifyProjectMember)

	//setting up middleware for protected apis
	authMiddleware := ginjwt.MwInitializer()

	v1.Use(authMiddleware.MiddlewareFunc())

	// api to get model lists
	v1.GET("/models", middleware.InjectDefaultDB(), api.GetModelList)

	projects := v1.Group("/projects")
	{
		projects.POST("", api.RBAC("project", "write"), middleware.InjectDefaultDB(), api.CreateProject)
		projects.GET("/:id", api.RBAC("project", "read"), middleware.InjectDefaultDB(), api.ShowProjectData)
		projects.PUT("/:id", api.RBAC("project", "write"), middleware.InjectDefaultDB(), api.UpdateProject)
		projects.DELETE("/:id", api.RBAC("project", "write"), middleware.InjectDefaultDB(), api.DeleteProject)

		projects.POST("/member/invite", api.RBAC("project", "write"), middleware.InjectDefaultDB(), api.ProjectSendInvite)
		projects.GET(":id/members", api.RBAC("project", "read"), middleware.InjectDefaultDB(), api.GetProjectMembers)
		projects.GET("/members/:id", api.RBAC("project", "read"), middleware.InjectDefaultDB(), api.GetProjectMemberByID)
		projects.GET(":id/activities", api.RBAC("project", "read"), middleware.InjectDefaultDB(), api.GetProjectActivities)
	}
	v1.GET("/user/projects", api.RBAC("project", "read"), middleware.InjectDefaultDB(), api.ProjectsByUserOrWorkspace)

	{
		v1.POST("/roles", api.RBAC("roles", "write"), middleware.InjectDefaultDB(), api.CreateRole)
		v1.POST("/permissions", api.RBAC("roles", "write"), middleware.InjectDefaultDB(), api.CreatePermission)
		v1.POST("/roles/:role_id/permissions", api.RBAC("roles", "write"), middleware.InjectDefaultDB(), api.AddPermissionToRole)
		v1.POST("/users/:user_id/roles/:role_id", api.RBAC("roles", "write"), middleware.InjectDefaultDB(), api.AddRoleToUser)

		v1.GET("/roles", api.RBAC("roles", "read"), middleware.InjectDefaultDB(), api.ListRoles)
		v1.GET("/permissions", api.RBAC("roles", "read"), middleware.InjectDefaultDB(), api.ListPermissions)
	}

	// v1.Use(middleware.InjectScopedDB())
	{

		// adding custom middleware for checking token validity
		v1.Use(api.CheckTokenValidity)
		{
			// session apis
			v1.GET("/activity", api.Activity)
			v1.GET("/refresh_token", api.RefreshToken)
			v1.GET("/check_token", api.CheckToken)
			v1.GET("/logout", api.Logout)
			v1.POST("/upgrade_token", api.UpgradeToken)

			// [ Deprecation : Start ]
			// v1.POST("/config/fields", api.RBAC("config", "write"), api.CreateFields)
			// v1.PUT("/config/fields/:id", api.RBAC("config", "write"), api.UpdateField)
			// v1.GET("/config/fields", api.RBAC("config", "read"), api.GetAllFields)
			// v1.DELETE("/config/field/:id", api.RBAC("config", "write"), api.RemoveField)
			// v1.GET("/config/fields/:id", api.RBAC("config", "read"), api.GetFieldsByUserId)

			// // finetune Page API's
			// v1.POST("/finetune/fields", api.RBAC("finetune", "write"), api.CreateFieldConfiguration)
			// v1.GET("/finetune/fields/:user_id", api.RBAC("finetune", "read"), api.GetFinetuneConfigByID)
			// v1.PATCH("/finetune/field", api.RBAC("finetune", "write"), api.UpdateIndividualFieldValuesByUser)
			// v1.GET("/finetune/:user_id/:job_id", api.RBAC("finetune", "read"), api.FineTuneModel)

			// // jobs related API's
			// v1.GET("/jobs/:account_id", api.RBAC("job", "read"), api.GetJobs)
			// [ Deprecation : End ]

			// user apis
			user := v1.Group("/")
			//middleware for user
			user.Use(api.CheckUser)
			{
				// profile related routes
				// api for changing password
				user.PUT("/changepass", api.RBAC("user_management", "write"), middleware.InjectDefaultDB(), api.ChangePasswordEp)
				// api for view profile
				user.GET("/profile", api.RBAC("user_management", "read"), middleware.InjectDefaultDB(), api.ViewProfile)
				// api for view profile
				user.PUT("/profile", api.RBAC("user_management", "write"), middleware.InjectDefaultDB(), api.UpdateProfile)
				//api for get workspace list for user
				user.GET("/workspaces", api.RBAC("workspace", "read"), middleware.InjectDefaultDB(), api.WorkspaceList)

				// user workspace routes
				// api for creating workspace
				user.POST("/workspaces", middleware.InjectDefaultDB(), api.CreateWorkSpaceEp)
				// api for checking workspace Availability
				user.POST("/workspace_availability", middleware.InjectDefaultDB(), api.WorkspaceAvailability)

				// api for get instances
				user.GET("/instances", api.RBAC("instance", "read"), middleware.InjectScopedDB(), api.GetNodes)

				//api for create minio bucket
				user.POST("/bucket", api.RBAC("storage", "write"), middleware.InjectScopedDB(), api.CreateMinioBucket)

				//api for upload dataset files and model files
				user.POST("/upload", api.RBAC("storage", "write"), middleware.InjectScopedDB(), api.UploadFile)

				//api for getting jupyterhub_api_token and username
				user.POST("/get_pod_details", api.RBAC("pod", "read"), middleware.InjectScopedDB(), api.GetPodDetails)

				//api for get folders from the minio bucket
				user.POST("/bucket/content", api.RBAC("storage", "read"), middleware.InjectScopedDB(), api.GetMinioBucketContents)

				//api for getting files present in folder
				user.POST("/bucket/content/:folderName/files", middleware.InjectScopedDB(), api.RBAC("storage", "read"), api.GetFilesInFolder)

				user.DELETE("/bucket/content/:folderName/:fileName", middleware.InjectScopedDB(), api.RBAC("storage", "write"), api.DeleteMinioObject)
				//api for get compute list
				// user.GET("/computes", api.RBAC("compute", "read"), api.GetComputeList)
				// // API for Compute configuratioons
				// user.POST("/compute_configuration", api.RBAC("compute", "write"), api.UpdateResourcesPreset)
				// user.DELETE("/compute/:computeId", api.RBAC("compute", "write"), api.DeleteCompute)

				// api to install model on the workspace of user
				user.POST("/install_model", api.RBAC("model", "write"), middleware.InjectScopedDB(), api.InstallModel)
				user.GET("/clusters", api.RBAC("cluster", "read"), middleware.InjectScopedDB(), api.GetSuitableCluster)
				user.POST("/upscale_model", api.RBAC("model", "write"), middleware.InjectScopedDB(), api.UpscaleModel)
				// api to get details of deployed models
				user.GET("/deployed_model", api.RBAC("model", "read"), middleware.InjectScopedDB(), api.GetDeployedModel)
				user.POST("/playground/podstatus", api.RBAC("pod", "read"), middleware.InjectScopedDB(), api.CheckDeployedPodStatus)
				//api to delete the deployed model
				user.DELETE("/deployed_model/:model_id", api.RBAC("model", "write"), middleware.InjectScopedDB(), api.DeleteDeployedModel)
				user.POST("/chat_response", api.RBAC("chat", "write"), middleware.InjectScopedDB(), api.ChatResponse)
				user.POST("/pod_status", api.RBAC("pod", "read"), middleware.InjectScopedDB(), api.PodStatus)
				user.POST("/deployment_status", api.RBAC("deployment", "read"), middleware.InjectScopedDB(), api.DeployemntStatus)
				user.POST("/model/podstatus", api.RBAC("pod", "read"), middleware.InjectScopedDB(), api.ModelPodStatus)

				// Azure and on-premises onbaording
				user.POST("/save/config", api.RBAC("infrastructure", "write"), middleware.InjectScopedDB(), api.SaveKube)
				user.POST("/save/config/file", api.RBAC("infrastructure", "write"), middleware.InjectScopedDB(), api.SaveKubeFile)
				user.GET("/infrastructure/list", api.RBAC("infrastructure", "read"), middleware.InjectScopedDB(), api.ListInfrastucture)
				user.DELETE("/infrastructure/:id", api.RBAC("infrastructure", "write"), middleware.InjectScopedDB(), api.DeleteInfrastucture)
				// user.GET("cluster/status", api.RBAC("infrastructure", "read"), api.GetClusterStatus)

				user.POST("/onboard/config/file", api.RBAC("infrastructure", "read"), middleware.InjectScopedDB(), api.MangagedByNexaStack)

				user.POST("/models/load", api.RBAC("model", "write"), middleware.InjectScopedDB(), huggingface.GetModelFromHuggingFaceURL)
				// AWS Cluster onboading API's
				user.GET("/aws/", api.RBAC("aws", "read"), middleware.InjectScopedDB(), api.AwsOnboardingHealthCheck)
				user.GET("/aws/clusters", api.RBAC("aws", "read"), middleware.InjectScopedDB(), api.AwsOnboardingListClusters)
				user.POST("/aws/cluster/register", api.RBAC("aws", "write"), middleware.InjectScopedDB(), api.AwsOnboardingClusterHealthCheck)
				user.POST("/aws/role/register", api.RBAC("aws", "write"), middleware.InjectScopedDB(), api.AwsOnboardingRegisterRole)
				user.GET("/aws/accounts/:user_id", api.RBAC("aws", "read"), middleware.InjectScopedDB(), api.GetAwsAccountsByUserId)
				user.GET("/aws/role", api.RBAC("aws", "read"), middleware.InjectScopedDB(), api.GetAwsOnboardRoleConfiguration)

				user.POST("/vm/onboarding", api.RBAC("vm", "write"), middleware.InjectScopedDB(), api.VmOnboarding)
				user.POST("cluster/:name/vm/save/key", api.RBAC("vm", "write"), middleware.InjectScopedDB(), api.SaveVmPrivateKey)
				user.DELETE("/vm/:name", api.RBAC("vm", "write"), middleware.InjectScopedDB(), api.DeleteVmNode)

				router.GET("/gcp/clusters", api.RBAC("gcp", "read"), middleware.InjectScopedDB(), api.ListGKEClusterNames)
				router.POST("/gcp/onboard", api.RBAC("gcp", "write"), middleware.InjectScopedDB(), api.OnboardGKE)

				user.POST("/model", api.RBAC("model", "write"), middleware.InjectScopedDB(), api.UploadModel)
				user.GET("/vulnerabilities", api.RBAC("model", "write"), middleware.InjectScopedDB(), api.GetVulnerabilities)

				// MCP marketplace
				user.GET("/mcp/fetch-data", api.RBAC("gcp", "write"), middleware.InjectScopedDB(), api.FetchMCPDataStreamHandler)

				user.GET("/mcp/marketplace", api.RBAC("gcp", "write"), middleware.InjectScopedDB(), api.GetMCPRepositories)
				user.GET("/mcp/marketplace/:id/readme", api.RBAC("gcp", "write"), middleware.InjectScopedDB(), api.GetMcpRepoReadMe)

				owner := user.Group("/")

				owner.Use(api.CheckOwner)
				{
					// send invite to member for joining workspace
					owner.POST("/workspaces/member", api.RBAC("workspace", "write"), middleware.InjectDefaultDB(), api.InviteWorkspaceMembers)
					// Delete members of a WorkSpace
					owner.DELETE("/workspaces/member", api.RBAC("workspace", "write"), middleware.InjectDefaultDB(), api.DeleteWorkspaceMember)
				}
				// fetch members of a WorkSpace
				user.GET("/workspaces/member", api.RBAC("workspace", "read"), middleware.InjectDefaultDB(), api.WorkspaceMembers)
				// chech member belongs to workspace and joined the workspace
				user.GET("/workspaces/checkmember", api.RBAC("workspace", "read"), middleware.InjectDefaultDB(), api.WorkspaceCheckMember)
			}
			// RBAC apis
			// rbac := v1.Group("/")

			// admin apis
			admin := v1.Group("/admin")
			//middleware for user
			admin.Use(api.CheckOwner)
			{

				// admin workspace routes
				admin.GET("/workspaces/:workspace_id/members", middleware.InjectDefaultDB(), api.ListWorkspaceMembers)
				// get user account
				admin.GET("/accounts", api.AccountsEmail)

				// upload model
				admin.POST("/model", middleware.InjectScopedDB(), api.UploadModel)
				// delete model
				admin.DELETE("/model/:id", middleware.InjectDefaultDB(), api.DeleteModel)

				// tester help endpoint
				if config.Conf.Service.Environment != "production" {
					// toggle mail service
					admin.PUT("/mail/:value", api.ChangeMail)
					// toggle otp service
					admin.PUT("/otp/:value", api.ChangeOTP)
				}
			}
		}
	}
}

// readLogs is a api handler for reading logs
func ReadLogs(c *gin.Context) {
	http.ServeFile(c.Writer, c.Request, "info.txt")
}

// readEnv is api handler for reading configuration variables data
func ReadEnv(c *gin.Context) {
	if config.TomlFile == "" {
		// if configuration is done using environment variables
		env := os.Environ()
		c.JSON(200, gin.H{
			"environments": env,
		})
	} else {
		// if configuration is done using toml file
		http.ServeFile(c.Writer, c.Request, config.TomlFile)
	}
}

// checkToken is a middleware to check header is set or not for secured api
func CheckToken(c *gin.Context) {
	xt := c.Request.Header.Get("Nexastack-TOKEN")
	if xt != "NexastackAgent1010" {
		c.Abort()
		c.JSON(404, gin.H{})
		return
	}
	c.Next()
}
