package routes

import (
	"testing"

	"github.com/gin-gonic/gin"
)

func TestV1Routes(t *testing.T) {
	// initialize gin router
	router := gin.Default()
	V1Routes(router)
}
