package kubernetes

import (
	"flag"
	"os"
	"testing"

	"git.xenonstack.com/nexa-platform/accounts/config"
)

func TestMain(m *testing.M) {
	// setup for reading flags for deciding whether to do configuration with toml or env variables
	conf := flag.String("conf", "environment", "set configuration from toml file or environment variables")

	file := flag.String("file", "", "set path of toml file")

	flag.Parse()

	if *conf == "environment" {
		config.Log.Error("environment")
		config.ConfigurationWithEnv()
	} else if *conf == "toml" {
		config.Log.Error("toml")
		if *file == "" {
			config.Log.Error("Please pass toml file path")
			os.Exit(1)
		} else {
			err := config.ConfigurationWithToml(*file)
			if err != nil {
				config.Log.Error("Error in parsing toml file")
				config.Log.Error(err)
				os.Exit(1)
			}
		}
	} else {
		config.Log.Error("Please pass valid arguments, conf can be set as toml or environment")
		os.Exit(1)
	}

	exitVal := m.Run()

	os.Exit(exitVal)
}
