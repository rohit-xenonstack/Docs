package kubernetes

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/integrations"
	"helm.sh/helm/v3/pkg/action"
	"helm.sh/helm/v3/pkg/kube"
)

// SetConfig sets up kube-config and returns action.Configuration
func SetConfig(nameSpace string) (*action.Configuration, int, error) {
	var kubeConfigPath string
	var err error

	// Load kube credentials from config
	kubecfg := KubeConfig{}
	if config.Conf.Kube.CertAuthData != nil {
		kubecfg.CertAuthData = *config.Conf.Kube.CertAuthData
	}
	if config.Conf.Kube.KubeServer != nil {
		kubecfg.KubeServer = *config.Conf.Kube.KubeServer
	}
	if config.Conf.Kube.ClientCertificate != nil {
		kubecfg.ClientCertificate = *config.Conf.Kube.ClientCertificate
	}
	if config.Conf.Kube.ClientKey != nil {
		kubecfg.ClientKey = *config.Conf.Kube.ClientKey
	}

	// Attempt to set kubeconfig from environment
	kubeConfigPath, err = SetKubeConfig(kubecfg)
	if err != nil || kubeConfigPath == "" {
		// Fall back to in-cluster config
		config.Log.Debug("Falling back to in-cluster config")
		clusterConfig, err := rest.InClusterConfig()
		if err != nil {
			config.Log.Error("Error creating in-cluster config: %v", err)
			return nil, 500, err
		}

		// Create Kubernetes clientset
		_, err = kubernetes.NewForConfig(clusterConfig)
		if err != nil {
			config.Log.Error("Error creating clientset: %v", err)
			return nil, 500, err
		}

		// Initialize Helm action configuration
		actionConfig := new(action.Configuration)
		if err = actionConfig.Init(kube.GetConfig("", "", nameSpace), nameSpace, "secret", func(format string, v ...interface{}) {
			config.Log.Error(fmt.Sprintf(format, v...))
		}); err != nil {
			config.Log.Error(err)
			return HandleConfigError(err)
		}
		return actionConfig, 200, nil
	}

	// Initialize Helm action configuration using environment kubeconfig
	actionConfig := new(action.Configuration)
	if err = actionConfig.Init(kube.GetConfig(kubeConfigPath, "", nameSpace), nameSpace, config.Conf.ChartHelm.HelmDriver, func(format string, v ...interface{}) {
		config.Log.Error(fmt.Sprintf(format, v...))
	}); err != nil {
		config.Log.Error(err)
		return HandleConfigError(err)
	}
	return actionConfig, 200, nil
}

// SetConfig sets up kube-config and returns action.Configuration
func SetInfraConfig(nameSpace, clusterName, workspace, email string) (*action.Configuration, string, int, error) {
	var kubeConfigPath string
	var err error
	mapd := make(map[string]interface{})
	mapd["error"] = false
	println(clusterName, workspace, email)
	// Attempt to set kubeconfig from environment
	mapd, code := SetInfraKubeConfig(clusterName, workspace, email)
	if code != 200 {
		config.Log.Error("Failed to get kubeconfig from vault")
		return nil, "", code, fmt.Errorf("failed to get kubeconfig from vault")
	}

	value := mapd["path"]
	fmt.Printf("Type of value: %T\n", value)
	kubeConfigPath, ok := value.(string)
	if !ok {
		config.Log.Error("Error: kubeConfigPath is not a string")
		return nil, "", 0, errors.New("kubeConfigPath is not a string")
	}
	if code != 200 || kubeConfigPath == "" {
		// Fall back to in-cluster config
		config.Log.Error("Falling back to in-cluster config")
		clusterConfig, err := rest.InClusterConfig()
		if err != nil {
			config.Log.Error("Error creating in-cluster config: %v", err)
			return nil, "", 500, err
		}

		// Create Kubernetes clientset
		_, err = kubernetes.NewForConfig(clusterConfig)
		if err != nil {
			config.Log.Error("Error creating clientset: %v", err)
			return nil, "", 500, err
		}

		// Initialize Helm action configuration
		actionConfig := new(action.Configuration)
		if err = actionConfig.Init(kube.GetConfig("", "", nameSpace), nameSpace, "secret", func(format string, v ...interface{}) {
			config.Log.Error(fmt.Sprintf(format, v...))
		}); err != nil {
			config.Log.Error(err)
			return nil, "", 401, err
		}

		return actionConfig, "", 200, nil
	}

	// Initialize Helm action configuration using environment kubeconfig
	actionConfig := new(action.Configuration)
	if err = actionConfig.Init(kube.GetConfig(kubeConfigPath, "", nameSpace), nameSpace, config.Conf.ChartHelm.HelmDriver, func(format string, v ...interface{}) {
		config.Log.Error(fmt.Sprintf(format, v...))
	}); err != nil {
		config.Log.Error(err)
		return nil, "", 401, err
	}

	// func() {
	// 	deleteFile(kubeConfigPath)
	// }()

	return actionConfig, kubeConfigPath, 200, nil
}

// func deleteFile(kubeConfigPath string) {
// 	if kubeConfigPath != "" {
// 		err := os.Remove(kubeConfigPath)
// 		if err != nil {
// 			log.Printf("Error removing kubeconfig file: %v", err)
// 		} else {
// 			log.Printf("Kubeconfig file deleted: %s", kubeConfigPath)
// 		}
// 	}
// }

// SetNamespace sets the default namespace
func SetNamespace() string {
	if config.Conf.Kube.Namespace != nil {
		return *config.Conf.Kube.Namespace
	}
	return "default"
}

// SetKubeConfig creates a temporary kubeconfig file
func SetKubeConfig(config KubeConfig) (string, error) {
	// Create directory if not exists
	if err := os.MkdirAll("data/.con", 0777); err != nil {
		return "", err
	}

	// workingDir, err := os.Getwd()
	// if err != nil {
	// 	log.Fatal("Error getting working directory:", err)
	// }

	// // Create kubeconfig file in the current working directory
	// filePath := filepath.Join(workingDir, "data/.con", "config")

	// fmt.Println("Kubeconfig file path:", filePath)
	// f, err := os.Create(filePath)
	// if err != nil {
	// 	config.Log.Error(err)
	// 	return "", err
	// }

	// fmt.Println("Kubeconfig File Path:", filePath)
	// defer f.Close()

	// Create kubeconfig file
	filePath := "data/.con/config"
	f, err := os.Create(filePath)
	if err != nil {
		return "", err
	}
	defer f.Close()

	// Write kubeconfig data
	data := clientAuthority + config.CertAuthData + server + config.KubeServer
	dataKey := clientCertData + config.ClientCertificate + clientKeyData + config.ClientKey
	if _, err = f.Write([]byte(data)); err != nil {
		return "", err
	}
	if _, err = f.WriteString(dataKey); err != nil {
		return "", err
	}

	return filePath, nil
}

func SetInfraKubeConfig(clusterName, workspace, email string) (map[string]interface{}, int) {
	mapd, code := integrations.GetFile(clusterName, workspace, email)
	if code != 200 {
		mapd["error"] = true
		mapd["message"] = "file content not found"
		return mapd, 500
	}
	fileBytes, ok := mapd["file"].([]byte)
	println("===filebyte==", fileBytes)
	if !ok {
		mapd["error"] = true
		mapd["message"] = "file content not found"
		return mapd, 500
	}
	if err := os.MkdirAll(".azure", 0777); err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	path := "data/.azure/config"
	f, err := os.Create(path)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}
	defer f.Close() // close the file to prevent leaks

	_, err = f.Write(fileBytes)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	mapd["path"] = path
	mapd["error"] = false
	return mapd, 200
}

// handleConfigError processes errors during config initialization
func HandleConfigError(err error) (*action.Configuration, int, error) {
	if strings.Contains(err.Error(), errorConfigFile) || strings.Contains(err.Error(), failQueryFile) {
		return nil, 401, errors.New(unauthorizedAccess)
	}
	return nil, 404, err
}

func NewKubeClient(kubeconfigPath string) (*kubernetes.Clientset, error) {
	absPath, err := filepath.Abs(kubeconfigPath)
	if err != nil {
		return nil, fmt.Errorf("error resolving kubeconfig path: %w", err)
	}

	config, err := clientcmd.BuildConfigFromFlags("", absPath)
	if err != nil {
		return nil, fmt.Errorf("error building kubeconfig: %w", err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, fmt.Errorf("error creating Kubernetes client: %w", err)
	}

	return clientset, nil
}
