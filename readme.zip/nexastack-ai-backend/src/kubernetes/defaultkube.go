package kubernetes

import "os"

const (
	clientAuthority       string = "clusters:\n- cluster:\n    certificate-authority-data: "
	server                string = "\n    server: "
	clientCertData        string = "\nusers:\n- user:\n    client-certificate-data: "
	clientKeyData         string = "\n    client-key-data: "
	token                 string = "\nusers:\n- user:\n    token:"
	Context               string = ""
	pleasePassValidConfig string = "Pleass pass valid configuration"
	unauthorizedAccess    string = "Unauthorized access \n (`Please Pass Right Config in Environment Variable`)"
	errorConfigFile       string = "error loading config file"
	failQueryFile         string = "failed to query with labels"
)

// KubeConfig is a structure for k8s configuration
type KubeConfig struct {
	KubeServer        string `json:"kube_server"`
	CertAuthData      string `json:"certificate_authority_data"`
	ClientCertificate string `json:"client_certificate"`
	ClientKey         string `json:"client_key"`
	Namespace         string `json:"namespace"`
	Context           string
	Token             string
}

// DefaultKubeClusterConfig Kube config form environment variable
var DefaultKubeClusterConfig = KubeConfig{KubeServer: os.Getenv("KUBERNETES_SERVICE_HOST") + ":" + os.Getenv("KUBERNETES_SERVICE_PORT"),
	CertAuthData:      os.Getenv("CERTIFICATE_AUTHORITY_DATA"),
	ClientCertificate: os.Getenv("KUBE_CLIENT_CERT_DATA"),
	ClientKey:         os.Getenv("KUBE_CLIENT_KEY"),
	// Token: os.Getenv("WORKSPACE_KUBE_TOKEN"),
}
