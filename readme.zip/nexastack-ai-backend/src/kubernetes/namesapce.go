package kubernetes

import (
	"context"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"time"

	"log"
	"strings"

	// "k8s.io/metrics/pkg/client/clientset/versioned"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/integrations"
	"github.com/kr/pretty"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"

	// appsv1 "k8s.io/api/apps/v1"

	contex "context"

	// "slices"

	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
	clientcmdapi "k8s.io/client-go/tools/clientcmd/api"
)

// CreateNamespace function used for Create new namespace
func CreateNamespace(name string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})

	clientSet, err := ClientSet()
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 401
	}

	// Set name in ObjectMeta
	opts := metav1.ObjectMeta{
		Name: name,
	}

	// Set namespace in Namespace
	namespace := v1.Namespace{
		ObjectMeta: opts,
	}

	// Create a context
	ctx := contex.Background()

	// Set CreateOptions (can be empty if not needed)
	createOptions := metav1.CreateOptions{}

	// Send request
	_, err = clientSet.CoreV1().Namespaces().Create(ctx, &namespace, createOptions)
	if err != nil {
		if !strings.Contains(err.Error(), "already") {
			config.Log.Error("namespace.....", err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			return mapd, 500
		}
	}
	return mapd, 200
}

// DeleteNamespace function used for delete namespace
func DeleteNamespace(name string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})

	clientSet, err := ClientSet()
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 401
	}

	ctx := contex.Background()
	//set optionis
	opts := metav1.DeleteOptions{}
	//send request
	err = clientSet.CoreV1().Namespaces().Delete(ctx, name, opts)
	if err != nil {
		if !strings.Contains(err.Error(), "already") {
			config.Log.Error("namespace.....", err)
			mapd["error"] = true
			mapd["message"] = err.Error()
			return mapd, 500
		}
	}
	return mapd, 200
}

// GetNodes function used for get nodes
func GetNodes(nameSpace, clusterName, worksapce, email string) ([]map[string]interface{}, error) {
	_, path, _, err := SetInfraConfig(nameSpace, clusterName, worksapce, email)
	defer os.Remove(path)
	if err != nil {
		config.Log.Error(err)
		return nil, err
	}
	var config *rest.Config
	config, err = clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		return nil, err
	}
	var clientset *kubernetes.Clientset

	clientset, err = kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	ctx := contex.Background()
	nodes, err := clientset.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	var result []map[string]interface{}
	for _, node := range nodes.Items {
		nodeInfo := map[string]interface{}{
			"Name": node.Name,
			"CPU": map[string]interface{}{
				"Capacity":        node.Status.Capacity.Cpu().String(),
				"Allocatable":     node.Status.Allocatable.Cpu().String(),
				"operatingSystem": node.Status.NodeInfo.OperatingSystem,
				"architecture":    node.Status.NodeInfo.Architecture,
			},
		}
		result = append(result, nodeInfo)
	}

	return result, nil
}

func GetNodesName(nameSpace, clusterName, worksapce, email string) ([]string, error) {
	_, path, _, err := SetInfraConfig(nameSpace, clusterName, worksapce, email)
	// defer os.Remove(path)
	if err != nil {
		config.Log.Error(err)
		return nil, err
	}
	var config *rest.Config
	config, err = clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		return nil, err
	}
	var clientset *kubernetes.Clientset

	clientset, err = kubernetes.NewForConfig(config)
	if err != nil {
		return nil, err
	}

	ctx := contex.Background()
	nodes, err := clientset.CoreV1().Nodes().List(ctx, metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	var result []string
	for _, node := range nodes.Items {

		result = append(result, node.Name)
	}

	return result, nil
}

// Functionality to get the nodes name present in specific workspace
// func GetNodesNames(nameSpace string, label string) ([]string, error) {
// 	clientSet, err := clientSet()
// 	if err != nil {
// 		return nil, err
// 	}

// 	ctx := contex.Background()
// 	nodes, err := clientSet.CoreV1().Nodes().List(ctx, metav1.ListOptions{
// 		LabelSelector: label,
// 	})
// 	if err != nil {
// 		return nil, err
// 	}

// 	var result []string
// 	for _, node := range nodes.Items {
// 		result = append(result, node.Name)

// 	}

//		return result, nil
//	}
func GetNodesNames(nameSpace string) ([]string, error) {
	db := config.DB
	var instances []database.Instance
	err := db.Model(&database.Instance{}).Where("workspace_id = ?", nameSpace).Find(&instances).Error
	if err != nil {
		return nil, err
	}

	var result []string
	for _, instance := range instances {
		result = append(result, instance.NodeName)
	}

	return result, nil
}

// Functionality to check the user pod is present or not
func CheckPodExists(namespace, podNamePrefix string) (bool, error) {
	clientSet, err := ClientSet()
	if err != nil {
		return false, err
	}

	pods, err := clientSet.CoreV1().Pods(namespace).List(contex.Background(), metav1.ListOptions{})
	if err != nil {
		return false, err
	}

	for _, pod := range pods.Items {
		if strings.HasPrefix(pod.Name, podNamePrefix) {
			return true, nil
		}
	}

	// Find the pod with the matching name
	for _, pod := range pods.Items {
		if strings.Contains(pod.Name, podNamePrefix) {
			break
		}
	}

	return false, nil
}

// Functionality to restart the user pod after upgradation
func RestartPod(namespace, podNamePrefix string) error {
	clientSet, err := ClientSet()
	if err != nil {
		return err
	}

	pods, err := clientSet.CoreV1().Pods(namespace).List(contex.Background(), metav1.ListOptions{})
	if err != nil {
		return err
	}

	for _, pod := range pods.Items {
		if strings.HasPrefix(pod.Name, podNamePrefix) {
			// Delete the pod to restart it
			err = clientSet.CoreV1().Pods(namespace).Delete(contex.Background(), pod.Name, metav1.DeleteOptions{})
			if err != nil {
				return err
			}
			return nil
		}
	}

	return errors.New("pod not found")
}

// func HasSufficientResources(nodeName string, requests map[string]string) bool {
// 	// Get the clientset
// 	clientset, err := ClientSet()
// 	if err != nil {
// 		config.Log.Error("Error getting clientset:", err)
// 		return false
// 	}

// 	// Get the node object (allocatable resources)
// 	node, err := clientset.CoreV1().Nodes().Get(contex.Background(), nodeName, metav1.GetOptions{})
// 	if err != nil {
// 		config.Log.Error("Error getting node:", err)
// 		return false
// 	}

// 	// Get the node's allocatable resources
// 	allocatableCPU := node.Status.Allocatable[v1.ResourceCPU]
// 	allocatableMemory := node.Status.Allocatable[v1.ResourceMemory]

// 	log.Printf("Allocatable CPU: %s", allocatableCPU.String())
// 	log.Printf("Allocatable Memory: %s", allocatableMemory.String())

// 	// Get all pods running on the node to calculate allocated resources
// 	pods, err := clientset.CoreV1().Pods("").List(contex.Background(), metav1.ListOptions{
// 		FieldSelector: fmt.Sprintf("spec.nodeName=%s", nodeName),
// 	})
// 	if err != nil {
// 		config.Log.Error("Error getting pods:", err)
// 		return false
// 	}

// 	// Initialize allocated CPU and memory to zero
// 	var allocatedCPU resource.Quantity
// 	var allocatedMemory resource.Quantity

// 	// Iterate over all pods to calculate allocated resources
// 	for _, pod := range pods.Items {
// 		for _, container := range pod.Spec.Containers {
// 			// Add up the requested CPU and memory for each container
// 			allocatedCPU.Add(container.Resources.Requests[v1.ResourceCPU])
// 			allocatedMemory.Add(container.Resources.Requests[v1.ResourceMemory])
// 		}
// 	}

// 	log.Printf("Allocated CPU: %s", allocatedCPU.String())
// 	log.Printf("Allocated Memory: %s", allocatedMemory.String())

// 	// Calculate available resources
// 	availableCPU := allocatableCPU.DeepCopy()
// 	availableCPU.Sub(allocatedCPU)

// 	availableMemory := allocatableMemory.DeepCopy()
// 	availableMemory.Sub(allocatedMemory)

// 	log.Printf("Available CPU: %s", availableCPU.String())
// 	log.Printf("Available Memory: %s", availableMemory.String())

// 	// Parse the requested resources from the map
// 	requestedCPU, err := resource.ParseQuantity(requests["cpu"])
// 	if err != nil {
// 		config.Log.Error("Error parsing requested CPU:", err)
// 		return false
// 	}

// 	requestedMemory, err := resource.ParseQuantity(requests["memory"])
// 	if err != nil {
// 		config.Log.Error("Error parsing requested memory:", err)
// 		return false
// 	}

// 	log.Printf("Requested CPU: %s", requestedCPU.String())
// 	log.Printf("Requested Memory: %s", requestedMemory.String())

// 	// Compare available resources with requested resources
// 	if availableCPU.Cmp(requestedCPU) < 0 {
// 		config.Log.Error("Insufficient CPU resources available")
// 		return false
// 	}

// 	if availableMemory.Cmp(requestedMemory) < 0 {
// 		config.Log.Error("Insufficient memory resources available")
// 		return false
// 	}

// 	config.Log.Error("Sufficient resources available")
// 	return true
// }

func HasSufficientResources(nodeName string, requests map[string]string) bool {
	// Get the clientset
	clientset, err := ClientSet()
	if err != nil {
		config.Log.Error("Error to make connection with cluster", err)
		return false
	}

	// Get the node object (allocatable resources)
	node, err := clientset.CoreV1().Nodes().Get(contex.Background(), nodeName, metav1.GetOptions{})
	if err != nil {
		config.Log.Error("Error getting node:", err)
		return false
	}

	// Get the node's allocatable resources
	allocatableCPU := node.Status.Allocatable[v1.ResourceCPU]
	allocatableMemory := node.Status.Allocatable[v1.ResourceMemory]
	allocatableGPU := node.Status.Allocatable[v1.ResourceName("nvidia.com/gpu")]

	log.Printf("Allocatable CPU: %s", allocatableCPU.String())
	log.Printf("Allocatable Memory: %s", allocatableMemory.String())
	log.Printf("Allocatable GPU: %s", allocatableGPU.String())

	// Get all pods running on the node to calculate allocated resources
	pods, err := clientset.CoreV1().Pods("").List(contex.Background(), metav1.ListOptions{
		FieldSelector: fmt.Sprintf("spec.nodeName=%s", nodeName),
	})
	if err != nil {
		config.Log.Error("Error getting pods:", err)
		return false
	}

	// Initialize allocated CPU, memory, and GPU to zero
	var allocatedCPU resource.Quantity
	var allocatedMemory resource.Quantity
	var allocatedGPU resource.Quantity

	// Iterate over all pods to calculate allocated resources
	for _, pod := range pods.Items {
		for _, container := range pod.Spec.Containers {
			// Add up the requested CPU, memory, and GPU for each container
			allocatedCPU.Add(container.Resources.Requests[v1.ResourceCPU])
			allocatedMemory.Add(container.Resources.Requests[v1.ResourceMemory])
			gpuRequest := container.Resources.Requests[v1.ResourceName("nvidia.com/gpu")]
			if gpuRequest != (resource.Quantity{}) {
				allocatedGPU.Add(gpuRequest)
			}
		}
	}

	log.Printf("Allocated CPU: %s", allocatedCPU.String())
	log.Printf("Allocated Memory: %s", allocatedMemory.String())
	log.Printf("Allocated GPU: %s", allocatedGPU.String())

	// Calculate available resources
	availableCPU := allocatableCPU.DeepCopy()
	availableCPU.Sub(allocatedCPU)

	availableMemory := allocatableMemory.DeepCopy()
	availableMemory.Sub(allocatedMemory)

	availableGPU := allocatableGPU.DeepCopy()
	availableGPU.Sub(allocatedGPU)

	log.Printf("Available CPU: %s", availableCPU.String())
	log.Printf("Available Memory: %s", availableMemory.String())
	log.Printf("Available GPU: %s", availableGPU.String())

	// Parse the requested resources from the map
	requestedCPU, err := resource.ParseQuantity(requests["cpu"])
	if err != nil {
		config.Log.Error("Error parsing requested CPU:", err)
		return false
	}

	requestedMemory, err := resource.ParseQuantity(requests["memory"])
	if err != nil {
		config.Log.Error("Error parsing requested memory:", err)
		return false
	}

	var requestedGPU resource.Quantity
	if requests["gpu"] != "" {
		requestedGPU, err = resource.ParseQuantity(requests["gpu"])
		if err != nil {
			config.Log.Error("Error parsing requested GPU:", err)
			return false
		}
	}

	log.Printf("Requested CPU: %s", requestedCPU.String())
	log.Printf("Requested Memory: %s", requestedMemory.String())
	if requests["gpu"] != "" {
		log.Printf("Requested GPU: %s", requestedGPU.String())
	}

	// Compare available resources with requested resources
	if availableCPU.Cmp(requestedCPU) < 0 {
		config.Log.Error("Insufficient CPU resources available")
		return false
	}

	if availableMemory.Cmp(requestedMemory) < 0 {
		config.Log.Error("Insufficient memory resources available")
		return false
	}

	if requests["gpu"] != "" && availableGPU.Cmp(requestedGPU) < 0 {
		config.Log.Error("Insufficient GPU resources available")
		return false
	}

	config.Log.Error("Sufficient resources available")
	return true
}

func HasSufficientInfraResources(path string, nodeName string, requests map[string]string) bool {
	// Get the clientset
	// clientset, err := ClientSet()
	// var config *rest.Config

	config1, err := clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		config.Log.Error("Error in building config from flag:", err.Error())
		return false
	}
	var clientset *kubernetes.Clientset
	clientset, err = kubernetes.NewForConfig(config1)

	if err != nil {
		config.Log.Error("Error getting clientset:", err)
		return false
	}

	// Get the node object (allocatable resources)
	node, err := clientset.CoreV1().Nodes().Get(contex.Background(), nodeName, metav1.GetOptions{})
	if err != nil {
		config.Log.Error("Error getting node:", err)
		return false
	}

	// Get the node's allocatable resources
	allocatableCPU := node.Status.Allocatable[v1.ResourceCPU]
	allocatableMemory := node.Status.Allocatable[v1.ResourceMemory]
	allocatableGPU := node.Status.Allocatable[v1.ResourceName("nvidia.com/gpu")]

	log.Printf("Allocatable CPU: %s", allocatableCPU.String())
	log.Printf("Allocatable Memory: %s", allocatableMemory.String())
	log.Printf("Allocatable GPU: %s", allocatableGPU.String())

	// Get all pods running on the node to calculate allocated resources
	pods, err := clientset.CoreV1().Pods("").List(contex.Background(), metav1.ListOptions{
		FieldSelector: fmt.Sprintf("spec.nodeName=%s", nodeName),
	})
	if err != nil {
		config.Log.Error("Error getting pods:", err)
		return false
	}

	// Initialize allocated CPU, memory, and GPU to zero
	var allocatedCPU resource.Quantity
	var allocatedMemory resource.Quantity
	var allocatedGPU resource.Quantity

	// Iterate over all pods to calculate allocated resources
	for _, pod := range pods.Items {
		for _, container := range pod.Spec.Containers {
			// Add up the requested CPU, memory, and GPU for each container
			allocatedCPU.Add(container.Resources.Requests[v1.ResourceCPU])
			allocatedMemory.Add(container.Resources.Requests[v1.ResourceMemory])
			gpuRequest := container.Resources.Requests[v1.ResourceName("nvidia.com/gpu")]
			if gpuRequest != (resource.Quantity{}) {
				allocatedGPU.Add(gpuRequest)
			}
		}
	}

	log.Printf("Allocated CPU: %s", allocatedCPU.String())
	log.Printf("Allocated Memory: %s", allocatedMemory.String())
	log.Printf("Allocated GPU: %s", allocatedGPU.String())

	// Calculate available resources
	availableCPU := allocatableCPU.DeepCopy()
	availableCPU.Sub(allocatedCPU)

	availableMemory := allocatableMemory.DeepCopy()
	availableMemory.Sub(allocatedMemory)

	availableGPU := allocatableGPU.DeepCopy()
	availableGPU.Sub(allocatedGPU)

	log.Printf("Available CPU: %s", availableCPU.String())
	log.Printf("Available Memory: %s", availableMemory.String())
	log.Printf("Available GPU: %s", availableGPU.String())

	// Parse the requested resources from the map
	requestedCPU, err := resource.ParseQuantity(requests["cpu"])
	if err != nil {
		config.Log.Error("Error parsing requested CPU:", err)
		return false
	}

	requestedMemory, err := resource.ParseQuantity(requests["memory"])
	if err != nil {
		config.Log.Error("Error parsing requested memory:", err)
		return false
	}

	var requestedGPU resource.Quantity
	if requests["gpu"] != "" {
		requestedGPU, err = resource.ParseQuantity(requests["gpu"])
		if err != nil {
			config.Log.Error("Error parsing requested GPU:", err)
			return false
		}
	}

	log.Printf("Requested CPU: %s", requestedCPU.String())
	log.Printf("Requested Memory: %s", requestedMemory.String())
	if requests["gpu"] != "" {
		log.Printf("Requested GPU: %s", requestedGPU.String())
	}

	// Compare available resources with requested resources
	if availableCPU.Cmp(requestedCPU) < 0 {
		config.Log.Error("Insufficient CPU resources available")
		return false
	}

	if availableMemory.Cmp(requestedMemory) < 0 {
		config.Log.Error("Insufficient memory resources available")
		return false
	}

	if requests["gpu"] != "" && availableGPU.Cmp(requestedGPU) < 0 {
		config.Log.Error("Insufficient GPU resources available")
		return false
	}

	config.Log.Debug("Sufficient resources available")
	return true
}

// Functionality to get the environment variables and annotations of a pod
func GetPodInfo(namespace, podNamePrefix string) (map[string]interface{}, error) {
	mapd := make(map[string]interface{})
	mapd["error"] = false
	clientSet, err := ClientSet()
	if err != nil {
		return nil, err
	}

	pods, err := clientSet.CoreV1().Pods(namespace).List(contex.Background(), metav1.ListOptions{})
	if err != nil {
		return nil, err
	}

	for _, pod := range pods.Items {
		if strings.Contains(pod.Name, podNamePrefix) {
			var jupyterhubApiToken string
			var username string

			// Get the environment variables of the pod
			for _, container := range pod.Spec.Containers {
				for _, env := range container.Env {
					if env.Name == "JUPYTERHUB_API_TOKEN" {
						jupyterhubApiToken = env.Value
					}
				}
			}

			// Get the annotations of the pod
			for key, value := range pod.Annotations {
				if key == "hub.jupyter.org/username" {
					username = value
				}
			}
			mapd["JUPYTERHUB_API_TOKEN"] = jupyterhubApiToken
			mapd["hub.jupyter.org/username"] = username

			// Return the environment variables and annotations
			return mapd, nil
		}
	}

	return nil, errors.New("pod not found")
}

func CheckPodStatus(namespace string, releaseName string) (bool, error) {
	clientSet, err := ClientSet()
	if err != nil {
		return false, err
	}
	pods, err := clientSet.CoreV1().Pods(namespace).List(contex.Background(), metav1.ListOptions{
		LabelSelector: "release=" + releaseName,
	})
	if err != nil {
		return false, err
	}

	allPodsRunning := true
	for _, pod := range pods.Items {
		if pod.Status.Phase != v1.PodRunning {
			allPodsRunning = false
			break
		}
	}
	if allPodsRunning {
		return true, nil
	}
	time.Sleep(300 * time.Second)
	return allPodsRunning, nil
}

func CheckModelPodStatus(path string, namespace string, releaseNames []string) (map[string]string, error) {
	config.Log.Debug("CheckModelPodStatus called with path:" + path)
	config.Log.Debug("and namespace:" + namespace)
	var config1 *rest.Config
	config1, err := clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		config.Log.Error("Error in building config from flag:", err.Error())
		return nil, err
	}
	var clientset *kubernetes.Clientset
	clientset, err = kubernetes.NewForConfig(config1)

	if err != nil {
		config.Log.Error("Error getting clientset:", err)
		return nil, err
	}

	pods, err := clientset.CoreV1().Pods(namespace).List(contex.Background(), metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Error getting pods:", err)
		return nil, fmt.Errorf("failed to get pods: %v", err)
	}

	if len(pods.Items) == 0 {
		config.Log.Error("No pods found")
		return nil, fmt.Errorf("no pods found")
	}

	config.Log.Debug("Pods found:", pods.Items)

	podStatus := make(map[string]string)
	for _, pod := range pods.Items {
		for _, releaseName := range releaseNames {
			if strings.Contains(pod.Name, releaseName) {
				config.Log.Debug("Pod found with release name:", pod.Name, releaseName)
				podStatus[pod.Name] = string(pod.Status.Phase)
			}
		}
	}

	if len(podStatus) == 0 {
		config.Log.Error("No pods found for deployments")
		return nil, fmt.Errorf("no pods found for deployments")
	}

	allPodsRunning := false
	for _, status := range podStatus {
		if status == string(v1.PodRunning) {
			allPodsRunning = true
			break
		}
	}

	if allPodsRunning {
		config.Log.Debug("All pods are running")
		return podStatus, nil
	}

	// time.Sleep(300 * time.Second)
	return podStatus, nil
}

func CheckModelPodStatusStaticKubeFiles(clientset *kubernetes.Clientset, path string, namespace string, releaseNames []string) (map[string]string, error) {
	config.Log.Debug("CheckModelPodStatus called with path:" + path)
	config.Log.Debug("and namespace:" + namespace)

	pods, err := clientset.CoreV1().Pods(namespace).List(contex.Background(), metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Error getting pods:", err)
		return nil, fmt.Errorf("failed to get pods: %v", err)
	}

	if len(pods.Items) == 0 {
		config.Log.Error("No pods found")
		return nil, fmt.Errorf("no pods found")
	}

	config.Log.Debug("Pods found:", pods.Items)

	podStatus := make(map[string]string)
	for _, pod := range pods.Items {
		for _, releaseName := range releaseNames {
			if strings.Contains(pod.Name, releaseName) {
				config.Log.Debug("Pod found with release name:", pod.Name, releaseName)
				podStatus[pod.Name] = string(pod.Status.Phase)
			}
		}
	}

	// if len(podStatus) == 0 {
	// 	config.Log.Error("No pods found for deployments")
	// 	return nil, fmt.Errorf("no pods found for deployments")
	// }

	allPodsRunning := false
	for _, status := range podStatus {
		if status == string(v1.PodRunning) {
			allPodsRunning = true
			break
		}
	}

	if allPodsRunning {
		config.Log.Debug("All pods are running")
		return podStatus, nil
	}

	// time.Sleep(300 * time.Second)
	return podStatus, nil
}

func CheckPlaygroundModelPodStatus(deploymentName string) (bool, error) {
	clientSet, err := ClientSet()
	if err != nil {
		return false, err
	}

	log.Println("check 1")

	for {
		deployment, err := clientSet.AppsV1().Deployments("playground").Get(contex.Background(), deploymentName, metav1.GetOptions{})
		if err != nil {
			if strings.Contains(err.Error(), "not found") {
				return true, nil
			}
			return false, err
		}

		log.Println("check 2")

		if deployment.Status.Replicas == 0 {
			pods, err := clientSet.CoreV1().Pods("playground").List(contex.Background(), metav1.ListOptions{
				LabelSelector: fmt.Sprintf("app=%s", deploymentName),
			})
			if err != nil {
				return false, err
			}

			if len(pods.Items) == 0 {
				return true, nil
			}

			pod := pods.Items[0]
			for _, containerStatus := range pod.Status.ContainerStatuses {
				if containerStatus.State.Terminated != nil && containerStatus.State.Terminated.Reason == "Completed" {
					return true, nil
				}
			}
		}

		log.Println("check 3")

		time.Sleep(5 * time.Second)
	}
}

// func contains(slice []string, item string) bool {
// 	return slices.Contains(slice, item)
// }

func CheckDeploymentStatus(namespace, deploymentName string) (bool, error) {
	clientSet, err := ClientSet()
	if err != nil {
		return false, fmt.Errorf("failed to create client set: %v", err)
	}

	deployment, err := clientSet.AppsV1().Deployments("playground").Get(contex.Background(), deploymentName, metav1.GetOptions{})
	if err != nil {
		return false, fmt.Errorf("failed to get deployment: %v", err)
	}

	replicas := deployment.Status.Replicas                   // Total replicas specified in the spec
	availableReplicas := deployment.Status.AvailableReplicas // Replicas that are available and running
	readyReplicas := deployment.Status.ReadyReplicas         // Replicas that are ready to serve traffic

	// If no replicas are defined, deployment is not running
	if replicas == 0 {
		fmt.Println("No replicas defined, deployment is not running")
		return false, nil
	}

	// Log warning if available replicas exceed desired replicas
	if availableReplicas > replicas {
		fmt.Printf("Warning: Available replicas (%d) exceed desired replicas (%d)\n", availableReplicas, replicas)
	}

	// Check if all expected replicas are available and ready
	if availableReplicas == replicas && readyReplicas == replicas {
		return true, nil
	}

	// If replicas are less or not all are ready, deployment is not in a running state
	return false, nil
}

func UpscaleDeployment(clientSet *kubernetes.Clientset, namespace string, deploymentName string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	var err error

	if clientSet == nil {
		clientSet, err = ClientSet()
		if err != nil {
			mapd["error"] = true
			mapd["message"] = err.Error()
			return mapd, 401
		}
	}

	// Get the deployment
	deployment, err := clientSet.AppsV1().Deployments("playground").Get(contex.Background(), deploymentName, metav1.GetOptions{})
	if err != nil {
		config.Log.Error("Error getting deployment:", err, deployment)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 404
	}

	var replicas int32 = 1
	// Update the replicas
	deployment.Spec.Replicas = &replicas

	// Update the deployment
	_, err = clientSet.AppsV1().Deployments("playground").Update(contex.Background(), deployment, metav1.UpdateOptions{})
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 500
	}

	mapd["message"] = "Deployment upscaled successfully"
	return mapd, 200
}

func DownscaleDeployment(clientSet *kubernetes.Clientset, deploymentName string) (map[string]interface{}, int) {
	result := map[string]interface{}{"error": true}
	var err error

	if clientSet == nil {
		clientSet, err = ClientSet()
		if err != nil {
			result["message"] = fmt.Sprintf("Failed to create client set: %v", err)
			return result, 401
		}
	}

	deployment, err := clientSet.AppsV1().Deployments("playground").Get(contex.Background(), deploymentName, metav1.GetOptions{})
	if err != nil {
		result["message"] = fmt.Sprintf("Failed to get deployment: %v", err)
		return result, 404
	}

	if deployment.Spec.Replicas == nil {
		result["message"] = "Deployment has no replicas"
		return result, 400
	}

	if *deployment.Spec.Replicas == 0 {
		result["error"] = false
		result["message"] = "Deployment is already at minimum replicas"
		return result, 200
	}

	zeroReplicas := int32(0)
	deployment.Spec.Replicas = &zeroReplicas

	_, err = clientSet.AppsV1().Deployments("playground").Update(contex.Background(), deployment, metav1.UpdateOptions{})
	if err != nil {
		result["message"] = fmt.Sprintf("Failed to update deployment: %v", err)
		return result, 500
	}

	result["error"] = false
	result["message"] = "Deployment downscaled successfully"
	return result, 200
}

// func clientSet() (*kubernetes.Clientset, error) {
// 	kubecfg := KubeConfig{
// 		CertAuthData:      *config.Conf.Kube.CertAuthData,
// 		KubeServer:        *config.Conf.Kube.KubeServer,
// 		ClientCertificate: *config.Conf.Kube.ClientCertificate,
// 		ClientKey:         *config.Conf.Kube.ClientKey,
// 	}

// 	config.Log.Error("Using Kubernetes API Server:", kubecfg.KubeServer)

// 	clientCertData, err := base64.StdEncoding.DecodeString(kubecfg.ClientCertificate)
// 	if err != nil {
// 		config.Log.Error("Failed to decode client certificate:", err)
// 		return nil, errors.New("invalid client certificate")
// 	}

// 	clientKeyData, err := base64.StdEncoding.DecodeString(kubecfg.ClientKey)
// 	if err != nil {
// 		config.Log.Error("Failed to decode client key:", err)
// 		return nil, errors.New("invalid client key")
// 	}

// 	kubeConfigGetter := func() (*clientcmdapi.Config, error) {
// 		defaultConfig := clientcmdapi.NewConfig()
// 		defaultConfig.Clusters["k"] = &clientcmdapi.Cluster{Server: kubecfg.KubeServer, InsecureSkipTLSVerify: true}
// 		defaultConfig.AuthInfos["k"] = &clientcmdapi.AuthInfo{
// 			ClientCertificateData: clientCertData,
// 			ClientKeyData:         clientKeyData,
// 		}
// 		defaultConfig.Contexts["k"] = &clientcmdapi.Context{Cluster: "k", AuthInfo: "k"}
// 		defaultConfig.CurrentContext = "k"
// 		return defaultConfig, nil
// 	}

// 	config, err := clientcmd.BuildConfigFromKubeconfigGetter("", kubeConfigGetter)
// 	if err != nil {
// 		config.Log.Error("Error creating kubeconfig:", err)
// 		return nil, errors.New("invalid Kubernetes configuration")
// 	}

// 	clientset, err := kubernetes.NewForConfig(config)
// 	if err != nil {
// 		config.Log.Error("Error creating Kubernetes clientset:", err)
// 		return nil, errors.New("could not create Kubernetes clientset")
// 	}

// 	config.Log.Error("Successfully created Kubernetes clientset")
// 	return clientset, nil
// }

func ClientSet() (*kubernetes.Clientset, error) {
	// First try to get config from environment variables
	if config.Conf.Kube.CertAuthData != nil &&
		config.Conf.Kube.KubeServer != nil &&
		config.Conf.Kube.ClientCertificate != nil &&
		config.Conf.Kube.ClientKey != nil {

		kubecfg := KubeConfig{
			CertAuthData:      *config.Conf.Kube.CertAuthData,
			KubeServer:        *config.Conf.Kube.KubeServer,
			ClientCertificate: *config.Conf.Kube.ClientCertificate,
			ClientKey:         *config.Conf.Kube.ClientKey,
		}

		config.Log.Debug("Using Kubernetes API Server from environment:", kubecfg.KubeServer)

		clientCertData, err := base64.StdEncoding.DecodeString(kubecfg.ClientCertificate)
		if err != nil {
			config.Log.Error("Failed to decode client certificate:", err)
			return nil, errors.New("invalid client certificate")
		}

		clientKeyData, err := base64.StdEncoding.DecodeString(kubecfg.ClientKey)
		if err != nil {
			config.Log.Error("Failed to decode client key:", err)
			return nil, errors.New("invalid client key")
		}

		kubeConfigGetter := func() (*clientcmdapi.Config, error) {
			defaultConfig := clientcmdapi.NewConfig()
			defaultConfig.Clusters["k"] = &clientcmdapi.Cluster{
				Server:                kubecfg.KubeServer,
				InsecureSkipTLSVerify: true,
			}
			defaultConfig.AuthInfos["k"] = &clientcmdapi.AuthInfo{
				ClientCertificateData: clientCertData,
				ClientKeyData:         clientKeyData,
			}
			defaultConfig.Contexts["k"] = &clientcmdapi.Context{
				Cluster:  "k",
				AuthInfo: "k",
			}
			defaultConfig.CurrentContext = "k"
			return defaultConfig, nil
		}

		config1, err := clientcmd.BuildConfigFromKubeconfigGetter("", kubeConfigGetter)
		if err != nil {
			config.Log.Error("Error creating kubeconfig:", err)
			return nil, errors.New("invalid Kubernetes configuration")
		}

		clientset, err := kubernetes.NewForConfig(config1)
		if err != nil {
			config.Log.Error("Error creating Kubernetes clientset:", err)
			return nil, errors.New("could not create Kubernetes clientset")
		}

		config.Log.Error("Successfully created Kubernetes clientset from environment config")
		return clientset, nil
	}

	// Fallback to in-cluster config
	config.Log.Error("Using in-cluster Kubernetes config")
	config1, err := rest.InClusterConfig()
	if err != nil {
		config.Log.Error("Error creating in-cluster config:", err)
		return nil, errors.New("could not create in-cluster config")
	}

	clientset, err := kubernetes.NewForConfig(config1)
	if err != nil {
		config.Log.Error("Error creating Kubernetes clientset:", err)
		return nil, errors.New("could not create Kubernetes clientset")
	}

	config.Log.Error("Successfully created Kubernetes clientset from in-cluster config")
	return clientset, nil
}

// func metricSet() (*versioned.Clientset, error) {

// 	kubecfg := KubeConfig{
// 		CertAuthData:      config.Conf.Kube.CertAuthData,
// 		KubeServer:        config.Conf.Kube.KubeServer,
// 		ClientCertificate: config.Conf.Kube.ClientCertificate,
// 		ClientKey:         config.Conf.Kube.ClientKey,
// 	}

// 	clientCertData, _ := base64.StdEncoding.DecodeString(kubecfg.ClientCertificate)
// 	clientKeyData, _ := base64.StdEncoding.DecodeString(kubecfg.ClientKey)

// 	kubeConfigGetter := func() (*clientcmdapi.Config, error) {
// 		defaultConfig := clientcmdapi.NewConfig()
// 		defaultConfig.Clusters["k"] = &clientcmdapi.Cluster{Server: kubecfg.KubeServer, InsecureSkipTLSVerify: true}
// 		defaultConfig.AuthInfos["k"] = &clientcmdapi.AuthInfo{
// 			ClientCertificateData: clientCertData,
// 			ClientKeyData:         clientKeyData}
// 		defaultConfig.Contexts["k"] = &clientcmdapi.Context{Cluster: "k", AuthInfo: "k"}
// 		defaultConfig.CurrentContext = "k"
// 		return defaultConfig, nil
// 	}

// 	// use the current context in kubeconfig
// 	config, err := clientcmd.BuildConfigFromKubeconfigGetter("", kubeConfigGetter)
// 	if err != nil {
// 		config.Log.Error("==", err)
// 		return nil, errors.New("PleasePassValidConfig")
// 	}
// 	// create the clientset
// 	clientset, err := versioned.NewForConfig(config)
// 	if err != nil {
// 		config.Log.Error("=-=-", err)
// 		return nil, errors.New("PleasePassValidConfig")
// 	}

// 	return clientset, err
// }

// clientSet function used to set kube config using a service account token
// func clientSet() (*kubernetes.Clientset, error) {
// 	kubecfg := KubeConfig{
// 		CertAuthData: config.Conf.Kube.CertAuthData, // Cert data for CA verification (not used for auth)
// 		KubeServer:   config.Conf.Kube.KubeServer,   // Kubernetes API server
// 		Token:        config.Conf.Kube.Token,        // Service account token for authentication
// 	}
// 	CertAuthData, _ := base64.StdEncoding.DecodeString(kubecfg.CertAuthData)
// 	// Kube config getter to build config from the token
// 	kubeConfigGetter := func() (*clientcmdapi.Config, error) {
// 		defaultConfig := clientcmdapi.NewConfig()

// 		// Adding cluster information (insecure skip TLS verification as example)
// 		defaultConfig.Clusters["k"] = &clientcmdapi.Cluster{
// 			Server:                   kubecfg.KubeServer,
// 			CertificateAuthorityData: CertAuthData,
// 		}

// 		// Using the token for authentication
// 		defaultConfig.AuthInfos["k"] = &clientcmdapi.AuthInfo{
// 			Token: kubecfg.Token, // Set the token here
// 		}

// 		// Adding context information
// 		defaultConfig.Contexts["k"] = &clientcmdapi.Context{
// 			Cluster:  "k",
// 			AuthInfo: "k",
// 		}

// 		defaultConfig.CurrentContext = "k"
// 		return defaultConfig, nil
// 	}

// 	// Use the kubeConfigGetter function to build the config
// 	config, err := clientcmd.BuildConfigFromKubeconfigGetter("", kubeConfigGetter)
// 	if err != nil {
// 		config.Log.Error("Error building kube config:", err)
// 		return nil, errors.New("PleasePassValidConfig")
// 	}

// 	// Create the clientset with the built config
// 	clientset, err := kubernetes.NewForConfig(config)
// 	if err != nil {
// 		config.Log.Error("Error creating Kubernetes clientset:", err)
// 		return nil, errors.New("PleasePassValidConfig")
// 	}

// 	return clientset, err
// }

// ClientSetFromVault creates a Kubernetes clientset using kubeconfig from Vault or local file in test mode
func ClientSetFromVault(clusterName, workspace, email string) (*kubernetes.Clientset, *rest.Config, error) {
	var fileBytes []byte
	var err error

	// Check if we're in test mode
	if os.Getenv("test") == "true" {
		// Read kubeconfig from local file
		path := "data/kubeconfig/azure_kubeconfig.yaml"
		fileBytes, err = os.ReadFile(path)
		if err != nil {
			config.Log.Error("Failed to read local kubeconfig file:", err)
			return nil, nil, errors.New("failed to read local kubeconfig file")
		}
		config.Log.Debug("Using local kubeconfig file for testing")
	} else {
		// Get kubeconfig from Vault
		mapd, code := integrations.GetFile(clusterName, workspace, email)
		if code != 200 {
			config.Log.Error("Failed to get kubeconfig from Vault")
			return nil, nil, errors.New("failed to get kubeconfig from Vault")
		}

		var ok bool
		fileBytes, ok = mapd["file"].([]byte)
		if !ok {
			config.Log.Error("Invalid kubeconfig format from Vault")
			return nil, nil, errors.New("invalid kubeconfig format from Vault")
		}
		config.Log.Debug("Using kubeconfig from Vault")
	}

	// Create temporary file for kubeconfig
	if err := os.MkdirAll(".azure", 0777); err != nil {
		config.Log.Error("Failed to create directory:", err)
		return nil, nil, err
	}

	path := "/app/data/.azure/config"
	f, err := os.Create(path)
	if err != nil {
		config.Log.Error("Failed to create kubeconfig file:", err)
		return nil, nil, err
	}
	defer f.Close()

	// Write kubeconfig to file
	_, err = f.Write(fileBytes)
	if err != nil {
		config.Log.Error("Failed to write kubeconfig:", err)
		return nil, nil, err
	}

	// Build config from the kubeconfig file
	config1, err := clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		config.Log.Error("Failed to build config from kubeconfig:", err)
		return nil, nil, err
	}

	// Create Kubernetes clientset
	clientset, err := kubernetes.NewForConfig(config1)
	if err != nil {
		config.Log.Error("Failed to create Kubernetes clientset:", err)
		return nil, nil, err
	}

	// Clean up the temporary file
	defer os.Remove(path)

	config.Log.Debug("Successfully created Kubernetes clientset")
	return clientset, config1, nil
}

// GetNodesWithClient gets cluster nodes information using an existing clientset
func GetNodesWithClient(clientset *kubernetes.Clientset, namespace string) ([]map[string]interface{}, error) {
	nodes, err := clientset.CoreV1().Nodes().List(context.Background(), metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Failed to get nodes:", err)
		return nil, err
	}

	var nodeList []map[string]interface{}
	var totalCPU resource.Quantity
	var totalMemory resource.Quantity
	var totalGPU resource.Quantity

	for _, node := range nodes.Items {
		// Extract CPU, memory, and GPU resources
		cpu := node.Status.Capacity.Cpu()
		memory := node.Status.Capacity.Memory()
		gpu, hasGPU := node.Status.Capacity["nvidia.com/gpu"]

		// Add to total resources
		if cpu != nil {
			totalCPU.Add(*cpu)
		}
		if memory != nil {
			totalMemory.Add(*memory)
		}
		if hasGPU {
			totalGPU.Add(gpu)
		}

		// Get node labels for GPU type
		gpuType := "N/A"
		if val, exists := node.Labels["nvidia.com/gpu.product"]; exists {
			gpuType = val
		}

		// Get CPU model and architecture
		cpuModel := "N/A"
		if val, exists := node.Labels["beta.kubernetes.io/instance-type"]; exists {
			cpuModel = val
		}

		// Get memory type if available
		memoryType := "N/A"
		if val, exists := node.Labels["node.kubernetes.io/memory-type"]; exists {
			memoryType = val
		}

		nodeInfo := map[string]interface{}{
			"name": node.Name,
			"CPU": map[string]interface{}{
				"Capacity":        cpu.String(),
				"Model":           cpuModel,
				"Architecture":    node.Status.NodeInfo.Architecture,
				"OperatingSystem": node.Status.NodeInfo.OperatingSystem,
			},
			"Memory": map[string]interface{}{
				"Capacity": memory.String(),
				"Type":     memoryType,
			},
			"GPU": map[string]interface{}{
				"Capacity": func() string {
					if hasGPU {
						return gpu.String()
					}
					return "0"
				}(),
				"Type": gpuType,
			},
			"Labels": node.Labels,
			"Conditions": func() []map[string]interface{} {
				var conditions []map[string]interface{}
				for _, condition := range node.Status.Conditions {
					conditions = append(conditions, map[string]interface{}{
						"Type":    condition.Type,
						"Status":  condition.Status,
						"Message": condition.Message,
					})
				}
				return conditions
			}(),
		}
		nodeList = append(nodeList, nodeInfo)
	}

	// Add cluster-wide resource summary
	clusterSummary := map[string]interface{}{
		"total_nodes": len(nodes.Items),
		"total_resources": map[string]interface{}{
			"CPU": map[string]interface{}{
				"Total": totalCPU.String(),
				"PerNode": func() string {
					if len(nodes.Items) > 0 {
						perNode := totalCPU.DeepCopy()
						perNode.SetMilli(totalCPU.MilliValue() / int64(len(nodes.Items)))
						return perNode.String()
					}
					return "0"
				}(),
			},
			"Memory": map[string]interface{}{
				"Total": totalMemory.String(),
				"PerNode": func() string {
					if len(nodes.Items) > 0 {
						perNode := totalMemory.DeepCopy()
						perNode.SetMilli(totalMemory.MilliValue() / int64(len(nodes.Items)))
						return perNode.String()
					}
					return "0"
				}(),
			},
			"GPU": map[string]interface{}{
				"Total": totalGPU.String(),
				"PerNode": func() string {
					if len(nodes.Items) > 0 {
						perNode := totalGPU.DeepCopy()
						perNode.SetMilli(totalGPU.MilliValue() / int64(len(nodes.Items)))
						return perNode.String()
					}
					return "0"
				}(),
			},
		},
	}

	// Add cluster summary to the first node's info
	if len(nodeList) > 0 {
		nodeList[0]["cluster_summary"] = clusterSummary
	}

	pretty.Println("nodelist", nodeList)
	return nodeList, nil
}

// GetDeploymentsWithClient gets active deployments using an existing clientset
func GetDeploymentsWithClient(clientset *kubernetes.Clientset, namespace string) ([]map[string]interface{}, error) {
	deployments, err := clientset.AppsV1().Deployments(namespace).List(context.Background(), metav1.ListOptions{})
	if err != nil {
		config.Log.Error("Failed to get deployments:", err)
		return nil, err
	}

	var deploymentList []map[string]interface{}
	for _, deployment := range deployments.Items {
		// Extract resource requests and limits
		resources := make(map[string]interface{})
		if len(deployment.Spec.Template.Spec.Containers) > 0 {
			container := deployment.Spec.Template.Spec.Containers[0]
			requests := make(map[string]string)
			limits := make(map[string]string)

			if container.Resources.Requests != nil {
				if cpu := container.Resources.Requests.Cpu(); cpu != nil {
					requests["cpu"] = cpu.String()
				}
				if memory := container.Resources.Requests.Memory(); memory != nil {
					requests["memory"] = memory.String()
				}
				if gpu, exists := container.Resources.Requests["nvidia.com/gpu"]; exists {
					requests["gpu"] = gpu.String()
				}
			}

			if container.Resources.Limits != nil {
				if cpu := container.Resources.Limits.Cpu(); cpu != nil {
					limits["cpu"] = cpu.String()
				}
				if memory := container.Resources.Limits.Memory(); memory != nil {
					limits["memory"] = memory.String()
				}
				if gpu, exists := container.Resources.Limits["nvidia.com/gpu"]; exists {
					limits["gpu"] = gpu.String()
				}
			}

			resources["requests"] = requests
			resources["limits"] = limits
		}

		deploymentInfo := map[string]interface{}{
			"name":      deployment.Name,
			"namespace": deployment.Namespace,
			"replicas":  deployment.Status.Replicas,
			"ready":     deployment.Status.ReadyReplicas,
			"resources": resources,
		}
		deploymentList = append(deploymentList, deploymentInfo)
	}

	return deploymentList, nil
}

func GetIngressInfo(nameSpace, clusterName, workspace, email, releaseName string) (string, error) {
	_, path, _, err := SetInfraConfig(nameSpace, clusterName, workspace, email)
	if err != nil {
		config.Log.Error(err)
		return "", err
	}

	var config *rest.Config
	config, err = clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		return "", err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "", err
	}

	ctx := context.Background()
	ingresses, err := clientset.NetworkingV1().Ingresses(nameSpace).List(ctx, metav1.ListOptions{
		LabelSelector: "app.kubernetes.io/instance=" + releaseName,
	})
	if err != nil {
		return "", err
	}

	if len(ingresses.Items) > 0 && len(ingresses.Items[0].Spec.Rules) > 0 {
		host := ingresses.Items[0].Spec.Rules[0].Host
		return "https://" + host + "/v1", nil
	}

	return "", fmt.Errorf("no ingress found for release %s", releaseName)
}

func GetDeploymentName(nameSpace, clusterName, workspace, email, releaseName string) (string, error) {
	_, path, _, err := SetInfraConfig(nameSpace, clusterName, workspace, email)
	if err != nil {
		config.Log.Error(err)
		return "", err
	}

	var config *rest.Config
	config, err = clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		return "", err
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return "", err
	}

	ctx := context.Background()
	deployments, err := clientset.AppsV1().Deployments(nameSpace).List(ctx, metav1.ListOptions{
		LabelSelector: "app.kubernetes.io/instance=" + releaseName,
	})
	if err != nil {
		return "", err
	}

	if len(deployments.Items) > 0 {
		return deployments.Items[0].Name, nil
	}

	return "", fmt.Errorf("no deployment found for release %s", releaseName)
}
