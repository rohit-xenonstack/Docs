package kubernetes

import "testing"

func TestCreateNamespace(t *testing.T) {

	//create namespace
	mapd, code := CreateNamespace("icp_test_xenon")
	if code != 200 {
		t.Error("test case fail", mapd)
	}

	// namespace Already exist
	mapd, code = CreateNamespace("icp_test_xenon")
	if code != 500 {
		t.Error("test case fail", mapd)
	}

	//wrong namespace pass
	mapd, code = CreateNamespace("icp_test-xenon")
	if code != 500 {
		t.Error("test case fail", mapd)
	}
}

func TestDeleteNamespace(t *testing.T) {

	//delete namespace
	mapd, code := DeleteNamespace("icp_test_xenon")
	if code != 200 {
		t.Error("test case fail", mapd)
	}

	// namespace Already delete
	mapd, code = DeleteNamespace("icp_test_xenon")
	if code != 500 {
		t.Error("test case fail", mapd)
	}

	//wrong namespace pass
	mapd, code = DeleteNamespace("icp_test-xenon")
	if code != 500 {
		t.Error("test case fail", mapd)
	}
}
