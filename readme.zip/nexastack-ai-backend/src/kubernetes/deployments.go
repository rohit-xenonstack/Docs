package kubernetes

import (
	"context"
	"fmt"
	"os"

	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/kubernetes"
	"k8s.io/client-go/tools/clientcmd"
)

// GetDeployments returns a list of active deployments in the specified namespace
func GetDeployments(namespace, clusterName, workspace, email string) ([]map[string]interface{}, error) {
	// Get kubeconfig from vault
	_, path, _, err := SetInfraConfig(namespace, clusterName, workspace, email)
	if err != nil {
		return nil, fmt.Errorf("failed to get kubeconfig: %v", err)
	}
	defer os.Remove(path)

	// Create kubernetes client
	config, err := clientcmd.BuildConfigFromFlags("", path)
	if err != nil {
		return nil, fmt.Errorf("failed to build config: %v", err)
	}

	clientset, err := kubernetes.NewForConfig(config)
	if err != nil {
		return nil, fmt.Errorf("failed to create kubernetes client: %v", err)
	}

	deployments, err := clientset.AppsV1().Deployments(namespace).List(context.Background(), metav1.ListOptions{})
	if err != nil {
		return nil, fmt.Errorf("failed to list deployments: %v", err)
	}

	var result []map[string]interface{}
	for _, deployment := range deployments.Items {
		deploymentInfo := map[string]interface{}{
			"name":               deployment.Name,
			"namespace":          deployment.Namespace,
			"replicas":           deployment.Status.Replicas,
			"available_replicas": deployment.Status.AvailableReplicas,
			"ready_replicas":     deployment.Status.ReadyReplicas,
			"updated_replicas":   deployment.Status.UpdatedReplicas,
			"conditions":         deployment.Status.Conditions,
		}

		// Add resource requests and limits if available
		if len(deployment.Spec.Template.Spec.Containers) > 0 {
			container := deployment.Spec.Template.Spec.Containers[0]
			resources := map[string]interface{}{
				"requests": map[string]string{},
				"limits":   map[string]string{},
			}

			if container.Resources.Requests != nil {
				if cpu, ok := container.Resources.Requests["cpu"]; ok {
					resources["requests"].(map[string]string)["cpu"] = cpu.String()
				}
				if memory, ok := container.Resources.Requests["memory"]; ok {
					resources["requests"].(map[string]string)["memory"] = memory.String()
				}
			}

			if container.Resources.Limits != nil {
				if cpu, ok := container.Resources.Limits["cpu"]; ok {
					resources["limits"].(map[string]string)["cpu"] = cpu.String()
				}
				if memory, ok := container.Resources.Limits["memory"]; ok {
					resources["limits"].(map[string]string)["memory"] = memory.String()
				}
				if gpu, ok := container.Resources.Limits["nvidia.com/gpu"]; ok {
					resources["limits"].(map[string]string)["gpu"] = gpu.String()
				}
			}

			deploymentInfo["resources"] = resources
		}

		result = append(result, deploymentInfo)
	}

	return result, nil
}
