package kubernetes

import (
	contex "context"

	"git.xenonstack.com/nexa-platform/accounts/config"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
)

// Healthz function used for check heathz
func Healthz() error {
	mapd := make(map[string]interface{})

	clientSet, err := ClientSet()
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return err
	}
	ctx := contex.Background()
	opts := metav1.ListOptions{}
	_, err = clientSet.CoreV1().Namespaces().List(ctx, opts)
	if err != nil {
		config.Log.Error(err)
		return err
	}
	return nil
}
