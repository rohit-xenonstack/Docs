package marketplace

import (
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"helm.sh/helm/v3/pkg/action"
)

func UninstallModel(namespace, releaseName, clusterName, workspace, email string) (map[string]interface{}, int) {

	mapd := make(map[string]interface{})
	mapd["error"] = false

	// set kube-config and generate actionConfiguration
	actionConfig, _, code, err := kubernetes.SetInfraConfig(namespace, clusterName, workspace, email)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, code
	}

	// Set Uninstall release on server
	icli := action.NewUninstall(actionConfig)
	_, err = icli.Run(releaseName)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, 404
	}

	mapd["error"] = false
	mapd["message"] = "Release Uninstalled Successfully"
	mapd["helm_chart_delete"] = true
	return mapd, 200
}
