package marketplace

import (
	// "bytes"
	"bufio"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"

	// "io"
	"net/http"
	"strings"

	contex "context"

	// "git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"github.com/gin-gonic/gin"
	"github.com/minio/minio-go/v7"
	"github.com/minio/minio-go/v7/pkg/credentials"
)

func CheckModelExists(hfName string) (bool, error) {
	// Replace / characters with %2F
	escapedHfName := strings.Replace(hfName, "/", "%2F", -1)

	// Use the escaped hfName in the URL
	resp, err := http.Get("https://huggingface.co/api/models/" + escapedHfName)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()

	if resp.StatusCode == 200 {
		return true, nil
	} else {
		return false, nil
	}
}

// var (
//
//	minioBucket    = config.Conf.ModelDownload.MinioBucket
//	minioEndpoint  = config.Conf.ModelDownload.MinioEndpoint
//	minioAccessKey = config.Conf.ModelDownload.MinioAccessKey
//	minioSecretKey = config.Conf.ModelDownload.MinioSecretKey
//
// )
// DOWNLOAD_MINIO_BUCKET="playground"
// DOWNLOAD_MINIO_ACCESS_KEY="admin"
// DOWNLOAD_MINIO_SECRET_KEY="3MAulYluIJ"
// DOWNLOAD_MINIO_ENDPOINT="10.0.0.55:32177"
var (
	minioBucket    = ""
	minioEndpoint  = ""
	minioAccessKey = ""
	minioSecretKey = ""
)

// func DownloadModelMinio(modelRepoName, modelName string) (string, error) {
// 	ctx := contex.Background()

// 	// Check if git-lfs is installed
// 	cmd := exec.Command("git", "lfs", "install")
// 	output, err := cmd.CombinedOutput()
// 	if err != nil {
// 		fmt.Println("Error installing git-lfs:")
// 		fmt.Println(string(output))
// 		// If git-lfs is not installed, install it
// 		fmt.Println("Installing git-lfs...")
// 		cmd = exec.Command("curl", "-s", "https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh", "|", "bash")
// 		output, err = cmd.CombinedOutput()
// 		if err != nil {
// 			return "", fmt.Errorf("failed to install git-lfs: %w", err)
// 		}
// 		fmt.Println("Output of git-lfs installation:")
// 		fmt.Println(string(output))
// 		fmt.Println("git-lfs installed successfully!")
// 	}

// 	fmt.Printf("==bucket:%s\n ==endpoint:%s\n ==AccessKey:%s\n ==SecretKey:%s\n", minioBucket, minioEndpoint, minioAccessKey, minioSecretKey)

// 	// Create MinIO client
// 	minioClient, err := minio.New(minioEndpoint, &minio.Options{
// 		Creds:  credentials.NewStaticV4(minioAccessKey, minioSecretKey, ""),
// 		Secure: false,
// 	})
// 	if err != nil {
// 		return "", fmt.Errorf("failed to create MinIO client: %w", err)
// 	}

// 	// Check and create bucket if it does not exist
// 	exists, err := minioClient.BucketExists(ctx, minioBucket)
// 	if err != nil {
// 		return "", fmt.Errorf("failed to check MinIO bucket existence: %w", err)
// 	}
// 	if !exists {
// 		if err = minioClient.MakeBucket(ctx, minioBucket, minio.MakeBucketOptions{}); err != nil {
// 			return "", fmt.Errorf("failed to create MinIO bucket: %w", err)
// 		}
// 	}

// 	// Clone Hugging Face model repo
// 	repoURL := fmt.Sprintf("https://huggingface.co/%s", modelRepoName)
// 	if err := os.MkdirAll("data/", 0600); err != nil {
// 		return "", err
// 	}
// 	clonePath := "data/" + modelName
// 	cmd = exec.Command("git", "clone", "--depth=1", repoURL, clonePath)
// 	var stderr bytes.Buffer
// 	cmd.Stderr = &stderr

// 	fmt.Println("Cloning Hugging Face model repository...")
// 	if err := cmd.Run(); err != nil {
// 		return "", fmt.Errorf("failed to clone repo: %s", stderr.String())
// 	}

// 	// Upload cloned folder to MinIO
// 	zipPath := fmt.Sprintf("data/%s.zip", modelName)
// 	cmd = exec.Command("zip", "-r", zipPath, clonePath)
// 	if err := cmd.Run(); err != nil {
// 		return "", fmt.Errorf("failed to zip repo: %w", err)
// 	}

// 	// Delete the cloned folder
// 	if err := os.RemoveAll(clonePath); err != nil {
// 		return "", fmt.Errorf("failed to delete cloned folder: %w", err)
// 	}

// 	file, err := os.Open(zipPath)
// 	if err != nil {
// 		return "", fmt.Errorf("failed to open zip file: %w", err)
// 	}
// 	defer file.Close()

// 	fileStat, err := file.Stat()
// 	if err != nil {
// 		return "", fmt.Errorf("failed to get file stat: %w", err)
// 	}

// 	uploadPath := modelName + ".zip"

// 	_, err = minioClient.PutObject(ctx, minioBucket, uploadPath, file, fileStat.Size(), minio.PutObjectOptions{})
// 	if err != nil {
// 		return "", fmt.Errorf("failed to upload model repo to MinIO: %w", err)
// 	}

// 	// Delete the zip file
// 	if err := os.Remove(zipPath); err != nil {
// 		return "", fmt.Errorf("failed to delete zip file: %w", err)
// 	}

// 	return fmt.Sprintf("%s/%s", minioBucket, uploadPath), nil
// }

func DownloadModelMinio(modelRepoName, modelName string) (string, error) {
	ctx := contex.Background()

	// Check if git-lfs is installed
	cmd := exec.Command("git", "lfs", "install")
	output, err := cmd.CombinedOutput()
	if err != nil {
		fmt.Println("Error installing git-lfs:")
		fmt.Println(string(output))
		// If git-lfs is not installed, install it
		fmt.Println("Installing git-lfs...")
		cmd = exec.Command("curl", "-s", "https://packagecloud.io/install/repositories/github/git-lfs/script.deb.sh", "|", "bash")
		output, err = cmd.CombinedOutput()
		if err != nil {
			return "", fmt.Errorf("failed to install git-lfs: %w", err)
		}
		fmt.Println("Output of git-lfs installation:")
		fmt.Println(string(output))
		fmt.Println("git-lfs installed successfully!")
	}

	fmt.Printf("==bucket:%s\n ==endpoint:%s\n ==AccessKey:%s\n ==SecretKey:%s\n", minioBucket, minioEndpoint, minioAccessKey, minioSecretKey)

	// Create MinIO client
	minioClient, err := minio.New(minioEndpoint, &minio.Options{
		Creds:  credentials.NewStaticV4(minioAccessKey, minioSecretKey, ""),
		Secure: false,
	})
	if err != nil {
		return "", fmt.Errorf("failed to create MinIO client: %w", err)
	}

	// Check and create bucket if it does not exist
	exists, err := minioClient.BucketExists(ctx, minioBucket)
	if err != nil {
		return "", fmt.Errorf("failed to check MinIO bucket existence: %w", err)
	}
	if !exists {
		if err = minioClient.MakeBucket(ctx, minioBucket, minio.MakeBucketOptions{}); err != nil {
			return "", fmt.Errorf("failed to create MinIO bucket: %w", err)
		}
	}

	// Clone Hugging Face model repo
	repoURL := fmt.Sprintf("https://huggingface.co/%s", modelRepoName)
	if err := os.MkdirAll("data/", 0600); err != nil {
		return "", err
	}
	clonePath := "data/" + modelName
	cmd = exec.Command("git", "clone", "--progress", "--depth=1", repoURL, clonePath)
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return "", fmt.Errorf("failed to get stderr pipe: %w", err)
	}
	defer stderr.Close()

	fmt.Println("Cloning Hugging Face model repository...")
	if err := cmd.Start(); err != nil {
		return "", fmt.Errorf("failed to start git clone command: %w", err)
	}

	// Process stderr output to extract progress
	scanner := bufio.NewScanner(stderr)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "Receiving objects") {
			// Extract progress from line
			words := strings.Split(line, " ")
			if len(words) > 3 {
				percent := words[3]
				fmt.Printf("\rCloning progress: %s", percent)
			}
		}
	}

	if err := cmd.Wait(); err != nil {
		return "", fmt.Errorf("failed to clone repo: %w", err)
	}

	// Upload cloned folder to MinIO
	zipPath := fmt.Sprintf("data/%s.zip", modelName)
	cmd = exec.Command("zip", "-r", zipPath, clonePath)
	stderr, err = cmd.StderrPipe()
	if err != nil {
		return "", fmt.Errorf("failed to get stderr pipe: %w", err)
	}
	defer stderr.Close()

	fmt.Println("Zipping model repository...")
	if err := cmd.Start(); err != nil {
		return "", fmt.Errorf("failed to start zip command: %w", err)
	}

	// Process stderr output to extract progress
	scanner = bufio.NewScanner(stderr)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "adding") {
			// Extract progress from line
			words := strings.Split(line, " ")
			if len(words) > 2 {
				fileName := words[1]
				fmt.Printf("\rZipping progress: %s", fileName)
			}
		}
	}

	if err := cmd.Wait(); err != nil {
		return "", fmt.Errorf("failed to zip repo: %w", err)
	}

	// Delete the cloned folder
	if err := os.RemoveAll(clonePath); err != nil {
		return "", fmt.Errorf("failed to delete cloned folder: %w", err)
	}

	file, err := os.Open(zipPath)
	if err != nil {
		return "", fmt.Errorf("failed to open zip file: %w", err)
	}
	defer file.Close()

	fileStat, err := file.Stat()
	if err != nil {
		return "", fmt.Errorf("failed to get file stat: %w", err)
	}

	uploadPath := modelName + ".zip"

	// Upload zip file to MinIO
	_, err = minioClient.PutObject(ctx, minioBucket, uploadPath, file, fileStat.Size(), minio.PutObjectOptions{})
	if err != nil {
		return "", fmt.Errorf("failed to upload model repo to MinIO: %w", err)
	}

	// Delete the zip file
	if err := os.Remove(zipPath); err != nil {
		return "", fmt.Errorf("failed to delete zip file: %w", err)
	}

	return fmt.Sprintf("%s/%s", minioBucket, uploadPath), nil
}

func UpdateModelStatus(modelName string, status string) error {
	// Update the status of the model in the database
	db := config.DB
	db.Model(&database.Model{}).Where("model_name = ?", modelName).Update("status", status)
	return nil
}

func UpdateModelPath(modelName string, modelPath string) error {
	// Update the model path in the database
	db := config.DB
	db.Model(&database.Model{}).Where("model_name = ?", modelName).Update("model_path", modelPath)
	return nil
}

func GetModelStatus(modelName string) (string, error) {
	// Fetch the status of the model from the database
	var model database.Model
	db := config.DB
	db.Debug().Where("model_name = ?", modelName).First(&model)
	return model.Status, nil
}

func GetModelPath(modelName string) (string, error) {
	// Fetch the model path from the database
	var model database.Model
	db := config.DB
	db.Debug().Where("model_name = ?", modelName).First(&model)
	return model.ModelPath, nil
}

func DeleteModel(modelName string) error {
	// Delete the model from the database
	db := config.DB
	db.Where("model_name = ?", modelName).Delete(&database.Model{})
	return nil
}

func InsertModel(modelName string, hfModelName string, status string) error {
	// Insert the model into the database
	db := config.DB
	db.Create(&database.Model{
		ModelName:   modelName,
		HFModelName: hfModelName,
		Status:      status,
	})
	return nil
}

func DownloadYAML(c *gin.Context) {
	filename := c.Param("filename") // Get the filename from the URL parameter

	// Validate the filename to prevent directory traversal attacks
	if strings.Contains(filename, "..") || strings.Contains(filename, "/") || strings.Contains(filename, "\\") {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": "Invalid filename"})
		return
	}

	// Only allow .yaml and .yml extensions
	if !strings.HasSuffix(filename, ".yaml") && !strings.HasSuffix(filename, ".yml") {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": "Only YAML files are allowed"})
		return
	}

	cwd, err := os.Getwd()
	if err != nil {
		log.Printf("Error getting current working directory: %v", err)
	} else {
		log.Printf("Current working directory: %s", cwd)
	}

	// Construct the full path to the YAML file within the nexastack-ai-backend/templates directory
	templatesDir := "templates"
	filePath := filepath.Join(templatesDir, filename)

	// Verify file exists before attempting to serve it
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		c.AbortWithStatusJSON(http.StatusNotFound, gin.H{"error": "File not found"})
		return
	}

	// Set the Content-Disposition header to force a download with the specified filename
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=%s", filename))

	// Set the Content-Type header based on the file type
	c.Header("Content-Type", "application/x-yaml")

	// Serve the file
	c.File(filePath)
}
