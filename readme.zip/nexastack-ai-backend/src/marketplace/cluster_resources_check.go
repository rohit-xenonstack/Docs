package marketplace

import (
	"context"
	"fmt"
	"os"

	"k8s.io/client-go/kubernetes"

	"k8s.io/metrics/pkg/apis/metrics/v1beta1"
	metricsv "k8s.io/metrics/pkg/client/clientset/versioned"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/models"
	kube "git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"github.com/kr/pretty"
	v1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/rest"
	"k8s.io/client-go/tools/clientcmd"
)

// Function to find the best cluster for deployment
func FindBestCluster(workspace, namespace, email, hfModelName string) ([]models.BestClusters, error) {
	// Connect to database
	db := config.DB

	// Fetch all clusters from the database
	var clusters []database.InfraIntegration
	err := db.Debug().Model(&database.InfraIntegration{}).Where("workspace = ?", workspace).Find(&clusters).Error
	if err != nil {
		return nil, err
	}

	var bestClusters []models.BestClusters

	if hfModelName == "" {
		for _, clust := range clusters {
			bestClusters = append(bestClusters, models.BestClusters{
				ClusterName:           clust.ClusterName,
				IsSuffiecientResource: true,
			})
		}
		return bestClusters, nil
	}

	var modelResource database.ModelMarketplace
	err = config.DefaultDb.Debug().Model(&database.ModelMarketplace{}).Where("hf_model_name = ?", hfModelName).Find(&modelResource).Error
	if err != nil {
		return nil, err
	}

	// Pass default values
	// defaultValues := map[string]map[string]interface{}{
	// 	"cpu": {
	// 		"limit":   "6", // 150m -> 0.15
	// 		"request": "2", // 100m -> 0.1
	// 	},
	// 	"memory": {
	// 		"limit":   "12Gi", // 192Mi -> 0.1875G
	// 		"request": "3Gi",  // 128Mi -> 0.125G
	// 	},
	// 	"gpu": {
	// 		"limit":   "1",
	// 		"request": "1",
	// 	},
	// }

	defaultValues := map[string]map[string]interface{}{
		"cpu": {
			"limit":   modelResource.CPULimit,   // 150m -> 0.15
			"request": modelResource.CPURequest, // 100m -> 0.1
		},
		"memory": {
			"limit":   modelResource.MemoryLimit,   // 192Mi -> 0.1875G
			"request": modelResource.MemoryRequest, // 128Mi -> 0.125G
		},
		"gpu": {
			"limit":   modelResource.GPULimit,
			"request": modelResource.GPURequest,
		},
	}
	// Initialize best cluster list
	// var bestClusters []string
	// Iterate over each cluster
	for _, cluster := range clusters {
		// Get the cluster name
		clusterName := cluster.ClusterName

		// Set kube-config
		_, path, _, err := kube.SetInfraConfig(namespace, clusterName, workspace, email)
		defer os.Remove(path)
		println("path====", path)
		if err != nil {
			return nil, err
		}

		// Get the nodes in the cluster
		nodes, err := kube.GetNodesName(namespace, clusterName, workspace, email)
		if err != nil {
			return nil, err
		}

		// if strings.EqualFold(workspace, "demotestops") {
		// 	// deprecate the check on demotestops workspace
		// 	logs.Info("[Skipping] resource check for demotestops workspace")
		// 	bestClusters = append(bestClusters, models.BestClusters{
		// 		ClusterName:           clusterName,
		// 		IsSuffiecientResource: true,
		// 	})
		// 	// return bestClusters, nil
		// }

		// Check if any node in the cluster has sufficient resources
		for _, node := range nodes {
			// Get the node name
			nodeName := node

			// Get the path to the kubeconfig file
			path := path

			// Check if the node has sufficient resources
			if kube.HasSufficientInfraResources(path, nodeName, map[string]string{
				"cpu":    defaultValues["cpu"]["request"].(string),
				"memory": defaultValues["memory"]["request"].(string),
				"gpu":    defaultValues["gpu"]["request"].(string),
			}) {
				// Add the cluster to the best cluster list
				// bestClusters = append(bestClusters, clusterName)
				bestClusters = append(bestClusters, models.BestClusters{
					ClusterName:           clusterName,
					IsSuffiecientResource: true,
				})
				break
				// break
			} else {
				bestClusters = append(bestClusters, models.BestClusters{
					ClusterName:           clusterName,
					IsSuffiecientResource: true,
				})
				break
			}
		}
	}

	pretty.Println("bestClusters")
	pretty.Println(bestClusters)

	return bestClusters, nil
}

// Function to get full cluster details
func GetFullClusterDetails(namespace string, clusterNames []models.BestClusters, workspace string) ([]database.InfraIntegration, error) {
	// Connect to database
	// db := config.DB

	// Initialize cluster list
	var clusters []database.InfraIntegration

	// Iterate over each cluster name
	for i, clusterName := range clusterNames {
		// Fetch the cluster from the database
		var cluster database.InfraIntegration
		err := config.DB.Debug().Model(&database.InfraIntegration{}).Where("cluster_name = ? AND workspace= ?", clusterName.ClusterName, workspace).First(&cluster).Error
		if err != nil {
			return nil, err
		}

		logs := config.Log

		cluster.IsSuffiecientResource = clusterName.IsSuffiecientResource

		_, path, _, err := kube.SetInfraConfig(namespace, clusterName.ClusterName, workspace, "")
		if err != nil {
			logs.Error("Failed to set kubeconfig:", err)
			return nil, err
		}

		var config *rest.Config
		config, err = clientcmd.BuildConfigFromFlags("", path)
		if err != nil {
			return nil, err
		}
		var clientset *kubernetes.Clientset

		clientset, err = kubernetes.NewForConfig(config)
		if err != nil {
			return nil, err
		}

		// Get nodes information
		nodes, err := clientset.CoreV1().Nodes().List(context.Background(), metav1.ListOptions{})
		if err != nil {
			logs.Error("Failed to get nodes:", err)
			return nil, err
		}

		var nodeMetrics *v1beta1.NodeMetricsList
		metricsClient, err := metricsv.NewForConfig(config)
		if err != nil {
			logs.Error("matrics client error : ", err)
		} else {
			nodeMetrics, err = metricsClient.MetricsV1beta1().NodeMetricses().List(context.TODO(), metav1.ListOptions{})
			if err != nil {
				logs.Error("err: ", err)
			}
		}

		var nodeMatrixs []database.NodeMetrics
		var totalAllocCPU, totalUsedCPU int64
		for _, node := range nodes.Items {
			var nodeMatrix database.NodeMetrics
			allocCPU := node.Status.Allocatable.Cpu()
			allocMem := node.Status.Allocatable.Memory()
			allocGPU := node.Status.Allocatable["nvidia.com/gpu"]

			var usedCPU resource.Quantity
			for _, usage := range nodeMetrics.Items {
				if usage.Name == node.Name {
					usedCPU = *usage.Usage.Cpu()
					break
				}
			}

			allocCPUMilli := float64(allocCPU.MilliValue())
			usedCPUMilli := float64(usedCPU.MilliValue())
			cpuUtil := 0.0
			if allocCPUMilli > 0 {
				cpuUtil = (usedCPUMilli / allocCPUMilli) * 100
			}

			totalAllocCPU += int64(allocCPUMilli)
			totalUsedCPU += int64(usedCPUMilli)

			nodeMatrix.NodeName = node.Name
			nodeMatrix.CPUAllocatable = fmt.Sprintf("%dm", int64(allocCPUMilli))
			nodeMatrix.CPUUsed = fmt.Sprintf("%dm", int64(usedCPUMilli))
			nodeMatrix.GPUAllocatable = allocGPU.String()
			nodeMatrix.GPUUsed = "0" // Fixed value
			nodeMatrix.MemoryAllocatable = formatMemory(allocMem)
			nodeMatrix.MemoryUsed = "0" // Fixed value
			nodeMatrix.InternalIP = getNodeInternalIP(node)

			fmt.Printf("Name                : %s\n", node.Name)
			fmt.Printf("CPU Allocatable     : %dm\n", int64(allocCPUMilli))
			fmt.Printf("CPU Used            : %dm\n", int64(usedCPUMilli))
			fmt.Printf("CPU Utilization     : %.2f%%\n", cpuUtil)
			fmt.Printf("Memory Allocatable  : %s\n", formatMemory(allocMem))
			fmt.Printf("GPU Allocatable     : %s\n", allocGPU.String())
			fmt.Printf("GPU Utilization     : 0%% (Fixed)\n")
			fmt.Printf("Internal IP         : %s\n", getNodeInternalIP(node))
			fmt.Println("--------------------------------------------------")
			nodeMatrixs = append(nodeMatrixs, nodeMatrix)
		}

		var clusterCPUUtil float64
		if totalAllocCPU > 0 {
			clusterCPUUtil = float64(totalUsedCPU) / float64(totalAllocCPU) * 100
		}

		fmt.Println("CLUSTER CPU UTILIZATION SUMMARY")
		fmt.Println("--------------------------------------------------")
		fmt.Printf("Total CPU Allocatable: %dm\n", totalAllocCPU)
		fmt.Printf("Total CPU Used       : %dm\n", totalUsedCPU)
		fmt.Printf("Total CPU Utilization: %.2f%%\n", clusterCPUUtil)
		fmt.Println("--------------------------------------------------")
		clusters = append(clusters, cluster)
		clusters[i].TotalCPUAllocatable = fmt.Sprintf("%dm", totalAllocCPU)
		clusters[i].TotalCPUUsed = fmt.Sprintf("%dm", totalUsedCPU)
		clusters[i].TotalCPUUtilization = fmt.Sprintf("%.2f", clusterCPUUtil)
		clusters[i].NodeMetrics = nodeMatrixs

	}

	return clusters, nil
}

func formatMemory(mem *resource.Quantity) string {
	memBytes, ok := mem.AsInt64()
	if !ok {
		return "Unknown"
	}

	memKi := float64(memBytes)
	memMi := memKi / 1024
	memGi := memMi / 1024
	memTi := memGi / 1024

	switch {
	case memTi >= 1:
		return fmt.Sprintf("%.2f TiB", memTi)
	case memGi >= 1:
		return fmt.Sprintf("%.2f GiB", memGi)
	case memMi >= 1:
		return fmt.Sprintf("%.2f MiB", memMi)
	default:
		return fmt.Sprintf("%.2f KiB", memKi)
	}
}

func getNodeInternalIP(node v1.Node) string {
	for _, addr := range node.Status.Addresses {
		if addr.Type == v1.NodeInternalIP {
			return addr.Address
		}
	}
	return "NotFound"
}
