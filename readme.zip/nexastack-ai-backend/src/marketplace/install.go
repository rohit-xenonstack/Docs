package marketplace

import (
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/helm"
	"git.xenonstack.com/nexa-platform/accounts/src/kubernetes"
	"git.xenonstack.com/nexa-platform/accounts/src/resource"
	"github.com/kr/pretty"
	"helm.sh/helm/v3/pkg/action"
	"helm.sh/helm/v3/pkg/chart"
	"helm.sh/helm/v3/pkg/chart/loader"
	// v1 "k8s.io/api/core/v1"
	// "k8s.io/apimachinery/pkg/api/resource"
	// metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	// "k8s.io/client-go/tools/clientcmd"
)

func InstallModel(email string, nameSpace string, workspace string, releaseName string, modelName string, clusterName string, apiKey string) (map[string]interface{}, int) {
	mapd := make(map[string]interface{})
	mapd["error"] = false

	// Set kube-config
	actionConfig, path, code, err := kubernetes.SetInfraConfig(nameSpace, clusterName, workspace, email)
	defer os.Remove(path)
	println("path====", path)
	if err != nil {
		log.Println(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return mapd, code
	}

	//Downlaod the Charts
	var bucketName = config.Conf.MinioModelHelm.BucketName
	var fileName = config.Conf.MinioModelHelm.FileName
	resource.DownloadChartsMinio(bucketName, fileName)

	db := config.DB
	var modelResource database.ModelMarketplace
	err = db.Debug().Model(&database.ModelMarketplace{}).Where("hf_model_name = ?", modelName).Find(&modelResource).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to fetch model details"
		return mapd, 404
	}

	// Get release name from valueYamlFile
	// releaseName = strings.TrimSuffix(modelResource.ValueYamlFile, "-values.yaml")

	// get infra_integration from database with cluster name

	var infraIntegration database.InfraIntegration
	err = config.DB.Debug().Model(&database.InfraIntegration{}).Where("cluster_name = ?", clusterName).Find(&infraIntegration).Error
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to fetch infra integration details"
		return mapd, 404
	}

	if infraIntegration.Ingress == "" || infraIntegration.IngressClass == "" {
		mapd["error"] = true
		mapd["message"] = "ingress or ingress class not found in infra integration"
		return mapd, 400
	}

	// Fetch the chart
	chart, rawVals, err := helm.FetchModelChart(workspace, nameSpace, modelResource.ValueYamlFile, infraIntegration)
	if err != nil {
		config.Log.Error("Failed to fetch chart:", err)
		mapd["error"] = true
		mapd["message"] = fmt.Sprintf("failed to fetch chart: %v", err)
		return mapd, 404
	}

	return mapd, 400

	// Get release name from values.yaml
	val, ok := rawVals["releaseName"]
	if !ok {
		config.Log.Error("Failed to get release name from values")
		mapd["error"] = true
		mapd["message"] = "failed to get release name from values"
		return mapd, 400
	} else {
		releaseName = val.(string)
	}

	// presetValues := map[string]map[string]map[string]interface{}{
	// 	"Qwen/Qwen2.5-1.5B-Instruct": {
	// 		"cpu": {
	// 			"limit":   "6", // 150m -> 0.15
	// 			"request": "2", // 100m -> 0.1
	// 		},
	// 		"memory": {
	// 			"limit":   "12Gi", // 192Mi -> 0.1875G
	// 			"request": "3Gi",  // 128Mi -> 0.125G
	// 		},
	// 		"gpu": {
	// 			"limit":   "1",
	// 			"request": "1",
	// 		},
	// 	},
	// 	"Qwen/Qwen2.5-VL-3B-Instruct": {
	// 		"cpu": {
	// 			"limit":   "6", // 150m -> 0.15
	// 			"request": "2", // 100m -> 0.1
	// 		},
	// 		"memory": {
	// 			"limit":   "12Gi", // 192Mi -> 0.1875G
	// 			"request": "3Gi",  // 128Mi -> 0.125G
	// 		},
	// 		"gpu": {
	// 			"limit":   "1",
	// 			"request": "1",
	// 		},
	// 	},
	// }

	// Get preset values for the specified ResourcesPreset
	// presetValue, ok := presetValues[modelName]
	// fmt.Printf("====presetvalues====: %s", presetValue)
	// if !ok {
	// 	mapd := make(map[string]interface{})
	// 	mapd["error"] = true
	// 	mapd["message"] = "Resource Preset for this HF model is not available"
	// 	return mapd, 400
	// }

	// if !kubernetes.HasSufficientInfraResources(path, nodeName, map[string]string{
	// 	"cpu":    presetValue["cpu"]["request"].(string),
	// 	"memory": presetValue["memory"]["request"].(string),
	// 	"gpu":    presetValue["gpu"]["request"].(string),
	// }) {
	// 	mapd["error"] = true
	// 	mapd["message"] = "Resources not available on the specified node"
	// 	return mapd, 500
	// }
	// connect to database

	// override deployment name

	// defaultValues := map[string]map[string]interface{}{
	// 	"cpu": {
	// 		"limit":   modelResource.CPULimit,   // 150m -> 0.15
	// 		"request": modelResource.CPURequest, // 100m -> 0.1
	// 	},
	// 	"memory": {
	// 		"limit":   modelResource.MemoryLimit,   // 192Mi -> 0.1875G
	// 		"request": modelResource.MemoryRequest, // 128Mi -> 0.125G
	// 	},
	// 	"gpu": {
	// 		"limit":   modelResource.GPULimit,
	// 		"request": modelResource.GPURequest,
	// 	},
	// }

	nodes, err := kubernetes.GetNodesName(nameSpace, clusterName, workspace, email)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Failed to retrieve nodes"
		return mapd, 500
	}
	pretty.Println("nodes: ", nodes)

	var suitableNode string
	for _, node := range nodes {
		config.Log.Info("node", node)
		suitableNode = node

		// if kubernetes.HasSufficientInfraResources(path, node, map[string]string{
		// 	"cpu":    defaultValues["cpu"]["request"].(string),
		// 	"memory": defaultValues["memory"]["request"].(string),
		// 	"gpu":    defaultValues["gpu"]["request"].(string),
		// }) {
		// 	suitableNode = node
		// 	break
		// }
	}

	config.Log.Debug("Suitable Node is ======", suitableNode)

	if suitableNode == "" {
		mapd["error"] = true
		mapd["message"] = fmt.Sprintf("Resources not available on cluster for model '%s'. Minimum resources required: CPU Limit: %s, CPU Request: %s, Memory Limit: %s, Memory Request: %s, GPU Limit: %s, GPU Request: %s",
			modelResource.ModelName, modelResource.CPULimit, modelResource.CPURequest, modelResource.MemoryLimit, modelResource.MemoryRequest, modelResource.GPULimit, modelResource.GPURequest)
		return mapd, 500
	}

	//set install release on server
	iCli := action.NewInstall(actionConfig)
	config.Log.Debug("=====icli====", iCli.CaFile)
	iCli.Namespace = nameSpace
	iCli.ReleaseName = releaseName

	// values := map[string]interface{}{
	// 	"deployment": map[string]interface{}{
	// 		"args": []string{
	// 			"vllm serve" + " " + modelName + " " + "--trust-remote-code --enable-chunked-prefill --max_num_batched_tokens 1024 --api-key" + " " + apiKey,
	// 		},
	// 		"cpu_limit":      defaultValues["cpu"]["limit"],
	// 		"cpu_request":    defaultValues["cpu"]["request"],
	// 		"memory_request": defaultValues["memory"]["request"],
	// 		"memory_limit":   defaultValues["memory"]["limit"],
	// 		"gpu":            defaultValues["gpu"]["request"],
	// 	},

	// 	"ingress": map[string]interface{}{
	// 		"hosts": []map[string]interface{}{
	// 			{
	// 				"host": releaseName + ".nexastack.neuralcompany.team",
	// 				"paths": []map[string]interface{}{
	// 					{
	// 						"path":     "/",
	// 						"pathType": "ImplementationSpecific",
	// 					},
	// 				},
	// 			},
	// 		},
	// 		"tls": []map[string]interface{}{
	// 			{
	// 				"secretName": releaseName + "-tls",
	// 				"hosts": []string{
	// 					releaseName + ".nexastack.neuralcompany.team",
	// 				},
	// 			},
	// 		},
	// 	},

	// 	// "nodeSelector": map[string]string{
	// 	// 	"kubernetes.io/hostname": nodeName,
	// 	// },
	// }

	_, err = iCli.Run(chart, rawVals)
	if err != nil {
		config.Log.Error(err)
		// Clean up failed deployment
		uninstall := action.NewUninstall(actionConfig)
		_, uninstallErr := uninstall.Run(releaseName)
		if uninstallErr != nil {
			config.Log.Info("Successfully cleaned up failed deployment:", releaseName)
		}
		mapd["error"] = false
		mapd["message"] = err.Error()
		return mapd, 400
	}

	log.Println("Release name:", releaseName)

	// Get ingress information using kubectl
	ingressURL, err := kubernetes.GetIngressInfo(nameSpace, clusterName, workspace, email, releaseName)
	if err != nil {
		config.Log.Error("Failed to get ingress:", err)
		mapd["error"] = false
		mapd["message"] = "Model deployed but failed to get ingress information"
		return mapd, 400
	}
	mapd["ingress"] = ingressURL

	deploymentName, err := kubernetes.GetDeploymentName(nameSpace, clusterName, workspace, email, releaseName)
	if err != nil {
		config.Log.Error("Failed to get deployment:", err)
		mapd["error"] = false
		mapd["message"] = "Model deployed but failed to get deployment information"
		return mapd, 400
	}
	mapd["deployment_name"] = deploymentName
	mapd["error"] = false
	mapd["deployment_sub_name"] = modelResource.DeploymentSubName
	mapd["release_name"] = releaseName
	mapd["message"] = "Model Deployed successfully"
	return mapd, 200
}

func FetchModelChart(workspace, namespace, modelName, apiKey string) (*chart.Chart, map[string]interface{}, error) {
	// Get the base directory from config or use default
	baseDir := "data/model-helm"

	// Construct the chart directory path
	chartDir := filepath.Join(baseDir, "model_ingress")

	// Verify the chart directory exists
	if _, err := os.Stat(chartDir); os.IsNotExist(err) {
		config.Log.Error("Chart directory does not exist:", chartDir)
		return nil, nil, fmt.Errorf("chart directory not found: %s", chartDir)
	}

	// Load the chart
	chart, err := loader.LoadDir(chartDir)
	if err != nil {
		config.Log.Error("Failed to load chart:", err)
		return nil, nil, fmt.Errorf("failed to load chart: %v", err)
	}

	// Verify the chart is valid
	if chart.Metadata == nil {
		return nil, nil, errors.New("invalid chart: missing metadata")
	}

	// Create values map with required fields
	rawVals := make(map[string]interface{})

	// Set workspace and namespace
	rawVals["teamSlug"] = workspace
	rawVals["namespace"] = namespace

	// Log the final values for debugging
	config.Log.Debug("Chart values:", rawVals)

	return chart, rawVals, nil
}
