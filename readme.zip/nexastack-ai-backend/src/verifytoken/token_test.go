package verifytoken

import (
	"os"
	"testing"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
	_ "github.com/mattn/go-sqlite3"
)

const (
	email string = "test@test.com"
	name  string = "test"
)

var (
	id int
)

func init() {

	os.Remove(os.Getenv("HOME") + "/account-testing.db")
	db, err := gorm.Open("sqlite3", os.Getenv("HOME")+"/account-testing.db")
	if err != nil {

		config.Log.Error(err)
		config.Log.Error("Exit")
		os.Exit(1)
	}
	config.DB = db

	//create table
	database.CreateDatabaseTables()
	acc := database.Accounts{}
	//save data in account table
	acc.Name = name
	acc.Email = email
	db.Create(&acc)
	id = acc.ID
}

func TestToken(t *testing.T) {

	//set fix opt false
	ToggleOTP("false")

	//test case when fix otp is false
	{
		//test case 1 -> email verification
		str := CheckSentToken(id, "email_verification")

		token, err := CheckToken(str)
		if err != nil {
			t.Error("test case fail", err)
		}

		//test case 2 -> again call generate the token
		str = CheckSentToken(id, "email_verification")
		//delete the token
		DeleteToken(token.Token)

		//test case 3 -> invite member task create the token
		str = CheckSentToken(id, "invite_member")

		token, err = CheckToken(str)
		if err != nil {
			t.Error("test case fail")
		}
		//delete the token
		DeleteToken(token.Token)

		//test case 4 -> when wrong token pass to function
		token, err = CheckToken("str")
		if err == nil {
			t.Error("test case fail")
		}
	}

	//set fix otp
	ToggleOTP("true")

	//test case when fix open is true
	{
		//test case -> Generate token for invite member in fix otp
		str := CheckSentToken(id, "invite_member")
		//delete the token
		DeleteToken(str)

		//set token for email_verification in fix otp
		str = CheckSentToken(id, "email_verification")
		//delete the token
		DeleteToken(str)
	}

}
