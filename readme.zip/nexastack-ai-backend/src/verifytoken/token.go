package verifytoken

import (
	"errors"
	"strconv"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
)

// ToggleOTP is a function to change the value of OTP in config
func ToggleOTP(value string) {
	if strings.ToLower(value) == "true" {
		config.Conf.Service.FixOTP = true
	} else {
		config.Conf.Service.FixOTP = false
	}
}

// CheckSentToken is a method to generate verifications token that are send in mail
// Before generating new token it checks is there any valid old token previouly
func CheckSentToken(id int, task string) string {

	// connecting to db
	db := config.DB
	// cheking previous token
	var tok []database.Tokens
	if task == "email_verification" {
		db.Where("userid= ? AND token_task= ? AND timestamp >= ?", id, task, (time.Now().Unix() - config.Conf.Service.VerifyLinkTimeout)).Find(&tok)
	} else {
		db.Where("userid= ? AND token_task= ? AND timestamp >= ?", id, task, (time.Now().Unix() - config.Conf.Service.InviteLinkTimeout)).Find(&tok)
	}
	token := ""
	if len(tok) != 0 {
		// if there is token
		token = tok[0].Token
	} else {
		// else creating new token
		token = newToken(id, task)
	}
	return token
}

//====================================================================

// newToken is a method to generate new verification token and add to database
func newToken(id int, task string) string {

	// connecting to db
	db := config.DB
	token := database.Tokens{}
	// setting token user id
	token.Userid = id
	// generating token on basis of task
	switch task {
	case "email_verification":
		// generating random 6 digit numeric string
		token.Token = methods.RandomStringIntegerOnly(6)
	default:
		// for other tasks creating 35 length random string
		token.Token = methods.RandomString(35)
	}

	if config.Conf.Service.FixOTP {
		acc := database.Accounts{}
		db.Where("id=?", id).Find(&acc)
		email := strings.Split(acc.Email, "@")
		token.Token = task + email[0]
		if task == "email_verification" {
			token.Token = "111111"
		}
	}

	token.TokenTask = task
	token.Timestamp = time.Now().Unix()
	token.CreateAt = time.Now()

	// save data in db
	db.Create(&token)
	return token.Token
}

//========================================================================

// CheckToken is a method to check token is valid or not
func CheckToken(token string) (database.Tokens, error) {
	// connecting to db
	db := config.DB
	// fetch token details
	tok := []database.Tokens{}
	db.Where("token=?", token).Find(&tok)
	//token not found
	if len(tok) == 0 {
		config.Log.Error("token not found")
		return database.Tokens{}, errors.New("Invalid or expired token")
	}

	//expired token
	if (time.Now().Unix() - tok[0].Timestamp) > config.Conf.Service.InviteLinkTimeout {
		config.Log.Error("expired token")
		return database.Tokens{}, errors.New("Invalid or expired token")
	}
	return tok[0], nil
}

//========================================================================

// DeleteToken is method to delete used and expired tokens
func DeleteToken(token string) {
	// connecting to db
	db := config.DB
	// delete used token
	row := db.Where("token=?", token).Delete(&database.Tokens{}).RowsAffected
	config.Log.Debug(row)
	// delete expired tokens
	row = db.Where("timestamp < ?", strconv.FormatInt((time.Now().Unix()-config.Conf.Service.InviteLinkTimeout), 10)).RowsAffected
	config.Log.Debug(row)
}
