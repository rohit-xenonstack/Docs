import os
import sys, logging, json
from utils.minio_utils import MinioClient
from utils.db_utils import PostgresDB
from utils.common import  remove_folder
from queries.query import get_fields_in_formation_by_user
from feature.finetuning import fine_tune

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Retrieve all command-line arguments
user_id = sys.argv[1]
config_id = sys.argv[2]
function_name = sys.argv[3]

# connect to database and minio
try:
    DB = PostgresDB()
    DB.connect()
    minio = MinioClient()
    minio.connect()
except Exception as e:
    logger.error(f"Error connecting to database: {e}")
    sys.exit(1)


# fetch data from database based on user_id and config_id
try:
    data = DB.fetch_all(get_fields_in_formation_by_user,(user_id))
except Exception as e:
    logger.error(f"Error fetching data from database: {e}")
    sys.exit(1)

# execute different functions
match (function_name.lower()):
    case "fine_tune":
        model_name = [data["model_name"] for data in data][0]
        fine_tune(data,model_name)
        
        # Store fine tuned models into Minio
        minio.upload_folder("nexa-finetuned-models","./src/python/outputs/"+model_name,"/"+model_name)
        remove_folder("./src/python/outputs/"+model_name)
        # file path: "./src/python/outputs/qwen/demo-model.model"
    case _:
        logger.error(f"Invalid function name: {function_name}")

logger.info(f"python finetuning executing for user: {user_id} and config_id: {config_id}")



#"Traceback (most recent call last):\n  File \"/Users/xs330-balsha/
#Desktop/Projects/nexastack-ai-backend/./src/python/main.py\", line 4, in <module>\n    
#from resource.python_queries.query import get_fields_in_formation_by_user\nModuleNo
#tFoundError: No module named 'resource.python_queries'; 'resource' is not a package\n"