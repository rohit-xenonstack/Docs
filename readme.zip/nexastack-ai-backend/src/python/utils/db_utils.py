import os
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import Dict, List, Any, Optional, Union, Tuple
from dotenv import load_dotenv

load_dotenv()

class DatabaseError(Exception):
    """Custom exception for database errors"""
    pass

class PostgresDB:
    """PostgreSQL database utility class with connection pooling"""
    
    def __init__(self, connection_params: Optional[Dict[str, str]] = None):
        """
        Initialize database connection with parameters or environment variables
        
        Args:
            connection_params: Dictionary with connection parameters:
                - host: Database host
                - port: Database port
                - database: Database name
                - user: Database user
                - password: Database password
        """
        self.conn = None
        self.cursor = None
        
        # If connection params not provided, try to get from env variables
        if connection_params is None:
            self.connection_params = {
                'host': os.getenv('AUTH_DB_HOST'),
                'port': os.getenv('AUTH_DB_PORT'),
                'database': os.getenv('AUTH_DB_NAME'),
                'user': os.getenv('AUTH_DB_USER'),
                'password': os.getenv('AUTH_DB_PASS')
            }
        else:
            self.connection_params = connection_params
    
    def connect(self) -> None:
        """Establish connection to the PostgreSQL database"""
        try:
            self.conn = psycopg2.connect(**self.connection_params)
            # Enable autocommit for simplicity, disable for transaction control
            self.conn.autocommit = True
        except psycopg2.Error as e:
            raise DatabaseError(f"Connection error: {e}")
    
    def disconnect(self) -> None:
        """Close the database connection"""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
        
        self.cursor = None
        self.conn = None
    
    def __enter__(self):
        """Context manager entry point"""
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit point"""
        self.disconnect()
    
    def fetch_one(self, query: str, params: Optional[tuple] = None) -> Optional[Dict[str, Any]]:
        """
        Execute a query and fetch a single row as a dictionary
        
        Args:
            query: SQL query to execute
            params: Parameters to pass to the query
            
        Returns:
            Dictionary with column names as keys, or None if no results
        """
        try:
            if not self.conn:
                self.connect()
            
            with self.conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, params)
                result = cursor.fetchone()
            
            return dict(result) if result else None
        
        except psycopg2.Error as e:
            self.conn.rollback()
            raise DatabaseError(f"Error fetching one row: {e}")
    
    def fetch_all(self, query: str, params: Optional[tuple] = None) -> List[Dict[str, Any]]:
        """
        Execute a query and fetch all rows as a list of dictionaries
        
        Args:
            query: SQL query to execute
            params: Parameters to pass to the query
            
        Returns:
            List of dictionaries with column names as keys
        """
        try:
            if not self.conn:
                self.connect()
            
            with self.conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, params)
                results = cursor.fetchall()
            
            return [dict(row) for row in results]
        
        except psycopg2.Error as e:
            self.conn.rollback()
            raise DatabaseError(f"Error fetching all rows: {e}")
    
    def execute(self, query: str, params: Optional[tuple] = None) -> int:
        """
        Execute a query (INSERT, UPDATE, DELETE) and return affected rows
        
        Args:
            query: SQL query to execute
            params: Parameters to pass to the query
            
        Returns:
            Number of affected rows
        """
        try:
            if not self.conn:
                self.connect()
            
            with self.conn.cursor() as cursor:
                cursor.execute(query, params)
                row_count = cursor.rowcount
            
            return row_count
        
        except psycopg2.Error as e:
            self.conn.rollback()
            raise DatabaseError(f"Error executing query: {e}")
    
    def execute_many(self, query: str, params_list: List[tuple]) -> int:
        """
        Execute a batch query with multiple parameter sets
        
        Args:
            query: SQL query to execute
            params_list: List of parameter tuples
            
        Returns:
            Number of affected rows
        """
        try:
            if not self.conn:
                self.connect()
            
            with self.conn.cursor() as cursor:
                cursor.executemany(query, params_list)
                row_count = cursor.rowcount
            
            return row_count
        
        except psycopg2.Error as e:
            self.conn.rollback()
            raise DatabaseError(f"Error executing batch query: {e}")
    
    def transaction(self) -> 'Transaction':
        """
        Start a transaction (to be used with context manager)
        
        Returns:
            Transaction object
        """
        return Transaction(self)


class Transaction:
    """Context manager for database transactions"""
    
    def __init__(self, db: PostgresDB):
        self.db = db
    
    def __enter__(self):
        if not self.db.conn:
            self.db.connect()
        self.db.conn.autocommit = False
        return self.db
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            self.db.conn.commit()
        else:
            self.db.conn.rollback()
        self.db.conn.autocommit = True


# # Example usage
# if __name__ == "__main__":
#     # Example 1: Basic query with context manager
#     with PostgresDB() as db:
#         users = db.fetch_all("SELECT * FROM accounts WHERE account_status = %s", ("active",))
#         print(f"Found {len(users)} active accounts")
    
#     # Example 2: Single query
#     db = PostgresDB()
#     try:
#         db.connect()
#         user = db.fetch_one("SELECT * FROM users WHERE id = %s", (123,))
#         if user:
#             print(f"Found user: {user['name']}")
#         else:
#             print("User not found")
#     finally:
#         db.disconnect()
    
#     # Example 3: Transaction
#     db = PostgresDB()
#     try:
#         with db.transaction() as tx:
#             tx.execute("UPDATE users SET status = %s WHERE id = %s", ("premium", 123))
#             tx.execute("INSERT INTO user_logs (user_id, action) VALUES (%s, %s)", (123, "upgraded"))
#             # Both queries will be committed if successful, or rolled back if any fails
#     except DatabaseError as e:
#         print(f"Transaction failed: {e}")