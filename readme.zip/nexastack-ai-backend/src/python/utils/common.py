import os
import shutil


def to_snake_case(text: str) -> str:
    text = text.strip()
    text = text.replace(" ", "_")
    return text.lower()

def remove_folder(folder_path):
    """Remove a folder and all of its contents."""
    if os.path.exists(folder_path):
        try:
            # Use shutil.rmtree to remove a directory and all its contents
            shutil.rmtree(folder_path)
            print(f"Folder {folder_path} has been removed successfully.")
        except Exception as e:
            print(f"Error while deleting folder {folder_path}: {e}")
    else:
        print(f"Folder {folder_path} does not exist.")
        
def preprocess_data(data):
    """
    Preprocess the data into a dictionary for fast lookups with typecasting information.
    
    Parameters:
        data (list of tuples): A list of tuples containing field information.
        
    Returns:
        dict: A dictionary where the key is the field name, and the value is a tuple of (field_type, value).
    """
    return {row[0]: (row[1], row[4]) for row in data}  # row[0] is field name, row[1] is field type, row[4] is value

def convert_value(value, field_type):
    """
    Convert the string value to the specified field type.
    
    Parameters:
        value (str): The value to be converted.
        field_type (str): The field type to which the value should be casted.
        
    Returns:
        The converted value according to the field type.
    """
    if field_type == 'int':
        try:
            return int(value)
        except ValueError:
            return None  # Return None if the value can't be converted to int
    elif field_type == 'float':
        try:
            return float(value)
        except ValueError:
            return None  # Return None if the value can't be converted to float
    elif field_type == 'bool':
        value = value.lower()
        if value == 'true':
            return True
        elif value == 'false':
            return False
        return None  # Return None if the value can't be converted to bool
    elif field_type == 'str':
        return str(value)  # If it's already a string, just return it
    else:
        raise ValueError(f"Unsupported field_type: {field_type}")  # Raise error for unsupported field type

def get_value(data_dict, name, default=None):
    """
    This function returns the value associated with the given name from the preprocessed data dictionary.
    It typecasts the value according to the field_type. If the field is not found, returns the provided default value (or None if no default is provided).
    
    Parameters:
        data_dict (dict): The preprocessed dictionary containing field names as keys and (field_type, value) as values.
        name (str): The field name to search for in the dictionary.
        default (any, optional): The default value to return if the field name is not found. Defaults to None.
        
    Returns:
        The value associated with the name, typecasted according to the field_type, or the default value if the name is not found.
    """
    if name in data_dict:
        field_type, value = data_dict[name]
        print(f'name: {name}, field: {value}')
        return convert_value(value, field_type)  # Typecast the value according to the field_type
    return default  # Return default value if the name is not found

