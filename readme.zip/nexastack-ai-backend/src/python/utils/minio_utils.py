import json
import os
import boto3
from botocore.client import Config
from botocore.exceptions import ClientError
from typing import Dict, List, Optional, Union, BinaryIO, Tuple, Iterator, Any

class MinioError(Exception):
    """Custom exception for MinIO operations"""
    pass

class MinioClient:
    """MinIO client utility class using boto3 for object storage operations"""
    
    def __init__(self, connection_params: Optional[Dict[str, str]] = None):
        """
        Initialize MinIO client with connection parameters or environment variables
        
        Args:
            connection_params: Dictionary with connection parameters:
                - endpoint_url: MinIO server endpoint URL (e.g., 'http://minio.example.com:9000')
                - aws_access_key_id: Access key (username)
                - aws_secret_access_key: Secret key (password)
                - region_name: Optional region name (default: us-east-1)
        """
        # If connection params not provided, try to get from environment variables
        if connection_params is None:
            self.connection_params = {
                'endpoint_url': 'http://'+os.environ.get('MINIO_ENDPOINT'),
                'aws_access_key_id': os.environ.get('MINIO_ACCESS_KEY'),
                'aws_secret_access_key': os.environ.get('MINIO_SECRET_KEY'),
                'region_name': os.environ.get('MINIO_REGION', 'us-east-1')
            }
        else:
            self.connection_params = connection_params
            # Ensure endpoint_url has proper protocol
            if 'endpoint_url' in self.connection_params and not self.connection_params['endpoint_url'].startswith(('http://', 'https://')):
                protocol = 'http://' if self.connection_params.get('use_ssl', True) else 'http://'
                self.connection_params['endpoint_url'] = f"{protocol}{self.connection_params['endpoint_url']}"
        
        self.client = None
        self.resource = None
        self.connect()
    
    def connect(self) -> None:
        """Establish connection to the MinIO server using boto3"""
        try:
            # Configure boto3 to use path-style URLs which is how MinIO works
            s3_config = Config(signature_version='s3v4', s3={'addressing_style': 'path'})
            
            # Create low-level client
            self.client = boto3.client(
                's3',
                endpoint_url=self.connection_params['endpoint_url'],
                aws_access_key_id=self.connection_params['aws_access_key_id'],
                aws_secret_access_key=self.connection_params['aws_secret_access_key'],
                region_name=self.connection_params.get('region_name', 'us-east-1'),
                config=s3_config
            )
            
            # Create resource for higher-level operations
            self.resource = boto3.resource(
                's3',
                endpoint_url=self.connection_params['endpoint_url'],
                aws_access_key_id=self.connection_params['aws_access_key_id'],
                aws_secret_access_key=self.connection_params['aws_secret_access_key'],
                region_name=self.connection_params.get('region_name', 'us-east-1'),
                config=s3_config
            )
        except Exception as e:
            raise MinioError(f"Connection error: {e}")
    
    def create_bucket(self, bucket_name: str, location: str = "us-east-1") -> bool:
        """
        Create a new bucket in MinIO
        
        Args:
            bucket_name: Name of the bucket to create
            location: Region where the bucket will be created (default: us-east-1)
            
        Returns:
            True if bucket was created, False if it already exists
        """
        try:
            # Check if bucket exists first
            if self.bucket_exists(bucket_name):
                return False
            
            # For most regions, we need to specify the LocationConstraint
            # For us-east-1, we should not include it at all
            if location == 'us-east-1':
                self.client.create_bucket(Bucket=bucket_name)
            else:
                self.client.create_bucket(
                    Bucket=bucket_name,
                    CreateBucketConfiguration={'LocationConstraint': location}
                )
            return True
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            if error_code == 'BucketAlreadyOwnedByYou':
                return False
            raise MinioError(f"Error creating bucket '{bucket_name}': {e}")
    
    def bucket_exists(self, bucket_name: str) -> bool:
        """
        Check if a bucket exists
        
        Args:
            bucket_name: Name of the bucket to check
            
        Returns:
            True if bucket exists, False otherwise
        """
        try:
            self.client.head_bucket(Bucket=bucket_name)
            return True
        except ClientError:
            return False
    
    def list_buckets(self) -> List[Dict[str, Union[str, Any]]]:
        """
        List all buckets
        
        Returns:
            List of dictionaries with bucket information
        """
        try:
            response = self.client.list_buckets()
            return [{'name': bucket['Name'], 'creation_date': bucket['CreationDate']} 
                    for bucket in response.get('Buckets', [])]
        except ClientError as e:
            raise MinioError(f"Error listing buckets: {e}")
    
    def delete_bucket(self, bucket_name: str, force: bool = False) -> bool:
        """
        Delete a bucket from MinIO
        
        Args:
            bucket_name: Name of the bucket to delete
            force: If True, delete all objects in the bucket before deleting the bucket
            
        Returns:
            True if bucket was deleted, False if it doesn't exist
        """
        try:
            if not self.bucket_exists(bucket_name):
                return False
            
            bucket = self.resource.Bucket(bucket_name)
            
            if force:
                # Delete all objects in the bucket first
                bucket.objects.all().delete()
                
                # Delete all object versions if versioning is enabled
                bucket_versioning = self.client.get_bucket_versioning(Bucket=bucket_name)
                if bucket_versioning.get('Status') == 'Enabled':
                    bucket.object_versions.all().delete()
            
            # Delete the bucket
            bucket.delete()
            return True
        except ClientError as e:
            raise MinioError(f"Error deleting bucket '{bucket_name}': {e}")
    
    def upload_file(self, bucket_name: str, object_name: str, file_path: str, 
                   extra_args: Optional[Dict] = None) -> Dict:
        """
        Upload a file to a MinIO bucket
        
        Args:
            bucket_name: Name of the bucket
            object_name: Name to assign to the object in the bucket
            file_path: Local path to the file to upload
            extra_args: Extra arguments to pass to boto3 (ContentType, Metadata, etc.)
            
        Returns:
            Dictionary with upload result
        """
        try:
            # Ensure bucket exists
            if not self.bucket_exists(bucket_name):
                self.create_bucket(bucket_name)
            
            extra_args = extra_args or {}
            
            # Upload the file
            self.client.upload_file(
                Filename=file_path,
                Bucket=bucket_name,
                Key=object_name,
                ExtraArgs=extra_args
            )
            
            # Get object info
            response = self.client.head_object(Bucket=bucket_name, Key=object_name)
            return {
                'etag': response.get('ETag', '').strip('"'),
                'version_id': response.get('VersionId')
            }
        except ClientError as e:
            raise MinioError(f"Error uploading file '{file_path}' to '{bucket_name}/{object_name}': {e}")
    def upload_folder(self, bucket_name: str, folder_path: str, remote_folder_path: str = "") -> List[Dict]:
        """
        Upload an entire folder to a MinIO bucket.
        
        Args:
            bucket_name: The name of the MinIO bucket.
            folder_path: The local path to the folder to upload.
            remote_folder_path: The remote path in the MinIO bucket (optional, defaults to root of the bucket).
        
        Returns:
            A list of dictionaries containing the details of each uploaded file.
        """
        uploaded_files = []

        # Ensure bucket exists
        if not self.bucket_exists(bucket_name):
            raise MinioError(f"Bucket '{bucket_name}' does not exist.")

        # Walk through the folder
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                local_file_path = os.path.join(root, file)

                # Calculate the object name in MinIO (preserve folder structure)
                relative_path = os.path.relpath(local_file_path, folder_path)
                remote_object_name = os.path.join(remote_folder_path, relative_path)

                try:
                    # Upload each file
                    upload_result = self.upload_file(
                        bucket_name,
                        remote_object_name,
                        local_file_path
                    )

                    # Add the upload result to the list
                    uploaded_files.append({
                        'local_file': local_file_path,
                        'remote_object': remote_object_name,
                        'etag': upload_result['etag'],
                        'version_id': upload_result.get('version_id')
                    })
                except ClientError as e:
                    # Log or handle errors per file
                    print(f"Error uploading {local_file_path}: {e}")
                    continue  # Proceed to the next file

        return uploaded_files

    def download_file(self, bucket_name: str, object_name: str, file_path: str) -> None:
        """
        Download an object from a MinIO bucket to a local file
        
        Args:
            bucket_name: Name of the bucket
            object_name: Name of the object to download
            file_path: Local path where the file will be saved
        """
        try:
            self.client.download_file(bucket_name, object_name, file_path)
        except ClientError as e:
            raise MinioError(f"Error downloading '{bucket_name}/{object_name}' to '{file_path}': {e}")
    
    def get_object(self, bucket_name: str, object_name: str) -> Dict:
        """
        Get an object from a MinIO bucket
        
        Args:
            bucket_name: Name of the bucket
            object_name: Name of the object to get
            
        Returns:
            Dictionary with object data and metadata
        """
        try:
            response = self.client.get_object(Bucket=bucket_name, Key=object_name)
            
            # Read the body data
            body_data = response['Body'].read()
            
            # Extract metadata
            metadata = {
                'content_length': response.get('ContentLength'),
                'content_type': response.get('ContentType'),
                'etag': response.get('ETag', '').strip('"'),
                'last_modified': response.get('LastModified'),
                'metadata': response.get('Metadata', {})
            }
            
            return {
                'data': body_data,
                'metadata': metadata
            }
        except ClientError as e:
            raise MinioError(f"Error getting object '{bucket_name}/{object_name}': {e}")
    
    def list_objects(self, bucket_name: str, prefix: str = "", max_keys: int = 1000) -> List[Dict]:
        """
        List objects in a bucket with optional prefix filtering
        
        Args:
            bucket_name: Name of the bucket
            prefix: Prefix to filter objects (default: "")
            max_keys: Maximum number of keys to return (default: 1000)
            
        Returns:
            List of dictionaries with object information
        """
        try:
            paginator = self.client.get_paginator('list_objects_v2')
            
            result = []
            for page in paginator.paginate(Bucket=bucket_name, Prefix=prefix, PaginationConfig={'MaxItems': max_keys}):
                if 'Contents' in page:
                    for obj in page['Contents']:
                        result.append({
                            'name': obj['Key'],
                            'size': obj['Size'],
                            'last_modified': obj['LastModified'],
                            'etag': obj['ETag'].strip('"')
                        })
            
            return result
        except ClientError as e:
            raise MinioError(f"Error listing objects in bucket '{bucket_name}': {e}")
    
    def delete_object(self, bucket_name: str, object_name: str) -> bool:
        """
        Delete an object from a bucket
        
        Args:
            bucket_name: Name of the bucket
            object_name: Name of the object to delete
            
        Returns:
            True if object was deleted, False if it doesn't exist
        """
        try:
            # Check if object exists
            try:
                self.client.head_object(Bucket=bucket_name, Key=object_name)
            except ClientError as e:
                if e.response['Error']['Code'] == '404':
                    return False
                raise
            
            # Delete the object
            self.client.delete_object(Bucket=bucket_name, Key=object_name)
            return True
        except ClientError as e:
            raise MinioError(f"Error deleting object '{bucket_name}/{object_name}': {e}")
    
    def get_presigned_url(self, bucket_name: str, object_name: str, 
                         expires_in: int = 3600, response_params: Dict = None) -> str:
        """
        Generate a presigned URL for object download
        
        Args:
            bucket_name: Name of the bucket
            object_name: Name of the object
            expires_in: Expiration time in seconds (default: 1 hour)
            response_params: Optional response parameters for the request
            
        Returns:
            Presigned URL string
        """
        try:
            params = {
                'Bucket': bucket_name,
                'Key': object_name
            }
            
            if response_params:
                params.update(response_params)
            
            url = self.client.generate_presigned_url(
                'get_object',
                Params=params,
                ExpiresIn=expires_in
            )
            
            return url
        except ClientError as e:
            raise MinioError(f"Error generating presigned URL for '{bucket_name}/{object_name}': {e}")
    
    def get_presigned_put_url(self, bucket_name: str, object_name: str, 
                             expires_in: int = 3600, content_type: str = None) -> str:
        """
        Generate a presigned URL for object upload
        
        Args:
            bucket_name: Name of the bucket
            object_name: Name of the object
            expires_in: Expiration time in seconds (default: 1 hour)
            content_type: Content type of the object
            
        Returns:
            Presigned URL string for PUT operation
        """
        try:
            params = {
                'Bucket': bucket_name,
                'Key': object_name
            }
            
            if content_type:
                params['ContentType'] = content_type
            
            url = self.client.generate_presigned_url(
                'put_object',
                Params=params,
                ExpiresIn=expires_in
            )
            
            return url
        except ClientError as e:
            raise MinioError(f"Error generating presigned PUT URL for '{bucket_name}/{object_name}': {e}")

# # Example usage
# if __name__ == "__main__":
#     # Example 1: Initialize client and create a bucket
#     minio = MinioClient()
    
#     # Create a bucket
#     try:
#         created = minio.create_bucket('test-bucket')
#         print(f"Bucket created: {created}")
#     except MinioError as e:
#         print(f"Error: {e}")
    
#     # Example 2: Upload a file
#     try:
#         result = minio.upload_file(
#             bucket_name='test-bucket',
#             object_name='example.txt',
#             file_path='/home/xs450-akatag/nexastack-ai-backend/Dockerfile',
#             extra_args={
#                 'ContentType': 'text/plain',
#                 'Metadata': {'created-by': 'minio-boto3-utils'}
#             }
#         )
#         print(f"Upload successful. ETag: {result['etag']}")
#     except MinioError as e:
#         print(f"Error: {e}")
    
#     # Example 3: List objects and generate a presigned URL
#     try:
#         objects = minio.list_objects('test-bucket')
#         for obj in objects:
#             print(f"Object: {obj['name']}, Size: {obj['size']} bytes")
            
#             # Generate a download URL valid for 1 hour
#             url = minio.get_presigned_url('test-bucket', obj['name'], expires_in=3600)
#             print(f"Download URL: {url}")
#     except MinioError as e:
#         print(f"Error: {e}")
    
#     # Example 4: Delete an object
#     try:
#         deleted = minio.delete_object('test-bucket', 'example.txt')
#         print(f"Object deleted: {deleted}")
#     except MinioError as e:
#         print(f"Error: {e}")