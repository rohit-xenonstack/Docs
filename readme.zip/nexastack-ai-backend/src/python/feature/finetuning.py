import time
from feature.multi_model_trainer import MultiModelTrainer
from utils.common import to_snake_case,get_value

# Main execution
def fine_tune(data,model_name):   
    try:        
        # Initialize trainer
        trainer = MultiModelTrainer(
            model_name=model_name, 
            task_type='CAUSAL_LM',
            quantization=get_value(data,"quantization"),
            lora_training=get_value(data,"lora_training")
        )
        
        # Prepare dataset
        dataset = trainer.prepare_dataset()
        
        # Train the model
        trainer.train(
            dataset=dataset, 
            output_dir=f'./src/python/outputs/{model_name.replace("/", "_")}',
            data=data,
        )
    
    except Exception as e:
        print(f"Error training {model_name}: {e}")
        import traceback
        traceback.print_exc()