import os
import torch
import sys
import subprocess
from utils.common import get_value

# Dependency installation function
def install_dependencies():
    subprocess.check_call([sys.executable, '-m', 'pip', 'install', 
        '-U',
        'transformers', 
        'datasets', 
        'accelerate', 
        'bitsandbytes',
        'deepspeed',
        'peft'
    ])

#install_dependencies()

import torch
from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer, 
    TrainingArguments, 
    Trainer,
    DefaultDataCollator
)
from datasets import load_dataset, Dataset
from peft import (
    prepare_model_for_kbit_training,
    LoraConfig,
    get_peft_model,
    TaskType
)
from transformers import BitsAndBytesConfig

class MultiModelTrainer:
    def __init__(
        self, 
        model_name: str = "Qwen/Qwen2-0.5B-Instruct", 
        task_type: str = 'CAUSAL_LM',
        quantization: bool = False,
        lora_training: bool = True
    ):
        """
        Initialize model trainer
        
        Args:
            model_name (str): Hugging Face model name
            task_type (str): Type of model task
            quantization (bool): Use quantization
            lora_training (bool): Use LoRA for efficient fine-tuning
        """
        self.model_name = model_name
        self.task_type = getattr(TaskType, task_type)
        self.quantization = quantization
        self.lora_training = lora_training
        
        # Load model and tokenizer
        self._load_model_and_tokenizer()
    
    def _load_model_and_tokenizer(self):
        """Load model and tokenizer with optional quantization"""
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        
        # Set pad token if not set
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load model
        try:
            # Prepare model loading arguments
            model_loading_args = {
                "pretrained_model_name_or_path": self.model_name,
                "device_map": "auto",
                "torch_dtype": torch.float16,
                "use_cache": False,  # Important for training
                "trust_remote_code": True  # For models that require it
            }
            
            # Apply quantization if specified
            if self.quantization:
                quantization_config = BitsAndBytesConfig(
                    load_in_8bit=True,
                    bnb_8bit_compute_dtype=torch.float16
                )
                model_loading_args["quantization_config"] = quantization_config
            
            # Load model
            self.model = AutoModelForCausalLM.from_pretrained(**model_loading_args)
            
            # Prepare for LoRA training
            if self.lora_training:
                self._apply_lora()
        
        except Exception as e:
            print(f"Model loading error: {e}")
            raise
    
    def _apply_lora(self):
        """Apply LoRA configuration for efficient fine-tuning"""
        try:
            # Define target modules (can be model-specific)
            target_modules = self._get_target_modules()
            
            # LoRA configuration
            lora_config = LoraConfig(
                r=16,  # Rank of LoRA adaptation
                lora_alpha=32,  # Scaling factor
                target_modules=target_modules,
                lora_dropout=0.1,
                bias="none",
                task_type=self.task_type
            )
            
            # Prepare model for kbit training
            self.model = prepare_model_for_kbit_training(self.model)
            
            # Get PEFT model
            self.model = get_peft_model(self.model, lora_config)
            
            # Print trainable parameters
            self.model.print_trainable_parameters()
        
        except Exception as e:
            print(f"LoRA application error: {e}")
            raise
    
    def _get_target_modules(self):
        """
        Get target modules based on model name
        This allows for model-specific LoRA configurations
        """
        model_specific_modules = {
            "Qwen/Qwen2-0.5B-Instruct": [
                "self_attn.q_proj", 
                "self_attn.k_proj", 
                "self_attn.v_proj",
                "self_attn.o_proj",
                "mlp.gate_proj",
                "mlp.down_proj",
                "mlp.up_proj"
            ],
            "meta-llama/Llama-2-7b-chat-hf": [
                "q_proj", 
                "k_proj", 
                "v_proj", 
                "o_proj",
                "gate_proj",
                "down_proj",
                "up_proj"
            ],
            "google/gemma-7b-it": [
                "q_proj", 
                "k_proj", 
                "v_proj", 
                "o_proj",
                "gate_proj",
                "down_proj",
                "up_proj"
            ]
        }
        
        return model_specific_modules.get(
            self.model_name, 
            ["q_proj", "k_proj", "v_proj", "o_proj"]  # Default fallback
        )
    
    def prepare_dataset(
        self, 
        dataset_name: str = 'databricks/databricks-dolly-15k', 
        text_column: str = 'instruction',
        max_length: int = 512
    ):
        """
        Prepare dataset for training
        
        Args:
            dataset_name (str): Hugging Face dataset name
            text_column (str): Column name for text data
            max_length (int): Maximum sequence length
        
        Returns:
            Tokenized dataset
        """
        # Load dataset
        try:
            data = load_dataset(dataset_name, split='train')
        except Exception as e:
            print(f"Failed to load dataset: {e}")
            # Fallback to sample dataset
            data = Dataset.from_dict({
                text_column: ["Sample text for training"]
            })
        
        def tokenize_function(examples):
            # Tokenize with labels set to input_ids for language modeling
            tokenized = self.tokenizer(
                examples[text_column], 
                truncation=True, 
                max_length=max_length, 
                padding='max_length'
            )
            
            # Add labels (for causal language modeling, labels are the same as input_ids)
            tokenized['labels'] = tokenized['input_ids'].copy()
            return tokenized
        
        # Tokenize dataset
        return data.map(
            tokenize_function, 
            batched=True, 
            remove_columns=data.column_names
        )
    
    def train(
        self, 
        dataset,
        output_dir: str = './model_output',
        data={},
    ):
        """
        Train the model
        
        Args:
            dataset: Prepared dataset
            output_dir (str): Directory to save model
            data (dict): query data for variables
        """
        # Create default data collator
        data_collator = DefaultDataCollator()
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=output_dir,
            overwrite_output_dir=get_value(data,"overwrite_output_dir",True),
            num_train_epochs=get_value(data,"num_train_epochs",1),
            per_device_train_batch_size=get_value(data,"per_device_train_batch_size",2),
            gradient_accumulation_steps=get_value(data,"gradient_accumulation_steps",4),
            learning_rate=get_value(data,"learning_rate",5e-5),
            warmup_steps=get_value(data,"warmup_steps",100),
            logging_dir='./logs',
            logging_steps=get_value(data,"logging_steps",10),
            save_steps=get_value(data,"save_steps",500),
            save_total_limit=get_value(data,"save_total_limit",2),
            fp16=get_value(data,"fp16",True), # Enable fp16
        )
        
        # Fp16 bool - True
        # Save Steps - Integer
        # save_total_limit - Integer
        # gradient_accumulation_steps - Integer
        # num_train_epochs - Integer
        # per_device_train_batch_size - Integer
        # learning_rate - Float
        # warmup_steps - Integer
        # logging_steps - Integer
        # fp16 - Boolean
        # lora_training - Boolean
        
        # Enable fp16 if specified
        if training_args.fp16:
            self.model.half()
        
        # Apply LoRA if specified
        
        # Create trainer using standard Trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=dataset,
            data_collator=data_collator,
        )
        
        # Start training
        trainer.train()
        
        # Save the model
        trainer.save_model(output_dir)
        print(f"Model saved to {output_dir}")
