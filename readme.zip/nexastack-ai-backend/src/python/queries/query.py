get_fields_in_formation_by_user = """WITH active_values AS (
    SELECT 
        fv.id as fv_id, fv.model_config_id,fv.field_id,
        jsonb_array_elements(fv.value::jsonb) AS elem
    FROM fine_tune_field_values fv
    WHERE fv.created_by = 124
)
SELECT 
    ffm.name, 
    ffm.field_type, 
    fm.model_name,
    fm.model_path,
    (elem ->> 'value') AS value
FROM active_values av
JOIN fine_tune_model_configurations fm ON av.fv_id = any(fm.field_configurations)
JOIN fine_tune_field_metadata ffm ON av.field_id = ffm.id"""