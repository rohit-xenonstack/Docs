package jwtToken

import (
	"errors"
	"os"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/ginjwt"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
)

// GinJwtToken is a method for creating claims map to be added in a token
// and also save sessions in cockroach database and redis database
func GinJwtToken(acs database.Accounts) (map[string]interface{}, error) {
	claims := make(map[string]interface{})
	// populate claims map
	claims["id"] = acs.ID
	claims["name"] = acs.Name
	claims["email"] = acs.Email
	claims["sys_role"] = acs.RoleID

	// generate jwt token, expiration time and extra info like (expire jwt time, start and end time)
	mapd, info := ginjwt.GinJwtToken(claims)

	// check token is empty or not
	if mapd["token"].(string) == "" {
		return mapd, nil
	}

	// remove all other sessions from session storage and save this session
	err := SaveSessions(acs.ID, mapd["token"].(string), info)
	if err != nil {
		config.Log.Error(err)
		return mapd, err
	}
	return mapd, nil
}

// JwtToken is a function to generate jwt token and pass workspace details in claims
func JwtToken(acs database.Accounts, workspace, role, environment string, projectId int) (map[string]interface{}, error) {

	claims := make(map[string]interface{}, 0)

	if environment == "" {
		environment = os.Getenv("ENVIRONMENT")
	}

	claims["id"] = acs.ID
	claims["name"] = acs.Name
	claims["email"] = acs.Email
	claims["sys_role"] = acs.RoleID
	claims["environment"] = environment
	claims["project_id"] = projectId

	if workspace != "" {
		claims["workspace"] = workspace
		claims["role"] = role
	}
	mapd, info := ginjwt.GinJwtToken(claims)
	if val, ok := mapd["token"].(string); !ok || val == "" {
		return mapd, nil
	}

	// remove all other sessions from session storage and save this session
	// err := SaveSessions(methods.ConvertID(claims["id"]), mapd["token"].(string), info)
	// if err != nil {
	// 	config.Log.Error(err)
	// 	return mapd, err
	// }

	// Try saving session to Redis, but continue even if it fails
	err := SaveSessions(methods.ConvertID(claims["id"]), mapd["token"].(string), info)
	if err != nil {
		config.Log.Warnf("Redis session save failed for user %s: %v", acs.Email, err)
		// Optionally: tag in claims that Redis failed
		mapd["redis_error"] = "session not stored: " + err.Error()
		// Do not return error, allow login to proceed
	}
	return mapd, nil
}

// JwtRefreshToken is a method for save old claims in a token
// and also save sessions in cockroach database and redis database
func JwtRefreshToken(claims map[string]interface{}) (map[string]interface{}, error) {

	// generate jwt token, expiration time and extra info like (expire jwt time, start and end time)
	mapd, info := ginjwt.GinJwtToken(claims)

	// check token is empty or not
	if mapd["token"].(string) == "" {
		return mapd, nil
	}
	// remove all other sessions from session storage and save this session
	err := SaveSessions(methods.ConvertID(claims["id"]), mapd["token"].(string), info)
	if err != nil {
		config.Log.Error(err)
		return mapd, err
	}
	return mapd, nil
}

// SaveSessions is a method for saving session details in redis and cockroachdb
func SaveSessions(id int, newSessToken string, info map[string]interface{}) error {

	db := config.DB
	err := redisdb.SaveToken(newSessToken, id, info["expire"].(time.Duration))
	if err != nil {
		config.Log.Error(err)
		return errors.New("Internal Server Error")
	}
	// deleting other active sessions of that user
	if config.Conf.Service.IsLogoutOthers == "true" {
		// fetch active session from dbs
		var actses []database.ActiveSessions
		db.Where("userid=?", id).Find(&actses)

		// delete all session from db
		db.Where("userid=?", id).Delete(&database.ActiveSessions{})
	}

	// creating one active session

	db.Create(&database.ActiveSessions{
		Userid:    id,
		SessionID: newSessToken,
		Start:     info["start"].(int64),
		End:       info["end"].(int64)})

	return nil
}

// DeleteTokenFromDb is a method to delete saved jwt token from db
func DeleteTokenFromDb(token string) {
	db := config.DB
	db.Debug().Exec("delete from active_sessions where session_id= '" + token + "';")
}
