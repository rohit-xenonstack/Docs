package activities

import (
	"encoding/json"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
)

// RecordActivity is a method use to record activity of a user in activity table
func RecordActivity(activity database.Activities) {
	// connecting to db
	db := config.DB

	// recording users activities
	db.Debug().Create(&activity)
}

// GetLoginActivities is a method used to get login activities of a user
func GetLoginActivities(email string) ([]database.Activities, error) {
	// connecting to db
	db := config.DB

	// fetching activities of user from activities table
	var activities []database.Activities
	db.Where("email=?", email).Order("timestamp desc").Find(&activities)
	if db.Error != nil {
		config.Log.Error(db.Error)
		return activities, db.Error
	}
	return activities, nil
}

func GetAvtivity(byteData []byte) ([]byte, error) {

	list, _ := GetLoginActivities(string(byteData))
	return json.Marshal(&list)
}
