package methods

import (
	"strconv"

	"git.xenonstack.com/nexa-platform/accounts/config"
)

// ConvertID into int
func ConvertID(i interface{}) int {
	var id int
	switch v := i.(type) {
	case int:
		id = i.(int)
	case string:
		id, _ = strconv.Atoi(i.(string))
	case float64:
		id = int(i.(float64))
	case float32:
		id = int(i.(float32))
	default:
		config.Log.Error("The type of interface is %T", v)
		id = 0
	}
	return id
}
