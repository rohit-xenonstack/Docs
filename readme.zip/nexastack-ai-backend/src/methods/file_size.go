package methods

import "errors"

//CheckFileSize function used for check file size
func CheckFileSize(size int) error {

	kilobytes := size / 1024

// if file less then 1 kb return nil
	if kilobytes < 0 {
		return nil
	}
    megabytes := float64(kilobytes) / 1024
	//if file less then 1 mb return nil
	if megabytes < 1 {
		return nil
	}
	return errors.New("file size must be less then 1 mb")
}
