package methods

import (
	// "bytes"
	"fmt"

	"os"

	"gopkg.in/yaml.v3"
)

type AnsibleVars struct {
	// AnsibleBecomePass  string `yaml:"ansible_become_pass"`
	// AnsibleSSHPass     string `yaml:"ansible_ssh_pass"`
	KubeadmJoinCommand string `yaml:"kubeadm_join_command"`
}

func UpdateYamlFile(ymlFilePath string, changingValues map[string]interface{}, token string) error {
	yamlData, err := os.ReadFile(ymlFilePath)
	if err != nil {
		return fmt.Errorf("failed to read YAML file: %v", err)
	}

	var ansibleVars []map[string]interface{}
	err = yaml.Unmarshal(yamlData, &ansibleVars)
	if err != nil {
		return fmt.Errorf("failed to unmarshal YAML: %v", err)
	}

	for _, vars := range ansibleVars {
		if vars["vars"] != nil {
			varsMap, ok := vars["vars"].(map[string]interface{})
			if ok {
				// varsMap["ansible_become_pass"] = changingValues["ansible_become_pass"]
				// varsMap["ansible_ssh_pass"] = changingValues["ansible_ssh_pass"]
				varsMap["kubeadm_join_command"] = fmt.Sprintf("%s --node-name %s",
					token, changingValues["node_name"].(string))
			}
		}
	}

	yamlData, err = yaml.Marshal(ansibleVars)
	if err != nil {
		return fmt.Errorf("failed to marshal YAML: %v", err)
	}

	return os.WriteFile(ymlFilePath, yamlData, 0644)
}

func CreateInventoryFile(ip, name string, sshPort int) error {
	inventoryFilePath := "ansible/inventory"
	inventoryFileContent := fmt.Sprintf("[my_servers]\n%s ansible_user=%s ansible_port=%d ansible_python_interpreter=/usr/bin/python3 ansible_connection=ssh",
		ip, name, sshPort)

	err := os.WriteFile(inventoryFilePath, []byte(inventoryFileContent), 0644)
	if err != nil {
		return fmt.Errorf("failed to create inventory file: %v", err)
	}

	return nil
}

// func CreatekeyFile(data []byte) (map[string]interface{}, error) {
// 	mapd := make(map[string]interface{})
// 	mapd["error"] = false
// 	path := "/home/xs453-ansgoy/Downloads/ansible-playbook-workernode/key"
// 	f, err := os.Create(path)
// 	if err != nil {
// 		log.Print(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, err
// 	}
// 	defer f.Close() // close the file to prevent leaks
// 	// defer os.Remove(path) // remove the file after use

// 	_, err = f.Write(data)
// 	if err != nil {
// 		log.Println(err)
// 		mapd["error"] = true
// 		mapd["message"] = err.Error()
// 		return mapd, err
// 	}

// 	mapd["key_path"] = path
// 	mapd["error"] = false

// 	return mapd, nil

// }
