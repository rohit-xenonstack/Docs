package signin

import (
	"strconv"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
)

// SimpleSignin is a method for checking email is there
// then password is matching with password saved in db
// correspondance to that email and then check account status
func SimpleSignin(email, password string) (bool, bool, string, database.Accounts) {

	//connection to db
	db := config.DB

	//Checking whether registered or not
	var account []database.Accounts
	db.Where("email=?", email).Find(&account)

	// when no account found
	if len(account) == 0 {
		return false, false, "Invalid email or password.", database.Accounts{}
	}

	// checking previous failed logins
	msg, isAccLocked, count := checkPreviousFailedLogins(account[0])
	if isAccLocked {
		// when account is locked
		return true, false, msg, account[0]
	}

	// checking password with saved password
	if methods.CheckHashForPassword(account[0].Password, password) {
		// when password matched
		// checking account status
		switch account[0].AccountStatus {
		case "active":
			// when user is active all well
			return false, true, "", account[0]
		case "blocked":
			// when user is blocked
			return false, false, "Your account has been blocked.", database.Accounts{}
		case "new":
			// when user is new not verified
			return false, false, "Please verify your email.", database.Accounts{}
		}
	}
	// when password not matched
	return false, false, "Invalid email or password. You have " + strconv.Itoa(count) + " login attempts left", database.Accounts{}
}

//==============================================================================

// checkPreviousFailedLogins is a method for checking previous failed login of a user
func checkPreviousFailedLogins(account database.Accounts) (string, bool, int) {
	// declaring variables
	var lockFor int64 = 3600
	var failedloginCount int
	var msg string
	var isLocked bool

	// connecting to db
	db := config.DB

	var LastFailedAttempt int64
	// extracting activities on bsis of id
	var activities []database.Activities
	db.Raw("select * from activities where email= '" + account.Email + "' order by timestamp desc limit 5;").Scan(&activities)
	for i := 0; i < len(activities); i++ {
		// if activity name is failed login and checking time interval is less then lockfor
		if activities[i].Status == "fail" && (time.Now().Unix()-activities[i].Timestamp) < lockFor {
			if i == 0 {
				// setting last failed attemp
				LastFailedAttempt = activities[i].Timestamp
			}
			// incrementing failed login count
			failedloginCount++
		} else {
			break
		}
	}

	// is count is more then equal to 5
	if failedloginCount >= 5 {
		msg = "Your account has been locked due to five invalid attempts. Either reset your password by clicking Forgot Password or try after " + time.Duration(1e9*(lockFor-time.Now().Unix()+LastFailedAttempt)).String() + "."
		isLocked = true
		return msg, isLocked, 0
	}

	return "", false, 5 - failedloginCount
}
