package signin

import (
	"log"
	"os"
	"strings"
	"testing"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/methods"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/sqlite"
	_ "github.com/mattn/go-sqlite3"
)

const (
	email    string = "test@test.com"
	name     string = "test"
	password string = "Admin#123"
)

var (
	id int
)

func init() {

	os.Remove(os.Getenv("HOME") + "/account-testing.db")
	db, err := gorm.Open("sqlite3", os.Getenv("HOME")+"/account-testing.db")
	if err != nil {

		log.Println(err)
		log.Println("Exit")
		os.Exit(1)
	}
	config.DB = db
	database.CreateDatabaseTables()

}

func TestSignIn(t *testing.T) {

	//conection to db

	db := config.DB

	acc := database.Accounts{}
	//save data in account table
	acc.Name = name
	acc.Email = email
	acc.AccountStatus = "active"
	acc.Password = methods.HashForNewPassword(password)
	db.Create(&acc)
	id = acc.ID

	//test case 1 -> when account status is active
	_, _, str, _ := SimpleSignin(email, password)
	if str != "" {
		t.Error("test case fail", str)
	}

	acc.AccountStatus = "blocked"
	db.Save(&acc)
	//test case 2 -> when account status is blocked
	_, _, str, _ = SimpleSignin(email, password)
	if str != "Your account has been blocked." {
		t.Error("test case fail", str)
	}

	acc.AccountStatus = "new"
	db.Save(&acc)
	//test case 3 -> when account status is new
	_, _, str, _ = SimpleSignin(email, password)
	if str != "Please verify your email." {
		t.Error("test case fail", str)
	}

	//test case 4 -> when wrong email pass
	_, _, str, _ = SimpleSignin("email", password)
	if str != "Invalid email or password." {
		t.Error("test case fail", str)
	}

	//test case 5 -> when wrong password pass
	_, _, str, _ = SimpleSignin(email, "password")
	if !strings.Contains(str, "Invalid email or password. You have ") {
		t.Error("test case fail", str)
	}
}
