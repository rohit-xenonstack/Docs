//go:build !test
// +build !test

package workspace

import (
	"errors"
	"strings"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/helm"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"github.com/gin-gonic/gin"
)

// CreateWorkspace is a method to create workspace
// save in database
func CreateWorkspace(c *gin.Context, email, token string, data database.Workspaces) (int, map[string]interface{}) {
	//result map
	mapd := make(map[string]interface{})
	// checking workspace url is correct
	wsURLParts := strings.Split(data.WorkspaceID, ".")
	if len(wsURLParts) != 0 && wsURLParts[0] == "" {
		mapd["error"] = true
		mapd["message"] = "WorkSpace URL is required."
		return 400, mapd
	}
	if !IsWorkspaceURLValid(wsURLParts[0]) {
		mapd["error"] = true
		mapd["message"] = "URL should not contain special characters."
		return 400, mapd
	}

	// connect to database
	db := config.DefaultDb

	config.Log.Debug(wsURLParts[0])

	// checking workspace already not present
	var count int64
	db.Model(&database.Workspaces{}).Where("workspace_id=?", wsURLParts[0]).Count(&count)
	if count != 0 {
		mapd["error"] = true
		mapd["message"] = "Workspace already exists."

		return 409, mapd
	}

	loginac, err := accounts.GetAccountForEmail(email)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = "Please create account first"
		return 501, mapd
	}

	// Create an instance of ReleaseConfig
	var ws helm.ReleaseConfig
	ws.WorkspaceURL = data.WorkspaceID // Set the workspace URL
	ws.Dry = false                     // Set other fields as needed
	ws.Context = ""                    // Set context if needed
	ws.Values = ""                     // Set values if needed

	// Call the new CreateWorkspace function
	vals := c.Request.URL.Query() // Get query parameters
	mapd, code := helm.InstallWorkspace(ws, vals, loginac.Name)
	if code != 200 {
		return code, mapd // Return the error response from helm.InstallWorkspace
	}

	// if team name is nil
	if data.TeamName == "" {
		data.TeamName = wsURLParts[0]
	}

	// creating workspace
	db.Create(&database.Workspaces{
		WorkspaceID: wsURLParts[0],
		Status:      "new",
		TeamName:    data.TeamName,
		TeamSize:    data.TeamSize,
		TeamType:    data.TeamType,
		Created:     time.Now().Unix()})

	// Create a Minio bucket with the same name as the workspace
	// err = minioBucket.CreateMinioBucket(wsURLParts[0])
	// if err != nil {
	// 	config.Log.Error(err)
	// 	mapd["error"] = true
	// 	mapd["message"] = err.Error()
	// 	return 500, mapd
	// }

	// add owner
	db.Create(&database.WorkspaceMembers{
		WorkspaceID: wsURLParts[0],
		MemberEmail: email,
		Role:        "owner",
		Joined:      time.Now().Unix(),
	})

	// create jwt token
	mapd, err = jwtToken.JwtToken(loginac, wsURLParts[0], "owner", data.Environment, data.ProjectId)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return 503, mapd
	}

	mapd["name"] = loginac.Name
	mapd["role_id"] = loginac.RoleID
	mapd["email"] = loginac.Email
	mapd["workspace_role"] = "owner"
	mapd["id"] = loginac.ID
	mapd["workspace_id"] = wsURLParts[0]
	mapd["workspace_name"] = data.TeamName
	mapd["message"] = "Workspace created."

	return 200, mapd
}

// WorkspaceJWT is structure to be send in body for deploying a workspace
type WorkspaceJWT struct {
	WorkspaceURL string `json:"workspace_url"`
}

// ======================

// CheckWorkspaceAvailability is a method to check workspace is there in database or not
func CheckWorkspaceAvailability(data database.Workspaces) (int, string) {
	config.Log.Debug(data)

	// check workspace url is valid
	if !IsWorkspaceURLValid(data.WorkspaceID) {
		return 400, "URL should not contain special characters."
	}

	// connecting to db
	db := config.DefaultDb
	// checking workspace already not present
	var count int64
	db.Debug().Model(&database.Workspaces{}).Where("workspace_id=?", data.WorkspaceID).Count(&count)
	config.Log.Debug(count)
	if count != 0 {
		return 409, "Workspace already exists."
	}
	err := CheckWorkspace(data.WorkspaceID)
	if err != nil {
		return 409, err.Error()
	}

	return 200, "Available."
}

// IsWorkspaceURLValid function or method for check workspace name
func IsWorkspaceURLValid(name string) bool {
	for i := 0; i < len(name); i++ {
		if !((name[i] > 47 && name[i] < 58) || (name[i] > 64 && name[i] < 91) || (name[i] > 96 && name[i] < 123) || name[i] == 45 || name[i] == 95) {
			return false
		}
	}
	return true
}

// CheckWorkspace is function for check workspace name authorized or not
func CheckWorkspace(name string) error {
	if config.Conf.Service.Workspaces != "" {
		ws := strings.Split(config.Conf.Service.Workspaces, ",")
		for i := 0; i < len(ws); i++ {
			if ws[i] == name {
				return errors.New("this workspace name is not available")
			}
		}
	}
	return nil
}

//=========================================================================//

// Login is a method to login in workspace
func Login(wsURL string) (int, map[string]interface{}) {
	//result map
	mapd := make(map[string]interface{})
	// connecting to db
	db := config.DB
	// details of workspace
	ws := []database.Workspaces{}
	db.Where("workspace_id= ?", wsURL).Find(&ws)
	if len(ws) == 0 {
		mapd["error"] = true
		mapd["message"] = "Workspace Not Found"
		return 404, mapd
	}
	mapd["error"] = false
	mapd["worksapce"] = ws[0]
	return 200, mapd
}
