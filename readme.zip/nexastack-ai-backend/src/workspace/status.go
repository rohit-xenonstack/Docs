//+bulid !test

package workspace

import (
	"crypto/tls"
	"net/http"
	"strings"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/jwtToken"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
)

// Status is a method to check workspace deployed or not
func Status(wsURL string) (int, map[string]interface{}) {
	//result map
	mapd := make(map[string]interface{})
	// urls for checking workspace is deployed or not
	urls := []string{
		"https://" + wsURL,
	}

	//fetch workspace service from config and check the status of service
	if config.Conf.Service.WSServices != "" {
		status := strings.Split(config.Conf.Service.WSServices, ",")
		for i := 0; i < len(status); i++ {
			urls = append(urls, "https://"+wsURL+status[i])
		}
	}
	config.Log.Debug(urls)
	// insecure transport enable
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}
	// intialize http client
	client := &http.Client{Transport: tr}

	// checking each url status by sending http request
	for i := 0; i < len(urls); i++ {
		config.Log.Debug("Checking for URL: ", urls[i])
		req, err := http.NewRequest("GET", urls[i], nil)
		if err != nil {
			config.Log.Error("Error while creating http request for "+urls[i]+": ", err)
			mapd["error"] = true
			mapd["message"] = "Please wait ! Creation of " + wsURL + " workspace is in progress."
			return 202, mapd
		}
		resp, err := client.Do(req)
		if err != nil {
			config.Log.Error("Error while sending request for "+urls[i]+": ", err)
			mapd["error"] = true
			mapd["message"] = "Please wait ! Creation of " + wsURL + " workspace is in progress."
			return 202, mapd
		}

		config.Log.Debug("Status for " + urls[i] + ": " + resp.Status)

		if resp.StatusCode != 200 {
			mapd["error"] = true
			mapd["message"] = "Please wait ! Creation of " + wsURL + " workspace is in progress."
			return 202, mapd
		}
	}

	// connect to database
	db := config.DB

	// split workspace url in parts
	wsURLParts := strings.Split(wsURL, ".")

	// fetch member detail of workpsace
	var mem []database.WorkspaceMembers
	db.Where("workspace_id=? AND role=?", wsURLParts[0], "owner").Find(&mem)
	config.Log.Debug(mem)
	if len(mem) == 0 {
		mapd["error"] = true
		mapd["message"] = "Please create workspace first"
		return 501, mapd
	}
	// fetch member details
	loginac, err := accounts.GetAccountForEmail(mem[0].MemberEmail)
	if err != nil {

		mapd["error"] = true
		mapd["message"] = "Please create account first"
		return 501, mapd
	}

	// fetch workspace details
	var work []database.Workspaces
	db.Where("workspace_id = ?", wsURLParts[0]).Find(&work)
	config.Log.Debug(work)
	if len(work) == 0 {
		mapd["error"] = true
		mapd["message"] = "Please create workspace first"
		return 501, mapd
	}

	//send mails
	go sendNotificationMails(loginac, wsURLParts[0])

	// create jwt token
	mapd, err = jwtToken.JwtToken(loginac, wsURLParts[0], mem[0].Role, "", 0)
	if err != nil {
		mapd["error"] = true
		mapd["message"] = err.Error()
		return 503, mapd

	}
	mapd["name"] = loginac.Name
	mapd["role_id"] = loginac.RoleID
	mapd["email"] = loginac.Email
	mapd["workspace_role"] = mem[0].Role
	mapd["workspace_name"] = work[0].TeamName
	mapd["message"] = "Your workspace is ready to use."

	//send final result
	return 200, mapd
}

func sendNotificationMails(acc database.Accounts, wsID string) {
	mapd := map[string]interface{}{
		"Workspace": wsID,
		"Name":      acc.Name,
		"Email":     acc.Email,
		"Phone":     acc.ContactNo,
	}

	// readtoml file to fetch template path, subject and images path to be passed in mail
	tmplPath, subject, images := mail.ReadToml("notification")

	// parse email template
	tmpl := mail.EmailTemplate(tmplPath, mapd)
	mails := strings.Split(config.Conf.Service.Mails, ",")
	//now sending mail
	for i := 0; i < len(mails); i++ {
		mail.SendMail(mails[i], subject, tmpl, images)
	}
}
