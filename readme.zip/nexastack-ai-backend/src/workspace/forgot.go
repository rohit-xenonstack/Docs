//+bulid !test

package workspace

import (
	"errors"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/accounts"
	"git.xenonstack.com/nexa-platform/accounts/src/mail"
	"git.xenonstack.com/nexa-platform/accounts/src/verifytoken"
)

// Forgot is a method to send recover workspace mail to a valid account
func Forgot(email string) error {

	//connection to db
	db := config.DB
	// fetch account details on basis of email
	acc, err := accounts.GetAccountForEmail(email)
	if err != nil {
		config.Log.Error(err)
		return err
	}

	if acc.VerifyStatus == "not_verified" {
		return errors.New("please verify your account first")
	}

	//fetch workspace ids correspondance to that user
	members := []database.WorkspaceMembers{}
	db.Where("member_email=?", email).Find(&members)
	if len(members) < 1 {
		return errors.New("no workspace is assigned to you")
	}

	go mail.SendRecoveryMail(acc)
	return nil
}

// WorkSpaceEmail is a structure for sending list of workspaces recovered by token
type WorkSpaceEmail struct {
	database.Workspaces
	Email string
}

// RecoverWorkspace is a method to list all the workspaces related to that user on basis of recover workspace token
func RecoverWorkspace(token string) (int, map[string]interface{}) {
	mapd := make(map[string]interface{})

	//Checking token in database
	tok, err := verifytoken.CheckToken(token)
	if err != nil {
		config.Log.Error(err)
		mapd["error"] = true
		mapd["message"] = err.Error()
		return 404, mapd
	}
	config.Log.Debug(tok)
	//check token task
	if tok.TokenTask != "recover_workspace" {
		mapd["error"] = true
		mapd["message"] = "Invalid or expired token."
		return 404, mapd
	}

	mapd["error"] = false
	mapd["workspaces"] = workspaceList(tok.Userid)
	return 200, mapd
}

// workspaceList is a method to fetch workspace correspondance to user on basis of id
func workspaceList(id int) []WorkSpaceEmail {

	// array with workspace list
	workspaces := make([]WorkSpaceEmail, 0)
	// connecting to db
	db := config.DB

	// fetch account on basis of id
	acc := accounts.GetAccountForid(id)

	members := []database.WorkspaceMembers{}
	db.Where("member_email=?", acc.Email).Find(&members)

	// fetch workspace detail correspondance to each workspace id
	for i := 0; i < len(members); i++ {
		ws := []database.Workspaces{}
		db.Where("workspace_id = ?", members[i].WorkspaceID).Find(&ws)
		if len(ws) != 0 {
			workspaces = append(workspaces, WorkSpaceEmail{ws[0], acc.Email})
		}
	}
	return workspaces
}
