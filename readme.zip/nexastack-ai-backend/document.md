## Admin -> Delete Accounts and Workspace


Delete workspace and account info use API with admin token

```
Delete request:-

https://baseurl/v1/admin/workspaces/:workspace_id

add header :- Authorization : Bearer jwt_token

for Example:-

workspace -> akshay.nexa.xenon.team

http://auth.nexa.xenon.team/v1/admin/workspaces/akshay.nexa.xenon.team

header :- Authorization : Bearer aeglbvlaivbyba14.asyfvblsd7q54o716535.aufbeauyvrywt8324568gfug28tf

```
