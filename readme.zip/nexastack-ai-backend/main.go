//go:build !test
// +build !test

package main

import (
	"flag"
	"io"
	"os"
	"strconv"
	"time"

	"git.xenonstack.com/nexa-platform/accounts/config"
	"git.xenonstack.com/nexa-platform/accounts/database"
	"git.xenonstack.com/nexa-platform/accounts/src/redisdb"
	"git.xenonstack.com/nexa-platform/accounts/src/routes"
	"git.xenonstack.com/nexa-platform/accounts/src/scheduler"
	"github.com/gin-contrib/cors"
	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/joho/godotenv"
)

// @title NexaStack AI Backend API
// @version 1.0
// @description This is the API documentation for NexaStack AI Backend.
// @host nexastack-backend.stage.neuralcompany.team/
// @schemes https
// @x-logo {"url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAicAAACXCAYAAADOBfuBAAAACXBIWXMAAAsSAAALEgHS3X78AAAYOUlEQVR4nO3dvW4cyXrG8ZJ9YBiwgdncAWn6AkSmggFSGbGJeADlolIHK+oKNLoCjfYGOMoFHAowFsxEJpsOeQNc8gosAs5plPzWntZwZrre6qrqqu7/DyCwH+RMf9fT9fnk4eHBAAAAlOIfOBMAAKAkhBMAAFAUwgkAACjKX5ob8+znzwfGmO3ff3s55zTF8eznz8fGmBNjzMHvv738NoR9AgAgpVU1J6dSoKIjOY6nxpinxpiLZz9//oljCgDAZuuadQgoHTWCiUNAAQDAw6Y+JwSUQCuCiUNAAQCgRVuHWAKK0oZg4hBQAADYwGe0DgHFk0cwcQgoAACs4TuUmIDSQhFMHAIKAAAraOY5IaCsERBMHAIKAABLtJOwEVCWdAgmDgEFAICGkBliCSgiQjBxCCgAAIjQ6etHH1AiBhOHgAIAGD3TcW2d0QaUBMHEIaAAAEav68J/owsoCYOJQ0ABAIxajFWJRxNQMgQTh4ACABitGOHEjCGgZAwmDgEFADBKscKJGXJA6SGYOAQUAMDoxAwnZogBpcdg4hBQAACjEjucmCEFlAKCiUNAAQCMRopwYs2e/fx5t+aDWFAwcQgoAIBRSBVOJlKQVhlQCgwmDgEFADB4qcKJqTWgFBxMHAIKAGDQUoYTU1tAqSCYOAQUAMBgpQ4nppaAUlEwcQgoAIBByhFOTOkBpcJg4hBQAACDkyucmFIDSsXBxCGgAAAGJWc4MaUFlAEEE4eAAgAYjNzhxJQSUAYUTBwCCgBgEPoIJ6bvgDLAYOIQUAAA1esrnJi+AsqAg4lDQAEAVK3PcGJyB5QRBBOHgAIAqFbf4cTkCigjCiYOAQUAUKUSwolJHVBGGEwcAgoAoDqlhBOTKqCMOJg4BBQAQFVKCicmdkAhmPyJgAIAqEZp4cTECigEk0cIKACAKpQYTkzXgEIwWYuAAgAoXqnhxIQGFIJJKwIKAKBoJYcTIwHlzLcgJZh4I6AAAIpVejixtnwKUoKJGgEFAFCkGsKJaStICSbBCCgAgOLUEk7MuoKUYNIZAQUAUJSawolZLkgJJtEQUAAAxagtnJhGQfpfBJOoCCgAgCL8pdLTYAvSfzLGPC9gW1r9y+Q/dv/5X//tQ+GbaT198uQf/9MY898FbAsAYKRqDSfW1e+/vbwoYDtavfzlofAt/MH/FrQtAIARqjmcoGI7e4cHxpivnnvw9mZxPsuxtzt7h5okeXmzOD9IuDkA0JnyeWu9v1mcT/s88jX2OcH4THf2DqOuVg0AKBfhBDWwMwXPd/YO6awLACNAOEEtbCfoXqsZAQB5EE5Qkzc7e4dHnDEAGDY6xKI2tnln+2Zx/o0zB6S1s3doR0Tu+37JzeL8CacEMVBzgtp8X6maswYAw0U4QY32d/YOTzhzADBMhBPU6gPDiwFgmAgnqBnDiwFggAgnqBnDiwFggAgnqB3DiwFgYAgnGAKadwBgQJjnBEPghhcPchE+CV6u8+8Vc7zEY+fMMcZsywcWfWxl8bbvbhbnVazInpN0kHcvKVXcJ41t/nazOL8qYJOKQTjBUHwfXpxr9eJUpInqQMLIrgSvH+zsHbp/vbQPYWOMLaguQh/GS+HHW5cCslnQZvo+u39Hsp/b0l9p1e+5f7TH9rZxbG9Dv1u5nT/J+fe9Bu4b14AtkIPmAFoq2JtUNZJt5zVGqJLvcD/2XG6t+T33j+4+sT9nfYQWOb7N8/pomxvbe9e49s5qCi2hz5JVYZJwgiGxw4svansDkbf3qRSejwqiDfbl5418zifbxBVQAPwkNU+a77bf9/pmcT5XflfI8u1GChhVoJHjaufDOdbuW+PYvpLPujbGzEL213NbD2RbXyj/dNLYVvs593IuZ8r7YKaZCXaDtvMaNIOsFO4nAfeIaR4fY8zpzt7hFyn0k5xLRwpqd/2tDFBr2N/dkm1+t7N3aMPKXM5p6bVB84Br+HrVvU2fEwzNWS39T2zhubN3aG/mP6QQ1D50l9nP+GoDmhTMXqRWIGTUU+hIKe3f3csD3svScX0T4bgaqWmxBdvtzt6h97a0saFEpoj/GvBQX2Ui18FCex2UyIYSOT6LSPeIkePszmX0pmD7/NnZO5xK7cc7ZTBZZUs+x27vtNTnm9xz2mvYBq+DVaGLcIKh2ZK3wKJJAXfl3swjs29cf2hm0ZXmsGvlZmxpC2opDLRv6FPfZpXEx9XI9XUqBX+nQmJn73AmoSRGjcUq9nOvYoapnKSAXyQ8PlsS5qN1qJcanisJEzGCVNNEPveqtAko5RrT3nP2peNoXW0Q4QRD9Krk4cXyhnGa4OG17IN8l6+QQmymfLBrg+O1bz+ijMfVNAr+oEJCtvVN/M16ZCJhqpq+WFLzMJeCOAdbqMYIm8cSprrWlLTZkpqxIkKnvHCcKv/sXmpM1jY9Ek4wVPMSq7TloZvqrX4VG9S8OknKg+Kj8vMn0q7eSh6mKzuibuD1AO7huBopJNSFWk/b+qai9aj6OD5PuwQUuba1BXRXp30HFAnnIZ2wT9r6RBFOUIuPkrZ9TeQhVwx5e8390LVeKGpQptIOrHHi+VDX9jX56NOpM7BKORbVKtkSEPra1g8p+ljEJPdIjL43IYJmnO4pmDinfdUSyz2v7khvjPHqSE84QS2+BTQ77Eu7de/kAZKjGn+dVz5vztL+q33Dbq09kQe4prr7zqegkNqxvpss9n3eYOVh3vf1WFRgb5Lg1Oc9YqSGyTvASc1BX8HE6auW+CKgCeuj7ygpwgmqIXM4aJsd3vXdeUwKpS6FwrUMpXU/oaY+DzE5ztrvedfy2dpC+dhz2OS0Qx+T+0jH1Xju30ngttqhr2+NMc8bP+8Dt1ndiTmjLsGteS61HbuXabajhLA3yR3QpSZW20T76WZx7v3iwzwnqM1UxsRrbgw7vHi3xzkCZgGF0r383XzVSBWpiZkqj8NE/sancHKjXjTbvfKzpcZG84b1xWeuFgl9ISME5nJcHzUZyXE9CRghYgv9o5ZJ0LSh4FJC2qqRSt+PjwRvbUFxsqJQXdd8tnISuA2CQp7sh/aYp7hHjNSEbbeNEJNaWe1nO27ukuZ1vi3PtpC5XGzT7UGOmYNlv7X33eXN4lx1/RNOUBUbMBq94n254cXZ3xilNkF9I28aYmf+XrtxJg8KzagG27zTOjTX/n9p/+/02QFNGZo5TbRt7ddyXNfue+O4hvQjOFrX/0SuA01Asw/z1uYFG7CkGeJCUVA+teeleX2te6OVOUa8Q4PPNq8REtx875GQDrZHm2ojGhOsad1LZ9B1NS7zRk2rtu/NyVLYiU7uC+0oquuAe5VmHdRH3njfKje8r+HF2qpqW2uwclKiVW4W5/bzX6fYJvlsbRX58gNd25QxVdRwaQpCN3TRa74UKTzeKz7ftEzbre0ToJmjJqQ/VlHzZCi357otmDTJG/sX5fa0XVshsw67a3BjU5Ddr5vF+VHA9fci5QRtUrulbT5aO8laG8IJqiRzX2irkLN2HJMHhSYQ3YXU7sjDTvPw1WyT9u3whetQGPB2ealcG0lzLk8CHpDaB/GmmgtVjYJ2CQb5fc01UNqoHU2TTsi51L4ktBXyIbUmG+f1WCYvB9pQleQFTJ6bF8pAtnGStTaEE9TsqPDhxdq2Y02twTLNw3LiW4skbdjaTsiuINDWmqhHYyl+Vz0Xg5yLrh1lgwS+AY9hVdu7kH4VEgo0Q+TXXltSg6AdpfI+cM2vY+UzLsl0/AFDhlsnWWtDnxNUq9H/5G+KfdiXfhE5hnRqHhR3XRYikz4iXxTt1AeKAnuqrMZ2Q2s1gem9duXfm8V50CJySleRpk/Xhs4T7du+XNNFDJ3XynQubyPN3qqtnbgPHU0jz7gzRZ+ZFDXDISNzWidZa0PNCarWYXhxjmptzXcELXXf4TO8ty1w7hPNNPJ3mcJiiFgjvLQP6ncVzeg6Ntpnx1nHkYKal5ao6xAFLuYXtFr5MsIJhiCk42a0xb5WCRidEaOXvabmQfUmJA+bVE0cVS5MpxTyFvlBVs49qX114YHRdibu9OIhzViXip8oAmde9p5krQ3NOqheh+HF81QdyAKqV49yTxbnM5fDEnuM/4i8GR9zzM3gQ8Lq8jmIUsMm1+h1QPW4vU4/SFC5k5Bjj9dVKcetRBLmmvfgTzGaPORztaN0Op+nDkO0Q4WsHq6aZK0N4QSDIPM9vJUHuS87suQ4VtJfog0afay3sq2pbZF+Le8jrhZ7n7qPRCNwuId78yGvrd3qatZxqvMt+Xkh+2akxvBCQstV13b+kjUCx4GEjeY9pp0sLpQ24Nz1OPljF9pgop5krQ3hBINhh6HKKBTNjWX/5kLbGdNDsiajPtm+IQHr5KzjO0W9itRAHQfMJJyUDcHSjyTmNj1tft7O3uG9hJWzCH0deid9w47kJ2eQjCX2c6VUMfrM/YA+JxiakOHF0W+sgYvxhnTZMtW7mi3IZEbThSwgV0wwadAODdWaSM2KraH5H9uhsfSViFexAdj2tzHGfJVzWUow0daIVh0OFbzW7dIgnGBQAmfLfFrK6sU1kL4OnzpsqmaK+lb2oSih5Gvs0QqxSbPLQeKA0mSbC7/a41NDp1pb67Wzd3gl4arEmhJtjegY5p4xKV7yCCcYnEKGF1f3tqrUpZPfJFazlzThxJqLJItGQOm6eq6GPT5XPS3h4EWaCzVrBKEsUV/yCCcYqpDhxTGT/2BHUkgn065LtHde4l2CiXZK7SLYgHKzON+V9VNy1aLY4/S3EgNKY6HF6s5li0H2PdvgXaxRh4QTDFJg887QHoypTCMcKzeLbJDAKbWLI5PPbctClrlqUrKuMdVGtqVzWM1E20xT2gKLOZzFmEOK0ToYrMDhxb3INH13Z9L09SbSx9mRUqEjSk469Em4lELmm4ymaI6ouG2O3JJq6lhDp1eS/Z/J8diWTt0HUrCl6HcxaSxJUIJ5h5B52ailbDuXFxGa/8bSwbWLLbm+Os15QjjBoAUOL45hqEMIY77hTkIeYgGrHTu2CWVW8vBaKUxn7jhLWNltzNUSaz6PV3ZYc9/HQpoAtPemW6umj3Op/b5q+kJtcBmwH29kiobgpnLCCcbgSMJCziYAVTixD+nSJ9CSWoTYnRXfSO2Jpo+OdrXnziuk9kXCym2zP5QElgP50R6LpqPMq3Sv2waNXs+l1Maq/ibGva3prB955uDXMj/PVcC9P5dZqIMCJOEEgxe4enFXIW3TxRaeUiCmWohupmyb146EmnUoHIobfiuBZe6ChVzbs4CQUsK+ac/lUQEhU7sMwUGXe1vuva+KP4nVRPy2MXv2cUDn80mXJULoEItRCBxeHEzeFjQdHIsd4ik0/QI+KedBeapcgVdbqHZpiiq+Q6MUIPaY3Cn/tIR902zDXcdagVj7q92GrqG+j2kJvtgmcfcvEghDhgm/CF1dm5oTjMk085TmmjkbXgQsxPeIdPrz4ruYmLyZ+7Y5N9fL0awXNJXmneh9dUKrleWNtfO1IlXymgJG3ZdCagenyrV7ShjmqnkTD742pN9ZrGbdC2Wn8K2Oa3hpOi7HWpX4UU2P9N87cGs7KQTd24QTjEbg6sVdnCkfYrMuNSjyhuIbIrxqdQLmNJm5h5BykcBJ1/1PIFbn313liJ/bwL4g2sI7ehC0hVfC1ZK7NENFa5K0tbCyhpEm7ExDRqZJGNB0Rk3d5HUc0H/PzR6rqrmiWQejItWTb3PsszykNVXtL0Ln/pBRD5pqV98CRNOX4X6pQJ8pJxh7kWIdmJBjKn+jfUNcR1tghA7x1daEpBhRlnJ48lbIBF92faEEo2a0o1C2tIFTau6035N08sfA+aNMyOyxhBOMjrSlxqr+bKN9Az7VttEGzpTa+tCToKBpmvmhOaIxf4eGz/HSNtNMNZNCyfHXNI9sJCFVE9L2A9vptYVGirfsV8owqJ14bq48l3PlNewrtP/Fhc/2N5ZlUI1Ki72Y5iod+u+pZo8lnGCstKsXh9LWHlgf5CG2sRbBPuTkbUQbTHw7FmqC1Z3MdvoD+W+a2qMtjzcsbaG6JevKtB1Pt6pxikn7tIXGB01AkUJYW9Pjcw2E9Nc5levXhsIjOa4na86r9lzaPkAXbYVcY1XjFMHEjZgKWfzS1uDcyrF5tA9yvOy5XAT0kck5y27I8iBGM3ssfU4wSrmGFzc6KmoLvH1ZTfZaCpFbeZBvy89uh2aH1rc+2WbN7KSbPlPbUdO+Yc03dKA7C5i1dWvpeDYLXTdvSMpVcEPe4F1A+R5Al4+HFG4HgbPlfvLs/3AVeJ3tr2lKWb5OLgKOiw0oCzmXy6Fvu+PcLxrTwO+ayPX7TuZMuZbt7rLNy02qSXXov+c9eyzhBKMlHds+RpyOfaWOs9Q+jTy66LJt1IAUeprC/3rTZ8okTifK/ZivG+EiE2Fp55pwYh9PL7amamfvMGSmzS0X7LSTf7XwLciSdrCUayNkjhbT17l0bFgMfPFYFmMfprlny5X7UNPp3fGaPZZmHYxdaPWkVq5mpE3uPfslaN/AfJoftH0o9ltWz422NHuLkKr7dY4LuAasj74TmUkBknqbc73xR+9nJv3XvsT+XKXL5pwkOUmzbchxbe07RDjBqHXofa4i33PQY+Hkpv3eOEJDORzZyIOxte+C/I72ITZb9wCTQjN1oXAZc3p3OfapZtn1ZWu5tNuQtOCTAi71C8LHhCNZjjOuKL3suoDh9yGhe9J2bxFOMHq5hhfL9/QRULzWI5EgoK2R0Py+NgRutXx+ykIhyUNfmr9ex/5cT9eBs42GdOrWSlmrFBLIvDVePHIHlGu5r3tdvLFD6N44eyzhBMg4vFgCwm7GB5n9Ht+Fx7RL13/STLgVOMLhzbqRGQkLhaQPfQkof80cUj+F7lOOWr+Ewf1Ljunf7TG6WZzvZlwi40sJwcSRazqkJnPlqCVTeTgpdtnzFWra1jHL0i/EFtLyIHuf8Pvs57633+MzbXTotNQB2zUN2Oe1zQqNgjNWE8/HHA99aZbazdA0ZYdx//VmcX7cZZ8a4SFZgJfv2I74Hfb6P8pZgEsNzfOAdY583cuCfFn3y9NxwH6vbd6pNZy8/v23l9Usf/751ydXPVblwlOu/ieOtLVvRw4p9/J526vmHVlFmnO0fSs+hayDI3+j7cOwcVIyeWs9kkIhtGCzf/fcFi65HvoSUt12x+x4a6SQsMvdb8eamMuGB1mP6XWqUCXn0n1HaAFvj+W/+17/sdnaRHvcO+7DsuZ93Uvn1zaxZ4+tcSixDSbROqnl8vnXJ/OXvzyYmDNPVu5WbjZfSadldmR48WvPdTw6T/8tN/RUqjePpPZGO+eGm7ujdXjeGtsB4aTLAzLJw1WamA6kmvjYY5HHSzlum+ZU0V6narLdFxLA3PkPmXfF7c+Z72icwO2du+tFatx2Zer83TVT6F9J7bH3NrnvUNwTlzLnyaYF5rI8Q5zGPvhej8vuGueza8DM8ryVIfO+z8+Nnjw8PPz5/5/9/NkevK9dPzShKoNJ08tfHo4LDyjPP//6JOtNjMekNqP50F/2/RwlXGRtMKRwaBaa31IW3rE0rgGzpt+EK/Cr2J8YVpzL2xQrWSfeB3cuV53TP4Ncgc02WdUUTqoPJk7hAYVwAgDoVS19TgYTTIw08dAHBQCA1WoIJ4MKJg4BBQCA1UoPJ4MMJg4BBQCAx0oOJ4MOJg4BBQCAH5UaTkYRTBwCCgAAf1diOBlVMHEIKAAA/L/Swskog4hDQAEAoKxwMupg4hBQAABjV0o4IZg0EFAAAGNWQjghmKxAQAEAjFXf4YRgsgEBBQAwRn2GE4KJBwIKAGBs+gonBBMFAgoAYEz6CCcEkwAEFADAWOQOJwSTDggoAIAxyBlOCCYREFAAAEOXK5wQTCIioAAAhixHOCGYJEBAAQAMVepwQjBJiIACABiilOGEYJIBAQUAMDSpwgnBJCMCCgBgSFKEE4JZLwgoAIChiB1OCCY9IqAAAIYgZjghmBSAgAIAqF2scEIwKQgBBQBQsxjhhGBSIAIKAKBWXcMJwaRgBBQAQI26hBOCSQUIKACA2oSGE4JJRQgoAICahIQTgkmFCCgAgFpowwnBpGIEFABADTThhGAyAAQUAEDpfMMJwWRACCgAgJL5hBOCyQARUAAApWoLJwSTASOgAABKtCmcEExGgIACACjNunBCMBkRAgoAoCTL4eQbwWScGgHl29iPBQCgX08eHh44BQAAoBgxViUGAACIhnACAACKQjgBAADlMMb8H2XRA00AnbMEAAAAAElFTkSuQmCC", "altText": "NexaStack Logo", "backgroundColor": "#FFFFFF"}
func main() {
	// Initialize logger
	config.InitLogger()

	// setup for reading flags for deciding whether to do configuration with toml or env variables
	conf := flag.String("conf", "environment", "set configuration from toml file or environment variables")
	file := flag.String("file", "", "set path of toml file")
	flag.Parse()

	folderPath := "/app/data/.azure" // change path as needed

	err := os.MkdirAll(folderPath, 0755)
	if err != nil {
		config.Log.Info("Failed to create folder: %v\n", err)
	}

	PrintEnv()

	config.Log.Info("Folder created successfully:", folderPath)

	if *conf == "environment" {
		config.Log.Info("environment")
		config.ConfigurationWithEnv()
		// Load .env file
		err := godotenv.Load()
		if err != nil {
			config.Log.Error("Error loading .env file")
		}
	} else if *conf == "toml" {
		config.Log.Info("toml")
		if *file == "" {
			config.Log.Error("Please pass toml file path")
			os.Exit(1)
		} else {
			err := config.ConfigurationWithToml(*file)
			if err != nil {
				config.Log.Error("Error in parsing toml file")
				config.Log.Error(err)
				os.Exit(1)
			}
		}
	} else {
		config.Log.Error("Please pass valid arguments, conf can be set as toml or environment")
		os.Exit(1)
	}

	// checking environment
	if config.Conf.Service.Environment != "production" {
		// removing info file if any.
		_ = os.Remove("data/info.txt")

		// creating and opening info.txt file for writting logs
		logFile, err := os.OpenFile("data/info.txt", os.O_CREATE|os.O_RDWR|os.O_APPEND, 0644)
		if err != nil {
			config.Log.Fatal(err)
		}

		defer logFile.Close()

		// changing default writer of gin to file and std output
		gin.DefaultWriter = io.MultiWriter(logFile, os.Stdout)

		// setting output for logs this will writes all logs to file
		config.SetLoggerOutput(gin.DefaultWriter)
		// writing log to check all in working
		config.Log.Info("Logging to a file in Go!")
	}

	//create database
	database.CreateDatabase()

	//check redis database
	err = redisdb.Initialise()
	if err != nil {
		config.Log.Error("please check the redis database credentials")
		//os.Exit(1)
	}

	//database config
	dbConfig := config.DBConfig()
	//number of ideal connections
	var ideal int
	idealStr := config.Conf.Database.Ideal
	if idealStr == "" {
		ideal = 50
	} else {
		ideal, _ = strconv.Atoi(idealStr)
	}
	// connecting db using connection string
	config.Log.Info("====db string=====", dbConfig)
	db, err := gorm.Open("postgres", dbConfig)
	if err != nil {
		config.Log.Error(err)
		return
	}
	// close db instance whenever whole work completed
	defer db.Close()
	db.DB().SetMaxIdleConns(ideal)
	db.DB().SetConnMaxLifetime(1 * time.Hour)
	config.DB = db
	config.DefaultDb = db
	//create auth-team database tables
	go database.CreateDatabaseTables()

	//start scheduler
	go scheduler.Start()

	// initialize gin router
	router := gin.Default()

	// profile.Start()
	pprof.Register(router, "pprof")

	// Serve static files from the images directory
	router.Static("/images", "./images")

	//allowing CORS
	corsConfig := cors.DefaultConfig()
	corsConfig.AllowAllOrigins = true
	corsConfig.AddAllowHeaders("Authorization")
	corsConfig.AddAllowMethods("DELETE")
	router.Use(cors.New(corsConfig))

	// index handler to view all registered routes
	router.GET("/", func(c *gin.Context) {
		type finalPath struct {
			Method string
			Path   string
		}

		data := router.Routes()
		finalPaths := make([]finalPath, 0)

		for i := 0; i < len(data); i++ {
			finalPaths = append(finalPaths, finalPath{
				Path:   data[i].Path,
				Method: data[i].Method,
			})
		}
		c.JSON(200, gin.H{
			"routes": finalPaths,
		})
	})

	// service specific routes
	routes.V1Routes(router)

	// run the service
	router.Run(":" + config.Conf.Service.Port)
}

func PrintEnv() {
	config.Log.Info("--------------------------")
	config.Log.Info("ONPREM_CLUSTER ", os.Getenv("ONPREM_CLUSTER"))
	config.Log.Info("GRAFANA_AZURE_CLUSTER ", os.Getenv("GRAFANA_AZURE_CLUSTER"))
	config.Log.Info("GRAFANA_NEXASTACK_CLUSTER ", os.Getenv("GRAFANA_NEXASTACK_CLUSTER"))
	config.Log.Info("NEXASTACK_CLUSTER_LOGS ", os.Getenv("NEXASTACK_CLUSTER_LOGS"))
	config.Log.Info("GRAFANA_AZURE_CLUSTER ", os.Getenv("GRAFANA_AZURE_CLUSTER"))
	config.Log.Info("AZURE_CLUSTER_LOGS ", os.Getenv("AZURE_CLUSTER_LOGS"))
	config.Log.Info("GOVERNANCE ", os.Getenv("GOVERNANCE"))
}
